import streamlit as st
from market_forensics import workstation as ws, v3

ticker=st.session_state.get("ticker") or ""
if not ticker: st.warning("Add or promote a company first.")
else:
    try: v3.render_monitor(ticker,ws.load_state(ticker))
    except Exception as e: st.error(f"Monitor view failed: {e}")
v3.render_footer()
