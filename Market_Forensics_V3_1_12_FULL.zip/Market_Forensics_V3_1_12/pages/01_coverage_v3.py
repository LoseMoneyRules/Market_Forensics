from market_forensics import v3
v3.render_coverage()
v3.render_footer()
