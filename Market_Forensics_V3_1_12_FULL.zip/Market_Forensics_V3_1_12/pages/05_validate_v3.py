from market_forensics import v3
v3.render_validate()
v3.render_footer()
