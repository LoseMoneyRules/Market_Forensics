from market_forensics import workstation as ws
ws.run_company_page(ws.render_management_forecast, "Management & 5Y Operating Forecast")
