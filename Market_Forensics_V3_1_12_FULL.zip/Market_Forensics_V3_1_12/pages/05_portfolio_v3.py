import streamlit as st
from market_forensics import workstation as ws, v3

ticker=st.session_state.get("ticker") or ""

@st.fragment(run_every="60s")
def _render_portfolio_live():
    state=ws.load_state(ticker,live_price=True) if ticker else {}
    v3.render_portfolio(ticker,state)

_render_portfolio_live()
v3.render_footer()
