import streamlit as st
from market_forensics import workstation as ws, v3

ticker=st.session_state.get("ticker") or ""
state=ws.load_state(ticker) if ticker else {}
v3.render_settings(ticker,state)
v3.render_footer()
