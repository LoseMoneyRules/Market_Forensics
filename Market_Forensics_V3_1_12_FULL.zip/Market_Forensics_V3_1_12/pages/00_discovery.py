from market_forensics import v3
v3.render_discovery()
v3.render_footer()
