import streamlit as st
from market_forensics import workstation as ws, v3

ticker=st.session_state.get("ticker") or ""

@st.fragment(run_every="60s")
def _render_decide_live():
    if not ticker:
        st.warning("Add a Portfolio position or select a company from Decision Queue first.")
    else:
        try:
            v3.render_decide(ticker,ws.load_state(ticker,live_price=True))
        except Exception as e:
            st.error(f"Decision view failed: {e}")

_render_decide_live()
v3.render_footer()
