from market_forensics import workstation as ws
ws.run_company_page(ws.render_fundamentals, "Business & Fundamentals")
