from market_forensics import workstation as ws
ws.run_company_page(ws.render_financial_flows, "Financial Flows")
