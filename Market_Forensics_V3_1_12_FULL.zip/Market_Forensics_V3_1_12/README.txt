MARKET FORENSICS V3.1.12
========================

V3.1.12 ADAPTIVE FINANCIAL FLOWS RELEASE
- Income Statement Sankey no longer requires a universal Revenue → Gross Profit → Operating Income → Pretax sequence.
- Gross Profit, Operating Income, Pretax and Tax are optional layers and are shown only when they reconcile.
- UPS-style Revenue → Operating Expenses → Operating Income presentations render without a Gross Profit blocker.
- Sparse statements use explicit aggregate/reconciliation buckets instead of fabricated line items.
- Loss years are supported with a signed Net Loss table row and positive-width deficit flow.
- Cash Flow requires CFO as the essential anchor; NI/Capex/FCF are optional layers. Negative CFO/FCF are represented with explicit deficit/funding nodes.
- Compact K/M/B/T formatting from V3.1.11 is retained.
- Valuation, Decide, Validate, Management, SEC/share-basis and Portfolio engines are unchanged.


A local buy-side research workstation built to guide attention from market discovery to evidence-backed capital decisions.

V3 changes the workflow from a collection of analytical pages into a guided investment process:

DISCOVER -> DECISION QUEUE -> DECIDE -> RESEARCH -> MONITOR -> VALIDATE -> PORTFOLIO

The normal interface shows conclusions first. Technical detail remains available in expandable sections and hidden Advanced pages for audit/review.

V3.1.8 CORRECTNESS / RECOVERY RELEASE
-----------------------------------
- Portfolio is a real holdings ledger, independent of research. Add or edit LONG/SHORT positions, shares and average cost before any thesis exists.
- Decision Queue combines researched names and real positions. It is the one list to review when deciding what needs attention.
- Decide begins with WHAT SHOULD I DO NOW? and a six-step path: Data -> Value -> Thesis -> Timing -> Risk -> Action.
- Actions are position-aware: BUY / SHORT / WAIT when outside; ADD / HOLD / REDUCE / SELL when long; ADD SHORT / HOLD SHORT / COVER when short.
- Bear / Base / Bull are current-valuation outputs and no longer depend on certification of the full historical OHLC series. Current price + a verified current-basis share denominator are sufficient.
- Current shares are recovered from the latest SEC 10-Q/10-K Inline XBRL cover page when Companyfacts is missing/stale/ambiguous (including valid multi-class issuers). Companyfacts remains the historical/PIT archive.
- Current valuation then verifies only the required split/reverse-split interval using Alpaca Corporate Actions when configured, with Yahoo split events as fallback. If exact instant shares remain unavailable/stale, verified diluted weighted-average shares can be used as a clearly labelled MEDIUM-confidence fallback.
- A years-old outstanding-share fact is never made “current” just because its split history is known; this avoids ignoring intervening buybacks/dilution.
- DATA REVIEW is reserved for an essential missing input and names the exact blocker (for example an unverified split after the selected SEC share fact). Missing net debt disables EV/Sales only; it does not suppress valid P/E/FCF-yield cases.
- Decide exposes the share fact date/filed date, corporate actions since the fact, normalized current shares, current price/date, share-basis status and confidence directly beside the price cases.
- Advanced pages are grouped under their parent area and expose a Back to Parent control.
- Discovery automatically invalidates incompatible legacy screener cache instead of silently returning an empty market screen.
- Management MET/MISS uses conservative parser v5 and scores only promises whose metric, period, target year and accounting basis are directly comparable.
- Validate remains deliberately stricter than current valuation: point-in-time SEC facts, raw historical closes, exact market dates and split/corporate-action normalization. It displays Anchor raw close, +1Y raw close, Comparable +1Y on anchor basis and all relevant basis factors.

WHAT V3 ADDS
------------
1. Market Discovery engine
   - Active US equity universe from Alpaca.
   - Price/liquidity prefilter.
   - SEC fundamentals cache.
   - Peer-relative quality, trend, valuation and forensic screening.
   - Automatic screening Base Fair Value + FV Gap as an absolute-value cross-check.
   - Separate Long Dislocation and Short Dislocation scores.
   - Main queue requires relative + absolute directional alignment and suppresses NO EDGE / fair-value names.

2. Discovery lenses
   - QUALITY AT DISCOUNT
   - FUNDAMENTAL INFLECTION
   - LONG DISLOCATION
   - POTENTIAL SHORT
   - SHORT DISLOCATION
   - VALUE TRAP
   - FORENSIC DIVERGENCE
   - DATA REVIEW / context kept outside the primary action queues.

3. External triangulation
   - Automatic peer set using SIC, with market-cap similarity as a tie-breaker.
   - Manual PEER / CUSTOMER / SUPPLIER / DISTRIBUTOR / INDUSTRY links.
   - Company vs peer median operating/working-capital/valuation comparison.
   - Signals distinguish company-specific from industry-wide evidence where data supports it.

4. Variant perception + path
   - Market believes
   - We believe
   - Evidence for the disagreement
   - What resolves it
   - Horizon
   - Path: SUPPORTIVE / UNCLEAR / HOSTILE

5. Consolidated Decision page
   - BUSINESS
   - VALUE
   - EXPECTATIONS (growth + margin + exit P/E)
   - MODEL CONFIDENCE (live valuation confidence + historical Reliability)
   - VARIANT
   - PATH
   - RISK
   - DECISION
   - ASYMMETRY & POSITION MATH
   - One-click Bear/Base/Bull table with every valuation input and method output.
   followed by Why now / Why not yet / What changes the decision / What kills the thesis.

6. Point-in-time historical validation
   - New Validate page replays the current valuation engine at historical year-end cutoffs.
   - SEC Companyfacts is filtered by original filing date so later filings/restatements cannot leak backward.
   - Current saved assumptions and manual thesis text are excluded from historical replay.
   - Scores historical Bear/Base/Bull against the realized +1Y market price.
   - Scores the operating thesis by comparing historical growth, net-margin and FCF-margin bands with the +1Y realized fundamentals.
   - Reports range-hit rate, direction-hit rate, median Base error, thesis-driver hit rate and a no-change price baseline.
   - Requests up to ~40 years of prices and reports the earliest issuer-specific modelable anchor; older XBRL can fall back to basic weighted-average shares.

7. Logic consolidation / progressive disclosure
   - Decide is the single decision cockpit; Research is the Evidence Room.
   - Variant perception has one canonical home in Decide.
   - Thesis invalidation means LOCKED numerical Monitoring KPIs; the Risk-page price is only a sizing reference.
   - Settings is the single configuration surface; Advanced Sources & Audit is provenance/audit only.
   - Eight visible work areas only; Advanced analytical pages remain hidden from normal navigation.



V3.1.8 RECOVERY ADDITIONS
-------------------------
- Current SEC share parsing now supports legitimate multi-class cover-page facts instead of falling
  back to obsolete single-class history.
- Decide includes Share Basis Recovery for the rare case where automatic corporate-action proof
  remains unresolved. Manual recovery is explicit, audit logged, MEDIUM confidence, and current-only.
- Fund/ETF structures whose SEC metadata identifies them as non-operating Companyfacts candidates
  can be cached as SEC FUNDAMENTALS N/A after a confirmed 404; a generic operating-company 404
  remains a visible error.

V3.1.8 INSTITUTIONAL DESIGN
---------------------------
- Strong bordered containers and restrained navy/slate visual hierarchy.
- No purple in the application or report palette.
- Market prices and scenario values are neutral; green/red/amber are reserved for positive/negative/mixed states.
- Settings -> Branding can save or remove a local PNG/JPG logo. If present, it is used in the sidebar and generated reports.
- Application and report footer: Lose Money Rules.
- Company research reports: four readable pages in both Word and PDF.
- Discovery PDF: two-page landscape screening brief for readable candidate tables.

DATA / SECURITY
---------------
Alpaca credentials stay in:
%LOCALAPPDATA%\MarketForensics\alpaca_secrets.json

SEC requires a truthful User-Agent with contact email. Configure it in Settings before Discovery.

The SQLite database remains in:
%LOCALAPPDATA%\MarketForensics\market_forensics.sqlite

RUN
---
Extract to a fresh folder and double-click RUN_DASHBOARD.cmd.
The launcher checks/repairs dependencies, runs SELF_TEST.py, and starts Streamlit only if the self-test passes.

See START_HERE.txt and USER_GUIDE.md.

V3.1.8 DATA RESILIENCE
----------------------
Daily bars: Alpaca -> optional IBKR Gateway -> optional Tiingo -> optional Alpha Vantage -> SQLite cache.
Full tape: Alpaca -> optional Massive -> LOW DATA.
Discovery universe: Alpaca -> SEC ticker/exchange mapping.
Independent price checks are stored with provider/timestamp/quality/deviation.
Optional backup API keys live only in %LOCALAPPDATA%\MarketForensics\market_data_secrets.json.
Word and PDF research reports are prepared separately. Discovery can export a printable PDF brief.


V3.1.8 RELIABILITY SCORE
------------------------
Validate now produces a company-specific 0-100 Reliability Score with separate Valuation, Thesis, Direction and Bias-Control components. The score is sample-adjusted and the latest result is persisted per ticker and shown on Decision. Historical tests are split-safe when a verifiable raw/split or explicit split-event basis is available. The long-history fallback is used for Validate only, never for live pricing or Discovery.
