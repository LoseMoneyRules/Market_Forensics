from __future__ import annotations

import math
import statistics


def clamp(x,a,b):
    try:return max(a,min(b,float(x)))
    except Exception:return a


def _median(vals, default=None):
    xs=[float(x) for x in vals if x is not None and math.isfinite(float(x))]
    return statistics.median(xs) if xs else default


def _annual_history(fund_rows):
    return sorted([r for r in fund_rows if r.get("period_type")=="FY" and r.get("revenue")], key=lambda r:r.get("fiscal_year") or 0)


def auto_assumptions(metrics: dict, fund_rows: list[dict], valuation_assumptions: dict | None=None, years=5) -> dict:
    hist=_annual_history(fund_rows)
    growths=[]; gm=[]; om=[]; nm=[]; fm=[]
    for a,b in zip(hist,hist[1:]):
        try: gap=max(1,int(b.get("fiscal_year"))-int(a.get("fiscal_year")))
        except Exception: gap=1
        if a.get("revenue") and b.get("revenue") and float(a["revenue"])>0 and float(b["revenue"])>0:
            growths.append((float(b["revenue"])/float(a["revenue"]))**(1/gap)-1)
    for r in hist[-5:]:
        rev=r.get("revenue")
        if not rev: continue
        if r.get("gross_profit") is not None: gm.append(r["gross_profit"]/rev)
        if r.get("operating_income") is not None: om.append(r["operating_income"]/rev)
        if r.get("net_income") is not None: nm.append(r["net_income"]/rev)
        if r.get("fcf") is not None: fm.append(r["fcf"]/rev)
    base_val=(valuation_assumptions or {}).get("base",{})
    long_g=clamp(_median(growths[-5:], metrics.get("cagr3") or 0.03),-0.10,0.20)
    start_g=clamp(metrics.get("recent_growth") if metrics.get("recent_growth") is not None else long_g,-0.20,0.30)
    target_g=clamp((long_g+0.03)/2,-0.05,0.10)
    def center(metric_key, hist_vals, fallback):
        current=metrics.get(metric_key)
        med=_median(hist_vals,current if current is not None else fallback)
        if current is None:return clamp(med,-0.5,0.8)
        return clamp(0.55*float(current)+0.45*float(med),-0.5,0.8)
    base={
        "growth_start":start_g,
        "growth_terminal":target_g,
        "gross_margin_target":center("gross_margin",gm,0.35),
        "operating_margin_target":center("operating_margin",om,0.12),
        "net_margin_target":center("net_margin",nm,0.08),
        "fcf_margin_target":center("fcf_margin",fm,0.08),
        "share_change":clamp(metrics.get("share_change") if metrics.get("share_change_verified") else 0,-0.05,0.05),
        "exit_pe":clamp(base_val.get("pe",18),5,60),
        "required_return":0.10,
    }
    bear={**base,"growth_start":base["growth_start"]-0.05,"growth_terminal":base["growth_terminal"]-0.03,
          "gross_margin_target":base["gross_margin_target"]-0.025,"operating_margin_target":base["operating_margin_target"]-0.03,
          "net_margin_target":base["net_margin_target"]-0.025,"fcf_margin_target":base["fcf_margin_target"]-0.03,"exit_pe":max(5,base["exit_pe"]*0.75)}
    bull={**base,"growth_start":base["growth_start"]+0.05,"growth_terminal":base["growth_terminal"]+0.03,
          "gross_margin_target":base["gross_margin_target"]+0.025,"operating_margin_target":base["operating_margin_target"]+0.03,
          "net_margin_target":base["net_margin_target"]+0.025,"fcf_margin_target":base["fcf_margin_target"]+0.03,"exit_pe":min(70,base["exit_pe"]*1.20)}
    return {"model_version":"2.7","years":int(years),"bear":bear,"base":base,"bull":bull,"reviewed_at":None}


def normalize_assumptions(saved: dict | None, auto: dict) -> dict:
    if not saved or str(saved.get("model_version"))!="2.7": return auto
    out={"model_version":"2.7","years":int(saved.get("years") or auto.get("years") or 5),"reviewed_at":saved.get("reviewed_at")}
    for s in ("bear","base","bull"):
        out[s]={**auto[s],**(saved.get(s) or {})}
    return out


def build_forecast(metrics: dict, assumptions: dict, scenario="base") -> list[dict]:
    a=assumptions[scenario]
    years=int(assumptions.get("years") or 5)
    revenue=float(metrics.get("revenue") or 0)
    shares=float((metrics.get("valuation_shares") or metrics.get("diluted_shares")) or 0)
    if revenue<=0 or shares<=0:return []
    gm0=float(metrics.get("gross_margin") if metrics.get("gross_margin") is not None else a["gross_margin_target"])
    om0=float(metrics.get("operating_margin") if metrics.get("operating_margin") is not None else a["operating_margin_target"])
    nm0=float(metrics.get("net_margin") if metrics.get("net_margin") is not None else a["net_margin_target"])
    fm0=float(metrics.get("fcf_margin") if metrics.get("fcf_margin") is not None else a["fcf_margin_target"])
    rows=[]
    for y in range(1,years+1):
        t=y/years
        growth=a["growth_start"]+(a["growth_terminal"]-a["growth_start"])*t
        revenue*=1+growth
        shares*=1+a.get("share_change",0)
        gm=gm0+(a["gross_margin_target"]-gm0)*t
        om=om0+(a["operating_margin_target"]-om0)*t
        nm=nm0+(a["net_margin_target"]-nm0)*t
        fm=fm0+(a["fcf_margin_target"]-fm0)*t
        ni=revenue*nm; fcf=revenue*fm; eps=ni/shares if shares else None
        rows.append({"year":y,"growth":growth,"revenue":revenue,"gross_margin":gm,"operating_margin":om,"net_margin":nm,"fcf_margin":fm,"net_income":ni,"fcf":fcf,"shares":shares,"eps":eps})
    return rows


def scenario_summary(metrics: dict, assumptions: dict, current_price: float | None):
    out={}
    for s in ("bear","base","bull"):
        rows=build_forecast(metrics,assumptions,s)
        if not rows:
            out[s]={"rows":[],"terminal_price":None,"present_value":None,"expected_cagr":None}; continue
        last=rows[-1]; pe=float(assumptions[s].get("exit_pe") or 0); rr=float(assumptions[s].get("required_return") or 0.10)
        terminal=(last.get("eps") or 0)*pe
        pv=terminal/((1+rr)**len(rows)) if terminal is not None else None
        cagr=((terminal/current_price)**(1/len(rows))-1) if current_price and terminal and current_price>0 and terminal>0 else None
        out[s]={"rows":rows,"terminal_price":terminal,"present_value":pv,"expected_cagr":cagr}
    return out


def _terminal_value_for_growth(metrics,a,growth,years=5):
    revenue=float(metrics.get("revenue") or 0); shares=float((metrics.get("valuation_shares") or metrics.get("diluted_shares")) or 0)
    if revenue<=0 or shares<=0:return None
    nm=float(a.get("net_margin_target") or 0); pe=float(a.get("exit_pe") or 0)
    revenue*=((1+growth)**years); shares*=((1+float(a.get("share_change") or 0))**years)
    eps=(revenue*nm)/shares if shares else None
    return eps*pe if eps is not None else None


def implied_growth_for_required_return(current_price, metrics, base_assumptions, years=5):
    if not current_price or current_price<=0:return None
    rr=float(base_assumptions.get("required_return") or 0.10)
    target_terminal=current_price*((1+rr)**years)
    lo,hi=-0.30,0.60
    flo=_terminal_value_for_growth(metrics,base_assumptions,lo,years); fhi=_terminal_value_for_growth(metrics,base_assumptions,hi,years)
    if flo is None or fhi is None or target_terminal<flo or target_terminal>fhi:return None
    for _ in range(80):
        mid=(lo+hi)/2; fm=_terminal_value_for_growth(metrics,base_assumptions,mid,years)
        if fm is None:return None
        if fm<target_terminal:lo=mid
        else:hi=mid
    return (lo+hi)/2


def implied_net_margin_for_required_return(current_price, metrics, base_assumptions, growth=None, years=5):
    if not current_price or current_price<=0:return None
    revenue=float(metrics.get("revenue") or 0); shares=float((metrics.get("valuation_shares") or metrics.get("diluted_shares")) or 0)
    if revenue<=0 or shares<=0:return None
    rr=float(base_assumptions.get("required_return") or 0.10); pe=float(base_assumptions.get("exit_pe") or 0)
    if pe<=0:return None
    g=float(growth if growth is not None else base_assumptions.get("growth_terminal") or 0.03)
    rev5=revenue*((1+g)**years); sh5=shares*((1+float(base_assumptions.get("share_change") or 0))**years)
    target_terminal=current_price*((1+rr)**years)
    required_eps=target_terminal/pe
    return (required_eps*sh5/rev5) if rev5 else None


def implied_exit_pe_for_required_return(current_price, forecast_rows, required_return=0.10):
    if not current_price or not forecast_rows:return None
    last=forecast_rows[-1]; eps=last.get("eps")
    if not eps or eps<=0:return None
    terminal_required=current_price*((1+required_return)**len(forecast_rows))
    return terminal_required/eps


def price_reconciliation(current_price, metrics, assumptions, scenario_pack=None):
    pack=scenario_pack or scenario_summary(metrics,assumptions,current_price)
    base_rows=pack.get("base",{}).get("rows") or []
    base=assumptions.get("base",{})
    years=len(base_rows) or 5
    implied_g=implied_growth_for_required_return(current_price,metrics,base,years)
    # Solve required terminal net margin on the SAME Base revenue/share path so only profitability changes.
    implied_nm=None
    if current_price and current_price>0 and base_rows:
        last=base_rows[-1]
        rev5=last.get("revenue"); sh5=last.get("shares"); exit_pe=float(base.get("exit_pe") or 0); rr=float(base.get("required_return") or .10)
        if rev5 and sh5 and exit_pe>0:
            target_terminal=current_price*((1+rr)**years)
            required_eps=target_terminal/exit_pe
            implied_nm=(required_eps*sh5/rev5) if rev5 else None
    implied_pe=implied_exit_pe_for_required_return(current_price,base_rows,float(base.get("required_return") or .10))
    forecast_g=None
    if base_rows:
        r0=float(metrics.get("revenue") or 0); rn=base_rows[-1].get("revenue")
        if r0>0 and rn and rn>0: forecast_g=(rn/r0)**(1/len(base_rows))-1
    return {
        "current_price":current_price,"base_present_value":pack.get("base",{}).get("present_value"),
        "base_terminal_price":pack.get("base",{}).get("terminal_price"),"base_expected_cagr":pack.get("base",{}).get("expected_cagr"),
        "forecast_revenue_cagr":forecast_g,"market_implied_revenue_cagr":implied_g,
        "forecast_terminal_net_margin":base_rows[-1].get("net_margin") if base_rows else None,
        "market_implied_net_margin":implied_nm,"forecast_exit_pe":base.get("exit_pe"),"market_implied_exit_pe":implied_pe,
        "required_return":base.get("required_return",.10),
    }
