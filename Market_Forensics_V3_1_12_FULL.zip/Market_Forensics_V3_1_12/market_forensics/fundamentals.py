from __future__ import annotations

import json
from datetime import date, datetime, timezone
import math
from . import sec

TAGS = {
 "revenue":[("us-gaap","RevenueFromContractWithCustomerExcludingAssessedTax"),
            ("us-gaap","SalesRevenueNet"),("us-gaap","Revenues")],
 "gross_profit":[("us-gaap","GrossProfit")],
 "operating_income":[("us-gaap","OperatingIncomeLoss")],
 "flow_total_costs":[("us-gaap","CostsAndExpenses")],
 "flow_operating_expenses":[("us-gaap","OperatingExpenses"),("us-gaap","OperatingCostsAndExpenses")],
 "flow_sga":[("us-gaap","SellingGeneralAndAdministrativeExpense")],
 "flow_rd":[("us-gaap","ResearchAndDevelopmentExpense"),("us-gaap","ResearchAndDevelopmentExpenseExcludingAcquiredInProcessCost")],
 "net_income":[("us-gaap","NetIncomeLoss"),("us-gaap","ProfitLoss")],
 "cfo":[("us-gaap","NetCashProvidedByUsedInOperatingActivities")],
 "capex":[("us-gaap","PaymentsToAcquirePropertyPlantAndEquipment"),
          ("us-gaap","PaymentsForAdditionsToPropertyPlantAndEquipment")],
 "sbc":[("us-gaap","ShareBasedCompensation")],
 "buybacks":[("us-gaap","PaymentsForRepurchaseOfCommonStock")],
 "dividends":[("us-gaap","PaymentsOfDividendsCommonStock"),
              ("us-gaap","PaymentsOfDividends")],
 # EPS denominator. Basic is a per-period fallback only; it is NOT mixed into the candidate
 # list because SEC.fact_units() intentionally selects one tag for the whole history.
 "diluted_shares":[("us-gaap","WeightedAverageNumberOfDilutedSharesOutstanding")],
 "basic_shares":[("us-gaap","WeightedAverageNumberOfSharesOutstandingBasic")],
 "diluted_eps":[("us-gaap","EarningsPerShareDiluted")],
 # Point-in-time outstanding shares are the correct basis for current market cap / EV.
 "shares_outstanding":[("dei","EntityCommonStockSharesOutstanding"),
                       ("us-gaap","CommonStockSharesOutstanding")],
 "cash":[("us-gaap","CashAndCashEquivalentsAtCarryingValue"),
         ("us-gaap","CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents")],
 "receivables":[("us-gaap","AccountsReceivableNetCurrent")],
 "inventory":[("us-gaap","InventoryNet"),("us-gaap","InventoryFinishedGoodsNetOfAllowancesCustomerAdvancesAndProgressBillings")],
 "payables":[("us-gaap","AccountsPayableCurrent")],
 "assets":[("us-gaap","Assets")],
 "liabilities":[("us-gaap","Liabilities")],
 "equity":[("us-gaap","StockholdersEquity"),("us-gaap","StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest")],
 # Debt is decomposed so current maturities are not silently replaced by short-term borrowings.
 "short_borrowings":[("us-gaap","ShortTermBorrowings"),("us-gaap","CommercialPaper")],
 "long_debt_current":[("us-gaap","LongTermDebtAndFinanceLeaseObligationsCurrent"),("us-gaap","LongTermDebtCurrent"),("us-gaap","DebtCurrent")],
 "long_debt_noncurrent":[("us-gaap","LongTermDebtAndFinanceLeaseObligationsNoncurrent"),("us-gaap","LongTermDebtNoncurrent")],
 "long_debt_total":[("us-gaap","LongTermDebtAndFinanceLeaseObligations"),("us-gaap","LongTermDebt")],
 "debt_combined":[("us-gaap","DebtLongtermAndShorttermCombinedAmount")],
 "pretax":[("us-gaap","IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest"),
           ("us-gaap","IncomeLossFromContinuingOperationsBeforeIncomeTaxesMinorityInterestAndIncomeLossFromEquityMethodInvestments")],
 "tax":[("us-gaap","IncomeTaxExpenseBenefit")],
}


def _annual_map(facts, metric, years=10):
    return {x["fy"]:x for x in sec.annual_series(facts, TAGS[metric], years)}


def _annual_share_map(facts, years=10):
    """Annual EPS denominator with a *per-period* diluted->basic fallback."""
    diluted={x["fy"]:dict(x) for x in sec.annual_series(facts,TAGS["diluted_shares"],years)}
    basic={x["fy"]:dict(x) for x in sec.annual_series(facts,TAGS["basic_shares"],years)}
    out={}
    for fy in sorted(set(diluted)|set(basic)):
        rec=dict(diluted.get(fy) or basic.get(fy) or {})
        rec["share_kind"]="DILUTED" if fy in diluted else "BASIC_FALLBACK"
        out[fy]=rec
    return out


def _latest_share_duration(facts):
    rec=sec.latest_duration_fact(facts,TAGS["diluted_shares"])
    if rec:
        return rec,"DILUTED"
    rec=sec.latest_duration_fact(facts,TAGS["basic_shares"])
    return (rec,"BASIC_FALLBACK") if rec else (None,"MISSING")


def _first(rec):
    if not rec:
        return None
    return rec.get("first_val") if rec.get("first_val") is not None else rec.get("val")


def _first_as_of(rec, cutoff):
    """First reported value only if it was actually public by the row's PIT filing date."""
    if not rec or not cutoff:
        return None
    filed=str(rec.get("first_filed") or rec.get("filed") or "")[:10]
    cut=str(cutoff)[:10]
    if not filed or filed>cut:
        return None
    return _first(rec)


def _debt_from_records(short_rec=None, current_rec=None, noncurrent_rec=None, total_rec=None, combined_rec=None, *, pit_cutoff=None):
    """Build debt once, without double-counting a comprehensive current-debt concept.

    `DebtCurrent` can already include short-term borrowings.  Specific current-long-debt tags do
    not.  The helper inspects the selected tag and adds short borrowings only when economically
    distinct.  `pit_cutoff` switches values to their first-public version as of that filing.
    """
    def val(rec):
        if not rec:
            return None
        return _first_as_of(rec,pit_cutoff) if pit_cutoff else rec.get("val")
    short=val(short_rec); cur=val(current_rec); noncur=val(noncurrent_rec); total=val(total_rec); combined=val(combined_rec)
    cur_tag=str((current_rec or {}).get("tag") or "")
    if noncur is not None or cur is not None:
        current_component=(cur or 0)
        # us-gaap:DebtCurrent is comprehensive current debt; do not add ShortTermBorrowings again.
        short_component=0 if cur_tag=="DebtCurrent" else (short or 0)
        return (noncur or 0)+current_component+short_component
    if total is not None:
        return (total or 0)+(short or 0)
    return combined


def build_fundamentals(ticker: str, companyfacts: dict, current_share_fact: dict | None = None):
    # Duration facts. Shares are merged separately to support a genuine per-period fallback.
    flow_metrics=("revenue","gross_profit","operating_income","net_income","cfo","capex","sbc","buybacks","dividends")
    annual_maps={m:_annual_map(companyfacts,m,10) for m in flow_metrics}
    # Financial Flows uses a stricter annual resolver so dimensioned note-table facts cannot
    # masquerade as consolidated statement lines. These fields are visualization-only and do
    # not replace the core operating-income series used by valuation/Validate.
    flow_maps={
        "pretax":{x["fy"]:x for x in sec.annual_series_unambiguous(companyfacts,TAGS["pretax"],10)},
        "tax":{x["fy"]:x for x in sec.annual_series_unambiguous(companyfacts,TAGS["tax"],10)},
        "direct_oi":{x["fy"]:x for x in sec.annual_series_unambiguous(companyfacts,TAGS["operating_income"],10)},
        "total_costs":{x["fy"]:x for x in sec.annual_series_unambiguous(companyfacts,TAGS["flow_total_costs"],10)},
        "operating_expenses":{x["fy"]:x for x in sec.annual_series_unambiguous(companyfacts,TAGS["flow_operating_expenses"],10)},
        "sga":{x["fy"]:x for x in sec.annual_series_unambiguous(companyfacts,TAGS["flow_sga"],10)},
        "rd":{x["fy"]:x for x in sec.annual_series_unambiguous(companyfacts,TAGS["flow_rd"],10)},
    }
    # Reported diluted EPS is stored separately from additive flow metrics. It is a ratio and
    # must never be reconstructed by annual-minus-quarter arithmetic.
    annual_eps=_annual_map(companyfacts,"diluted_eps",10)
    share_map=_annual_share_map(companyfacts,10)
    annual_maps["diluted_shares"]=share_map

    instant_metrics=("cash","receivables","inventory","payables","assets","liabilities","equity")
    instant_maps={m:{x["fy"]:x for x in sec.annual_instant_series(companyfacts,TAGS[m],10)} for m in instant_metrics}

    debt_short={x["fy"]:x for x in sec.annual_instant_series(companyfacts,TAGS["short_borrowings"],10)}
    debt_cur={x["fy"]:x for x in sec.annual_instant_series(companyfacts,TAGS["long_debt_current"],10)}
    debt_noncur={x["fy"]:x for x in sec.annual_instant_series(companyfacts,TAGS["long_debt_noncurrent"],10)}
    debt_total={x["fy"]:x for x in sec.annual_instant_series(companyfacts,TAGS["long_debt_total"],10)}
    debt_combined={x["fy"]:x for x in sec.annual_instant_series(companyfacts,TAGS["debt_combined"],10)}

    years=sorted(set().union(
        *[set(mp.keys()) for mp in annual_maps.values()],
        *[set(mp.keys()) for mp in instant_maps.values()],
        set(debt_short.keys()),set(debt_cur.keys()),set(debt_noncur.keys()),set(debt_total.keys()),set(debt_combined.keys()),set(annual_eps.keys()),
        *[set(mp.keys()) for mp in flow_maps.values()]
    ))
    rows=[]; now=datetime.now(timezone.utc).isoformat()
    pit_flow={"revenue","gross_profit","operating_income","net_income","cfo","capex","buybacks"}
    pit_inst={"cash"}
    for fy in years[-10:]:
        row={"ticker":ticker.upper(),"period_key":f"FY{fy}","period_end":None,"period_filed":None,
             "fiscal_year":fy,"period_type":"FY","updated_at":now}
        # Revenue is the preferred filing/date anchor; other annual facts fill gaps only.
        anchor_rec=annual_maps.get("revenue",{}).get(fy) or next((mp.get(fy) for mp in annual_maps.values() if fy in mp),None)
        if anchor_rec:
            row["period_end"]=anchor_rec.get("end")
            row["period_filed"]=anchor_rec.get("first_filed") or anchor_rec.get("filed")
        for m,mp in annual_maps.items():
            rec=mp.get(fy) or {}
            row[m]=rec.get("val")
            if m=="diluted_shares":
                row["pit_diluted_shares"]=_first_as_of(rec,row.get("period_filed"))
                row["share_denominator_kind"]=rec.get("share_kind")
                row["pit_share_denominator_kind"]=rec.get("share_kind")
                row["share_value_filed"]=rec.get("filed")
                row["pit_share_value_filed"]=rec.get("first_filed") or rec.get("filed")
            elif m in pit_flow:
                row[f"pit_{m}"]=_first_as_of(rec,row.get("period_filed"))
            if row["period_end"] is None and rec: row["period_end"]=rec.get("end")
            if row["period_filed"] is None and rec: row["period_filed"]=rec.get("first_filed") or rec.get("filed")
        eps_rec=annual_eps.get(fy) or {}
        row["diluted_eps_reported"]=eps_rec.get("val")
        row["pit_diluted_eps"]=_first_as_of(eps_rec,row.get("period_filed"))
        row["diluted_eps_filed"]=eps_rec.get("filed")
        row["pit_diluted_eps_filed"]=eps_rec.get("first_filed") or eps_rec.get("filed")
        row["diluted_eps_source"]="annual reported diluted EPS" if eps_rec else None
        row["fcf"]=(row["cfo"]-row["capex"]) if row.get("cfo") is not None and row.get("capex") is not None else None
        row["pit_fcf"]=(row.get("pit_cfo")-row.get("pit_capex")) if row.get("pit_cfo") is not None and row.get("pit_capex") is not None else None
        for m,mp in instant_maps.items():
            rec=mp.get(fy) or {}
            row[m]=rec.get("val")
            if m in pit_inst: row[f"pit_{m}"]=_first_as_of(rec,row.get("period_filed"))
            if row["period_end"] is None and rec: row["period_end"]=rec.get("end")
            if row["period_filed"] is None and rec: row["period_filed"]=rec.get("first_filed") or rec.get("filed")
        row["debt"]=_debt_from_records(debt_short.get(fy),debt_cur.get(fy),debt_noncur.get(fy),debt_total.get(fy),debt_combined.get(fy))
        row["pit_debt"]=_debt_from_records(debt_short.get(fy),debt_cur.get(fy),debt_noncur.get(fy),debt_total.get(fy),debt_combined.get(fy),pit_cutoff=row.get("period_filed"))
        # Shares outstanding known at the original annual filing are used for PIT market-cap methods.
        so=sec.latest_unambiguous_instant_as_of_filing(companyfacts,TAGS["shares_outstanding"],row.get("period_filed")) if row.get("period_filed") else None
        row["pit_shares_outstanding"]=so.get("val") if so else None
        row["pit_shares_outstanding_date"]=so.get("end") if so else None
        row["shares_outstanding"]=row["pit_shares_outstanding"]
        row["shares_outstanding_date"]=so.get("end") if so else None
        row["shares_outstanding_filed"]=so.get("filed") if so else None
        row["shares_outstanding_method"]=so.get("aggregation_method") if so else None
        row["shares_outstanding_components_json"]=json.dumps(so.get("components") or [],separators=(",",":")) if so else None

        # V3.1.11 Financial Flows annual statement lines. Pretax/tax were accidentally
        # nulled in V3.1.9. Resolve them conservatively from consolidated annual SEC facts.
        pre_rec=flow_maps["pretax"].get(fy) or {}
        tax_rec=flow_maps["tax"].get(fy) or {}
        row["pretax"]=pre_rec.get("val")
        row["tax"]=tax_rec.get("val")

        # Keep the valuation engine's reported operating_income untouched. The Sankey gets a
        # separate audit-friendly operating-income bridge that may use exact statement arithmetic
        # when a filer (e.g. NIKE) does not tag a standalone OperatingIncomeLoss line.
        flow_oi=None; flow_method=None
        direct=(flow_maps["direct_oi"].get(fy) or {}).get("val")
        if direct is not None:
            flow_oi=float(direct); flow_method="REPORTED_OPERATING_INCOME"
        elif row.get("revenue") is not None and (flow_maps["total_costs"].get(fy) or {}).get("val") is not None:
            flow_oi=float(row["revenue"])-float(flow_maps["total_costs"][fy]["val"]); flow_method="DERIVED_REVENUE_MINUS_TOTAL_COSTS"
        elif row.get("gross_profit") is not None and (flow_maps["operating_expenses"].get(fy) or {}).get("val") is not None:
            flow_oi=float(row["gross_profit"])-float(flow_maps["operating_expenses"][fy]["val"]); flow_method="DERIVED_GROSS_PROFIT_MINUS_OPERATING_EXPENSES"
        elif row.get("gross_profit") is not None and (flow_maps["sga"].get(fy) or {}).get("val") is not None:
            sga=float(flow_maps["sga"][fy]["val"]); rd_rec=flow_maps["rd"].get(fy) or {}
            rd=float(rd_rec.get("val") or 0.0)
            flow_oi=float(row["gross_profit"])-sga-rd
            flow_method="DERIVED_GROSS_PROFIT_MINUS_SG&A" + ("_AND_R&D" if rd_rec.get("val") is not None else "")
            # SG&A-only is the least explicit fallback. Require a plausible bridge to pretax so an
            # omitted material operating-cost category (for example a separate R&D line) cannot
            # silently inflate operating income. This is a fail-closed visualization guard.
            if row.get("pretax") is not None:
                rev_abs=abs(float(row.get("revenue") or 0.0)); gp_abs=abs(float(row.get("gross_profit") or 0.0))
                if abs(flow_oi-float(row["pretax"])) > max(1.0,rev_abs*.10,gp_abs*.25):
                    flow_oi=None; flow_method="DATA_REVIEW_SG&A_BRIDGE_NOT_RECONCILABLE"
        # Fail closed on implausible arithmetic instead of feeding a distorted Sankey.
        if flow_oi is not None:
            rev=abs(float(row.get("revenue") or 0.0))
            gp=row.get("gross_profit")
            if not math.isfinite(flow_oi) or (gp is not None and flow_oi > float(gp)+max(1.0,rev*1e-8)):
                flow_oi=None; flow_method="DATA_REVIEW_IMPLAUSIBLE_OPERATING_BRIDGE"
        row["flow_operating_income"]=flow_oi
        row["flow_operating_income_method"]=flow_method
        rows.append(row)

    # Latest balance-sheet facts.
    inst={}
    for m in instant_metrics:
        x=sec.latest_instant(companyfacts,TAGS[m]); inst[m]=x["val"] if x else None
    ds=sec.latest_instant(companyfacts,TAGS["short_borrowings"])
    dc=sec.latest_instant(companyfacts,TAGS["long_debt_current"])
    dn=sec.latest_instant(companyfacts,TAGS["long_debt_noncurrent"])
    dt=sec.latest_instant(companyfacts,TAGS["long_debt_total"])
    dcomb=sec.latest_instant(companyfacts,TAGS["debt_combined"])
    inst["debt"]=_debt_from_records(ds,dc,dn,dt,dcomb)
    so=sec.latest_unambiguous_instant(companyfacts,TAGS["shares_outstanding"])
    # Live current-valuation recovery: Companyfacts may omit dimensional cover-page share facts
    # for multi-class issuers. A fresher Inline XBRL cover-page fact may replace ONLY the current
    # TTM denominator; historical FY/PIT rows above remain filing-bounded Companyfacts.
    if current_share_fact:
        try:
            cur_end=str(current_share_fact.get("end") or "")[:10]
            old_end=str((so or {}).get("end") or "")[:10]
            if cur_end and (not old_end or cur_end>=old_end) and float(current_share_fact.get("val") or 0)>0:
                so=dict(current_share_fact)
        except Exception:
            pass
    inst["shares_outstanding"]=so["val"] if so else None
    inst["shares_outstanding_date"]=so.get("end") if so else None
    inst["shares_outstanding_filed"]=so.get("filed") if so else None
    inst["shares_outstanding_method"]=so.get("aggregation_method") if so else None
    inst["shares_outstanding_components_json"]=json.dumps(so.get("components") or [],separators=(",",":")) if so else None

    ttm={}
    for m in ("revenue","gross_profit","operating_income","net_income","cfo","capex","sbc","buybacks","dividends","pretax","tax"):
        ttm[m]=sec.ttm_value(companyfacts,TAGS[m])
    ttm["fcf"]=(ttm["cfo"]-ttm["capex"]) if ttm["cfo"] is not None and ttm["capex"] is not None else None
    # Independent per-share cross-check. EPS is a ratio: use only explicit standalone quarter
    # observations (or a current FY fallback), never FY minus Q1-Q3.
    eps_snap=sec.ttm_eps_snapshot(companyfacts,TAGS["diluted_eps"])
    ttm["diluted_eps_reported"]=eps_snap.get("value") if eps_snap else None
    ttm["diluted_eps_filed"]=eps_snap.get("filed") if eps_snap else None
    ttm["diluted_eps_source"]=eps_snap.get("source") if eps_snap else None
    ttm["diluted_eps_components_json"]=json.dumps(eps_snap.get("components") or [],separators=(",",":"),default=str) if eps_snap else None
    share_fact,share_kind=_latest_share_duration(companyfacts)
    ttm["diluted_shares"]=share_fact["val"] if share_fact else (share_map[max(share_map)]["val"] if share_map else None)
    ttm["diluted_shares_date"]=share_fact.get("end") if share_fact else (share_map[max(share_map)].get("end") if share_map else None)
    ttm["diluted_shares_filed"]=share_fact.get("filed") if share_fact else (share_map[max(share_map)].get("filed") if share_map else None)
    ttm["share_denominator_kind"]=share_kind if share_fact else (share_map[max(share_map)].get("share_kind") if share_map else "MISSING")

    latest_end=max([x.get("end","") for m in instant_metrics for x in [sec.latest_instant(companyfacts,TAGS[m])] if x] or [""])
    ttmrow={"ticker":ticker.upper(),"period_key":"TTM","period_end":latest_end or None,"period_filed":None,
            "fiscal_year":None,"period_type":"TTM","updated_at":now,**ttm,**inst}
    rows.append(ttmrow)
    return rows


def _safe_div(a,b):
    try:
        if a is None or b is None or float(b)==0:return None
        return float(a)/float(b)
    except Exception:return None


def _split_factor_at(bars, basis_date):
    """Cumulative future split factor from a verified market bar at/on-before basis_date."""
    if not bars or not basis_date:
        return 1.0,False
    try: target=date.fromisoformat(str(basis_date)[:10])
    except Exception:return 1.0,False
    best_verified=None; best_any=None
    for b in bars:
        try:d=date.fromisoformat(str(b.get("trade_date") or b.get("date"))[:10])
        except Exception:continue
        if d>target:continue
        if best_any is None or d>best_any[0]: best_any=(d,b)
        ok=bool((b.get("split_factor_verified") or b.get("basis_verified")) in (True,1,"1"))
        if ok and (best_verified is None or d>best_verified[0]): best_verified=(d,b)
    best=best_verified or best_any
    if best is None:return 1.0,False
    b=best[1]
    verified=bool((b.get("split_factor_verified") or b.get("basis_verified")) in (True,1,"1"))
    try:f=float(b.get("split_factor") or 1.0)
    except Exception:f=1.0
    return (f if f>0 else 1.0),verified



def _latest_market_bar(bars):
    """Latest quote-bearing bar, independent of historical raw/adjusted-basis certification."""
    if not bars:
        return None
    good=[]
    for b in bars:
        ds=str(b.get("trade_date") or b.get("date") or "")[:10]
        try:
            d=date.fromisoformat(ds)
            px=float(b.get("close"))
            if px>0: good.append((d,b))
        except Exception:
            continue
    return max(good,key=lambda x:x[0])[1] if good else None


def current_valuation_share_anchor(ttm_row: dict, current_price_date: str | None, max_outstanding_age_days: int = 550):
    """Choose the denominator date whose split ledger should be verified for current valuation.

    Exact outstanding shares are preferred only while the instant fact is reasonably current.
    If it is stale (or postdates the quote), verify the recent diluted-share filing/date instead so
    the model can use its explicit MEDIUM-confidence fallback. This selection does not itself mark
    either denominator verified.
    """
    r=ttm_row or {}
    out_anchor=r.get("shares_outstanding_date")
    dil_anchor=r.get("diluted_shares_filed") or r.get("diluted_shares_date")
    if not out_anchor or not current_price_date:
        return out_anchor or dil_anchor
    try:
        age=(date.fromisoformat(str(current_price_date)[:10])-date.fromisoformat(str(out_anchor)[:10])).days
        if age < 0 or age > int(max_outstanding_age_days):
            return dil_anchor or out_anchor
    except Exception:
        pass
    return out_anchor or dil_anchor


def _current_basis_factor(bars, anchor_date, current_date=None):
    """Return cumulative split/reverse-split factor from a fact basis to the current quote basis.

    This deliberately uses only ``split_factor_verified`` (with legacy ``basis_verified`` as a
    compatibility fallback). It does *not* require historical raw-vs-adjusted OHLC semantics.
    """
    if not anchor_date:
        return 1.0,False,"Share fact date is missing"
    try:
        anchor=date.fromisoformat(str(anchor_date)[:10])
    except Exception:
        return 1.0,False,"Share fact date is invalid"
    try:
        cur=date.fromisoformat(str(current_date)[:10]) if current_date else None
    except Exception:
        cur=None
    if cur is not None and anchor>cur:
        return 1.0,False,f"Share fact dated {anchor.isoformat()} postdates current price dated {cur.isoformat()}; refresh the market quote before combining them"
    if cur is not None and anchor==cur:
        return 1.0,True,None
    factor,verified=_split_factor_at(bars,anchor.isoformat())
    if verified:
        return factor,True,None
    return factor,False,f"Unable to verify split/reverse-split actions after share fact dated {anchor.isoformat()}"


def _corporate_action_summary(bars, anchor_date, current_date=None):
    """Describe deterministic share-basis actions between a fact and today's quote basis.

    Buybacks / issuance are economic share-count changes and are captured by newer SEC share facts
    and forward-share assumptions. They are intentionally not treated as split factors here.
    """
    factor,verified,issue=_current_basis_factor(bars,anchor_date,current_date)
    if not verified:
        return "UNVERIFIED",factor,issue
    if abs(float(factor)-1.0)<1e-10:
        return "None (verified)",1.0,None
    if factor>=1:
        rounded=round(float(factor),6)
        label=f"Verified cumulative forward split factor {rounded:g}:1"
    else:
        inv=round(1.0/float(factor),6) if factor else None
        label=f"Verified cumulative reverse-split factor 1:{inv:g}" if inv else "Verified reverse split"
    return label,float(factor),None


def metrics_from_rows(rows, current_price=None, bars=None, current_basis_evidence=None):
    by={r["period_key"]:r for r in rows}; t=by.get("TTM",{})
    rev=t.get("revenue"); gp=t.get("gross_profit"); oi=t.get("operating_income"); ni=t.get("net_income"); cfo=t.get("cfo"); fcf=t.get("fcf")
    cogs=(rev-gp) if rev is not None and gp is not None else None
    gross_margin=_safe_div(gp,rev); op_margin=_safe_div(oi,rev); net_margin=_safe_div(ni,rev); fcf_margin=_safe_div(fcf,rev); cfo_ni=_safe_div(cfo,ni)
    dso=365*_safe_div(t.get("receivables"),rev) if _safe_div(t.get("receivables"),rev) is not None else None
    dio=365*_safe_div(t.get("inventory"),cogs) if _safe_div(t.get("inventory"),cogs) is not None else None
    dpo=365*_safe_div(t.get("payables"),cogs) if _safe_div(t.get("payables"),cogs) is not None else None
    ccc=(dso+dio-dpo) if None not in (dso,dio,dpo) else None
    cash=t.get("cash"); debt=t.get("debt"); equity=t.get("equity"); net_debt=(debt-cash) if debt is not None and cash is not None else None
    tax_rate=None
    if t.get("pretax") not in (None,0) and t.get("tax") is not None: tax_rate=max(0,min(0.35,float(t["tax"])/float(t["pretax"])))
    if tax_rate is None: tax_rate=0.21
    invested=(debt+equity-cash) if debt is not None and equity is not None and cash is not None else None
    roic=_safe_div((oi*(1-tax_rate)) if oi is not None else None,invested)

    # CURRENT VALUATION SHARE BASIS (V3.1.8)
    # ----------------------------------------
    # Current valuation is intentionally independent from historical OHLC calibration.  The only
    # market-history property required to move a SEC denominator onto today's quote basis is a
    # verified split/reverse-split ledger.  Historical ``basis_verified`` remains a stricter and
    # separate requirement for Validate / historical multiple calibration.
    latest_bar=_latest_market_bar(bars)
    current_price_date=str((latest_bar or {}).get("trade_date") or (latest_bar or {}).get("date") or "")[:10] or None
    if current_price is None and latest_bar is not None:
        try: current_price=float(latest_bar.get("close"))
        except Exception: pass
    current_price_source=(latest_bar or {}).get("feed") if latest_bar else None
    latest_raw_close=(latest_bar or {}).get("raw_close") if latest_bar else None
    latest_split_adjusted_close=(latest_bar or {}).get("split_adjusted_close") if latest_bar else None
    latest_price_split_factor=(latest_bar or {}).get("split_factor") if latest_bar else None
    historical_price_basis_verified=bool((latest_bar or {}).get("basis_verified")) if latest_bar else False
    split_ledger_verified=bool((latest_bar or {}).get("split_factor_verified") or (latest_bar or {}).get("basis_verified")) if latest_bar else False

    def _current_evidence(anchor):
        e=current_basis_evidence or {}
        if str(e.get("status") or "").upper()!="VERIFIED" or not anchor or not current_price_date:
            return None
        if str(e.get("anchor_date") or "")[:10]!=str(anchor)[:10]:
            return None
        try:
            if date.fromisoformat(str(e.get("verified_through") or "")[:10]) < date.fromisoformat(str(current_price_date)[:10]):
                return None
            f=float(e.get("split_factor") or 1.0)
            if not math.isfinite(f) or f<=0:return None
        except Exception:
            return None
        acts=e.get("actions") or []
        if acts:
            labels=[]
            for a in acts:
                try:labels.append(f"{str(a.get('date') or '')[:10]} {float(a.get('ratio')):g}x")
                except Exception:continue
            action_label="; ".join(labels) if labels else f"Verified cumulative split factor {f:g}x"
        else:
            action_label="None (verified)"
        return f,action_label,str(e.get("source") or "VERIFIED CORPORATE-ACTION LEDGER")

    reported_dil=t.get("diluted_shares")
    # Weighted-average diluted shares are retrospectively recast for splits that occur before the
    # filing is issued, so filing date is the safest normalization anchor for that denominator.
    dil_anchor=t.get("diluted_shares_filed") or t.get("diluted_shares_date")
    _dile=_current_evidence(dil_anchor)
    if _dile:
        dil_factor,dil_actions,dil_source=_dile; dil_issue=None; dil_verified=True
    else:
        dil_actions,dil_factor,dil_issue=_corporate_action_summary(bars,dil_anchor,current_price_date); dil_source="MARKET BAR SPLIT LEDGER"
        dil_verified=bool(bars) and dil_issue is None
    diluted_shares=(float(reported_dil)*dil_factor) if reported_dil is not None else None

    reported_out=t.get("shares_outstanding")
    out_anchor=t.get("shares_outstanding_date")
    # A split ledger can normalize units, but it cannot repair years of buybacks / issuance.
    # Therefore an old instant share fact must never be promoted to CURRENT_OUTSTANDING merely
    # because the split history is known.  Prefer the fresh Inline-XBRL cover fact; otherwise
    # fall through to a recent diluted-share denominator or DATA REVIEW.
    out_stale=False
    if reported_out is not None and out_anchor and current_price_date:
        try:
            out_stale=(date.fromisoformat(str(current_price_date)[:10])-date.fromisoformat(str(out_anchor)[:10])).days>550
        except Exception:
            out_stale=False
    _oute=None if out_stale else _current_evidence(out_anchor)
    if out_stale:
        out_factor=1.0; out_actions="STALE FACT"; out_source="STALE SEC SHARE FACT"
        out_issue=f"Current shares fact dated {str(out_anchor)[:10]} is too old for current market-cap use; refresh the latest SEC filing cover shares"
        out_verified=False
    elif _oute:
        out_factor,out_actions,out_source=_oute; out_issue=None; out_verified=True
        split_ledger_verified=True
    else:
        out_actions,out_factor,out_issue=_corporate_action_summary(bars,out_anchor,current_price_date); out_source="MARKET BAR SPLIT LEDGER"
        out_verified=bool(bars) and out_issue is None
    shares_outstanding=(float(reported_out)*out_factor) if reported_out is not None else None

    # Select the best denominator that is mathematically auditable on today's share basis.
    # Exact current shares win.  Verified weighted-average diluted shares are a declared MEDIUM
    # confidence fallback rather than a reason to hide Bear/Base/Bull.
    valuation_share_source="MISSING"
    valuation_share_confidence="LOW"
    valuation_share_basis_verified=False
    valuation_share_basis_usable=False
    valuation_basis_issue=None
    valuation_shares=None
    selected_raw_shares=None
    selected_fact_date=None
    selected_filed_date=None
    selected_split_factor=None
    selected_actions=None
    selected_corp_basis="UNVERIFIED"

    if bars and shares_outstanding is not None and out_verified:
        valuation_shares=shares_outstanding
        valuation_share_source="CURRENT_OUTSTANDING"
        valuation_share_confidence="HIGH"
        valuation_share_basis_verified=True
        valuation_share_basis_usable=True
        selected_raw_shares=reported_out
        selected_fact_date=t.get("shares_outstanding_date")
        selected_filed_date=t.get("shares_outstanding_filed")
        selected_split_factor=out_factor
        selected_actions=out_actions
        selected_corp_basis=str(out_source or "VERIFIED SPLIT / REVERSE-SPLIT LEDGER")
    elif bars and diluted_shares is not None and dil_verified:
        valuation_shares=diluted_shares
        valuation_share_source="DILUTED_WA_FALLBACK"
        valuation_share_confidence="MEDIUM"
        valuation_share_basis_verified=True
        valuation_share_basis_usable=True
        selected_raw_shares=reported_dil
        selected_fact_date=t.get("diluted_shares_date")
        selected_filed_date=t.get("diluted_shares_filed")
        selected_split_factor=dil_factor
        selected_actions=dil_actions
        selected_corp_basis=str(dil_source or "VERIFIED SPLIT / REVERSE-SPLIT LEDGER")+" · DILUTED-WA FALLBACK"
        if reported_out is not None and not out_verified:
            valuation_basis_issue=(out_issue or "Current shares outstanding basis was not verifiable")+"; using verified diluted-share fallback instead."
    elif not bars:
        # Synthetic/offline math remains testable, but live decisions will independently fail the
        # current-price/data gate.  Never label this path VERIFIED.
        valuation_shares=shares_outstanding or diluted_shares
        valuation_share_source="CURRENT_OUTSTANDING" if shares_outstanding is not None else ("DILUTED_WA_FALLBACK" if diluted_shares is not None else "MISSING")
        valuation_share_confidence="LOW"
        valuation_share_basis_usable=valuation_shares is not None
        selected_raw_shares=reported_out if shares_outstanding is not None else reported_dil
        selected_fact_date=t.get("shares_outstanding_date") if shares_outstanding is not None else t.get("diluted_shares_date")
        selected_filed_date=t.get("shares_outstanding_filed") if shares_outstanding is not None else t.get("diluted_shares_filed")
        selected_split_factor=1.0
        selected_actions="Not checked — no market split ledger supplied"
        selected_corp_basis="UNCHECKED"
        valuation_basis_issue="Corporate-action basis has not been checked against market data."
    else:
        valuation_shares=shares_outstanding or diluted_shares
        valuation_share_source="UNVERIFIED_FALLBACK" if valuation_shares is not None else "MISSING"
        valuation_basis_issue=out_issue if reported_out is not None else dil_issue if reported_dil is not None else "No SEC current-share or diluted-share denominator is available."
        if reported_out is not None and diluted_shares is not None and not dil_verified:
            valuation_basis_issue=(out_issue or "Current shares outstanding basis unverified")+"; diluted-share fallback is also unverified."

    valuation_share_basis_status=("VERIFIED" if valuation_share_basis_usable and valuation_share_confidence=="HIGH" else
                                  "VERIFIED FALLBACK" if valuation_share_basis_usable and valuation_share_confidence=="MEDIUM" else
                                  "UNCHECKED" if valuation_share_basis_usable and not bars else "DATA REVIEW")

    # Market cap is exact when based on current outstanding shares; with the verified diluted-WA
    # fallback it remains a disclosed proxy and is usable for orientation/current multiples.
    market_cap_shares=valuation_shares
    market_cap_share_kind=("OUTSTANDING" if valuation_share_source=="CURRENT_OUTSTANDING" else
                           "DILUTED_FALLBACK" if valuation_share_source=="DILUTED_WA_FALLBACK" else
                           "MISSING" if valuation_shares is None else "UNVERIFIED")
    market_cap_basis_verified=bool(valuation_share_source=="CURRENT_OUTSTANDING" and valuation_share_basis_verified)
    market_cap_basis_usable=bool(valuation_share_basis_usable)
    reported_eps=t.get("diluted_eps_reported")
    eps_components=[]
    try:
        eps_components=json.loads(t.get("diluted_eps_components_json") or "[]")
        if not isinstance(eps_components,list):eps_components=[]
    except Exception:
        eps_components=[]
    normalized_eps_parts=[];eps_component_basis_ok=True
    if eps_components:
        for comp in eps_components:
            try:val=float(comp.get("val"))
            except Exception:
                eps_component_basis_ok=False;continue
            ef,ok=_split_factor_at(bars,comp.get("filed"))
            if not ok:
                eps_component_basis_ok=False;continue
            normalized_eps_parts.append(val/ef)
        eps_verified=bool(normalized_eps_parts) and eps_component_basis_ok and len(normalized_eps_parts)==len(eps_components)
        diluted_eps_sec=sum(normalized_eps_parts) if eps_verified else None
    else:
        eps_factor,eps_verified=_split_factor_at(bars,t.get("diluted_eps_filed"))
        diluted_eps_sec=(float(reported_eps)/eps_factor) if reported_eps is not None and eps_factor>0 and eps_verified else None
    # Legacy alias retained for persisted caches.  In V3.1.8 it means that the *selected current
    # valuation denominator* is on a verified current split basis; it no longer inherits the
    # historical OHLC raw/adjusted certification gate.
    share_basis_verified=valuation_share_basis_verified

    fys=sorted([r for r in rows if r.get("period_type")=="FY" and r.get("revenue")],key=lambda x:x["fiscal_year"])
    growth=[]
    for a,b in zip(fys,fys[1:]):
        try: gap=max(1,int(b["fiscal_year"])-int(a["fiscal_year"]))
        except Exception: gap=1
        if a["revenue"] and b.get("revenue") is not None and float(a["revenue"])>0 and float(b["revenue"])>0:
            growth.append((float(b["revenue"])/float(a["revenue"]))**(1/gap)-1)
    cagr3=None
    if len(fys)>=2 and fys[-1].get("revenue") and float(fys[-1]["revenue"])>0:
        # Choose the nearest observation at least three fiscal years back; annualize over the
        # actual fiscal-year gap rather than assuming four stored rows always mean exactly 3Y.
        candidates=[r for r in fys[:-1] if r.get("revenue") and int(fys[-1]["fiscal_year"])-int(r["fiscal_year"])>=3]
        if candidates:
            anchor=max(candidates,key=lambda r:int(r["fiscal_year"]))
            gap=int(fys[-1]["fiscal_year"])-int(anchor["fiscal_year"])
            if gap>0 and float(anchor["revenue"])>0:
                cagr3=(float(fys[-1]["revenue"])/float(anchor["revenue"]))**(1/gap)-1

    share_change=None; share_change_verified=False
    share_fys=[r for r in fys if r.get("diluted_shares")]
    if len(share_fys)>=2:
        a,b=share_fys[-2],share_fys[-1]
        af,av=_split_factor_at(bars,a.get("share_value_filed") or a.get("period_filed")); bf,bv=_split_factor_at(bars,b.get("share_value_filed") or b.get("period_filed"))
        sa=float(a["diluted_shares"])*(af if av else 1.0); sb=float(b["diluted_shares"])*(bf if bv else 1.0)
        raw=sb/sa-1 if sa else None
        # Without a verified split basis, a huge discontinuity is not safe to interpret as economic dilution.
        if raw is not None and ((av and bv) or abs(raw)<=.35 or (a.get("share_value_filed") and a.get("share_value_filed")==b.get("share_value_filed"))):
            share_change=raw; share_change_verified=bool(av and bv) or bool(a.get("share_value_filed") and a.get("share_value_filed")==b.get("share_value_filed"))

    sbc_rev=_safe_div(t.get("sbc"),rev); buyback_rev=_safe_div(t.get("buybacks"),rev)
    market_cap=(float(current_price)*float(market_cap_shares)) if (current_price not in (None,0) and market_cap_shares not in (None,0) and (not bars or market_cap_basis_usable)) else None
    eps_proxy=_safe_div(ni,diluted_shares)
    diluted_eps=diluted_eps_sec if diluted_eps_sec is not None else eps_proxy
    eps_reconciliation_gap=None
    if diluted_eps_sec is not None and eps_proxy not in (None,0):
        eps_reconciliation_gap=float(diluted_eps_sec)/float(eps_proxy)-1
    eps_basis_warning=bool(eps_reconciliation_gap is not None and abs(eps_reconciliation_gap)>.15)

    return {
      "revenue":rev,"gross_profit":gp,"operating_income":oi,"net_income":ni,"cfo":cfo,
      "gross_margin":gross_margin,"operating_margin":op_margin,"net_margin":net_margin,"fcf":fcf,"fcf_margin":fcf_margin,"cfo_ni":cfo_ni,
      "dso":dso,"dio":dio,"dpo":dpo,"ccc":ccc,"cash":cash,"debt":debt,"receivables":t.get("receivables"),"inventory":t.get("inventory"),"payables":t.get("payables"),
      "assets":t.get("assets"),"liabilities":t.get("liabilities"),"net_debt":net_debt,"equity":equity,"roic":roic,"tax_rate":tax_rate,
      "cagr3":cagr3,"recent_growth":growth[-1] if growth else None,
      "diluted_shares":diluted_shares,"diluted_shares_reported":reported_dil,"diluted_shares_date":t.get("diluted_shares_date"),"diluted_shares_filed":t.get("diluted_shares_filed"),
      "shares_outstanding":shares_outstanding,"shares_outstanding_reported":reported_out,"shares_outstanding_date":t.get("shares_outstanding_date"),"shares_outstanding_filed":t.get("shares_outstanding_filed"),
      "shares_outstanding_method":t.get("shares_outstanding_method"),"shares_outstanding_components_json":t.get("shares_outstanding_components_json"),
      "current_price":current_price,"current_market_price":current_price,"current_price_date":current_price_date,"current_price_source":current_price_source,"current_price_basis":"CURRENT MARKET QUOTE",
      "latest_raw_close":latest_raw_close,"latest_split_adjusted_close":latest_split_adjusted_close,"current_price_split_factor":latest_price_split_factor,"historical_price_basis_verified":historical_price_basis_verified,"split_ledger_verified":split_ledger_verified,
      "valuation_shares":valuation_shares,"valuation_share_source":valuation_share_source,"valuation_share_confidence":valuation_share_confidence,"valuation_share_basis_status":valuation_share_basis_status,"valuation_share_basis_usable":valuation_share_basis_usable,
      "valuation_share_raw":selected_raw_shares,"valuation_share_fact_date":selected_fact_date,"valuation_share_filed_date":selected_filed_date,"valuation_split_factor":selected_split_factor,"corporate_actions_since_share_fact":selected_actions,"corporate_action_basis":selected_corp_basis,"valuation_basis_issue":valuation_basis_issue,
      "market_cap_shares":market_cap_shares,"market_cap_share_kind":market_cap_share_kind,"market_cap_basis_usable":market_cap_basis_usable,"market_cap":market_cap,
      "diluted_eps":diluted_eps,"diluted_eps_sec":diluted_eps_sec,"diluted_eps_proxy":eps_proxy,"eps_reconciliation_gap":eps_reconciliation_gap,"eps_basis_warning":eps_basis_warning,
      "diluted_eps_filed":t.get("diluted_eps_filed"),"diluted_eps_source":t.get("diluted_eps_source"),"diluted_eps_components_json":t.get("diluted_eps_components_json"),"eps_basis_verified":eps_verified if reported_eps is not None else None,
      "share_denominator_kind":t.get("share_denominator_kind"),"share_basis_verified":share_basis_verified,"valuation_share_basis_verified":valuation_share_basis_verified,"market_cap_basis_verified":market_cap_basis_verified,"share_basis_checked":bool(bars),
      "current_shares_outstanding":shares_outstanding,"weighted_average_diluted_shares":diluted_shares,
      "share_change":share_change,"share_change_verified":share_change_verified,"sbc_rev":sbc_rev,"buyback_rev":buyback_rev,
    }


def apply_share_basis_override(metrics: dict, override: dict | None) -> dict:
    """Apply a user-confirmed *current* share-basis recovery without altering SEC source facts.

    The override is intentionally excluded from backtests/historical calibration.  It only tells
    current valuation which already-normalized denominator the user has independently checked.
    This is auditable and MEDIUM-confidence, not silently promoted to independently VERIFIED.
    """
    if not metrics or not override or not bool(override.get("confirmed")):
        return metrics
    # A saved manual recovery must never mask a later independently verified exact current-share
    # basis. Once automatic CURRENT_OUTSTANDING is HIGH-confidence again, it wins automatically.
    if (bool(metrics.get("valuation_share_basis_usable")) and bool(metrics.get("valuation_share_basis_verified"))
            and str(metrics.get("valuation_share_confidence") or "").upper()=="HIGH"
            and str(metrics.get("valuation_share_source") or "")=="CURRENT_OUTSTANDING"):
        out=dict(metrics); out["saved_share_basis_override_not_used"]=True
        return out
    try:
        shares=float(override.get("current_basis_shares"))
    except Exception:
        return metrics
    if not math.isfinite(shares) or shares<=0:
        return metrics
    out=dict(metrics)
    # Preserve the automatic diagnosis so Sources/Audit can explain why the override was needed.
    for k in ("valuation_shares","valuation_share_source","valuation_share_confidence","valuation_share_basis_status",
              "valuation_share_raw","valuation_share_fact_date","valuation_share_filed_date","valuation_split_factor",
              "corporate_actions_since_share_fact","corporate_action_basis","valuation_basis_issue"):
        out[f"auto_{k}"]=metrics.get(k)
    mode=str(override.get("mode") or "MANUAL_CURRENT_BASIS").upper()
    no_split=(mode=="USER_VERIFIED_NO_SPLIT")
    basis_date=str(override.get("basis_date") or metrics.get("valuation_share_fact_date") or metrics.get("current_price_date") or "")[:10] or None
    out.update({
        "valuation_shares":shares,
        "valuation_share_source":"USER_VERIFIED_NO_SPLIT" if no_split else "USER_CURRENT_BASIS",
        "valuation_share_confidence":"MEDIUM",
        "valuation_share_basis_status":"USER VERIFIED",
        "valuation_share_basis_usable":True,
        "valuation_share_basis_verified":False,
        "share_basis_verified":False,
        "valuation_share_raw":shares,
        "valuation_share_fact_date":basis_date,
        "valuation_share_filed_date":metrics.get("valuation_share_filed_date") if no_split else None,
        "valuation_split_factor":1.0,
        "corporate_actions_since_share_fact":"None — user verified" if no_split else "Already normalized to current share basis by user",
        "corporate_action_basis":"USER-VERIFIED NO-SPLIT BASIS" if no_split else "USER-SUPPLIED CURRENT SHARE BASIS",
        "valuation_basis_issue":None,
        "valuation_basis_override_active":True,
        "valuation_basis_override_note":str(override.get("source_note") or ""),
        "valuation_basis_override_updated_at":override.get("updated_at"),
        "market_cap_shares":shares,
        "market_cap_share_kind":"USER_OVERRIDE",
        "market_cap_basis_usable":True,
        "market_cap_basis_verified":False,
        "current_shares_outstanding":shares,
    })
    px=out.get("current_price")
    try:
        out["market_cap"]=float(px)*shares if px is not None and float(px)>0 else None
    except Exception:
        out["market_cap"]=None
    return out


def fundamental_score(m: dict):
    dims={}
    gm=m.get("gross_margin"); om=m.get("operating_margin"); fm=m.get("fcf_margin"); roic=m.get("roic"); conv=m.get("cfo_ni"); nd=m.get("net_debt"); rev=m.get("revenue")
    sbc=m.get("sbc_rev"); share=m.get("share_change"); ccc=m.get("ccc")
    dims["Revenue Quality"]=3.0+max(-1,min(1,(m.get("cagr3") or 0)/0.10))
    dims["Margin Structure"]=3.0+max(-1,min(1,(om or 0)/0.20))
    dims["FCF Quality"]=3.0+max(-1,min(1,((fm or 0)-0.05)/0.10))+(0.5 if conv and conv>1 else 0)
    dims["Balance Sheet"]=3.0+(0.75 if nd is not None and nd<0 else -0.5 if nd is not None and rev and nd>rev else 0)
    dims["Working Capital"]=3.0+(0.4 if ccc is not None and ccc<60 else -0.4 if ccc is not None and ccc>150 else 0)
    dims["Capital Allocation"]=3.0+(-0.6 if share and share>0.02 else 0.4 if share and share<-0.02 else 0)+(-0.3 if sbc and sbc>0.05 else 0)
    dims["Moat / Competitive"]=3.0; dims["Management Execution"]=3.0; dims["Valuation"]=3.0; dims["Risk / Reward"]=3.0
    dims={k:max(1,min(5,v)) for k,v in dims.items()}
    weights={"Revenue Quality":.10,"Margin Structure":.10,"FCF Quality":.12,"Balance Sheet":.10,"Working Capital":.08,"Capital Allocation":.10,"Moat / Competitive":.10,"Management Execution":.08,"Valuation":.12,"Risk / Reward":.10}
    return sum(dims[k]*weights[k] for k in weights),dims


def provenance_rows(ticker: str, companyfacts: dict, cik: str | None = None):
    """Record the exact XBRL tag selected for each modeled fundamental field.

    This does not prove an issuer's filing is error-free; it makes the extraction path auditable.
    """
    now = datetime.now(timezone.utc).isoformat()
    rows=[]
    source_url = f"https://data.sec.gov/api/xbrl/companyfacts/CIK{str(cik).zfill(10)}.json" if cik else "SEC Companyfacts"
    method_map={
        "revenue":"TTM from fiscal-quarter contexts; annual fallback",
        "gross_profit":"TTM from fiscal-quarter contexts; annual fallback",
        "operating_income":"TTM from fiscal-quarter contexts; annual fallback",
        "net_income":"TTM from fiscal-quarter contexts; annual fallback",
        "cfo":"TTM from fiscal-quarter contexts; annual fallback",
        "capex":"TTM from fiscal-quarter contexts; annual fallback",
        "sbc":"TTM from fiscal-quarter contexts; annual fallback",
        "buybacks":"TTM from fiscal-quarter contexts; annual fallback",
        "dividends":"TTM from fiscal-quarter contexts; annual fallback",
        "diluted_shares":"Latest diluted weighted-average duration fact; basic fallback handled per period",
        "basic_shares":"Per-period fallback only when diluted weighted-average shares are absent",
        "diluted_eps":"TTM from four explicit standalone diluted-EPS quarters; current FY fallback only when no newer quarter exists",
        "shares_outstanding":"Latest point-in-time common shares outstanding for market-cap / EV basis",
        "cash":"Latest balance-sheet instant",
        "receivables":"Latest balance-sheet instant",
        "inventory":"Latest balance-sheet instant",
        "payables":"Latest balance-sheet instant",
        "assets":"Latest balance-sheet instant",
        "liabilities":"Latest balance-sheet instant",
        "equity":"Latest balance-sheet instant",
        "short_borrowings":"Latest short-term borrowing instant; Commercial Paper fallback",
        "long_debt_current":"Latest current long-debt / finance-lease instant",
        "long_debt_noncurrent":"Latest noncurrent long-debt / finance-lease instant",
        "long_debt_total":"Fallback comprehensive long-debt instant",
        "pretax":"TTM from fiscal-quarter contexts; annual fallback",
        "tax":"TTM from fiscal-quarter contexts; annual fallback",
    }
    for metric,candidates in TAGS.items():
        units, tag, unit = sec.fact_units(companyfacts, candidates)
        if not tag:
            continue
        relevant=[x for x in units if x.get("form") in ("10-K","10-Q","10-K/A","10-Q/A")]
        latest_end=max((x.get("end") or "" for x in relevant), default="")
        latest_filed=max((x.get("filed") or "" for x in relevant), default="")
        rows.append({
            "ticker":ticker.upper(),"metric":metric,"xbrl_tag":tag,"unit":unit,
            "latest_end":latest_end or None,"latest_filed":latest_filed or None,
            "method":method_map.get(metric,"SEC XBRL extraction"),"source_url":source_url,"updated_at":now,
        })
    return rows


def revision_rows(ticker: str, companyfacts: dict):
    """Material SEC value changes for modeled facts. Review alerts, not fraud labels."""
    now=datetime.now(timezone.utc).isoformat()
    rows=[]
    # Use modeled tags only; debt is represented by its components.
    metrics=[m for m in TAGS if m not in ("debt_current","debt_noncurrent")]
    for metric in metrics:
        for r in sec.fact_revisions(companyfacts,TAGS[metric],years=10):
            rows.append({
                "ticker":ticker.upper(),"metric":metric,"xbrl_tag":r.get("tag"),"unit":r.get("unit"),
                "period_start":r.get("period_start"),"period_end":r.get("period_end"),
                "fiscal_year":r.get("fy"),"fiscal_period":r.get("fp"),
                "first_filed":r.get("first_filed"),"latest_filed":r.get("latest_filed"),
                "first_form":r.get("first_form"),"latest_form":r.get("latest_form"),
                "first_value":r.get("first_value"),"latest_value":r.get("latest_value"),
                "delta":r.get("delta"),"delta_pct":r.get("delta_pct"),"updated_at":now,
            })
    return rows
