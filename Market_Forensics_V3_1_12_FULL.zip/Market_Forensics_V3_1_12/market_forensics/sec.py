from __future__ import annotations
import requests, time, re, html as html_lib
from datetime import datetime, date
from collections import defaultdict

SEC_BASE = "https://data.sec.gov"
WWW = "https://www.sec.gov"

class SECError(RuntimeError):
    pass

def _headers(user_agent: str):
    if not user_agent or "@" not in user_agent:
        raise SECError("Set a truthful SEC User-Agent in Settings, including a contact email.")
    return {"User-Agent": user_agent, "Accept-Encoding": "gzip, deflate"}

def _get(url: str, user_agent: str):
    r = requests.get(url, headers=_headers(user_agent), timeout=45)
    if r.status_code != 200:
        raise SECError(f"SEC HTTP {r.status_code}: {r.text[:300]}")
    return r.json()

def ticker_map(user_agent: str):
    j = _get(f"{WWW}/files/company_tickers.json", user_agent)
    out = {}
    for v in j.values():
        out[str(v["ticker"]).upper()] = {
            "cik": str(v["cik_str"]).zfill(10),
            "name": v["title"]
        }
    return out

def resolve_ticker(ticker: str, user_agent: str):
    m = ticker_map(user_agent)
    t = ticker.upper()
    if t not in m:
        raise SECError(f"{t} not found in SEC ticker mapping.")
    return m[t]

def get_submissions(cik: str, user_agent: str):
    return _get(f"{SEC_BASE}/submissions/CIK{cik}.json", user_agent)

def get_companyfacts(cik: str, user_agent: str):
    return _get(f"{SEC_BASE}/api/xbrl/companyfacts/CIK{cik}.json", user_agent)

def companyfacts_not_applicable(meta: dict | None) -> bool:
    """Conservatively identify fund/ETF structures where operating-company Companyfacts may be N/A.

    A bare HTTP 404 is *not* enough to suppress an error: an incorrect CIK/mapping for an
    operating company must remain visible.  We only classify the 404 as expected N/A when SEC
    metadata itself identifies an ETF / unit-investment-fund structure.
    """
    meta=meta or {}
    name=str(meta.get("company_name") or meta.get("name") or "").upper()
    sic=str(meta.get("sic") or "").strip()
    desc=str(meta.get("sic_description") or "").upper()
    if sic in {"6722","6726"}:
        return True
    etp_markers=(" ETF ","ETF TRUST","EXCHANGE-TRADED FUND","EXCHANGE TRADED FUND","UNIT INVESTMENT TRUST")
    hay=f" {name} {desc} "
    return any(x in hay for x in etp_markers)

def company_metadata(ticker: str, user_agent: str):
    r = resolve_ticker(ticker, user_agent)
    sub = get_submissions(r["cik"], user_agent)
    ex = ""
    try:
        tickers = sub.get("tickers", [])
        exchanges = sub.get("exchanges", [])
        if ticker.upper() in [x.upper() for x in tickers]:
            ex = exchanges[[x.upper() for x in tickers].index(ticker.upper())]
    except Exception:
        pass
    return {
        "ticker": ticker.upper(), "cik": r["cik"],
        "company_name": sub.get("name") or r["name"],
        "exchange": ex, "sic": str(sub.get("sic") or ""),
        "sic_description": sub.get("sicDescription") or "",
        "fiscal_year_end": sub.get("fiscalYearEnd") or "",
    }

def filing_links(ticker: str, user_agent: str, forms=("10-K","10-Q","8-K","DEF 14A"), limit=20):
    meta = resolve_ticker(ticker, user_agent)
    sub = get_submissions(meta["cik"], user_agent)
    recent = sub.get("filings", {}).get("recent", {})
    rows = []
    n = len(recent.get("form", []))
    cik_int = str(int(meta["cik"]))
    for i in range(n):
        form = recent["form"][i]
        if form not in forms:
            continue
        acc = recent["accessionNumber"][i]
        primary = recent["primaryDocument"][i]
        acc_nodash = acc.replace("-", "")
        url = f"https://www.sec.gov/Archives/edgar/data/{cik_int}/{acc_nodash}/{primary}"
        rows.append({"form":form, "filed":recent["filingDate"][i],
                     "report_date":recent["reportDate"][i], "url":url})
        if len(rows) >= limit:
            break
    return rows


def _get_text(url: str, user_agent: str):
    r=requests.get(url,headers=_headers(user_agent),timeout=45)
    if r.status_code!=200:
        raise SECError(f"SEC HTTP {r.status_code}: {r.text[:300]}")
    return r.text


def _attrs(tag_text: str) -> dict:
    out={}
    for m in re.finditer(r"([:\w.-]+)\s*=\s*([\"'])(.*?)\2",tag_text,re.I|re.S):
        out[m.group(1).lower()]=html_lib.unescape(m.group(3))
    return out


def _ix_numeric(body: str, attrs: dict):
    if str(attrs.get('xsi:nil') or attrs.get('nil') or '').lower()=='true':
        return None
    txt=html_lib.unescape(re.sub(r'<[^>]+>','',body or ''))
    txt=txt.replace('\u00a0',' ').strip()
    if not txt or txt in {'—','-','–'}:
        return None
    neg=txt.startswith('(') and txt.endswith(')')
    txt=txt.strip('()').replace(',','').replace('$','').replace(' ','')
    try:v=float(txt)
    except Exception:return None
    try:scale=int(attrs.get('scale') or 0)
    except Exception:scale=0
    v*=10**scale
    if str(attrs.get('sign') or '')=='-' or neg:v=-v
    return v


def parse_inline_cover_shares(document_html: str, *, filed: str | None=None, form: str | None=None, source_url: str | None=None):
    """Parse current cover-page common shares directly from an Inline XBRL filing.

    Companyfacts can omit dimensional class-level EntityCommonStockSharesOutstanding facts.
    This parser reads the filing itself and sums distinct classes only on the same instant.
    """
    text=str(document_html or '')
    if not text:
        return None

    contexts={}
    cre=re.compile(r'<(?:[\w.-]+:)?context\b([^>]*)>(.*?)</(?:[\w.-]+:)?context\s*>',re.I|re.S)
    for m in cre.finditer(text):
        a=_attrs(m.group(1)); cid=a.get('id')
        if not cid:continue
        body=m.group(2)
        dm=re.search(r'<(?:[\w.-]+:)?instant\b[^>]*>\s*(\d{4}-\d{2}-\d{2})\s*</(?:[\w.-]+:)?instant\s*>',body,re.I|re.S)
        if not dm:continue
        dims=[]
        for em in re.finditer(r'<(?:[\w.-]+:)?explicitmember\b([^>]*)>(.*?)</(?:[\w.-]+:)?explicitmember\s*>',body,re.I|re.S):
            ea=_attrs(em.group(1)); member=html_lib.unescape(re.sub(r'<[^>]+>','',em.group(2))).strip()
            dims.append((str(ea.get('dimension') or ''),member))
        contexts[cid]={'instant':dm.group(1),'dims':dims}

    facts=[]
    fre=re.compile(r'<ix:nonfraction\b([^>]*)>(.*?)</ix:nonfraction\s*>',re.I|re.S)
    for m in fre.finditer(text):
        a=_attrs(m.group(1)); name=str(a.get('name') or '')
        if not name.lower().endswith('entitycommonstocksharesoutstanding'):
            continue
        cref=a.get('contextref')
        ctx=contexts.get(cref or '')
        if not ctx:continue
        v=_ix_numeric(m.group(2),a)
        if v is None or v<=0:continue
        facts.append({'value':float(v),'instant':ctx['instant'],'dims':ctx['dims'],'context':cref})
    if not facts:
        return None

    latest=max(x['instant'] for x in facts)
    rows=[x for x in facts if x['instant']==latest]

    ded=[]; seen=set()
    for x in rows:
        sig=(round(float(x['value']),6),tuple(sorted((str(d),str(m)) for d,m in x['dims'])))
        if sig in seen:continue
        seen.add(sig); ded.append(x)
    rows=ded

    nondim=[]
    for x in rows:
        if not x['dims'] and not any(abs(float(x['value'])-v)<=max(1.0,abs(v)*1e-9) for v in nondim):
            nondim.append(float(x['value']))
    if len(nondim)==1:
        return {'end':latest,'val':nondim[0],'filed':filed,'tag':'EntityCommonStockSharesOutstanding','unit':'shares',
                'aggregation_method':'INLINE_XBRL_CONSOLIDATED','components':[nondim[0]],'form':form,'source_url':source_url}

    def class_key(x):
        candidates=[]
        for dim,member in x['dims']:
            dl=str(dim).lower(); ml=str(member).lower()
            if ('class' in dl and 'stock' in dl) or ('class' in ml and ('stock' in ml or 'member' in ml)):
                candidates.append((dim,member))
        if candidates:
            return tuple(sorted(candidates))
        return tuple(sorted(x['dims'])) if x['dims'] else None

    class_rows={}
    for x in rows:
        k=class_key(x)
        if not k:continue
        if k in class_rows and abs(float(class_rows[k]['value'])-float(x['value']))>max(1.0,abs(float(x['value']))*1e-9):
            return None
        class_rows[k]=x
    if 2<=len(class_rows)<=8:
        vals=[float(x['value']) for x in class_rows.values()]
        return {'end':latest,'val':sum(vals),'filed':filed,'tag':'EntityCommonStockSharesOutstanding','unit':'shares',
                'aggregation_method':'INLINE_XBRL_MULTI_CLASS_SUM','components':sorted(vals),'form':form,'source_url':source_url}
    return None


def latest_cover_page_shares(ticker: str, user_agent: str, limit: int=4, cik: str | None=None):
    """Best-effort current shares from newest 10-Q/10-K Inline XBRL cover page.

    Current valuation only. Historical PIT replay continues to use filing-bounded Companyfacts.
    """
    if cik:
        sub=get_submissions(str(cik).zfill(10),user_agent)
        recent=sub.get("filings",{}).get("recent",{})
        links=[]; cik_int=str(int(str(cik)))
        n=len(recent.get("form",[]))
        allowed={"10-Q","10-K","10-Q/A","10-K/A"}
        for i in range(n):
            form=recent["form"][i]
            if form not in allowed: continue
            acc=recent["accessionNumber"][i]; primary=recent["primaryDocument"][i]
            links.append({"form":form,"filed":recent["filingDate"][i],"report_date":recent["reportDate"][i],
                          "url":f"https://www.sec.gov/Archives/edgar/data/{cik_int}/{acc.replace('-','')}/{primary}"})
            if len(links)>=max(1,int(limit)): break
    else:
        links=filing_links(ticker,user_agent,forms=("10-Q","10-K","10-Q/A","10-K/A"),limit=max(1,int(limit)))
    last_error=None
    for row in links:
        try:
            doc=_get_text(row['url'],user_agent)
            rec=parse_inline_cover_shares(doc,filed=row.get('filed'),form=row.get('form'),source_url=row.get('url'))
            if rec:return rec
        except Exception as e:
            last_error=e
        time.sleep(.12)
    if last_error:
        raise SECError(f"Inline XBRL cover-share recovery unavailable: {last_error}")
    return None

def _namespace(facts, ns):
    return facts.get("facts", {}).get(ns, {})

def fact_units(facts, candidates):
    """candidates: list of (namespace, tag). Return first tag with units."""
    for ns, tag in candidates:
        obj = _namespace(facts, ns).get(tag)
        if obj and obj.get("units"):
            # Prefer USD, shares, USD/shares, pure, otherwise first.
            units = obj["units"]
            for u in ("USD", "shares", "USD/shares", "pure"):
                if u in units:
                    return units[u], tag, u
            u = next(iter(units))
            return units[u], tag, u
    return [], None, None

def annual_series(facts, candidates, years=10):
    """Annual duration series with per-period tag fallback and true earliest-public PIT values.

    For the current/restated series the highest-priority available concept wins for a period.
    For point-in-time replay, however, `first_filed/first_val` come from the earliest equivalent
    candidate concept actually published for that same economic period.  A later taxonomy
    migration therefore cannot rewrite when the market could first have known the number.
    """
    records=defaultdict(list)
    for priority,(ns,tag_name) in enumerate(candidates):
        units, tag, unit = fact_units(facts, [(ns,tag_name)])
        for x in units:
            if x.get("form") not in ("10-K","10-K/A") or not x.get("start") or not x.get("end"):
                continue
            try:dur=(date.fromisoformat(x["end"])-date.fromisoformat(x["start"])).days
            except Exception:continue
            if 300 <= dur <= 430:
                records[x["end"]].append((priority,tag,unit,x))
    out=[]
    for end_date in sorted(records)[-years:]:
        rows=records[end_date]
        # Current/restated value: newest public equivalent concept wins; candidate priority only
        # breaks ties within the same filing. This preserves genuine comparative restatements
        # across taxonomy migrations instead of freezing an older preferred tag forever.
        latest_filed=max(str(r[3].get("filed") or "") for r in rows)
        latest_rows=[r for r in rows if str(r[3].get("filed") or "")==latest_filed]
        latest_rows.sort(key=lambda r:(-r[0],str(r[3].get("accn") or "")))
        latest_priority,tag,unit,latest=latest_rows[-1]
        # PIT value: earliest filing across all equivalent candidate concepts.
        chronological=sorted(rows,key=lambda r:(r[3].get("filed", ""),r[0],r[3].get("accn", "")))
        first=chronological[0][3]
        vals=[]
        for _,_,_,x in rows:
            try:v=float(x["val"])
            except Exception:continue
            if not any(abs(v-d)<=max(1.0,abs(d)*1e-9) for d in vals):vals.append(v)
        try:fy=date.fromisoformat(end_date).year; latest_val=float(latest["val"]); first_val=float(first["val"])
        except Exception:continue
        out.append({"fy":fy,"end":end_date,"val":latest_val,"filed":latest.get("filed"),
                    "first_filed":first.get("filed"),"first_val":first_val,
                    "revision_count":max(0,len(vals)-1),"tag":tag,"unit":unit,"tag_priority":latest_priority})
    return out



def annual_series_unambiguous(facts, candidates, years=10):
    """Conservative annual duration series for visualization/reconciliation layers.

    Companyfacts can flatten dimensional facts into the same concept/end-date bucket.  For
    Financial Flows we must not accidentally pick a segment/geography amount as the consolidated
    statement line.  This helper therefore accepts an annual period only when the latest filing
    exposes either one unique value or one unique framed (normally non-dimensional) value.
    Candidate order is used only as a tie-breaker after freshness. Ambiguous periods are omitted.
    """
    by_end=defaultdict(list)
    for priority,(ns,tag_name) in enumerate(candidates):
        units, tag, unit = fact_units(facts,[(ns,tag_name)])
        for x in units:
            if x.get("form") not in ("10-K","10-K/A") or not x.get("start") or not x.get("end"):
                continue
            try:
                dur=(date.fromisoformat(str(x["end"])[:10])-date.fromisoformat(str(x["start"])[:10])).days
            except Exception:
                continue
            if 300 <= dur <= 430:
                by_end[str(x.get("end"))].append((priority,tag,unit,x))

    out=[]
    for end_date in sorted(by_end)[-years:]:
        rows=by_end[end_date]
        latest_filed=max((str(r[3].get("filed") or "") for r in rows),default="")
        latest=[r for r in rows if str(r[3].get("filed") or "")==latest_filed]
        # Prefer the highest-priority candidate concept available in the freshest filing.
        priorities=sorted({r[0] for r in latest})
        selected=None
        for pri in priorities:
            cand=[r for r in latest if r[0]==pri]
            vals=[]
            for r in cand:
                try:v=float(r[3].get("val"))
                except Exception:continue
                if not any(abs(v-y)<=max(1.0,abs(y)*1e-9) for y in vals): vals.append(v)
            if len(vals)==1:
                selected=(cand[-1],vals[0],"UNIQUE")
                break
            framed=[]
            framed_rows=[]
            for r in cand:
                if not r[3].get("frame"):
                    continue
                try:v=float(r[3].get("val"))
                except Exception:continue
                if not any(abs(v-y)<=max(1.0,abs(y)*1e-9) for y in framed):
                    framed.append(v); framed_rows.append(r)
            if len(framed)==1:
                selected=(framed_rows[-1],framed[0],"FRAMED")
                break
        if not selected:
            continue
        (priority,tag,unit,x),val,resolution=selected
        try:fy=date.fromisoformat(end_date[:10]).year
        except Exception:continue
        out.append({
            "fy":fy,"end":end_date,"val":val,"filed":x.get("filed"),
            "tag":tag,"unit":unit,"tag_priority":priority,"resolution":resolution
        })
    return out

def latest_instant(facts, candidates):
    """Freshest eligible instant fact across equivalent candidate concepts.

    Candidate order breaks ties, but a stale legacy concept may not override a fresher equivalent
    concept merely because it appears first in the taxonomy preference list.
    """
    rows=[]
    for priority,(ns,tag_name) in enumerate(candidates):
        units, tag, unit = fact_units(facts,[(ns,tag_name)])
        for x in units:
            if x.get("form") not in ("10-K","10-Q","10-K/A","10-Q/A") or not x.get("end") or x.get("start"):
                continue
            rows.append((str(x.get("end") or ""),str(x.get("filed") or ""),-priority,tag,unit,x))
    if not rows:return None
    rows.sort(key=lambda r:(r[0],r[1],r[2],str(r[3]),str(r[4]),str((r[5] or {}).get("accn") or "")));_,_,_,tag,unit,x=rows[-1]
    return {"end":x.get("end"),"val":float(x["val"]),"filed":x.get("filed"),"tag":tag,"unit":unit}


def _unique_instant_value(records, *, allow_multiclass=False):
    """Resolve one point-in-time share fact from a same-date/same-filing set.

    SEC Companyfacts flattens dimensioned cover-page share facts.  Multi-class issuers such as
    NIKE and UPS therefore legitimately expose two distinct ``EntityCommonStockSharesOutstanding``
    values for the same filing (Class A + Class B).  V3.1.8 resolves that deterministically:

    * one unique value -> use it;
    * one non-dimensional framed total alongside class facts -> use the framed total once (do not double count);
    * otherwise, for a small same-accession multi-class set, sum the unique class values.

    Anything more complex still fails closed.  This prevents the old behaviour where a valid
    current multi-class filing was rejected and the parser silently fell back to a stale 2010/2015
    single-class taxonomy fact.
    """
    if not records:
        return None

    # Prefer one accession.  If an amendment and an original happen to share a filing date, the
    # lexicographically latest accession is the most recent deterministic context.
    by_acc=defaultdict(list)
    for x in records:
        by_acc[str(x.get("accn") or "")].append(x)
    if len(by_acc)>1:
        records=by_acc[sorted(by_acc)[-1]]

    vals=[]
    for x in records:
        try:v=float(x.get("val"))
        except Exception:continue
        if v<=0:continue
        if not any(abs(v-y)<=max(1.0,abs(y)*1e-9) for y in vals):vals.append(v)
    vals=sorted(vals)
    if len(vals)==1:
        return records[-1] | {"val":vals[0],"aggregation_method":"SINGLE","components":[vals[0]]}
    if not allow_multiclass or not (2 <= len(vals) <= 4):
        return None

    # A non-dimensional instant can carry an SEC ``frame`` while class-dimensioned facts usually
    # do not. If exactly one framed value exists, treat it as the consolidated company-wide total
    # and do not add class rows on top of it.
    framed=[]
    for x in records:
        if not x.get("frame"):continue
        try:v=float(x.get("val"))
        except Exception:continue
        if v>0 and not any(abs(v-y)<=max(1.0,abs(y)*1e-9) for y in framed):framed.append(v)
    if len(framed)==1:
        return records[-1] | {"val":framed[0],"aggregation_method":"CONSOLIDATED_FRAME","components":vals}

    # Otherwise treat the distinct values as separate common-share classes from the same cover
    # filing. SEC cover-page DEI share facts for dual/multi-class issuers are dimensioned this way.
    total=sum(vals)
    return records[-1] | {"val":total,"aggregation_method":"MULTI_CLASS_SUM","components":vals}


def latest_unambiguous_instant(facts, candidates, forms=("10-K","10-Q","10-K/A","10-Q/A")):
    """Freshest point-in-time common-share fact, with deterministic multi-class recovery.

    A stale legacy tag is never allowed to win simply because the freshest equivalent concept is
    complex. If the selected resolvable fact is more than ~6 months older than the freshest share
    disclosure seen across equivalent concepts, return None and let the diluted-share fallback or
    manual recovery handle it instead of silently jumping back years.
    """
    choices=[]; freshest_seen=None
    for priority,(ns,tag_name) in enumerate(candidates):
        units, tag, unit = fact_units(facts,[(ns,tag_name)])
        xs=[x for x in units if x.get("form") in forms and x.get("end") and not x.get("start")]
        if not xs:continue
        latest_end=max(str(x.get("end")) for x in xs); end_rows=[x for x in xs if str(x.get("end"))==latest_end]
        latest_filed=max((str(x.get("filed") or "") for x in end_rows),default="")
        if freshest_seen is None or (latest_end,latest_filed)>freshest_seen: freshest_seen=(latest_end,latest_filed)
        final=[x for x in end_rows if str(x.get("filed") or "")==latest_filed]
        x=_unique_instant_value(final, allow_multiclass=(tag_name=="EntityCommonStockSharesOutstanding"))
        if x:choices.append((latest_end,latest_filed,-priority,tag,unit,x))
    if not choices:return None
    choices.sort(key=lambda r:(r[0],r[1],r[2],str(r[3]),str(r[4]))); selected=choices[-1]
    if freshest_seen:
        try:
            fresh_d=date.fromisoformat(freshest_seen[0][:10]); sel_d=date.fromisoformat(str(selected[0])[:10])
            if (fresh_d-sel_d).days>183:return None
        except Exception:pass
    _,_,_,tag,unit,x=selected
    return {"end":x.get("end"),"val":float(x["val"]),"filed":x.get("filed"),"tag":tag,"unit":unit,
            "aggregation_method":x.get("aggregation_method") or "SINGLE","components":x.get("components") or [float(x["val"])]}


def latest_unambiguous_instant_as_of_filing(facts, candidates, filed_date, max_age_days=240):
    """Historical unambiguous instant, bounded by what was public at the requested filing date."""
    try:cutoff=date.fromisoformat(str(filed_date)[:10])
    except Exception:return None
    choices=[]
    for priority,(ns,tag_name) in enumerate(candidates):
        units, tag, unit = fact_units(facts,[(ns,tag_name)]); eligible=[]
        for x in units:
            if x.get("form") not in ("10-K","10-Q","10-K/A","10-Q/A") or x.get("start") or not x.get("end"):
                continue
            try:end_d=date.fromisoformat(str(x.get("end"))[:10]); filed_d=date.fromisoformat(str(x.get("filed"))[:10])
            except Exception:continue
            if filed_d>cutoff or end_d>cutoff or (cutoff-end_d).days>int(max_age_days):continue
            eligible.append((end_d,filed_d,x))
        if not eligible:continue
        latest_end=max(x[0] for x in eligible); erows=[x for x in eligible if x[0]==latest_end]
        latest_filed=max(x[1] for x in erows); final=[x[2] for x in erows if x[1]==latest_filed]
        x=_unique_instant_value(final, allow_multiclass=(tag_name=="EntityCommonStockSharesOutstanding"))
        if x:choices.append((latest_end,latest_filed,-priority,tag,unit,x))
    if not choices:return None
    choices.sort(key=lambda r:(r[0],r[1],r[2],str(r[3]),str(r[4])));_,_,_,tag,unit,x=choices[-1]
    return {"end":x.get("end"),"val":float(x["val"]),"filed":x.get("filed"),"tag":tag,"unit":unit,
            "aggregation_method":x.get("aggregation_method") or "SINGLE","components":x.get("components") or [float(x["val"])]}


def latest_instant_as_of_filing(facts, candidates, filed_date, max_age_days=240):
    """Freshest equivalent instant fact actually public by *filed_date*."""
    try:cutoff=date.fromisoformat(str(filed_date)[:10])
    except Exception:return None
    rows=[]
    for priority,(ns,tag_name) in enumerate(candidates):
        units, tag, unit = fact_units(facts,[(ns,tag_name)])
        for x in units:
            if x.get("form") not in ("10-K","10-Q","10-K/A","10-Q/A") or x.get("start") or not x.get("end"):
                continue
            try:end_d=date.fromisoformat(str(x.get("end"))[:10]); filed_d=date.fromisoformat(str(x.get("filed"))[:10])
            except Exception:continue
            if filed_d>cutoff or end_d>cutoff or (cutoff-end_d).days>int(max_age_days):continue
            rows.append((end_d,filed_d,-priority,tag,unit,x))
    if not rows:return None
    rows.sort(key=lambda r:(r[0],r[1],r[2],str(r[3]),str(r[4]),str((r[5] or {}).get("accn") or "")));_,_,_,tag,unit,x=rows[-1]
    return {"end":x.get("end"),"val":float(x["val"]),"filed":x.get("filed"),"tag":tag,"unit":unit}


def annual_instant_series(facts, candidates, years=10):
    """Annual instant facts with per-period fallback and earliest-public PIT preservation."""
    records=defaultdict(list)
    for priority,(ns,tag_name) in enumerate(candidates):
        units, tag, unit = fact_units(facts, [(ns,tag_name)])
        for x in units:
            if x.get("form") not in ("10-K","10-K/A") or x.get("start") or not x.get("end"):
                continue
            records[x["end"]].append((priority,tag,unit,x))
    out=[]
    for end_date in sorted(records)[-years:]:
        rows=records[end_date]
        latest_filed=max(str(r[3].get("filed") or "") for r in rows)
        latest_rows=[r for r in rows if str(r[3].get("filed") or "")==latest_filed]
        latest_rows.sort(key=lambda r:(-r[0],str(r[3].get("accn") or "")))
        latest_priority,tag,unit,latest=latest_rows[-1]
        chronological=sorted(rows,key=lambda r:(r[3].get("filed", ""),r[0],r[3].get("accn", "")))
        first=chronological[0][3];vals=[]
        for _,_,_,x in rows:
            try:v=float(x["val"])
            except Exception:continue
            if not any(abs(v-d)<=max(1.0,abs(d)*1e-9) for d in vals):vals.append(v)
        try:fy=date.fromisoformat(end_date).year;latest_val=float(latest["val"]);first_val=float(first["val"])
        except Exception:continue
        out.append({"fy":fy,"end":end_date,"val":latest_val,"filed":latest.get("filed"),
                    "first_filed":first.get("filed"),"first_val":first_val,
                    "revision_count":max(0,len(vals)-1),"tag":tag,"unit":unit,"tag_priority":latest_priority})
    return out


def latest_duration_fact(facts, candidates, forms=("10-Q","10-K","10-Q/A","10-K/A")):
    """Latest duration disclosure, useful for weighted-average shares (do not sum shares across quarters)."""
    units, tag, unit = fact_units(facts, candidates)
    xs=[]
    for x in units:
        if x.get("form") not in forms or not x.get("end"):
            continue
        if not x.get("start"):
            continue
        try:
            dur=(date.fromisoformat(x["end"])-date.fromisoformat(x["start"])).days
        except Exception:
            continue
        # Prefer a recent standalone quarter when available, otherwise latest annual.
        priority = 0 if 60 <= dur <= 120 else 1 if 300 <= dur <= 430 else 2
        xs.append((x.get("end",""), -priority, x.get("filed",""), x))
    if not xs:
        return None
    xs.sort(key=lambda r:(str(r[0]),int(r[1]),str(r[2]),str((r[3] or {}).get("accn") or "")))
    x=xs[-1][3]
    return {"end":x.get("end"),"val":float(x["val"]),"filed":x.get("filed"),"tag":tag,"unit":unit}


def period_quarters(facts, candidates, max_years=6):
    """Build standalone quarters primarily from real start/end dates, not SEC `fy` metadata.

    Direct 3-month 10-Q contexts are preferred. Q4 is inferred from the annual fact minus
    the first three direct quarters when the issuer does not report a standalone Q4 context.
    This makes TTM reconstruction more robust to comparative facts whose `fy` metadata refers
    to the filing year rather than the economic period.
    """
    units, tag, unit = fact_units(facts, candidates)
    direct_by_end = defaultdict(list)
    annual_by_end = defaultdict(list)
    for x in units:
        if x.get("form") not in ("10-K","10-Q","10-K/A","10-Q/A") or not x.get("start") or not x.get("end"):
            continue
        try:
            start = date.fromisoformat(x["start"]); end = date.fromisoformat(x["end"]); dur=(end-start).days
        except Exception:
            continue
        if 60 <= dur <= 120:
            direct_by_end[x["end"]].append(x)
        if x.get("form") in ("10-K","10-K/A") and 300 <= dur <= 430:
            annual_by_end[x["end"]].append(x)

    direct=[]
    for end_date,xs in direct_by_end.items():
        xs=sorted(xs,key=lambda x:(x.get("filed", ""),x.get("accn", "")))
        x=xs[-1]
        try: v=float(x["val"])
        except Exception: continue
        direct.append({"start":x["start"],"end":x["end"],"val":v,"tag":tag,"unit":unit,"source":"direct quarter"})
    direct.sort(key=lambda x:x["end"])

    inferred=[]
    annual_periods=[]
    for end_date,xs in annual_by_end.items():
        xs=sorted(xs,key=lambda x:(x.get("filed", ""),x.get("accn", "")))
        a=xs[-1]
        try:
            av=float(a["val"]); astart=date.fromisoformat(a["start"]); aend=date.fromisoformat(a["end"])
        except Exception:
            continue
        annual_periods.append((astart,aend,av,a))
    annual_periods.sort(key=lambda x:x[1])
    annual_periods=annual_periods[-max_years:]

    for astart,aend,av,a in annual_periods:
        qs=[]
        for q in direct:
            try: qs_date_start=date.fromisoformat(q["start"]); qs_date_end=date.fromisoformat(q["end"])
            except Exception: continue
            if astart <= qs_date_start <= qs_date_end <= aend:
                qs.append(q)
        # If a direct quarter already ends on the FY end, Q4 is explicitly available.
        if any(q["end"] == aend.isoformat() for q in qs):
            continue
        # Most 10-Q issuers expose direct Q1/Q2/Q3 facts. Infer Q4 only with exactly
        # three distinct direct quarter endpoints to avoid subtracting duplicate contexts.
        uniq={q["end"]:q for q in qs}
        qlist=sorted(uniq.values(),key=lambda q:q["end"])
        if len(qlist) == 3:
            q4=av-sum(q["val"] for q in qlist)
            inferred.append({"start":None,"end":aend.isoformat(),"val":q4,"tag":tag,"unit":unit,"source":"annual less Q1-Q3"})

    combined={q["end"]:q for q in inferred}
    for q in direct:
        combined[q["end"]]=q  # direct evidence wins
    out=sorted(combined.values(),key=lambda q:q["end"])
    return out[-(max_years*4):]


def direct_standalone_quarters(facts, candidates, max_years=6):
    """Return only explicitly reported standalone quarterly duration facts.

    Unlike :func:`period_quarters`, this helper NEVER infers Q4 by subtracting Q1-Q3 from an
    annual amount.  That subtraction is valid for additive flow measures such as revenue or
    cash flow, but it is mathematically invalid for per-share ratios such as EPS.
    """
    choices=[]
    for priority,(ns,tag_name) in enumerate(candidates):
        units, tag, unit = fact_units(facts,[(ns,tag_name)])
        by_end=defaultdict(list)
        for x in units:
            if x.get("form") not in ("10-Q","10-Q/A","10-K","10-K/A") or not x.get("start") or not x.get("end"):
                continue
            try:
                start=date.fromisoformat(str(x["start"])[:10]); end=date.fromisoformat(str(x["end"])[:10]); dur=(end-start).days
            except Exception:
                continue
            if 60 <= dur <= 120:
                by_end[str(x["end"])[:10]].append(x)
        rows=[]
        for end_date,xs in by_end.items():
            # Latest filing wins for current/fully-restated current-basis EPS history.
            xs=sorted(xs,key=lambda x:(str(x.get("filed") or ""),str(x.get("accn") or "")))
            x=xs[-1]
            try:v=float(x["val"])
            except Exception:continue
            rows.append({"start":x.get("start"),"end":end_date,"filed":x.get("filed"),"val":v,"tag":tag,"unit":unit,"source":"direct quarter"})
        rows.sort(key=lambda x:x["end"])
        if rows:
            choices.append((rows[-1]["end"],-priority,rows[-(max_years*4):]))
    if not choices:
        return []
    choices.sort(key=lambda r:(str(r[0]),int(r[1])))
    return choices[-1][2]


def ttm_eps_snapshot(facts, candidates):
    """Return current TTM diluted EPS plus the filing basis used for split normalization."""
    choices=[]
    for priority,cand in enumerate(candidates):
        qs=direct_standalone_quarters(facts,[cand],max_years=6)
        if len(qs)>=4:
            last=qs[-4:]
            try:
                first_start=date.fromisoformat(str(last[0].get("start"))[:10])
                last_end=date.fromisoformat(str(last[-1].get("end"))[:10])
                span=(last_end-first_start).days
            except Exception:
                span=9999
            if 300 <= span <= 430 and len({x.get("end") for x in last})==4:
                filed=max(str(x.get("filed") or "") for x in last)
                choices.append((str(last[-1].get("end") or ""),3,-priority,
                                {"value":sum(float(x["val"]) for x in last),"filed":filed or None,
                                 "end":last[-1].get("end"),"source":"4 direct quarters",
                                 "components":[dict(x) for x in last]}))
                continue
        ann=annual_series(facts,[cand],years=1)
        if ann:
            annual_end=str(ann[-1].get("end") or "")
            newer_direct=any(str(q.get("end") or "")>annual_end for q in qs)
            if not newer_direct:
                a=ann[-1]
                choices.append((annual_end,1,-priority,
                                {"value":float(a["val"]),"filed":a.get("filed"),"end":a.get("end"),"source":"latest reported FY",
                                 "components":[{"val":float(a["val"]),"filed":a.get("filed"),"end":a.get("end"),"source":"annual reported EPS"}]}))
    if not choices:
        return None
    choices.sort(key=lambda r:(str(r[0]),int(r[1]),int(r[2])))
    return choices[-1][3]


def ttm_eps_value(facts, candidates):
    """Current TTM diluted EPS without invalid Q4 arithmetic."""
    snap=ttm_eps_snapshot(facts,candidates)
    return snap.get("value") if snap else None


def fiscal_quarters(facts, candidates, max_years=4):
    """Reconstruct standalone fiscal quarters from YTD 10-Q plus annual 10-K."""
    units, tag, unit = fact_units(facts, candidates)
    annual = {}
    ytd = defaultdict(dict)
    for x in units:
        form, fp, fy = x.get("form"), x.get("fp"), x.get("fy")
        if fy is None or not x.get("start") or not x.get("end"):
            continue
        fy = int(fy)
        try:
            dur = (date.fromisoformat(x["end"]) - date.fromisoformat(x["start"])).days
        except Exception:
            continue
        if form in ("10-K","10-K/A") and fp == "FY" and 300 <= dur <= 430:
            cur = annual.get(fy)
            if cur is None or x.get("filed","") > cur.get("filed",""):
                annual[fy] = x
        elif form in ("10-Q","10-Q/A") and fp in ("Q1","Q2","Q3") and 60 <= dur <= 310:
            # Prefer longest duration context => YTD, latest filing if tied.
            cur = ytd[fy].get(fp)
            if cur is None:
                ytd[fy][fp] = x
            else:
                try:
                    curdur = (date.fromisoformat(cur["end"]) - date.fromisoformat(cur["start"])).days
                except Exception:
                    curdur = -1
                if dur > curdur or (dur == curdur and x.get("filed","") > cur.get("filed","")):
                    ytd[fy][fp] = x

    records = []
    fys = sorted(set(annual) | set(ytd))[-max_years:]
    for fy in fys:
        prev = 0.0
        for fp in ("Q1","Q2","Q3"):
            x = ytd.get(fy, {}).get(fp)
            if x is None:
                continue
            v = float(x["val"])
            q = v - prev
            records.append({"fy":fy,"fp":fp,"end":x["end"],"val":q,"tag":tag,"unit":unit})
            prev = v
        if fy in annual:
            a = annual[fy]
            q4 = float(a["val"]) - prev
            records.append({"fy":fy,"fp":"Q4","end":a["end"],"val":q4,"tag":tag,"unit":unit})
    records.sort(key=lambda x: x["end"])
    return records


def _valid_four_quarter_window(rows):
    """Reject accidental 'TTM' sums built from four non-consecutive quarter observations."""
    if len(rows)!=4 or len({str(x.get("end") or "")[:10] for x in rows})!=4:
        return False
    try:
        ends=sorted(date.fromisoformat(str(x.get("end"))[:10]) for x in rows)
    except Exception:
        return False
    span=(ends[-1]-ends[0]).days
    if not (240 <= span <= 310):
        return False
    gaps=[(b-a).days for a,b in zip(ends,ends[1:])]
    return all(55 <= g <= 125 for g in gaps)


def ttm_value(facts, candidates):
    """Best current TTM across candidate tags without letting taxonomy migration truncate data."""
    choices=[]
    for priority,cand in enumerate(candidates):
        single=[cand]
        qs=period_quarters(facts,single,max_years=6)
        if len(qs)>=4:
            last=qs[-4:]
            if _valid_four_quarter_window(last):
                end_date=max(str(x.get("end") or "") for x in last)
                choices.append((end_date,3,-priority,sum(float(x["val"]) for x in last)))
                continue
        fq=fiscal_quarters(facts,single,max_years=5)
        if len(fq)>=4:
            last=fq[-4:]
            if _valid_four_quarter_window(last):
                end_date=max(str(x.get("end") or "") for x in last)
                choices.append((end_date,2,-priority,sum(float(x["val"]) for x in last)))
                continue
        ann=annual_series(facts,single,years=1)
        if ann:
            choices.append((str(ann[-1].get("end") or ""),1,-priority,float(ann[-1]["val"])))
    if choices:
        choices.sort();return choices[-1][3]
    return None


def fact_revisions(facts, candidates, years=10):
    """Return material value changes for the same SEC concept/period across filings.

    A change is an alert to review, not automatically evidence of wrongdoing: later filings can
    reclassify, restate, amend or present comparative periods differently.
    """
    units, tag, unit = fact_units(facts, candidates)
    groups=defaultdict(list)
    for x in units:
        if x.get("form") not in ("10-K","10-Q","10-K/A","10-Q/A") or not x.get("end"):
            continue
        key=(x.get("start") or "INSTANT", x.get("end"), x.get("fp") or "")
        groups[key].append(x)
    rows=[]
    for key,xs in groups.items():
        xs=sorted(xs,key=lambda x:(x.get("filed", ""),x.get("accn", "")))
        if len(xs)<2:
            continue
        first=xs[0]; latest=xs[-1]
        try:
            fv=float(first["val"]); lv=float(latest["val"])
        except Exception:
            continue
        tol=max(1.0,abs(fv)*1e-7,abs(lv)*1e-7)
        if abs(lv-fv)<=tol:
            continue
        delta_pct=(lv/fv-1) if fv not in (0,None) else None
        rows.append({"tag":tag,"unit":unit,"period_start":None if key[0]=="INSTANT" else key[0],
                     "period_end":key[1],"fy":date.fromisoformat(key[1]).year,"fp":key[2],"first_filed":first.get("filed"),
                     "latest_filed":latest.get("filed"),"first_form":first.get("form"),
                     "latest_form":latest.get("form"),"first_value":fv,"latest_value":lv,
                     "delta":lv-fv,"delta_pct":delta_pct})
    rows.sort(key=lambda r:(r.get("period_end") or "",r.get("latest_filed") or ""),reverse=True)
    return rows[:50]


def _get_text(url: str, user_agent: str):
    r = requests.get(url, headers=_headers(user_agent), timeout=45)
    if r.status_code != 200:
        raise SECError(f"SEC HTTP {r.status_code}: {r.text[:300]}")
    return r.text


def recent_filing_records(ticker: str, user_agent: str, forms=("10-K","10-Q","8-K"), limit=40):
    """Recent filing metadata including accession and primary-document URLs."""
    meta = resolve_ticker(ticker, user_agent)
    sub = get_submissions(meta["cik"], user_agent)
    recent = sub.get("filings", {}).get("recent", {})
    rows=[]; cik_int=str(int(meta["cik"])); n=len(recent.get("form", []))
    for i in range(n):
        form=recent["form"][i]
        if form not in forms: continue
        acc=recent["accessionNumber"][i]; primary=recent["primaryDocument"][i]; acc_nodash=acc.replace("-","")
        base=f"https://www.sec.gov/Archives/edgar/data/{cik_int}/{acc_nodash}"
        rows.append({
            "ticker":ticker.upper(),"cik":meta["cik"],"form":form,"filed":recent["filingDate"][i],
            "report_date":recent["reportDate"][i],"accession":acc,"primary_document":primary,
            "primary_url":f"{base}/{primary}","index_url":f"{base}/{acc}-index.htm","archive_base":base,
        })
        if len(rows)>=limit: break
    return rows


def fetch_filing_primary(record: dict, user_agent: str) -> str:
    return _get_text(record["primary_url"], user_agent)


def filing_exhibit_links(record: dict, user_agent: str, exhibit_types=("EX-99.1","EX-99.01","EX-99"), max_links=3):
    """Best-effort official SEC filing-index parser for earnings-release / presentation exhibits."""
    try:
        raw=_get_text(record["index_url"],user_agent)
    except Exception:
        return []
    # Filing index rows generally contain a document link followed by a filing type cell.
    links=[]
    row_pat=re.compile(r"<tr[^>]*>(.*?)</tr>",re.I|re.S)
    href_pat=re.compile(r'href=["\']([^"\']+)["\']',re.I)
    text_pat=re.compile(r"<[^>]+>")
    for row in row_pat.findall(raw):
        plain=re.sub(r"\s+"," ",text_pat.sub(" ",row)).strip()
        if not any(x.lower() in plain.lower() for x in exhibit_types):
            continue
        hm=href_pat.search(row)
        if not hm: continue
        href=hm.group(1)
        if href.startswith("http"): url=href
        elif href.startswith("/"): url="https://www.sec.gov"+href
        else: url=record["archive_base"].rstrip("/")+"/"+href
        if url not in links:
            links.append(url)
        if len(links)>=max_links: break
    return links
