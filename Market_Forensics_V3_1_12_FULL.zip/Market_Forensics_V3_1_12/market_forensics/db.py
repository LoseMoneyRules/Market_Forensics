from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from .config import DB_PATH


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _backup_pre_v2_once():
    """Create a consistent one-time SQLite backup before V2 schema migration."""
    if not DB_PATH.exists():
        return None
    backup_path = DB_PATH.with_name("market_forensics_pre_v2_backup.sqlite")
    if backup_path.exists():
        return backup_path
    src = sqlite3.connect(DB_PATH)
    dst = sqlite3.connect(backup_path)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    return backup_path


SCHEMA = r"""
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS watchlist (
  ticker TEXT PRIMARY KEY,
  added_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS coverage (
  ticker TEXT PRIMARY KEY,
  status TEXT DEFAULT 'RESEARCH',
  priority INTEGER DEFAULT 3,
  company_type TEXT DEFAULT 'Generic',
  tags TEXT DEFAULT '',
  portfolio_state TEXT DEFAULT 'NO POSITION',
  shares_owned REAL DEFAULT 0,
  avg_cost REAL DEFAULT 0,
  thesis_horizon_months INTEGER DEFAULT 24,
  notes TEXT DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);


CREATE TABLE IF NOT EXISTS portfolio_positions (
  ticker TEXT PRIMARY KEY,
  side TEXT NOT NULL DEFAULT 'LONG',
  shares REAL NOT NULL DEFAULT 0,
  avg_cost REAL NOT NULL DEFAULT 0,
  tags TEXT DEFAULT '',
  notes TEXT DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS company_meta (
  ticker TEXT PRIMARY KEY,
  cik TEXT,
  company_name TEXT,
  exchange TEXT,
  sic TEXT,
  sic_description TEXT,
  fiscal_year_end TEXT,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS daily_bars (
  ticker TEXT NOT NULL,
  trade_date TEXT NOT NULL,
  open REAL, high REAL, low REAL, close REAL,
  raw_close REAL, split_adjusted_close REAL, split_factor REAL DEFAULT 1.0,
  basis_verified INTEGER DEFAULT 0, split_factor_verified INTEGER DEFAULT 0, price_basis TEXT DEFAULT '',
  volume REAL, trade_count REAL, vwap REAL,
  feed TEXT,
  updated_at TEXT,
  PRIMARY KEY (ticker, trade_date)
);

CREATE TABLE IF NOT EXISTS finra_short_volume (
  ticker TEXT NOT NULL,
  trade_date TEXT NOT NULL,
  short_volume REAL,
  short_exempt_volume REAL,
  total_reported_volume REAL,
  short_pct REAL,
  market TEXT,
  updated_at TEXT,
  PRIMARY KEY (ticker, trade_date)
);

CREATE TABLE IF NOT EXISTS short_interest (
  ticker TEXT NOT NULL,
  settlement_date TEXT NOT NULL,
  publication_date TEXT NOT NULL,
  shares_short REAL NOT NULL,
  days_to_cover REAL,
  source TEXT DEFAULT 'FINRA/manual',
  notes TEXT,
  created_at TEXT NOT NULL,
  PRIMARY KEY (ticker, settlement_date)
);

CREATE TABLE IF NOT EXISTS flow_daily (
  ticker TEXT NOT NULL,
  trade_date TEXT NOT NULL,
  feed TEXT,
  large_buy REAL, large_sell REAL, net_large REAL,
  whale_buy REAL, whale_sell REAL, net_whale REAL,
  large_turnover_pct REAL, whale_turnover_pct REAL,
  avg_aggressive_buy REAL, avg_aggressive_sell REAL,
  quote_coverage REAL,
  large_threshold REAL, very_large_threshold REAL, whale_threshold REAL,
  trade_count REAL, classified_count REAL,
  updated_at TEXT,
  PRIMARY KEY (ticker, trade_date)
);

CREATE TABLE IF NOT EXISTS fundamentals (
  ticker TEXT NOT NULL,
  period_key TEXT NOT NULL,
  period_end TEXT,
  fiscal_year INTEGER,
  period_type TEXT,
  revenue REAL, gross_profit REAL, operating_income REAL, net_income REAL,
  cfo REAL, capex REAL, fcf REAL, sbc REAL, buybacks REAL, dividends REAL,
  diluted_shares REAL, diluted_eps_reported REAL, diluted_eps_filed TEXT, diluted_eps_source TEXT, diluted_eps_components_json TEXT,
  pit_diluted_eps REAL, pit_diluted_eps_filed TEXT,
  shares_outstanding REAL, shares_outstanding_date TEXT, shares_outstanding_filed TEXT, shares_outstanding_method TEXT, shares_outstanding_components_json TEXT, diluted_shares_date TEXT, diluted_shares_filed TEXT,
  share_denominator_kind TEXT, share_value_filed TEXT,
  pit_revenue REAL,
            pit_gross_profit REAL, pit_operating_income REAL, pit_net_income REAL, pit_cfo REAL, pit_capex REAL, pit_fcf REAL,
            pit_buybacks REAL,
  pit_diluted_shares REAL, pit_cash REAL, pit_debt REAL, pit_shares_outstanding REAL,
  pit_shares_outstanding_date TEXT, pit_share_denominator_kind TEXT, pit_share_value_filed TEXT,
  pretax REAL, tax REAL, flow_operating_income REAL, flow_operating_income_method TEXT,
  cash REAL, debt REAL, receivables REAL, inventory REAL, payables REAL,
  assets REAL, liabilities REAL, equity REAL,
  source TEXT DEFAULT 'SEC XBRL',
  updated_at TEXT,
  PRIMARY KEY (ticker, period_key)
);

CREATE TABLE IF NOT EXISTS research_notes (
  ticker TEXT PRIMARY KEY,
  market_narrative TEXT,
  variant_view TEXT,
  key_evidence TEXT,
  catalysts TEXT,
  invalidation TEXT,
  primary_risk TEXT,
  secondary_risks TEXT,
  business_notes TEXT,
  monitoring_kpis TEXT,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS research_v2 (
  ticker TEXT PRIMARY KEY,
  thesis_title TEXT DEFAULT '',
  business_notes TEXT DEFAULT '',
  value_drivers TEXT DEFAULT '',
  market_narrative TEXT DEFAULT '',
  variant_view TEXT DEFAULT '',
  key_evidence TEXT DEFAULT '',
  catalysts TEXT DEFAULT '',
  evidence_to_add TEXT DEFAULT '',
  invalidation TEXT DEFAULT '',
  primary_risk TEXT DEFAULT '',
  secondary_risks TEXT DEFAULT '',
  portfolio_risk_notes TEXT DEFAULT '',
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS research_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticker TEXT NOT NULL,
  created_at TEXT NOT NULL,
  payload TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS valuation_assumptions (
  ticker TEXT PRIMARY KEY,
  payload TEXT NOT NULL,
  updated_at TEXT
);


CREATE TABLE IF NOT EXISTS share_basis_overrides (
  ticker TEXT PRIMARY KEY,
  mode TEXT NOT NULL,
  current_basis_shares REAL,
  basis_date TEXT,
  source_note TEXT DEFAULT '',
  confirmed INTEGER DEFAULT 0,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS current_share_basis_evidence (
  ticker TEXT PRIMARY KEY,
  anchor_date TEXT,
  verified_through TEXT,
  split_factor REAL DEFAULT 1.0,
  source TEXT DEFAULT '',
  actions_json TEXT DEFAULT '[]',
  status TEXT DEFAULT 'DATA REVIEW',
  issue TEXT DEFAULT '',
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS decision_journal (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL,
  ticker TEXT NOT NULL,
  action TEXT,
  price REAL,
  position_pct REAL,
  thesis TEXT,
  variant_view TEXT,
  bear_value REAL, bear_prob REAL,
  base_value REAL, base_prob REAL,
  bull_value REAL, bull_prob REAL,
  invalidation TEXT,
  evidence_to_add TEXT,
  bias_check TEXT,
  outcome TEXT,
  post_mortem TEXT
);

CREATE TABLE IF NOT EXISTS decision_outcomes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  decision_id INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  thesis_state TEXT,
  outcome TEXT,
  post_mortem TEXT,
  FOREIGN KEY(decision_id) REFERENCES decision_journal(id)
);

CREATE TABLE IF NOT EXISTS source_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL,
  ticker TEXT,
  source_type TEXT,
  document TEXT,
  url TEXT,
  key_fact TEXT,
  supports_challenges TEXT,
  reliability INTEGER
);

CREATE TABLE IF NOT EXISTS refresh_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticker TEXT NOT NULL,
  started_at TEXT NOT NULL,
  completed_at TEXT,
  status TEXT NOT NULL,
  bars_rows INTEGER DEFAULT 0,
  finra_rows INTEGER DEFAULT 0,
  fundamental_periods INTEGER DEFAULT 0,
  flow_dates INTEGER DEFAULT 0,
  market_feed TEXT,
  flow_feed TEXT,
  error_message TEXT
);


CREATE TABLE IF NOT EXISTS price_checks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticker TEXT NOT NULL,
  checked_at TEXT NOT NULL,
  provider TEXT NOT NULL,
  price REAL,
  asof TEXT,
  quality TEXT,
  deviation_pct REAL,
  comparable INTEGER,
  status TEXT,
  message TEXT
);

CREATE TABLE IF NOT EXISTS metric_snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticker TEXT NOT NULL,
  captured_at TEXT NOT NULL,
  trade_date TEXT,
  price REAL,
  base_value REAL,
  expected_value REAL,
  fundamental_score REAL,
  institutional_flow REAL,
  long_demand REAL,
  short_pressure REAL,
  absorption REAL,
  battle_intensity REAL,
  price_resilience REAL,
  net_tape REAL,
  confidence REAL,
  regime TEXT,
  net_large REAL,
  net_whale REAL,
  short_pct REAL,
  roic REAL,
  fcf_margin REAL,
  ccc REAL
);

CREATE TABLE IF NOT EXISTS decision_gates (
  ticker TEXT NOT NULL,
  gate_key TEXT NOT NULL,
  manual_status TEXT,
  notes TEXT DEFAULT '',
  updated_at TEXT NOT NULL,
  PRIMARY KEY(ticker, gate_key)
);

CREATE TABLE IF NOT EXISTS monitoring_kpis (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticker TEXT NOT NULL,
  name TEXT NOT NULL,
  category TEXT DEFAULT 'Business',
  metric_key TEXT DEFAULT '',
  source_type TEXT DEFAULT 'AUTO',
  unit TEXT DEFAULT '',
  manual_value REAL,
  operator TEXT DEFAULT '>=',
  threshold REAL,
  linked_to TEXT DEFAULT 'THESIS',
  importance INTEGER DEFAULT 3,
  locked INTEGER DEFAULT 0,
  notes TEXT DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS monitoring_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kpi_id INTEGER NOT NULL,
  ticker TEXT NOT NULL,
  captured_at TEXT NOT NULL,
  value REAL,
  FOREIGN KEY(kpi_id) REFERENCES monitoring_kpis(id)
);

CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticker TEXT NOT NULL,
  event_date TEXT NOT NULL,
  event_type TEXT DEFAULT 'Catalyst',
  title TEXT NOT NULL,
  thesis_expectation TEXT DEFAULT '',
  bear_case TEXT DEFAULT '',
  base_case TEXT DEFAULT '',
  bull_case TEXT DEFAULT '',
  add_condition TEXT DEFAULT '',
  reduce_condition TEXT DEFAULT '',
  exit_condition TEXT DEFAULT '',
  status TEXT DEFAULT 'UPCOMING',
  thesis_state TEXT DEFAULT '',
  post_result TEXT DEFAULT '',
  notes TEXT DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS bear_case_items (
  ticker TEXT NOT NULL,
  item_key TEXT NOT NULL,
  evidence_for TEXT DEFAULT '',
  evidence_against TEXT DEFAULT '',
  severity INTEGER DEFAULT 3,
  status TEXT DEFAULT 'OPEN',
  updated_at TEXT NOT NULL,
  PRIMARY KEY(ticker, item_key)
);

CREATE TABLE IF NOT EXISTS risk_plans (
  ticker TEXT PRIMARY KEY,
  portfolio_risk_budget REAL DEFAULT 0.0075,
  invalidation_price REAL,
  event_liquidity_haircut REAL DEFAULT 0.05,
  max_position_cap REAL DEFAULT 0.10,
  correlation_notes TEXT DEFAULT '',
  kill_switch TEXT DEFAULT '',
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sec_provenance (
  ticker TEXT NOT NULL,
  metric TEXT NOT NULL,
  xbrl_tag TEXT,
  unit TEXT,
  latest_end TEXT,
  latest_filed TEXT,
  method TEXT,
  source_url TEXT,
  updated_at TEXT NOT NULL,
  PRIMARY KEY(ticker, metric)
);

CREATE TABLE IF NOT EXISTS sec_revisions (
  ticker TEXT NOT NULL,
  metric TEXT NOT NULL,
  xbrl_tag TEXT,
  unit TEXT,
  period_start TEXT,
  period_end TEXT NOT NULL,
  fiscal_year INTEGER,
  fiscal_period TEXT,
  first_filed TEXT,
  latest_filed TEXT,
  first_form TEXT,
  latest_form TEXT,
  first_value REAL,
  latest_value REAL,
  delta REAL,
  delta_pct REAL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY(ticker, metric, period_end, first_filed, latest_filed)
);


CREATE TABLE IF NOT EXISTS filing_documents (
  ticker TEXT NOT NULL,
  accession TEXT NOT NULL,
  document_type TEXT NOT NULL DEFAULT 'PRIMARY',
  form TEXT,
  filed TEXT,
  report_date TEXT,
  source_url TEXT NOT NULL,
  content_sha1 TEXT,
  parser_version INTEGER DEFAULT 1,
  extracted_at TEXT NOT NULL,
  PRIMARY KEY(ticker, accession, document_type, source_url)
);

CREATE TABLE IF NOT EXISTS management_statements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticker TEXT NOT NULL,
  statement_hash TEXT NOT NULL,
  form TEXT,
  filed TEXT,
  accession TEXT,
  document_type TEXT,
  source_url TEXT,
  statement TEXT NOT NULL,
  metric_key TEXT DEFAULT '',
  target_fiscal_year INTEGER,
  target_low REAL,
  target_high REAL,
  target_kind TEXT DEFAULT 'QUALITATIVE',
  unit TEXT DEFAULT '',
  extract_confidence REAL,
  created_at TEXT NOT NULL,
  UNIQUE(ticker, statement_hash)
);

CREATE TABLE IF NOT EXISTS forecast_assumptions (
  ticker TEXT PRIMARY KEY,
  payload TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS refresh_batches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL,
  started_at TEXT,
  completed_at TEXT,
  reason TEXT DEFAULT 'MANUAL',
  include_flow INTEGER DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'QUEUED',
  total INTEGER DEFAULT 0,
  completed INTEGER DEFAULT 0,
  passed INTEGER DEFAULT 0,
  failed INTEGER DEFAULT 0,
  current_ticker TEXT,
  error_message TEXT
);



CREATE TABLE IF NOT EXISTS discovery_universe (
  ticker TEXT PRIMARY KEY,
  cik TEXT,
  company_name TEXT,
  exchange TEXT,
  sic TEXT,
  sic_description TEXT,
  tradable INTEGER DEFAULT 1,
  shortable INTEGER DEFAULT 0,
  borrow_status TEXT DEFAULT '',
  has_options INTEGER DEFAULT 0,
  price REAL,
  prev_close REAL,
  daily_change REAL,
  volume REAL,
  dollar_volume REAL,
  market_cap REAL,
  enterprise_value REAL,
  revenue REAL,
  revenue_prev REAL,
  revenue_growth REAL,
  revenue_growth_prev REAL,
  operating_margin REAL,
  operating_margin_prev REAL,
  net_margin REAL,
  net_margin_prev REAL,
  fcf REAL,
  fcf_margin REAL,
  fcf_margin_prev REAL,
  roic REAL,
  cfo_ni REAL,
  cash REAL,
  debt REAL,
  net_debt REAL,
  diluted_shares REAL, diluted_eps_reported REAL,
  shares_outstanding REAL, shares_outstanding_date TEXT, shares_outstanding_filed TEXT, shares_outstanding_method TEXT, shares_outstanding_components_json TEXT, diluted_shares_date TEXT, diluted_shares_filed TEXT,
  valuation_shares REAL, valuation_share_source TEXT DEFAULT '', valuation_share_confidence TEXT DEFAULT '', valuation_share_basis_usable INTEGER DEFAULT 0,
  share_basis_checked INTEGER DEFAULT 0, share_basis_verified INTEGER DEFAULT 0,
  valuation_share_basis_verified INTEGER DEFAULT 0, market_cap_basis_verified INTEGER DEFAULT 0, eps_basis_verified INTEGER DEFAULT 0,
  eps_basis_warning INTEGER DEFAULT 0,
  share_change REAL,
  inventory_rev REAL,
  inventory_rev_prev REAL,
  receivables_rev REAL,
  receivables_rev_prev REAL,
  pe REAL,
  ev_sales REAL,
  fcf_yield REAL,
  screen_base_value REAL,
  screen_value_gap REAL,
  screen_value_status TEXT DEFAULT '',
  screen_model_version TEXT DEFAULT '',
  quality_score REAL,
  trend_score REAL,
  forensic_score REAL,
  valuation_score REAL,
  long_score REAL,
  short_score REAL,
  confidence REAL,
  lens TEXT DEFAULT 'NO EDGE',
  system_priority INTEGER DEFAULT 5,
  reason TEXT DEFAULT '',
  fundamentals_updated_at TEXT,
  market_updated_at TEXT,
  scored_at TEXT
);

CREATE TABLE IF NOT EXISTS discovery_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL,
  started_at TEXT,
  completed_at TEXT,
  status TEXT NOT NULL DEFAULT 'QUEUED',
  stage TEXT DEFAULT 'QUEUED',
  universe_total INTEGER DEFAULT 0,
  market_rows INTEGER DEFAULT 0,
  fundamentals_rows INTEGER DEFAULT 0,
  scored_rows INTEGER DEFAULT 0,
  current_ticker TEXT,
  error_message TEXT
);

CREATE TABLE IF NOT EXISTS peer_links (
  ticker TEXT NOT NULL,
  peer_ticker TEXT NOT NULL,
  relation_type TEXT DEFAULT 'PEER',
  source TEXT DEFAULT 'AUTO_SIC',
  confidence REAL DEFAULT 0.5,
  notes TEXT DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY(ticker, peer_ticker, relation_type)
);

CREATE TABLE IF NOT EXISTS variant_case (
  ticker TEXT PRIMARY KEY,
  market_belief TEXT DEFAULT '',
  our_belief TEXT DEFAULT '',
  disagreement_evidence TEXT DEFAULT '',
  resolution_signal TEXT DEFAULT '',
  resolution_horizon TEXT DEFAULT '',
  path_status TEXT DEFAULT 'UNCLEAR',
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS validation_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticker TEXT NOT NULL,
  generated_at TEXT NOT NULL,
  model_version TEXT NOT NULL,
  start_year INTEGER NOT NULL,
  end_year INTEGER NOT NULL,
  call_threshold REAL NOT NULL,
  reliability_score REAL,
  reliability_label TEXT,
  complete_tests INTEGER DEFAULT 0,
  payload TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_validation_runs_ticker_generated
ON validation_runs(ticker, generated_at DESC);

CREATE TABLE IF NOT EXISTS refresh_batch_items (
  batch_id INTEGER NOT NULL,
  ticker TEXT NOT NULL,
  position INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'QUEUED',
  started_at TEXT,
  completed_at TEXT,
  error_message TEXT,
  PRIMARY KEY(batch_id, ticker),
  FOREIGN KEY(batch_id) REFERENCES refresh_batches(id)
);
"""


@contextmanager
def connect():
    # Each call owns its SQLite connection, which is safe for background refresh threads.
    # WAL + busy_timeout reduce transient lock errors while Streamlit reads during refresh writes.
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=10000")
    con.execute("PRAGMA foreign_keys=ON")
    try:
        yield con
        con.commit()
    finally:
        con.close()


def _columns(con, table: str) -> set[str]:
    return {r["name"] for r in con.execute(f"PRAGMA table_info({table})").fetchall()}


def _migrate_research(con):
    old_rows = con.execute("SELECT * FROM research_notes").fetchall()
    for r in old_rows:
        exists = con.execute("SELECT 1 FROM research_v2 WHERE ticker=?", (r["ticker"],)).fetchone()
        if exists:
            continue
        con.execute(
            """INSERT INTO research_v2(
                ticker,business_notes,market_narrative,variant_view,key_evidence,catalysts,
                invalidation,primary_risk,secondary_risks,updated_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?)""",
            (
                r["ticker"], r["business_notes"] or "", r["market_narrative"] or "",
                r["variant_view"] or "", r["key_evidence"] or "", r["catalysts"] or "",
                r["invalidation"] or "", r["primary_risk"] or "", r["secondary_risks"] or "",
                r["updated_at"] or now_utc(),
            ),
        )


def init_db():
    _backup_pre_v2_once()
    with connect() as con:
        con.executescript(SCHEMA)
        cols = _columns(con, "fundamentals")
        if "pretax" not in cols:
            con.execute("ALTER TABLE fundamentals ADD COLUMN pretax REAL")
        if "tax" not in cols:
            con.execute("ALTER TABLE fundamentals ADD COLUMN tax REAL")
        if "flow_operating_income" not in cols:
            con.execute("ALTER TABLE fundamentals ADD COLUMN flow_operating_income REAL")
        if "flow_operating_income_method" not in cols:
            con.execute("ALTER TABLE fundamentals ADD COLUMN flow_operating_income_method TEXT")
        if "period_filed" not in cols:
            con.execute("ALTER TABLE fundamentals ADD COLUMN period_filed TEXT")
        # V3.1.2: keep share/price basis explicit. These columns are additive so existing databases migrate in place.
        for col, ctype in (
            ("shares_outstanding","REAL"),("shares_outstanding_date","TEXT"),("diluted_shares_filed","TEXT"),("diluted_eps_reported","REAL"),
            ("diluted_eps_filed","TEXT"),("diluted_eps_source","TEXT"),("diluted_eps_components_json","TEXT"),("pit_diluted_eps","REAL"),("pit_diluted_eps_filed","TEXT"),
            ("share_denominator_kind","TEXT"),("share_value_filed","TEXT"),
            ("pit_revenue","REAL"),("pit_gross_profit","REAL"),("pit_operating_income","REAL"),("pit_net_income","REAL"),("pit_cfo","REAL"),
            ("pit_capex","REAL"),("pit_fcf","REAL"),("pit_buybacks","REAL"),("pit_diluted_shares","REAL"),("pit_cash","REAL"),
            ("pit_debt","REAL"),("pit_shares_outstanding","REAL"),("pit_shares_outstanding_date","TEXT"),
            ("shares_outstanding_method","TEXT"),("shares_outstanding_components_json","TEXT"),
            ("pit_share_denominator_kind","TEXT"),("pit_share_value_filed","TEXT"),
        ):
            if col not in cols:
                con.execute(f"ALTER TABLE fundamentals ADD COLUMN {col} {ctype}")
        bar_cols = _columns(con, "daily_bars")
        for col, ctype in (
            ("raw_close","REAL"),("split_adjusted_close","REAL"),("split_factor","REAL DEFAULT 1.0"),
            ("basis_verified","INTEGER DEFAULT 0"),("split_factor_verified","INTEGER DEFAULT 0"),("price_basis","TEXT DEFAULT ''"),
        ):
            if col not in bar_cols:
                con.execute(f"ALTER TABLE daily_bars ADD COLUMN {col} {ctype}")
        filing_cols = _columns(con, "filing_documents")
        if "parser_version" not in filing_cols:
            con.execute("ALTER TABLE filing_documents ADD COLUMN parser_version INTEGER DEFAULT 1")
        event_cols = _columns(con, "events")
        if "thesis_state" not in event_cols:
            con.execute("ALTER TABLE events ADD COLUMN thesis_state TEXT DEFAULT ''")
        if "post_result" not in event_cols:
            con.execute("ALTER TABLE events ADD COLUMN post_result TEXT DEFAULT ''")
        price_cols = _columns(con, "price_checks")
        if "comparable" not in price_cols:
            con.execute("ALTER TABLE price_checks ADD COLUMN comparable INTEGER")
        discovery_cols = _columns(con, "discovery_universe")
        if "screen_base_value" not in discovery_cols:
            con.execute("ALTER TABLE discovery_universe ADD COLUMN screen_base_value REAL")
        if "screen_value_gap" not in discovery_cols:
            con.execute("ALTER TABLE discovery_universe ADD COLUMN screen_value_gap REAL")
        if "share_basis_checked" not in discovery_cols:
            con.execute("ALTER TABLE discovery_universe ADD COLUMN share_basis_checked INTEGER DEFAULT 0")
        if "share_basis_verified" not in discovery_cols:
            con.execute("ALTER TABLE discovery_universe ADD COLUMN share_basis_verified INTEGER DEFAULT 0")
        if "eps_basis_warning" not in discovery_cols:
            con.execute("ALTER TABLE discovery_universe ADD COLUMN eps_basis_warning INTEGER DEFAULT 0")
        for col in ("valuation_share_basis_verified","market_cap_basis_verified","eps_basis_verified"):
            if col not in discovery_cols:
                con.execute(f"ALTER TABLE discovery_universe ADD COLUMN {col} INTEGER DEFAULT 0")
        if "screen_value_status" not in discovery_cols:
            con.execute("ALTER TABLE discovery_universe ADD COLUMN screen_value_status TEXT DEFAULT ''")
        if "screen_model_version" not in discovery_cols:
            con.execute("ALTER TABLE discovery_universe ADD COLUMN screen_model_version TEXT DEFAULT ''")
        for col, ctype in (("shares_outstanding","REAL"),("shares_outstanding_date","TEXT"),("shares_outstanding_filed","TEXT"),("diluted_shares_date","TEXT"),("diluted_shares_filed","TEXT"),
                           ("valuation_shares","REAL"),("valuation_share_source","TEXT DEFAULT ''"),("valuation_share_confidence","TEXT DEFAULT ''"),("valuation_share_basis_usable","INTEGER DEFAULT 0")):
            if col not in discovery_cols:
                con.execute(f"ALTER TABLE discovery_universe ADD COLUMN {col} {ctype}")

        fundamental_cols = {r["name"] for r in con.execute("PRAGMA table_info(fundamentals)").fetchall()}
        for col, ctype in (("shares_outstanding_filed","TEXT"),("diluted_shares_date","TEXT")):
            if col not in fundamental_cols:
                con.execute(f"ALTER TABLE fundamentals ADD COLUMN {col} {ctype}")

        # Migrate legacy watchlist rows into Coverage without losing old data.
        for r in con.execute("SELECT ticker, added_at FROM watchlist").fetchall():
            con.execute(
                """INSERT OR IGNORE INTO coverage(ticker,status,created_at,updated_at)
                   VALUES(?,?,?,?)""",
                (r["ticker"], "WATCHLIST", r["added_at"] or now_utc(), now_utc()),
            )
        # V3.1.8: portfolio is an independent real-position ledger. Existing LONG/SHORT
        # positions stored in Coverage are migrated once, without requiring a thesis/research state.
        for r in con.execute("SELECT ticker,portfolio_state,shares_owned,avg_cost,tags,notes,created_at,updated_at FROM coverage WHERE portfolio_state IN ('LONG','SHORT') AND ABS(COALESCE(shares_owned,0))>0").fetchall():
            con.execute(
                """INSERT OR IGNORE INTO portfolio_positions(ticker,side,shares,avg_cost,tags,notes,created_at,updated_at)
                   VALUES(?,?,?,?,?,?,?,?)""",
                (r["ticker"], r["portfolio_state"], abs(float(r["shares_owned"] or 0)), float(r["avg_cost"] or 0), r["tags"] or "", r["notes"] or "", r["created_at"] or now_utc(), r["updated_at"] or now_utc()),
            )
        _migrate_research(con)


def upsert_many(table: str, rows: list[dict], keys: list[str]):
    if not rows:
        return
    cols = list(rows[0].keys())
    placeholders = ",".join(["?"] * len(cols))
    update_cols = [c for c in cols if c not in keys]
    update_sql = ", ".join([f"{c}=excluded.{c}" for c in update_cols])
    sql = f"""INSERT INTO {table} ({','.join(cols)}) VALUES ({placeholders})
              ON CONFLICT ({','.join(keys)}) DO UPDATE SET {update_sql}"""
    vals = [[r.get(c) for c in cols] for r in rows]
    with connect() as con:
        con.executemany(sql, vals)


def query(sql: str, params=()):
    with connect() as con:
        return [dict(r) for r in con.execute(sql, params).fetchall()]


def execute(sql: str, params=()):
    with connect() as con:
        con.execute(sql, params)


def ensure_coverage(ticker: str, status: str = "RESEARCH"):
    t = ticker.upper().strip()
    if not t:
        return
    stamp = now_utc()
    execute(
        """INSERT INTO coverage(ticker,status,created_at,updated_at) VALUES(?,?,?,?)
           ON CONFLICT(ticker) DO UPDATE SET updated_at=coverage.updated_at""",
        (t, status, stamp, stamp),
    )
    execute("INSERT OR IGNORE INTO watchlist(ticker,added_at) VALUES(?,?)", (t, stamp))


def list_coverage(include_archived: bool = False):
    if include_archived:
        return query("SELECT * FROM coverage ORDER BY priority, ticker")
    return query("SELECT * FROM coverage WHERE status!='ARCHIVED' ORDER BY priority, ticker")


def coverage_row(ticker: str):
    rows = query("SELECT * FROM coverage WHERE ticker=?", (ticker.upper(),))
    return rows[0] if rows else None


def remove_from_coverage(ticker: str):
    """Remove a ticker from the Coverage list while preserving downloaded/research history.

    Re-adding the ticker later restores access to the retained local history.
    """
    t = ticker.upper().strip()
    if not t:
        return
    execute("DELETE FROM coverage WHERE ticker=?", (t,))
    execute("DELETE FROM watchlist WHERE ticker=?", (t,))


def update_coverage(ticker: str, **fields):
    allowed = {
        "status", "priority", "company_type", "tags", "portfolio_state", "shares_owned",
        "avg_cost", "thesis_horizon_months", "notes"
    }
    pairs = [(k, v) for k, v in fields.items() if k in allowed]
    if not pairs:
        return
    ensure_coverage(ticker)
    pairs.append(("updated_at", now_utc()))
    set_sql = ",".join(f"{k}=?" for k, _ in pairs)
    execute(f"UPDATE coverage SET {set_sql} WHERE ticker=?", tuple(v for _, v in pairs) + (ticker.upper(),))


def add_watchlist(ticker: str):
    ensure_coverage(ticker, "WATCHLIST")


def list_watchlist():
    return [r["ticker"] for r in list_coverage()]


def portfolio_position(ticker: str):
    rows=query("SELECT * FROM portfolio_positions WHERE ticker=?",(ticker.upper().strip(),))
    return rows[0] if rows else None


def list_portfolio_positions():
    return query("SELECT * FROM portfolio_positions WHERE ABS(COALESCE(shares,0))>0 ORDER BY ticker")


def upsert_portfolio_position(ticker: str, side: str, shares: float, avg_cost: float = 0.0, tags: str = "", notes: str = ""):
    t=ticker.upper().strip(); side=str(side or 'LONG').upper().strip()
    if not t: raise ValueError("Ticker is required")
    if side not in ('LONG','SHORT'): raise ValueError("Side must be LONG or SHORT")
    sh=abs(float(shares or 0)); cost=max(0.0,float(avg_cost or 0)); stamp=now_utc()
    if sh<=0:
        delete_portfolio_position(t); return
    execute(
        """INSERT INTO portfolio_positions(ticker,side,shares,avg_cost,tags,notes,created_at,updated_at)
           VALUES(?,?,?,?,?,?,?,?)
           ON CONFLICT(ticker) DO UPDATE SET side=excluded.side,shares=excluded.shares,avg_cost=excluded.avg_cost,
           tags=excluded.tags,notes=excluded.notes,updated_at=excluded.updated_at""",
        (t,side,sh,cost,tags or '',notes or '',stamp,stamp),
    )
    # Keep legacy Coverage fields synchronized only when that ticker is already researched.
    # Do NOT create Coverage here: a real position is allowed to exist before any thesis.
    if coverage_row(t):
        execute("UPDATE coverage SET portfolio_state=?,shares_owned=?,avg_cost=?,tags=CASE WHEN ?<>'' THEN ? ELSE tags END,updated_at=? WHERE ticker=?",
                (side,sh,cost,tags or '',tags or '',stamp,t))


def delete_portfolio_position(ticker: str):
    t=ticker.upper().strip()
    execute("DELETE FROM portfolio_positions WHERE ticker=?",(t,))
    if coverage_row(t):
        execute("UPDATE coverage SET portfolio_state='NO POSITION',shares_owned=0,avg_cost=0,updated_at=? WHERE ticker=?",(now_utc(),t))


def all_workspace_tickers():
    return sorted(set([r['ticker'] for r in list_coverage()] + [r['ticker'] for r in list_portfolio_positions()]))


def discovery_rows(limit: int | None = None, lenses: list[str] | None = None):
    sql = "SELECT * FROM discovery_universe"
    params = []
    if lenses:
        sql += " WHERE lens IN (%s)" % ",".join(["?"] * len(lenses))
        params.extend(lenses)
    sql += " ORDER BY system_priority ASC, MAX(long_score,short_score) DESC, ticker ASC"
    if limit:
        sql += " LIMIT ?"
        params.append(int(limit))
    return query(sql, tuple(params))


def discovery_row(ticker: str):
    rows = query("SELECT * FROM discovery_universe WHERE ticker=?", (ticker.upper(),))
    return rows[0] if rows else None


def save_peer_link(ticker: str, peer_ticker: str, relation_type: str = "PEER", source: str = "MANUAL", confidence: float = 1.0, notes: str = ""):
    stamp = now_utc()
    execute(
        """INSERT INTO peer_links(ticker,peer_ticker,relation_type,source,confidence,notes,created_at,updated_at)
           VALUES(?,?,?,?,?,?,?,?)
           ON CONFLICT(ticker,peer_ticker,relation_type) DO UPDATE SET
           source=excluded.source,confidence=excluded.confidence,notes=excluded.notes,updated_at=excluded.updated_at""",
        (ticker.upper(), peer_ticker.upper(), relation_type, source, confidence, notes, stamp, stamp),
    )


def delete_peer_link(ticker: str, peer_ticker: str, relation_type: str = "PEER"):
    execute("DELETE FROM peer_links WHERE ticker=? AND peer_ticker=? AND relation_type=?", (ticker.upper(), peer_ticker.upper(), relation_type))


def peer_links(ticker: str):
    return query("SELECT * FROM peer_links WHERE ticker=? ORDER BY relation_type,confidence DESC,peer_ticker", (ticker.upper(),))


def load_variant_case(ticker: str):
    """Canonical variant-perception record with legacy research fallback for older databases."""
    t=ticker.upper()
    rows = query("SELECT * FROM variant_case WHERE ticker=?", (t,))
    if rows:
        return rows[0]
    legacy=query("SELECT market_narrative,variant_view,key_evidence,catalysts FROM research_v2 WHERE ticker=?",(t,))
    if legacy:
        r=legacy[0]
        if str(r.get("market_narrative") or "").strip() or str(r.get("variant_view") or "").strip():
            return {
                "ticker":t,
                "market_belief":r.get("market_narrative") or "",
                "our_belief":r.get("variant_view") or "",
                "disagreement_evidence":r.get("key_evidence") or "",
                "resolution_signal":r.get("catalysts") or "",
                "resolution_horizon":"",
                "path_status":"UNCLEAR",
                "legacy_fallback":1,
            }
    return {}


def save_variant_case(ticker: str, payload: dict):
    execute(
        """INSERT INTO variant_case(ticker,market_belief,our_belief,disagreement_evidence,resolution_signal,resolution_horizon,path_status,updated_at)
           VALUES(?,?,?,?,?,?,?,?)
           ON CONFLICT(ticker) DO UPDATE SET market_belief=excluded.market_belief,our_belief=excluded.our_belief,
           disagreement_evidence=excluded.disagreement_evidence,resolution_signal=excluded.resolution_signal,
           resolution_horizon=excluded.resolution_horizon,path_status=excluded.path_status,updated_at=excluded.updated_at""",
        (ticker.upper(), payload.get("market_belief", ""), payload.get("our_belief", ""),
         payload.get("disagreement_evidence", ""), payload.get("resolution_signal", ""),
         payload.get("resolution_horizon", ""), payload.get("path_status", "UNCLEAR"), now_utc()),
    )


def save_forecast_assumptions(ticker: str, payload: dict):
    execute(
        """INSERT INTO forecast_assumptions(ticker,payload,updated_at) VALUES(?,?,?)
           ON CONFLICT(ticker) DO UPDATE SET payload=excluded.payload, updated_at=excluded.updated_at""",
        (ticker.upper(), json.dumps(payload), now_utc()),
    )


def load_forecast_assumptions(ticker: str):
    rows=query("SELECT payload FROM forecast_assumptions WHERE ticker=?", (ticker.upper(),))
    if not rows: return None
    try: return json.loads(rows[0]["payload"])
    except Exception: return None


def save_json_assumptions(ticker: str, payload: dict):
    stamp = now_utc()
    execute(
        """INSERT INTO valuation_assumptions(ticker,payload,updated_at) VALUES(?,?,?)
           ON CONFLICT(ticker) DO UPDATE SET payload=excluded.payload, updated_at=excluded.updated_at""",
        (ticker.upper(), json.dumps(payload), stamp),
    )


def load_json_assumptions(ticker: str):
    rows = query("SELECT payload FROM valuation_assumptions WHERE ticker=?", (ticker.upper(),))
    if not rows:
        return None
    try:
        return json.loads(rows[0]["payload"])
    except Exception:
        return None


def load_research(ticker: str) -> dict:
    rows = query("SELECT * FROM research_v2 WHERE ticker=?", (ticker.upper(),))
    return rows[0] if rows else {}


def save_research(ticker: str, payload: dict):
    t = ticker.upper()
    stamp = now_utc()
    current = load_research(t)
    if current:
        archive = {k: v for k, v in current.items()}
        execute(
            "INSERT INTO research_history(ticker,created_at,payload) VALUES(?,?,?)",
            (t, stamp, json.dumps(archive)),
        )
    fields = [
        "thesis_title", "business_notes", "value_drivers", "market_narrative", "variant_view",
        "key_evidence", "catalysts", "evidence_to_add", "invalidation", "primary_risk",
        "secondary_risks", "portfolio_risk_notes"
    ]
    vals = [str(payload.get(f, "")) for f in fields]
    execute(
        f"""INSERT INTO research_v2(ticker,{','.join(fields)},updated_at)
            VALUES({','.join(['?']*(len(fields)+2))})
            ON CONFLICT(ticker) DO UPDATE SET
            {','.join([f'{f}=excluded.{f}' for f in fields])}, updated_at=excluded.updated_at""",
        (t, *vals, stamp),
    )


def save_gate_override(ticker: str, gate_key: str, status: str | None, notes: str = ""):
    execute(
        """INSERT INTO decision_gates(ticker,gate_key,manual_status,notes,updated_at) VALUES(?,?,?,?,?)
           ON CONFLICT(ticker,gate_key) DO UPDATE SET manual_status=excluded.manual_status,
           notes=excluded.notes,updated_at=excluded.updated_at""",
        (ticker.upper(), gate_key, status, notes, now_utc()),
    )


def gate_overrides(ticker: str):
    return {r["gate_key"]: r for r in query("SELECT * FROM decision_gates WHERE ticker=?", (ticker.upper(),))}


def save_current_share_basis_evidence(ticker: str, evidence: dict | None):
    e=evidence or {}
    execute(
        """INSERT INTO current_share_basis_evidence(ticker,anchor_date,verified_through,split_factor,source,actions_json,status,issue,updated_at)
           VALUES(?,?,?,?,?,?,?,?,?)
           ON CONFLICT(ticker) DO UPDATE SET anchor_date=excluded.anchor_date,verified_through=excluded.verified_through,
           split_factor=excluded.split_factor,source=excluded.source,actions_json=excluded.actions_json,status=excluded.status,
           issue=excluded.issue,updated_at=excluded.updated_at""",
        (str(ticker or "").upper().strip(),e.get("anchor_date"),e.get("verified_through"),float(e.get("split_factor") or 1.0),
         str(e.get("source") or ""),json.dumps(e.get("actions") or [],separators=(",",":"),default=str),
         str(e.get("status") or "DATA REVIEW"),str(e.get("issue") or ""),now_utc()),
    )


def current_share_basis_evidence(ticker: str):
    rows=query("SELECT * FROM current_share_basis_evidence WHERE ticker=?",(str(ticker or "").upper().strip(),))
    if not rows:return None
    out=dict(rows[0])
    try:out["actions"]=json.loads(out.get("actions_json") or "[]")
    except Exception:out["actions"]=[]
    return out


def save_share_basis_override(ticker: str, mode: str, current_basis_shares: float, basis_date: str = "", source_note: str = "", confirmed: bool = True):
    t=str(ticker or "").upper().strip()
    if not t:
        raise ValueError("Ticker is required")
    shares=float(current_basis_shares)
    if shares<=0:
        raise ValueError("Current-basis shares must be positive")
    execute(
        """INSERT INTO share_basis_overrides(ticker,mode,current_basis_shares,basis_date,source_note,confirmed,updated_at)
           VALUES(?,?,?,?,?,?,?)
           ON CONFLICT(ticker) DO UPDATE SET mode=excluded.mode,current_basis_shares=excluded.current_basis_shares,
           basis_date=excluded.basis_date,source_note=excluded.source_note,confirmed=excluded.confirmed,updated_at=excluded.updated_at""",
        (t,str(mode or "MANUAL_CURRENT_BASIS"),shares,str(basis_date or "")[:10],str(source_note or ""),1 if confirmed else 0,now_utc()),
    )


def share_basis_override(ticker: str):
    rows=query("SELECT * FROM share_basis_overrides WHERE ticker=?",(str(ticker or "").upper().strip(),))
    return rows[0] if rows else None


def clear_share_basis_override(ticker: str):
    execute("DELETE FROM share_basis_overrides WHERE ticker=?",(str(ticker or "").upper().strip(),))


def risk_plan(ticker: str):
    rows = query("SELECT * FROM risk_plans WHERE ticker=?", (ticker.upper(),))
    return rows[0] if rows else {}


def save_risk_plan(ticker: str, payload: dict):
    execute(
        """INSERT INTO risk_plans(ticker,portfolio_risk_budget,invalidation_price,event_liquidity_haircut,
        max_position_cap,correlation_notes,kill_switch,updated_at) VALUES(?,?,?,?,?,?,?,?)
        ON CONFLICT(ticker) DO UPDATE SET portfolio_risk_budget=excluded.portfolio_risk_budget,
        invalidation_price=excluded.invalidation_price,event_liquidity_haircut=excluded.event_liquidity_haircut,
        max_position_cap=excluded.max_position_cap,correlation_notes=excluded.correlation_notes,
        kill_switch=excluded.kill_switch,updated_at=excluded.updated_at""",
        (
            ticker.upper(), payload.get("portfolio_risk_budget"), payload.get("invalidation_price"),
            payload.get("event_liquidity_haircut"), payload.get("max_position_cap"),
            payload.get("correlation_notes", ""), payload.get("kill_switch", ""), now_utc(),
        ),
    )

def save_validation_result(ticker: str, result: dict):
    """Persist a completed point-in-time validation so Decision can show company-specific reliability."""
    t = str(ticker or "").upper().strip()
    if not t or not isinstance(result, dict):
        return
    summary = result.get("summary") or {}
    execute(
        """INSERT INTO validation_runs(
            ticker,generated_at,model_version,start_year,end_year,call_threshold,
            reliability_score,reliability_label,complete_tests,payload
        ) VALUES(?,?,?,?,?,?,?,?,?,?)""",
        (
            t, str(result.get("generated_at") or now_utc()), str(result.get("model_version") or "UNKNOWN"),
            int(result.get("start_year") or 0), int(result.get("end_year") or 0),
            float(result.get("call_threshold") or 0),
            summary.get("reliability_score"), summary.get("reliability_label"),
            int(summary.get("complete_tests") or 0), json.dumps(result),
        ),
    )


def latest_validation_result(ticker: str):
    rows = query(
        "SELECT payload FROM validation_runs WHERE ticker=? ORDER BY generated_at DESC, id DESC LIMIT 1",
        (str(ticker or "").upper().strip(),),
    )
    if not rows:
        return None
    try:
        return json.loads(rows[0]["payload"])
    except Exception:
        return None

