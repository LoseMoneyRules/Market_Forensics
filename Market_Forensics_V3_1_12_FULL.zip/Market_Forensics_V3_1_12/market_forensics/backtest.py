from __future__ import annotations

"""Point-in-time walk-forward validation for Market Forensics.

The module intentionally separates the information set used to build a historical
valuation from the future data used to score it.  The current V3 valuation rules are
replayed on old information; saved present-day assumptions and notes are never used.
"""

from copy import deepcopy
from datetime import date, datetime, timedelta, timezone
from statistics import median
import math

from . import db, fundamentals, marketdata, sec, valuation
from .config import load_settings


def _finite(x):
    try:
        return x is not None and math.isfinite(float(x))
    except Exception:
        return False


def _iso_day(value) -> str | None:
    if value is None:
        return None
    s = str(value)[:10]
    try:
        return date.fromisoformat(s).isoformat()
    except Exception:
        return None


def _bar_date(row: dict) -> date | None:
    raw = row.get("trade_date") or row.get("date")
    try:
        return date.fromisoformat(str(raw)[:10])
    except Exception:
        return None


def normalize_bars(rows: list[dict]) -> list[dict]:
    """Normalize provider/cached bars to a stable trade_date schema."""
    out = []
    for raw in rows or []:
        d = _bar_date(raw)
        close = raw.get("close")
        if d is None or not _finite(close) or float(close) <= 0:
            continue
        row = dict(raw)
        row["trade_date"] = d.isoformat()
        row["date"] = d.isoformat()
        row["close"] = float(close)
        out.append(row)
    out.sort(key=lambda x: x["trade_date"])
    # Last duplicate wins; this is mostly defensive for mixed provider/cache inputs.
    return list({x["trade_date"]: x for x in out}.values())


def filter_companyfacts_as_of(companyfacts: dict, cutoff) -> dict:
    """Return a Companyfacts view containing only facts filed by *cutoff*.

    This is the anti-look-ahead boundary.  Later amendments, later comparative
    restatements and future quarters are absent from the model's historical view.
    """
    cutoff_iso = _iso_day(cutoff)
    if not cutoff_iso:
        raise ValueError(f"Invalid point-in-time cutoff: {cutoff}")

    src = companyfacts or {}
    out = {k: deepcopy(v) for k, v in src.items() if k != "facts"}
    out["facts"] = {}
    for ns, tags in (src.get("facts") or {}).items():
        ns_out = {}
        for tag, obj in (tags or {}).items():
            units_out = {}
            for unit, observations in (obj.get("units") or {}).items():
                kept = []
                for x in observations or []:
                    filed = _iso_day(x.get("filed"))
                    # Facts without a filing date cannot safely enter a PIT backtest.
                    if filed and filed <= cutoff_iso:
                        kept.append(dict(x))
                if kept:
                    units_out[unit] = kept
            if units_out:
                obj_out = {k: deepcopy(v) for k, v in obj.items() if k != "units"}
                obj_out["units"] = units_out
                ns_out[tag] = obj_out
        if ns_out:
            out["facts"][ns] = ns_out
    return out


def _bars_through(bars: list[dict], cutoff: date, *, rebase_split_to_cutoff: bool = True) -> list[dict]:
    """Return bars known by *cutoff*, optionally rebased to the cutoff share basis.

    Provider ``split_factor`` values are normally cumulative from each bar all the way to the
    present.  Feeding those values directly into a historical replay leaks *future* splits into
    the share denominator.  Divide every pre-cutoff factor by the factor at the cutoff so the
    cutoff itself is 1.0 and only splits that had already happened by then can affect the model.
    Raw contemporaneous prices are intentionally left untouched.
    """
    kept=[dict(b) for b in bars if (_bar_date(b) and _bar_date(b) <= cutoff)]
    if not kept or not rebase_split_to_cutoff:
        return kept
    latest=max(kept,key=lambda x:_bar_date(x))
    if not bool(latest.get("basis_verified")):
        return kept
    try: cutoff_factor=float(latest.get("split_factor") or 1.0)
    except Exception: return kept
    if not math.isfinite(cutoff_factor) or cutoff_factor<=0:
        return kept
    for row in kept:
        if not bool(row.get("basis_verified")):
            continue
        try:f=float(row.get("split_factor") or 1.0)
        except Exception:continue
        if math.isfinite(f) and f>0:
            row["split_factor"]=f/cutoff_factor
            row["rebase_cutoff_factor"]=cutoff_factor
            row["price_basis"]=(str(row.get("price_basis") or "")+f"; rebased to {cutoff.isoformat()} share basis").strip("; ")
    return kept


def price_on_or_before(bars: list[dict], target: date, max_gap_days: int = 10) -> dict | None:
    best = None
    for b in bars:
        d = _bar_date(b)
        if d is None or d > target:
            continue
        if best is None or d > best[0]:
            best = (d, b)
    if best is None or (target - best[0]).days > int(max_gap_days):
        return None
    factor = best[1].get("split_factor")
    factor = float(factor) if _finite(factor) and float(factor) > 0 else 1.0
    naf=best[1].get("non_split_action_factor"); naf=float(naf) if _finite(naf) and float(naf)>0 else 1.0
    return {"date": best[0].isoformat(), "close": float(best[1]["close"]), "split_factor": factor,
            "basis_verified":bool(best[1].get("basis_verified")),"non_split_action_factor":naf,
            "non_split_action_verified":bool(best[1].get("non_split_action_verified"))}


def _comparable_outcome_price(anchor_px: dict, outcome_px: dict):
    """Translate the future raw quote to the anchor-date share basis.

    Example: a 4-for-1 split occurs after the anchor. Anchor raw=$400, factor=4;
    outcome raw=$120, factor=1 -> comparable outcome=$480 on the old share basis.
    """
    if not anchor_px or not outcome_px or not _finite(outcome_px.get("close")):
        return None
    af = float(anchor_px.get("split_factor") or 1.0)
    of = float(outcome_px.get("split_factor") or 1.0)
    if af <= 0 or of <= 0:
        return float(outcome_px["close"])
    return float(outcome_px["close"]) * af / of


def _latest_filed_date(fund_rows: list[dict]) -> str | None:
    vals = [str(r.get("period_filed"))[:10] for r in fund_rows or [] if _iso_day(r.get("period_filed"))]
    return max(vals) if vals else None


def _scenario_band(assumptions: dict, field: str):
    vals = []
    for name in ("bear", "bull"):
        v = (assumptions.get(name) or {}).get(field)
        if _finite(v):
            vals.append(float(v))
    if len(vals) < 2:
        return None, None
    return min(vals), max(vals)


def _inside(value, low, high):
    if not all(_finite(x) for x in (value, low, high)):
        return None
    return float(low) <= float(value) <= float(high)


def _thesis_status(hits: list[bool | None]) -> tuple[str, float | None]:
    usable = [bool(x) for x in hits if x is not None]
    if not usable:
        return "NO DATA", None
    ratio = sum(1 for x in usable if x) / len(usable)
    if ratio >= 2 / 3:
        return "SUPPORTED", ratio
    if ratio >= 1 / 3:
        return "MIXED", ratio
    return "MISSED", ratio


def _call_from_gap(gap, threshold=.15):
    if not _finite(gap):
        return "NO CALL"
    g = float(gap)
    if g >= threshold:
        return "LONG"
    if g <= -threshold:
        return "SHORT"
    return "NEUTRAL"


def _direction_hit(call: str, realized_return, threshold=.15):
    if not _finite(realized_return):
        return None
    rr = float(realized_return)
    if call == "LONG":
        return rr > 0
    if call == "SHORT":
        return rr < 0
    if call == "NEUTRAL":
        return abs(rr) < threshold
    return None


def _confidence(metrics, scenarios, calibration, company_type):
    try:
        return valuation.valuation_confidence(
            metrics, scenarios, calibration, company_type=company_type,
            audit_summary=None, reviewed=False, revision_count=0, regime_breaks=None,
        )
    except Exception:
        return {"score": None, "label": "UNKNOWN", "reasons": []}


def replay_one_year(
    ticker: str,
    companyfacts: dict,
    bars: list[dict],
    anchor_year: int,
    company_type: str = "Generic",
    call_threshold: float = .15,
) -> dict:
    """Replay the current model at Dec-31 of *anchor_year*, then score +1 year."""
    t = ticker.upper().strip()
    anchor_date = date(int(anchor_year), 12, 31)
    outcome_date = date(int(anchor_year) + 1, 12, 31)
    anchor_px = price_on_or_before(bars, anchor_date)
    if not anchor_px:
        return {"anchor_year": anchor_year, "anchor_date": anchor_date.isoformat(), "status": "NO ANCHOR PRICE"}

    historical_bars = _bars_through(bars, anchor_date)
    facts_then = filter_companyfacts_as_of(companyfacts, anchor_date)
    fund_then = fundamentals.build_fundamentals(t, facts_then)
    metrics_then = fundamentals.metrics_from_rows(fund_then, anchor_px["close"], bars=historical_bars) if fund_then else {}
    if not (_finite(metrics_then.get("revenue")) and _finite(metrics_then.get("diluted_shares"))):
        return {
            "anchor_year": anchor_year, "anchor_date": anchor_date.isoformat(),
            "anchor_price_date": anchor_px["date"], "anchor_price": anchor_px["close"],
            "status": "INSUFFICIENT PIT FUNDAMENTALS",
        }

    # Critical: saved current assumptions are intentionally excluded.
    assumptions, calibration, _legacy = valuation.resolve_assumptions(
        None, metrics_then, fund_then, historical_bars, company_type
    )
    scenarios, expected_value = valuation.scenario_values(metrics_then, assumptions)
    bear = (scenarios.get("bear") or {}).get("fair_value")
    base = (scenarios.get("base") or {}).get("fair_value")
    bull = (scenarios.get("bull") or {}).get("fair_value")
    price_gap = float(base) / anchor_px["close"] - 1 if _finite(base) and anchor_px["close"] else None
    model_call = _call_from_gap(price_gap, call_threshold)
    conf = _confidence(metrics_then, scenarios, calibration, company_type)

    row = {
        "anchor_year": int(anchor_year),
        "anchor_date": anchor_date.isoformat(),
        "anchor_price_date": anchor_px["date"],
        "anchor_price": anchor_px["close"],
        "anchor_split_factor": anchor_px.get("split_factor", 1.0),
        "latest_filing_used": _latest_filed_date(fund_then),
        "bear_target": bear,
        "base_target": base,
        "bull_target": bull,
        "expected_value": expected_value,
        "base_gap": price_gap,
        "model_call": model_call,
        "valuation_confidence": conf.get("label"),
        "valuation_confidence_score": conf.get("score"),
        "calibration_years": len((calibration or {}).get("observations") or []),
        "base_growth": (assumptions.get("base") or {}).get("growth"),
        "bear_growth": (assumptions.get("bear") or {}).get("growth"),
        "bull_growth": (assumptions.get("bull") or {}).get("growth"),
        "base_net_margin": (assumptions.get("base") or {}).get("net_margin"),
        "bear_net_margin": (assumptions.get("bear") or {}).get("net_margin"),
        "bull_net_margin": (assumptions.get("bull") or {}).get("net_margin"),
        "base_fcf_margin": (assumptions.get("base") or {}).get("fcf_margin"),
        "bear_fcf_margin": (assumptions.get("bear") or {}).get("fcf_margin"),
        "bull_fcf_margin": (assumptions.get("bull") or {}).get("fcf_margin"),
        "status": "PENDING",
    }

    outcome_px = price_on_or_before(bars, outcome_date)
    latest_bar_date = _bar_date(bars[-1]) if bars else None
    if outcome_px is None:
        row["status"] = "PENDING" if latest_bar_date and outcome_date > latest_bar_date else "NO OUTCOME PRICE"
        return row

    # Spin-offs transfer value away from the parent but do not change the share count like a
    # split. If Alpaca proves a non-split corporate-action adjustment changed between anchor and
    # outcome, quarantine that replay from Reliability instead of pretending the parent-only
    # quote is a clean price-target miss.
    if anchor_px.get("non_split_action_verified") and outcome_px.get("non_split_action_verified"):
        a=float(anchor_px.get("non_split_action_factor") or 1.0); o=float(outcome_px.get("non_split_action_factor") or 1.0)
        if a>0 and o>0 and abs(a/o-1.0) > .005:
            row.update({
                "outcome_date":outcome_date.isoformat(),"outcome_price_date":outcome_px["date"],
                "outcome_market_price":outcome_px["close"],"status":"CORPORATE ACTION REVIEW",
                "corporate_action_note":"Non-split corporate action (e.g. spin-off) detected between anchor and outcome; excluded from Reliability until distributed value is normalized.",
            })
            return row

    comparable_outcome = _comparable_outcome_price(anchor_px, outcome_px)
    actual_return = comparable_outcome / anchor_px["close"] - 1 if _finite(comparable_outcome) and anchor_px["close"] else None
    low_target = min(float(x) for x in (bear, bull) if _finite(x)) if any(_finite(x) for x in (bear, bull)) else None
    high_target = max(float(x) for x in (bear, bull) if _finite(x)) if any(_finite(x) for x in (bear, bull)) else None
    range_hit = _inside(comparable_outcome, low_target, high_target)
    base_abs_error = abs(float(base) / comparable_outcome - 1) if _finite(base) and _finite(comparable_outcome) and comparable_outcome else None
    base_signed_error = float(base) / comparable_outcome - 1 if _finite(base) and _finite(comparable_outcome) and comparable_outcome else None
    naive_abs_error = abs(anchor_px["close"] / comparable_outcome - 1) if _finite(comparable_outcome) and comparable_outcome else None
    baseline_win = (base_abs_error < naive_abs_error) if _finite(base_abs_error) and _finite(naive_abs_error) else None

    # Score the operating thesis using only information that had become public by +1Y.
    facts_future = filter_companyfacts_as_of(companyfacts, outcome_date)
    fund_future = fundamentals.build_fundamentals(t, facts_future)
    metrics_future = fundamentals.metrics_from_rows(fund_future, outcome_px["close"], bars=_bars_through(bars, outcome_date)) if fund_future else {}
    rev_then = metrics_then.get("revenue")
    rev_future = metrics_future.get("revenue")
    actual_growth = float(rev_future) / float(rev_then) - 1 if _finite(rev_future) and _finite(rev_then) and float(rev_then) != 0 else None
    actual_nm = metrics_future.get("net_margin")
    actual_fm = metrics_future.get("fcf_margin")

    g_lo, g_hi = _scenario_band(assumptions, "growth")
    nm_lo, nm_hi = _scenario_band(assumptions, "net_margin")
    fm_lo, fm_hi = _scenario_band(assumptions, "fcf_margin")
    growth_hit = _inside(actual_growth, g_lo, g_hi)
    net_margin_hit = _inside(actual_nm, nm_lo, nm_hi)
    fcf_margin_hit = _inside(actual_fm, fm_lo, fm_hi)
    thesis_status, thesis_ratio = _thesis_status([growth_hit, net_margin_hit, fcf_margin_hit])

    row.update({
        "outcome_date": outcome_date.isoformat(),
        "outcome_price_date": outcome_px["date"],
        "outcome_price": comparable_outcome,
        "outcome_market_price": outcome_px["close"],
        "outcome_split_factor": outcome_px.get("split_factor", 1.0),
        "share_basis_normalization": (float(anchor_px.get("split_factor") or 1.0) / float(outcome_px.get("split_factor") or 1.0)),
        "realized_return": actual_return,
        "price_range_low": low_target,
        "price_range_high": high_target,
        "price_range_hit": range_hit,
        "base_abs_error": base_abs_error,
        "base_signed_error": base_signed_error,
        "naive_abs_error": naive_abs_error,
        "beat_no_change_baseline": baseline_win,
        "direction_hit": _direction_hit(model_call, actual_return, call_threshold),
        "actual_revenue_growth": actual_growth,
        "actual_net_margin": actual_nm,
        "actual_fcf_margin": actual_fm,
        "growth_thesis_hit": growth_hit,
        "net_margin_thesis_hit": net_margin_hit,
        "fcf_margin_thesis_hit": fcf_margin_hit,
        "thesis_driver_hit_ratio": thesis_ratio,
        "thesis_status": thesis_status,
        "status": "COMPLETE",
    })
    return row


def _clamp(value, low=0.0, high=100.0):
    try:
        return max(float(low), min(float(high), float(value)))
    except Exception:
        return None


def _reliability_label(score, complete_tests):
    if score is None:
        return "NO DATA"
    s = float(score)
    base = "HIGH" if s >= 80 else "GOOD" if s >= 65 else "MIXED" if s >= 50 else "WEAK"
    if int(complete_tests or 0) < 3:
        return f"LOW SAMPLE · {base}"
    return base


def _error_accuracy_score(error):
    """Convert median absolute price-target error into a 0-100 accuracy score.

    <=10% error receives full credit. Accuracy then decays linearly to zero at 50%.
    This prevents a wide scenario range from masking a poor Base estimate.
    """
    if not _finite(error):
        return None
    e = max(0.0, float(error))
    if e <= .10:
        return 100.0
    return _clamp(100.0 * (1.0 - (e - .10) / .40))


def summarize(rows: list[dict]) -> dict:
    complete = [r for r in rows if r.get("status") == "COMPLETE"]

    def rate(key):
        vals = [bool(r[key]) for r in complete if r.get(key) is not None]
        return sum(vals) / len(vals) if vals else None

    def med(key):
        vals = [float(r[key]) for r in complete if _finite(r.get(key))]
        return median(vals) if vals else None

    driver_hits = []
    for r in complete:
        for k in ("growth_thesis_hit", "net_margin_thesis_hit", "fcf_margin_thesis_hit"):
            if r.get(k) is not None:
                driver_hits.append(bool(r[k]))
    driver_rate = sum(driver_hits) / len(driver_hits) if driver_hits else None
    supported = [r.get("thesis_status") == "SUPPORTED" for r in complete if r.get("thesis_status") not in (None, "NO DATA")]
    supported_rate = sum(supported) / len(supported) if supported else None

    range_rate = rate("price_range_hit")
    direction_rate = rate("direction_hit")
    baseline_rate = rate("beat_no_change_baseline")
    base_mape = med("base_abs_error")
    bias = med("base_signed_error")

    # Four independent lenses. Missing components are excluded rather than silently scored as zero.
    accuracy_score = _error_accuracy_score(base_mape)
    valuation_parts = []
    if range_rate is not None:
        valuation_parts.append((float(range_rate) * 100.0, .45))
    if accuracy_score is not None:
        valuation_parts.append((accuracy_score, .55))
    valuation_score = (sum(v*w for v,w in valuation_parts) / sum(w for _,w in valuation_parts)) if valuation_parts else None

    thesis_parts = []
    if driver_rate is not None:
        thesis_parts.append((float(driver_rate) * 100.0, .65))
    if supported_rate is not None:
        thesis_parts.append((float(supported_rate) * 100.0, .35))
    thesis_score = (sum(v*w for v,w in thesis_parts) / sum(w for _,w in thesis_parts)) if thesis_parts else None
    direction_score = float(direction_rate) * 100.0 if direction_rate is not None else None
    bias_control_score = _clamp(100.0 * (1.0 - min(abs(float(bias)) / .35, 1.0))) if _finite(bias) else None

    weighted = []
    for value, weight in ((valuation_score,.35),(thesis_score,.30),(direction_score,.25),(bias_control_score,.10)):
        if value is not None:
            weighted.append((float(value), weight))
    raw_reliability = (sum(v*w for v,w in weighted) / sum(w for _,w in weighted)) if weighted else None

    # Sample penalty is deliberate: two good historical observations must not look as trustworthy as
    # a slightly lower score backed by six or more completed walk-forward tests.
    n = len(complete)
    sample_factor = min(1.0, n / 6.0) if n else 0.0
    sample_confidence = "HIGH" if n >= 6 else "MEDIUM" if n >= 3 else "LOW"
    reliability_score = None if raw_reliability is None else _clamp(raw_reliability * (.65 + .35 * sample_factor))
    reliability_label = _reliability_label(reliability_score, n)

    if not _finite(bias):
        bias_label = "NO DATA"
    elif abs(float(bias)) <= .05:
        bias_label = "BALANCED"
    elif float(bias) > 0:
        bias_label = "OVERPREDICTS"
    else:
        bias_label = "UNDERPREDICTS"

    tests = [
        range_rate is not None and range_rate >= .60,
        direction_rate is not None and direction_rate >= .60,
        driver_rate is not None and driver_rate >= .60,
        base_mape is not None and base_mape <= .25,
    ]
    passed = sum(bool(x) for x in tests)
    if n < 3:
        verdict = "LOW SAMPLE"
    elif passed == 4:
        verdict = "STRONG HISTORICAL SUPPORT"
    elif passed >= 2:
        verdict = "MIXED HISTORICAL SUPPORT"
    else:
        verdict = "WEAK HISTORICAL SUPPORT"

    return {
        "complete_tests": n,
        "pending_tests": sum(1 for r in rows if r.get("status") == "PENDING"),
        "price_range_hit_rate": range_rate,
        "direction_hit_rate": direction_rate,
        "median_base_abs_error": base_mape,
        "median_base_signed_error": bias,
        "beat_no_change_rate": baseline_rate,
        "thesis_driver_hit_rate": driver_rate,
        "thesis_supported_rate": supported_rate,
        "long_calls": sum(1 for r in complete if r.get("model_call") == "LONG"),
        "short_calls": sum(1 for r in complete if r.get("model_call") == "SHORT"),
        "neutral_calls": sum(1 for r in complete if r.get("model_call") == "NEUTRAL"),
        "verdict": verdict,
        "valuation_reliability_score": valuation_score,
        "thesis_reliability_score": thesis_score,
        "direction_reliability_score": direction_score,
        "bias_control_score": bias_control_score,
        "bias_label": bias_label,
        "raw_reliability_score": raw_reliability,
        "sample_factor": sample_factor,
        "sample_confidence": sample_confidence,
        "reliability_score": reliability_score,
        "reliability_label": reliability_label,
    }


def run_validation(
    ticker: str,
    start_year: int,
    end_year: int,
    company_type: str | None = None,
    call_threshold: float = .15,
    lookback_days: int = 14610,
) -> dict:
    """Fetch once, replay each year with point-in-time SEC facts, and score +1Y outcomes."""
    t = ticker.upper().strip()
    if not t:
        raise ValueError("Ticker is required")
    settings = load_settings()
    ua = str(settings.get("sec_user_agent") or "").strip()
    if "@" not in ua:
        raise RuntimeError("Set a truthful SEC User-Agent with contact email in Settings before running validation.")

    resolved = sec.resolve_ticker(t, ua)
    companyfacts = sec.get_companyfacts(resolved["cik"], ua)
    bars_raw, provider, price_basis_verified = marketdata.get_validation_daily_bars(
        t,
        lookback_days=int(lookback_days),
        feed_mode=settings.get("alpaca_feed", "auto"),
        minimum_start_year=int(start_year),
    )
    bars = normalize_bars(bars_raw)
    if not bars:
        raise RuntimeError("No historical daily bars available for validation.")

    cov = db.coverage_row(t) or {}
    ctype = company_type or cov.get("company_type") or "Generic"
    sy, ey = int(start_year), int(end_year)
    if sy > ey:
        sy, ey = ey, sy
    rows = []
    for y in range(sy, ey + 1):
        try:
            rows.append(replay_one_year(t, companyfacts, bars, y, ctype, float(call_threshold)))
        except Exception as exc:
            # One malformed/ambiguous SEC period must not destroy the entire validation run.
            rows.append({"anchor_year":int(y),"anchor_date":date(int(y),12,31).isoformat(),
                         "status":"ERROR","error":f"{type(exc).__name__}: {exc}"})
    for row in rows:
        row["price_basis_verified"] = bool(price_basis_verified)
    price_history_start = bars[0].get("date") if bars else None
    modelable = [r.get("anchor_year") for r in rows if r.get("status") in ("COMPLETE", "PENDING")]
    complete_years = [r.get("anchor_year") for r in rows if r.get("status") == "COMPLETE"]
    result = {
        "ticker": t,
        "company_name": companyfacts.get("entityName") or t,
        "company_type": ctype,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "model_version": "V3.1.12 / valuation engine 2.5",
        "price_provider": provider,
        "price_history_start": price_history_start,
        "earliest_modelable_year": min(modelable) if modelable else None,
        "earliest_complete_year": min(complete_years) if complete_years else None,
        "price_basis_verified": bool(price_basis_verified),
        "price_adjustment_note": (
            "VERIFIED: raw historical prices are modeled on their contemporaneous share basis and future outcomes are normalized using explicit split-basis factors."
            if price_basis_verified else
            "UNVERIFIED CORPORATE-ACTION BASIS: fallback provider could not be cross-normalized against raw/split Alpaca history. Review split-sensitive years before relying on the score."
        ),
        "start_year": sy,
        "end_year": ey,
        "call_threshold": float(call_threshold),
        "rows": rows,
        "summary": summarize(rows),
        "methodology": {
            "anchor": "Raw/as-traded close on the final trading day on/before Dec 31 (maximum 10-calendar-day lookup gap)",
            "horizon": "+1 calendar-year end; raw outcome shown separately and comparable outcome rebased to the anchor share basis for split-safe scoring",
            "fundamentals": "SEC Companyfacts filtered strictly by filing date <= historical cutoff",
            "assumptions": "Auto assumptions regenerated from information available at each cutoff; current saved assumptions excluded",
            "price_scoring": "Bear/Base/Bull generated from contemporaneous raw price; +1Y raw price normalized to the anchor share basis for stock splits. Yahoo long-history fallback reconstructs raw price from split-adjusted chart quotes plus explicit split events. Alpaca-detected spin-off intervals are quarantined from Reliability until distributed value is normalized.",
            "thesis_scoring": "Actual +1Y revenue growth, net margin and FCF margin tested against anchor Bear/Bull assumption bands",
            "reliability": "Company-specific composite of valuation accuracy, thesis-driver hit rate, direction accuracy and historical bias, penalized for small samples",
        },
    }
    if not price_basis_verified:
        base_label = (result.get("summary") or {}).get("reliability_label") or "NO DATA"
        result["summary"]["reliability_label"] = f"PRICE BASIS REVIEW · {base_label}"

    # Store the latest completed run locally so the Decision page can show the historical trust score.
    # A local persistence problem must not invalidate an otherwise valid historical replay.
    try:
        db.save_validation_result(t, result)
    except Exception as exc:
        result["persistence_warning"] = f"Validation completed but local history could not be saved: {exc}"
    return result


def leakage_self_test() -> dict:
    """Tiny deterministic test proving later SEC observations are excluded by cutoff."""
    sample = {
        "entityName": "TEST CO",
        "facts": {
            "us-gaap": {
                "Revenues": {
                    "label": "Revenue",
                    "units": {"USD": [
                        {"form": "10-K", "filed": "2024-02-01", "start": "2023-01-01", "end": "2023-12-31", "val": 100.0},
                        {"form": "10-K", "filed": "2025-02-01", "start": "2023-01-01", "end": "2023-12-31", "val": 110.0},
                    ]},
                }
            }
        },
    }
    pit = filter_companyfacts_as_of(sample, "2024-12-31")
    vals = pit["facts"]["us-gaap"]["Revenues"]["units"]["USD"]
    ok = len(vals) == 1 and float(vals[0]["val"]) == 100.0 and vals[0]["filed"] == "2024-02-01"
    return {"pass": bool(ok), "kept": vals}
