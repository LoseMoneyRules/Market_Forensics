from __future__ import annotations

import json
import math
import time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Iterable

import requests
import urllib3

from . import alpaca, db
from .config import MARKET_DATA_SECRETS_PATH, alpaca_ready, load_market_data_secrets, load_settings

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class MarketDataError(RuntimeError):
    pass


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _f(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None




def _yahoo_split_events(ticker: str, start_date: str | None = None) -> list[tuple[date,float]]:
    """Independent split-event ledger used to verify share basis for current valuation.

    This does NOT assert that another provider's historical OHLC is raw or adjusted. It only
    proves the cumulative stock-split/reverse-split factor between an SEC share fact and today.
    An empty list is still a verified result when Yahoo responds successfully.
    """
    symbol=ticker.upper().strip().replace(".","-")
    end=datetime.now(timezone.utc)
    try:
        start=date.fromisoformat(str(start_date)[:10]) if start_date else (end.date()-timedelta(days=365*25))
    except Exception:
        start=end.date()-timedelta(days=365*25)
    start_dt=datetime.combine(start-timedelta(days=7), datetime.min.time(), tzinfo=timezone.utc)
    url=f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"
    params={"period1":int(start_dt.timestamp()),"period2":int((end+timedelta(days=1)).timestamp()),"interval":"1d","events":"splits","includeAdjustedClose":"false"}
    headers={"User-Agent":"Mozilla/5.0 MarketForensics/3.1.12 (split-basis verification)"}
    r=requests.get(url,params=params,headers=headers,timeout=25)
    if r.status_code!=200:
        raise MarketDataError(f"Yahoo split ledger HTTP {r.status_code}")
    payload=r.json() or {}; result=((payload.get("chart") or {}).get("result") or [None])[0]
    if not result:
        err=(payload.get("chart") or {}).get("error") or {}
        raise MarketDataError(f"Yahoo split ledger unavailable: {err.get('description') or 'empty result'}")
    events=[]
    for ev in ((result.get("events") or {}).get("splits") or {}).values():
        try:
            sd=datetime.fromtimestamp(int(ev.get("date")),tz=timezone.utc).date()
            num=_f(ev.get("numerator")); den=_f(ev.get("denominator")); ratio=(num/den) if num and den else None
            if ratio is None:
                txt=str(ev.get("splitRatio") or "")
                if ":" in txt:
                    a,b=txt.split(":",1); ratio=float(a)/float(b)
            if ratio and ratio>0: events.append((sd,float(ratio)))
        except Exception:
            continue
    return sorted(events,key=lambda x:x[0])


def _enrich_split_factor_verification(ticker: str, bars: list[dict]) -> list[dict]:
    """Attach a verified cumulative split factor without changing provider price semantics.

    `basis_verified` continues to mean raw-vs-adjusted OHLC mapping is proven.
    `split_factor_verified` is narrower: the split/reverse-split ledger itself is proven.
    Current per-share valuation only needs the latter to reconcile SEC share facts to today's
    share basis; historical raw-price calibration still requires the stronger `basis_verified`.
    """
    rows=[dict(x) for x in (bars or [])]
    if not rows: return rows
    # A provider that already proves raw/split mapping also proves the split factor.
    for r in rows:
        if r.get("basis_verified"):
            r["split_factor_verified"]=True
    # Do not short-circuit on only the recent window. Current valuation may need the split
    # factor at an older SEC filing/share-fact date; every cached bar used as a possible basis
    # anchor must be repaired, otherwise a refresh can appear successful while Bear/Base/Bull
    # remain blocked.
    if all(bool(r.get("split_factor_verified")) for r in rows):
        return rows
    dates=[str(r.get("date") or r.get("trade_date") or "")[:10] for r in rows if r.get("date") or r.get("trade_date")]
    start=min(dates) if dates else None
    try:
        events=_yahoo_split_events(ticker,start)
    except Exception:
        return rows
    for r in rows:
        try: d=date.fromisoformat(str(r.get("date") or r.get("trade_date"))[:10])
        except Exception: continue
        factor=1.0
        for split_day,ratio in events:
            if split_day>d: factor*=ratio
        r["split_factor"]=float(factor)
        r["split_factor_verified"]=True
        old=str(r.get("price_basis") or "").strip()
        suffix="split ledger verified independently (Yahoo events)"
        r["price_basis"]=(old+"; "+suffix).strip("; ") if old else suffix
    return rows


def ensure_split_factor_verification(ticker: str, bars: list[dict]) -> tuple[list[dict], bool]:
    """Best-effort current-valuation share-basis repair.

    Returns the same price observations with an independently verified cumulative split ledger.
    This is intentionally narrower than proving historical OHLC raw/adjusted semantics.
    """
    rows=_enrich_split_factor_verification(ticker,bars)
    usable=[r for r in rows if r.get("date") or r.get("trade_date")]
    verified=bool(usable) and all(bool(r.get("split_factor_verified") or r.get("basis_verified")) for r in usable)
    return rows,verified


def current_split_basis_evidence(ticker: str, anchor_date: str, current_date: str | None=None) -> dict:
    """Verify only the split/reverse-split ledger needed by *current* valuation.

    This is deliberately separate from historical OHLC calibration.  Alpaca corporate actions is
    tried first when credentials are configured; Yahoo split events is the independent public
    fallback.  A successful empty ledger is VERIFIED NONE.
    """
    try:
        anchor=date.fromisoformat(str(anchor_date)[:10])
    except Exception:
        return {"anchor_date":anchor_date,"verified_through":current_date,"split_factor":1.0,"source":"","actions":[],"status":"DATA REVIEW","issue":"Share fact date is missing or invalid"}
    try:
        cur=date.fromisoformat(str(current_date)[:10]) if current_date else datetime.now(timezone.utc).date()
    except Exception:
        cur=datetime.now(timezone.utc).date()
    if anchor>cur:
        return {"anchor_date":anchor.isoformat(),"verified_through":cur.isoformat(),"split_factor":1.0,"source":"","actions":[],"status":"DATA REVIEW","issue":f"Share fact dated {anchor.isoformat()} postdates current price dated {cur.isoformat()}"}

    events=None; source=None; errors=[]
    if alpaca_ready():
        try:
            events=alpaca.get_split_events(ticker,anchor.isoformat(),cur.isoformat())
            source="ALPACA CORPORATE ACTIONS"
        except Exception as e:
            errors.append(f"Alpaca: {e}")
    if events is None:
        try:
            events=[(d,r) for d,r in _yahoo_split_events(ticker,anchor.isoformat()) if d<=cur]
            source="YAHOO SPLIT EVENTS"
        except Exception as e:
            errors.append(f"Yahoo: {e}")
    if events is None:
        return {"anchor_date":anchor.isoformat(),"verified_through":cur.isoformat(),"split_factor":1.0,"source":"","actions":[],"status":"DATA REVIEW",
                "issue":"Unable to verify split/reverse-split actions after share fact dated "+anchor.isoformat()+(" ("+" | ".join(errors)+")" if errors else "")}

    factor=1.0; actions=[]
    for d,ratio in sorted(events,key=lambda x:x[0]):
        if d<=anchor or d>cur:continue
        try:r=float(ratio)
        except Exception:continue
        if r<=0:continue
        factor*=r
        actions.append({"date":d.isoformat(),"ratio":r})
    return {"anchor_date":anchor.isoformat(),"verified_through":cur.isoformat(),"split_factor":float(factor),"source":source or "VERIFIED LEDGER",
            "actions":actions,"status":"VERIFIED","issue":""}


def provider_configuration() -> dict:
    s = load_market_data_secrets()
    settings = load_settings()
    return {
        "ALPACA": bool(alpaca_ready()),
        "IBKR": bool(settings.get("ibkr_enabled", False)),
        "TIINGO": bool(s.get("TIINGO_API_KEY")),
        "ALPHA_VANTAGE": bool(s.get("ALPHA_VANTAGE_API_KEY")),
        "MASSIVE": bool(s.get("MASSIVE_API_KEY")),
        "secrets_path": str(MARKET_DATA_SECRETS_PATH),
    }


def _ibkr_base() -> str:
    return str(load_settings().get("ibkr_base_url") or "https://localhost:5000/v1/api").rstrip("/")


def _ibkr_get(path: str, params=None, timeout=5):
    url = _ibkr_base() + path
    r = requests.get(url, params=params or {}, timeout=timeout, verify=False)
    if r.status_code != 200:
        raise MarketDataError(f"IBKR HTTP {r.status_code}: {r.text[:250]}")
    return r.json()


def _ibkr_conid(ticker: str) -> int:
    rows = _ibkr_get("/iserver/secdef/search", {"symbol": ticker.upper()}, timeout=6)
    if not isinstance(rows, list):
        raise MarketDataError("IBKR contract search returned no list.")
    exact = [x for x in rows if str(x.get("symbol") or "").upper() == ticker.upper()]
    for x in exact or rows:
        try:
            sections = x.get("sections") or []
            if any(str(s.get("secType") or "").upper() == "STK" for s in sections) or x.get("description"):
                return int(x["conid"])
        except Exception:
            continue
    raise MarketDataError(f"IBKR could not resolve {ticker} to a stock conid.")


def test_ibkr() -> dict:
    if not load_settings().get("ibkr_enabled", False):
        return {"ready": False, "status": "DISABLED"}
    try:
        j = _ibkr_get("/tickle", timeout=2.5)
        return {"ready": True, "status": "READY", "detail": "Client Portal Gateway reachable", "raw": j}
    except Exception as exc:
        return {"ready": False, "status": "OFFLINE", "detail": str(exc)}


def _ibkr_period(days: int) -> str:
    if days <= 365: return "1y"
    if days <= 730: return "2y"
    if days <= 1095: return "3y"
    return "15y"


def _ibkr_daily_bars(ticker: str, lookback_days: int) -> list[dict]:
    # A brokerage session + relevant market-data entitlement are required.
    try:
        _ibkr_get("/iserver/accounts", timeout=4)
    except Exception:
        pass
    conid = _ibkr_conid(ticker)
    j = _ibkr_get("/iserver/marketdata/history", {
        "conid": conid,
        "period": _ibkr_period(lookback_days),
        "bar": "1d",
        "outsideRth": "false",
    }, timeout=20)
    data = j.get("data") if isinstance(j, dict) else None
    if not data:
        raise MarketDataError("IBKR historical data returned no bars.")
    out = []
    cutoff = datetime.now(timezone.utc).date() - timedelta(days=int(lookback_days)+3)
    for b in data:
        ts = b.get("t") or b.get("time")
        try:
            if isinstance(ts, (int, float)):
                d = datetime.fromtimestamp(float(ts)/1000.0, timezone.utc).date()
            else:
                d = datetime.fromisoformat(str(ts).replace("Z", "+00:00")).date()
        except Exception:
            continue
        if d < cutoff:
            continue
        close = _f(b.get("c") if "c" in b else b.get("close"))
        if close is None:
            continue
        out.append({
            "date": d.isoformat(),
            "open": _f(b.get("o") if "o" in b else b.get("open")) or close,
            "high": _f(b.get("h") if "h" in b else b.get("high")) or close,
            "low": _f(b.get("l") if "l" in b else b.get("low")) or close,
            "close": close,
            "volume": _f(b.get("v") if "v" in b else b.get("volume")) or 0,
            "trade_count": _f(b.get("n") if "n" in b else b.get("count")) or 0,
            "vwap": _f(b.get("wap") if "wap" in b else b.get("vwap")) or close,
        })
    if not out:
        raise MarketDataError("IBKR historical data could not be parsed.")
    return out


def _tiingo_daily_bars(ticker: str, lookback_days: int, key: str) -> list[dict]:
    """Tiingo EOD on one explicit split-only basis.

    Tiingo exposes raw OHLC plus a per-date splitFactor.  We deliberately do NOT use adjClose
    because it also incorporates cash distributions.  Instead we build the cumulative future
    split factor ourselves, retaining both the contemporaneous raw quote and a split-only
    adjusted quote.
    """
    end = datetime.now(timezone.utc).date()
    start = end - timedelta(days=int(lookback_days)+5)
    r = requests.get(
        f"https://api.tiingo.com/tiingo/daily/{ticker.upper()}/prices",
        headers={"Authorization": f"Token {key}"},
        params={"startDate": start.isoformat(), "endDate": end.isoformat(), "resampleFreq": "daily"},
        timeout=30,
    )
    if r.status_code != 200:
        raise MarketDataError(f"Tiingo HTTP {r.status_code}: {r.text[:250]}")
    raw_rows=[]
    for b in r.json() or []:
        close=_f(b.get("close"))
        if close is None or close <= 0:
            continue
        raw_rows.append({
            "date":str(b.get("date") or "")[:10],
            "open":_f(b.get("open")) or close,"high":_f(b.get("high")) or close,"low":_f(b.get("low")) or close,
            "raw_close":close,"volume":_f(b.get("volume")) or 0,"trade_count":0,"vwap":close,
            "event_split_factor":_f(b.get("splitFactor")) or 1.0,
        })
    raw_rows.sort(key=lambda x:x["date"])
    if not raw_rows:
        raise MarketDataError("Tiingo returned no EOD bars.")
    # splitFactor applies on the ex-date.  A quote ON the ex-date is already on the new basis,
    # so only later split events belong in that date's cumulative factor.
    cumulative=1.0
    out=[]
    for b in reversed(raw_rows):
        factor=cumulative
        raw=float(b["raw_close"]); split_close=raw/factor if factor > 0 else raw
        out.append({
            "date":b["date"],"open":float(b["open"])/factor,"high":float(b["high"])/factor,"low":float(b["low"])/factor,
            "close":split_close,"raw_close":raw,"split_adjusted_close":split_close,"split_factor":factor,
            "basis_verified":True,"split_factor_verified":True,"price_basis":"split-adjusted; raw retained (Tiingo splitFactor)",
            "volume":float(b["volume"])*factor,"trade_count":0,"vwap":split_close,
        })
        ev=float(b.get("event_split_factor") or 1.0)
        if ev > 0:
            cumulative *= ev
    out.reverse()
    return out


def _alpha_daily_bars(ticker: str, lookback_days: int, key: str) -> list[dict]:
    """Alpha Vantage bars with raw and split-only bases kept separate.

    DAILY_ADJUSTED exposes raw OHLC plus split coefficients, which lets us reconstruct a
    split-only adjusted close without mixing dividends into valuation history.  If that endpoint
    is not available for the user's entitlement, raw DAILY remains usable for charts/live price
    but is explicitly marked basis-unverified for split normalization.
    """
    params={"function":"TIME_SERIES_DAILY_ADJUSTED","symbol":ticker.upper(),"outputsize":"full","apikey":key}
    r=requests.get("https://www.alphavantage.co/query",params=params,timeout=35)
    j=r.json() if r.status_code==200 else {}
    ts=(j or {}).get("Time Series (Daily)") or {}
    adjusted=bool(ts)
    if not ts:
        r=requests.get("https://www.alphavantage.co/query",params={"function":"TIME_SERIES_DAILY","symbol":ticker.upper(),"outputsize":"full","apikey":key},timeout=35)
        if r.status_code != 200:
            raise MarketDataError(f"Alpha Vantage HTTP {r.status_code}")
        j=r.json() or {}; ts=j.get("Time Series (Daily)") or {}
    if not ts:
        msg=(j or {}).get("Note") or (j or {}).get("Information") or (j or {}).get("Error Message") or "no daily series"
        raise MarketDataError(f"Alpha Vantage: {msg}")
    cutoff=datetime.now(timezone.utc).date()-timedelta(days=int(lookback_days)+5)
    rows=[]
    for ds,row in sorted(ts.items()):
        try:d=date.fromisoformat(ds)
        except Exception:continue
        if d<cutoff:continue
        raw=_f(row.get("4. close"))
        if raw is None or raw <= 0:continue
        rows.append({
            "date":ds,"raw_open":_f(row.get("1. open")) or raw,"raw_high":_f(row.get("2. high")) or raw,
            "raw_low":_f(row.get("3. low")) or raw,"raw_close":raw,"raw_volume":_f(row.get("6. volume") if adjusted else row.get("5. volume")) or 0,
            "event_split_factor":_f(row.get("8. split coefficient")) if adjusted else 1.0,
        })
    if not rows:
        raise MarketDataError("Alpha Vantage returned no usable bars.")
    cumulative=1.0; out=[]
    for b in reversed(rows):
        factor=cumulative if adjusted else 1.0
        raw=float(b["raw_close"]); split_close=raw/factor if factor>0 else raw
        out.append({
            "date":b["date"],"open":float(b["raw_open"])/factor,"high":float(b["raw_high"])/factor,"low":float(b["raw_low"])/factor,
            "close":split_close,"raw_close":raw,"split_adjusted_close":split_close,"split_factor":factor,
            "basis_verified":bool(adjusted),"split_factor_verified":bool(adjusted),
            "price_basis":"split-adjusted; raw retained (Alpha split coefficient)" if adjusted else "raw only; split basis unverified",
            "volume":float(b["raw_volume"])*factor,"trade_count":0,"vwap":split_close,
        })
        ev=float(b.get("event_split_factor") or 1.0)
        if adjusted and ev > 0:cumulative*=ev
    out.reverse(); return out


def _alpaca_canonical_bars(ticker: str, lookback_days: int, feed_mode="auto"):
    """Fetch raw + split-adjusted Alpaca bars and bind them to one explicit basis."""
    raw, raw_feed = alpaca.get_daily_bars(ticker,lookback_days,feed_mode,adjustment="raw")
    split, split_feed = alpaca.get_daily_bars(ticker,lookback_days,feed_mode,adjustment="split")
    raw_map={str(x.get("date") or "")[:10]:x for x in raw or []}
    out=[]; matched=0
    same_feed=(raw_feed==split_feed)
    for a in split or []:
        ds=str(a.get("date") or "")[:10]; r=raw_map.get(ds)
        adj_close=_f(a.get("close")); raw_close=_f((r or {}).get("close"))
        factor=(raw_close/adj_close) if raw_close and adj_close and adj_close>0 else None
        verified=bool(same_feed and factor and factor>0)
        if verified:matched+=1
        row=dict(a)
        row.update({
            "raw_close":raw_close if raw_close is not None else adj_close,
            "split_adjusted_close":adj_close,"split_factor":float(factor) if verified else 1.0,
            "basis_verified":verified,"split_factor_verified":verified,"price_basis":"split-adjusted; raw retained (Alpaca raw/split pair)" if verified else "split-adjusted; raw pairing unverified",
        })
        out.append(row)
    coverage=(matched/len(out)) if out else 0.0
    basis_ok=bool(out and same_feed and coverage>=.90)
    if not basis_ok:
        for row in out:row["basis_verified"]=False
    return out, split_feed, basis_ok


def get_daily_bars(ticker: str, lookback_days=500, feed_mode="auto"):
    """Provider router returning split-adjusted chart bars plus explicit raw/share-basis metadata.

    `close` is ALWAYS split-adjusted when the provider can prove the mapping.  `raw_close` is the
    contemporaneous quote and `split_factor = raw_close / split_adjusted_close`.  Unverified
    providers are retained for continuity but may not be used to normalize SEC share counts or
    historical valuation calibration.
    """
    secrets=load_market_data_secrets(); settings=load_settings(); errors=[]
    order = [str(x).upper() for x in settings.get("market_data_order", ["ALPACA","IBKR","TIINGO","ALPHA_VANTAGE"])]
    for name in order:
        try:
            if name=="ALPACA" and alpaca_ready():
                bars,feed,_ok=_alpaca_canonical_bars(ticker,lookback_days,feed_mode)
                return _enrich_split_factor_verification(ticker,bars), f"alpaca_{feed}"
            if name=="IBKR" and settings.get("ibkr_enabled",False):
                rows=_ibkr_daily_bars(ticker,lookback_days)
                for r in rows:
                    r["raw_close"]=r.get("close");r["split_adjusted_close"]=r.get("close");r["split_factor"]=1.0
                    r["basis_verified"]=False;r["split_factor_verified"]=False;r["price_basis"]="IBKR OHLC basis not independently verified"
                return _enrich_split_factor_verification(ticker,rows), "ibkr"
            if name=="TIINGO" and secrets.get("TIINGO_API_KEY"):
                rows=_tiingo_daily_bars(ticker,lookback_days,secrets["TIINGO_API_KEY"])
                return _enrich_split_factor_verification(ticker,rows), "tiingo_eod"
            if name=="ALPHA_VANTAGE" and secrets.get("ALPHA_VANTAGE_API_KEY"):
                rows=_alpha_daily_bars(ticker,lookback_days,secrets["ALPHA_VANTAGE_API_KEY"])
                return _enrich_split_factor_verification(ticker,rows), "alpha_vantage"
        except Exception as exc:
            errors.append(f"{name}: {exc}")
            continue
    cached=db.query("SELECT * FROM daily_bars WHERE ticker=? ORDER BY trade_date",(ticker.upper(),))
    if cached:
        out=[]
        for x in cached:
            r=dict(x) | {"date":x["trade_date"]}
            r["raw_close"]=_f(r.get("raw_close")) or _f(r.get("close"))
            r["split_adjusted_close"]=_f(r.get("split_adjusted_close")) or _f(r.get("close"))
            r["split_factor"]=_f(r.get("split_factor")) or 1.0
            r["basis_verified"]=bool(r.get("basis_verified"))
            r["split_factor_verified"]=bool(r.get("split_factor_verified") or r.get("basis_verified"))
            r["price_basis"]=r.get("price_basis") or "legacy cache; basis unverified"
            out.append(r)
        return _enrich_split_factor_verification(ticker,out), "sqlite_cache"
    raise MarketDataError("No daily-price provider available. " + " | ".join(errors[-4:]))


def _yahoo_validation_bars(ticker: str, lookback_days=14610) -> list[dict]:
    """Long-history fallback with Yahoo split-adjusted quotes reconstructed to raw basis.

    Yahoo chart `quote.close` is treated as split-adjusted.  Split events are therefore used to
    reconstruct the historical as-traded/raw share basis; we must NOT apply the split factor to
    that quote a second time during scoring.  Cash dividends are intentionally excluded from the
    factor because Validate scores price targets, not total return.
    """
    symbol=ticker.upper().strip().replace(".","-")
    url=f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"
    end=datetime.now(timezone.utc);start=end-timedelta(days=int(lookback_days)+15)
    params={"period1":int(start.timestamp()),"period2":int((end+timedelta(days=1)).timestamp()),"interval":"1d","events":"splits","includeAdjustedClose":"true"}
    headers={"User-Agent":"Mozilla/5.0 MarketForensics/3.1.12 (historical validation)"}
    r=requests.get(url,params=params,headers=headers,timeout=35)
    if r.status_code!=200:raise MarketDataError(f"Yahoo history HTTP {r.status_code}")
    payload=r.json() or {};result=((payload.get("chart") or {}).get("result") or [None])[0]
    if not result:
        err=(payload.get("chart") or {}).get("error") or {};raise MarketDataError(f"Yahoo history unavailable: {err.get('description') or 'empty result'}")
    timestamps=result.get("timestamp") or [];quotes=(((result.get("indicators") or {}).get("quote") or [{}])[0])
    split_events=[]
    for ev in ((result.get("events") or {}).get("splits") or {}).values():
        try:
            sd=datetime.fromtimestamp(int(ev.get("date")),tz=timezone.utc).date();num=_f(ev.get("numerator"));den=_f(ev.get("denominator"))
            ratio=(num/den) if num and den else None
            if ratio is None:
                txt=str(ev.get("splitRatio") or "")
                if ":" in txt:
                    a,b=txt.split(":",1);ratio=float(a)/float(b)
            if ratio and ratio>0:split_events.append((sd,float(ratio)))
        except Exception:continue
    split_events.sort(key=lambda x:x[0])
    out=[]
    for i,ts in enumerate(timestamps):
        try:
            day=datetime.fromtimestamp(int(ts),tz=timezone.utc).date();adj=_f((quotes.get("close") or [])[i])
            if adj is None or adj<=0:continue
            factor=1.0
            for split_day,ratio in split_events:
                if split_day>day:factor*=ratio
            raw=adj*factor
            def q(name):
                v=_f((quotes.get(name) or [])[i]);return (v*factor) if v is not None else raw
            out.append({
                "date":day.isoformat(),"open":q("open"),"high":q("high"),"low":q("low"),
                "close":raw,"raw_close":raw,"split_adjusted_close":adj,"split_factor":factor,
                "basis_verified":True,"split_factor_verified":True,"price_basis":"raw reconstructed from Yahoo split-adjusted close + split events",
                "non_split_action_factor":1.0,"non_split_action_verified":False,
                "volume":_f((quotes.get("volume") or [])[i]),
            })
        except (IndexError,TypeError,ValueError):continue
    if not out:raise MarketDataError("Yahoo history returned no usable daily bars")
    return out


def _earliest_bar_year(rows: list[dict]) -> int | None:
    years=[]
    for row in rows or []:
        try:
            years.append(int(str(row.get("date") or row.get("trade_date") or "")[:4]))
        except Exception:
            pass
    return min(years) if years else None


def get_validation_daily_bars(ticker: str, lookback_days=14610, feed_mode="auto", minimum_start_year: int | None = None):
    """Return raw point-in-time quotes + split factors for walk-forward validation.

    The scorer operates on `close=raw_close`.  `split_factor` converts a later raw quote back to
    the anchor share basis.  A basis is considered verified only when raw and split-adjusted
    histories (or explicit split events) prove that conversion.
    """
    alpaca_candidate=None
    if alpaca_ready():
        try:
            canon,feed,ok=_alpaca_canonical_bars(ticker,lookback_days,feed_mode)
            # A split is share-basis math; a spin-off is value transfer. Detect the latter
            # separately so pre/post spin-off replays can be quarantined rather than "fixed"
            # with a split ratio. This call is best-effort and does not block split verification.
            spin_map={}; spin_verified=False
            try:
                spin_rows,spin_feed=alpaca.get_daily_bars(ticker,lookback_days,feed_mode,adjustment="split,spin-off")
                if spin_feed==feed:
                    spin_map={str(x.get("date") or "")[:10]:_f(x.get("close")) for x in spin_rows or []};spin_verified=bool(spin_map)
            except Exception:
                pass
            rows=[]
            for x in canon:
                r=dict(x);raw=_f(r.get("raw_close"));
                if raw is None:continue
                split_px=_f(r.get("split_adjusted_close") or r.get("close")); spin_px=spin_map.get(str(r.get("date") or "")[:10])
                spin_factor=(split_px/spin_px) if spin_verified and split_px and spin_px and spin_px>0 else 1.0
                r["close"]=raw;r["basis_verified"]=bool(ok and r.get("basis_verified"));
                r["non_split_action_factor"]=float(spin_factor) if spin_factor and spin_factor>0 else 1.0
                r["non_split_action_verified"]=bool(spin_verified)
                rows.append(r)
            if rows and ok:
                alpaca_candidate=(rows,f"alpaca_{feed}_raw+split_basis",True)
                earliest=_earliest_bar_year(rows)
                if minimum_start_year is None or (earliest is not None and earliest<=int(minimum_start_year)):
                    return alpaca_candidate
        except Exception:
            pass
    try:
        yahoo=_yahoo_validation_bars(ticker,lookback_days);y_start=_earliest_bar_year(yahoo)
        a_start=_earliest_bar_year(alpaca_candidate[0]) if alpaca_candidate else None
        if yahoo and (alpaca_candidate is None or (y_start is not None and (a_start is None or y_start<a_start))):
            return yahoo,"yahoo_chart_reconstructed_raw+split_events_long_history",True
    except Exception:
        pass
    if alpaca_candidate is not None:return alpaca_candidate
    bars,provider=get_daily_bars(ticker,lookback_days,feed_mode);out=[]
    for row in bars or []:
        r=dict(row);raw=_f(r.get("raw_close"))
        r["close"]=raw if raw is not None else _f(r.get("close"));r["split_factor"]=_f(r.get("split_factor")) or 1.0
        out.append(r)
    verified=bool(out) and all(bool(x.get("basis_verified")) for x in out[-min(len(out),250):])
    return out,provider,verified


def _massive_paged(path: str, params: dict, key: str) -> list[dict]:
    url=f"https://api.massive.com{path}"; out=[]; loops=0
    while url and loops<100:
        q=dict(params) if loops==0 else {"apiKey":key}
        if loops==0: q["apiKey"]=key
        r=requests.get(url,params=q,timeout=40)
        if r.status_code!=200: raise MarketDataError(f"Massive HTTP {r.status_code}: {r.text[:250]}")
        j=r.json() or {}; out.extend(j.get("results") or [])
        url=j.get("next_url"); loops+=1
        if url and "apiKey=" not in url: pass
    return out


def get_session_trades_quotes(ticker: str, day, feed_mode="auto"):
    """Full tape router. Alpaca first; Massive is the independent tick/NBBO fallback."""
    errors=[]
    if alpaca_ready():
        try:
            tr,qt,feed=alpaca.get_session_trades_quotes(ticker,day,feed_mode)
            return tr,qt,feed
        except Exception as exc: errors.append(f"ALPACA: {exc}")
    key=load_market_data_secrets().get("MASSIVE_API_KEY")
    if key:
        try:
            start,end=alpaca.regular_session_utc(day)
            p={"timestamp.gte":start.isoformat().replace("+00:00","Z"),"timestamp.lte":end.isoformat().replace("+00:00","Z"),"order":"asc","sort":"timestamp","limit":50000}
            trades_raw=_massive_paged(f"/v3/trades/{ticker.upper()}",p,key)
            quotes_raw=_massive_paged(f"/v3/quotes/{ticker.upper()}",p,key)
            tr=[]; qt=[]
            for x in trades_raw:
                ts=x.get("sip_timestamp") or x.get("participant_timestamp")
                if ts is None: continue
                iso=datetime.fromtimestamp(float(ts)/1e9,timezone.utc).isoformat().replace("+00:00","Z")
                tr.append({"t":iso,"p":x.get("price"),"s":x.get("size")})
            for x in quotes_raw:
                ts=x.get("sip_timestamp") or x.get("participant_timestamp") or x.get("trf_timestamp")
                if ts is None: continue
                iso=datetime.fromtimestamp(float(ts)/1e9,timezone.utc).isoformat().replace("+00:00","Z")
                qt.append({"t":iso,"bp":x.get("bid_price"),"ap":x.get("ask_price"),"bs":x.get("bid_size"),"as":x.get("ask_size")})
            return tr,qt,"massive_sip"
        except Exception as exc: errors.append(f"MASSIVE: {exc}")
    return [],[],"none"



_LIVE_PRICE_CACHE = {}

def _snapshot_price_result(snap: dict, feed: str) -> dict | None:
    snap=snap or {}
    candidates=[]
    lt=snap.get("latestTrade") or snap.get("latest_trade") or {}
    mb=snap.get("minuteBar") or snap.get("minute_bar") or {}
    dbb=snap.get("dailyBar") or snap.get("daily_bar") or {}
    for kind,row,pk,tk in (("LAST TRADE",lt,"p","t"),("MINUTE BAR",mb,"c","t"),("DAILY BAR",dbb,"c","t")):
        px=_f(row.get(pk)) if isinstance(row,dict) else None
        ts=row.get(tk) if isinstance(row,dict) else None
        if px is not None and px>0:
            candidates.append((kind,px,ts))
    if not candidates:
        return None
    kind,px,ts=candidates[0]
    age_minutes=None
    if ts:
        try:
            dt=datetime.fromisoformat(str(ts).replace("Z","+00:00"))
            if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
            age_minutes=max(0.0,(datetime.now(timezone.utc)-dt).total_seconds()/60.0)
        except Exception:
            pass
    if age_minutes is None:
        freshness="TIMESTAMP UNKNOWN"
    elif age_minutes <= 2.5:
        freshness="RECENT"
    elif age_minutes <= 20:
        freshness=f"DELAYED ~{int(round(age_minutes))} MIN"
    else:
        freshness="LAST SESSION / STALE"
    return {"price":px,"asof":ts,"provider":f"ALPACA {str(feed).upper()}","quality":kind,"age_minutes":age_minutes,"freshness":freshness}


def current_price_overlay(ticker: str, feed_mode: str = "auto", max_cache_seconds: int = 45) -> dict | None:
    """Return a recent quote/snapshot for display and current decision gaps without a full refresh.

    This is intentionally separate from daily-bar history and from SEC/share-basis validation. It never
    rewrites historical bars. The returned timestamp/status makes delayed or last-session prices explicit.
    """
    t=str(ticker or "").upper().strip()
    if not t:
        return None
    now_mono=time.monotonic()
    cache_key=(t,str(feed_mode or "auto").lower())
    cached=_LIVE_PRICE_CACHE.get(cache_key)
    if cached and now_mono-cached[0] <= max(1,int(max_cache_seconds)):
        return dict(cached[1]) if cached[1] else None
    result=None
    try:
        snaps,feed=alpaca.get_snapshots([t],feed_mode)
        result=_snapshot_price_result((snaps or {}).get(t) or {},feed)
    except Exception:
        result=None
    _LIVE_PRICE_CACHE[cache_key]=(now_mono,result)
    return dict(result) if result else None


def current_price_overlays(tickers, feed_mode: str = "auto", max_cache_seconds: int = 45) -> dict:
    """Batch version of current_price_overlay used by Portfolio/queues to avoid one HTTP call per ticker."""
    names=[]; seen=set(); now_mono=time.monotonic(); out={}; missing=[]
    mode=str(feed_mode or "auto").lower()
    for raw in tickers or []:
        t=str(raw or "").upper().strip()
        if not t or t in seen: continue
        seen.add(t); names.append(t)
        cached=_LIVE_PRICE_CACHE.get((t,mode))
        if cached and now_mono-cached[0] <= max(1,int(max_cache_seconds)):
            if cached[1]: out[t]=dict(cached[1])
        else:
            missing.append(t)
    if missing:
        try:
            snaps,feed=alpaca.get_snapshots(missing,feed_mode)
            for t in missing:
                result=_snapshot_price_result((snaps or {}).get(t) or {},feed)
                _LIVE_PRICE_CACHE[(t,mode)]=(now_mono,result)
                if result: out[t]=dict(result)
        except Exception:
            for t in missing:
                _LIVE_PRICE_CACHE[(t,mode)]=(now_mono,None)
    return out


def _tiingo_price(ticker: str, key: str) -> dict | None:
    # Prefer IEX/reference endpoint; fall back to latest EOD.
    try:
        r=requests.get(f"https://api.tiingo.com/iex/{ticker.upper()}",headers={"Authorization":f"Token {key}"},timeout=10)
        if r.status_code==200:
            j=r.json(); row=(j[0] if isinstance(j,list) and j else j) or {}
            px=_f(row.get("last") or row.get("tngoLast") or row.get("mid") or row.get("prevClose"))
            if px is not None: return {"provider":"TIINGO","price":px,"asof":row.get("timestamp") or row.get("lastSaleTimestamp"),"quality":"IEX/REFERENCE"}
    except Exception: pass
    try:
        r=requests.get(f"https://api.tiingo.com/tiingo/daily/{ticker.upper()}/prices",headers={"Authorization":f"Token {key}"},timeout=10)
        if r.status_code==200 and r.json():
            row=r.json()[-1]; px=_f(row.get("close"))
            if px is not None:return {"provider":"TIINGO","price":px,"asof":str(row.get("date") or ""),"quality":"EOD"}
    except Exception: pass
    return None


def _alpha_price(ticker: str, key: str) -> dict | None:
    try:
        r=requests.get("https://www.alphavantage.co/query",params={"function":"GLOBAL_QUOTE","symbol":ticker.upper(),"apikey":key},timeout=12)
        if r.status_code==200:
            q=(r.json() or {}).get("Global Quote") or {}; px=_f(q.get("05. price"))
            if px is not None:return {"provider":"ALPHA_VANTAGE","price":px,"asof":q.get("07. latest trading day"),"quality":"REFERENCE"}
    except Exception: pass
    return None


def _ibkr_price(ticker: str) -> dict | None:
    try:
        _ibkr_get("/iserver/accounts",timeout=3)
        conid=_ibkr_conid(ticker)
        # Preflight then second request; field 31 = last price.
        _ibkr_get("/iserver/marketdata/snapshot",{"conids":str(conid),"fields":"31,84,86"},timeout=4)
        time.sleep(.35)
        j=_ibkr_get("/iserver/marketdata/snapshot",{"conids":str(conid),"fields":"31,84,86"},timeout=4)
        row=(j[0] if isinstance(j,list) and j else {}) or {}
        raw=str(row.get("31") or "").lstrip("CH")
        px=_f(raw)
        if px is not None:return {"provider":"IBKR","price":px,"asof":datetime.fromtimestamp((row.get("_updated") or 0)/1000,timezone.utc).isoformat() if row.get("_updated") else None,"quality":"TOP_OF_BOOK"}
    except Exception: pass
    return None


def _asof_date(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).date().isoformat()
    except Exception:
        try:
            return date.fromisoformat(str(value)[:10]).isoformat()
        except Exception:
            return None


def _market_session_may_be_partial(asof_date: str | None) -> bool:
    """Conservative flag for a US daily bar that may still be moving.

    No holiday calendar is required here: false positives merely downgrade a
    discrepancy to WARN instead of FAIL. They never suppress a disagreement.
    """
    if not asof_date:
        return False
    try:
        from zoneinfo import ZoneInfo
        now_et = datetime.now(ZoneInfo("America/New_York"))
        d = date.fromisoformat(str(asof_date)[:10])
        if d != now_et.date() or now_et.weekday() >= 5:
            return False
        mins = now_et.hour * 60 + now_et.minute
        return (9 * 60 + 30) <= mins <= (16 * 60 + 20)
    except Exception:
        return False


def reference_prices(ticker: str, primary_price=None, primary_asof=None, primary_provider=None) -> list[dict]:
    """Return independent reference prices with explicit timestamps/quality.

    The primary value normally comes from the bar actually used by the model.
    Independent references can be live/top-of-book/EOD. The cross-check later
    refuses to call mismatched trading dates a hard FAIL.
    """
    out=[]; secrets=load_market_data_secrets(); settings=load_settings()
    if primary_price is not None:
        out.append({
            "provider": str(primary_provider or "PRIMARY").upper(),
            "price": float(primary_price),
            "asof": primary_asof or _now_iso(),
            "quality": "MODEL_INPUT_BAR",
            "is_primary": True,
        })
    if settings.get("ibkr_enabled",False):
        x=_ibkr_price(ticker)
        if x: out.append(x)
    if secrets.get("TIINGO_API_KEY"):
        x=_tiingo_price(ticker,secrets["TIINGO_API_KEY"])
        if x: out.append(x)
    if secrets.get("ALPHA_VANTAGE_API_KEY"):
        x=_alpha_price(ticker,secrets["ALPHA_VANTAGE_API_KEY"])
        if x: out.append(x)
    return out


def price_cross_check(ticker: str, primary_price=None, primary_asof=None, primary_provider=None) -> dict:
    settings=load_settings(); rows=reference_prices(ticker,primary_price,primary_asof,primary_provider)
    for r in rows:
        r["asof_date"]=_asof_date(r.get("asof"))
    primary = next((r for r in rows if r.get("is_primary")), None)
    primary_date = (primary or {}).get("asof_date")

    # Compare like-for-like trading dates whenever timestamps are available.
    comparable=[]
    for r in rows:
        px=_f(r.get("price"))
        same_date = (not primary_date) or (not r.get("asof_date")) or (r.get("asof_date")==primary_date)
        r["comparable"] = bool(px is not None and px>0 and same_date)
        if r["comparable"]:
            comparable.append(r)

    vals=[float(r["price"]) for r in comparable]
    if not vals:
        return {"status":"NO DATA","consensus":None,"max_deviation_pct":None,"sources":rows,"message":"No comparable independent price source available."}
    vals2=sorted(vals); consensus=vals2[len(vals2)//2] if len(vals2)%2 else sum(vals2[len(vals2)//2-1:len(vals2)//2+1])/2
    for r in rows:
        px=_f(r.get("price"))
        r["deviation_pct"]=(px/consensus-1) if (px is not None and consensus and r.get("comparable")) else None
    maxdev=max((abs(r.get("deviation_pct") or 0) for r in comparable), default=0.0)
    warn=float(settings.get("price_crosscheck_warn_pct",.005)); fail=float(settings.get("price_crosscheck_fail_pct",.02))
    independent=[r for r in comparable if not r.get("is_primary")]
    mismatched=[r for r in rows if _f(r.get("price")) is not None and not r.get("comparable")]
    partial = _market_session_may_be_partial(primary_date)

    if not independent:
        status="LOW DATA"; msg="No independent price on the same trading date is currently available."
    elif maxdev>=fail:
        # Intraday references can legitimately be newer than a partial/delayed daily bar.
        # Never pretend this is a verified bad price when timing is mixed.
        if partial:
            status="WARN"; msg=f"Price sources differ by as much as {maxdev:.2%} during a potentially partial US session. Re-check after the close before treating this as a hard discrepancy."
        else:
            status="FAIL"; msg=f"Comparable price providers disagree by as much as {maxdev:.2%}. Review timestamps/corporate actions before relying on the price."
    elif maxdev>=warn:
        status="WARN"; msg=f"Comparable price providers show a {maxdev:.2%} dispersion. Check feed timing before acting."
    else:
        status="PASS"; msg=f"Independent comparable prices agree within {maxdev:.2%}."
    if mismatched:
        msg += f" {len(mismatched)} source(s) were excluded from the hard comparison because their trading date differed."
    return {"status":status,"consensus":consensus,"max_deviation_pct":maxdev,"sources":rows,"message":msg,"primary_asof":primary_asof,"partial_session":partial}


def store_price_check(ticker: str, check: dict) -> None:
    now=_now_iso()
    for r in check.get("sources") or []:
        comparable = r.get("comparable")
        comparable_db = None if comparable is None else (1 if bool(comparable) else 0)
        db.execute("""INSERT INTO price_checks(ticker,checked_at,provider,price,asof,quality,deviation_pct,comparable,status,message)
                      VALUES(?,?,?,?,?,?,?,?,?,?)""",
                   (ticker.upper(),now,r.get("provider"),r.get("price"),r.get("asof"),r.get("quality"),r.get("deviation_pct"),comparable_db,check.get("status"),check.get("message")))


def latest_price_check(ticker: str) -> dict:
    rows=db.query("SELECT * FROM price_checks WHERE ticker=? ORDER BY id DESC LIMIT 8",(ticker.upper(),))
    if not rows:return {"status":"NO DATA","sources":[]}
    checked=rows[0]["checked_at"]; group=[dict(r) for r in rows if r["checked_at"]==checked]
    return {"status":group[0].get("status"),"message":group[0].get("message"),"checked_at":checked,"sources":group}


def get_active_us_assets(user_agent: str = ""):
    """Universe router. Alpaca first; SEC ticker/exchange mapping is the independent fallback."""
    try:
        if alpaca_ready():
            return alpaca.get_active_us_assets(), "alpaca_assets"
    except Exception:
        pass
    ua = user_agent or str(load_settings().get("sec_user_agent") or "")
    if not ua:
        raise MarketDataError("No asset-universe provider available: Alpaca unavailable and SEC User-Agent missing.")
    r=requests.get("https://www.sec.gov/files/company_tickers_exchange.json",headers={"User-Agent":ua,"Accept-Encoding":"gzip, deflate"},timeout=30)
    if r.status_code!=200: raise MarketDataError(f"SEC ticker/exchange map HTTP {r.status_code}")
    j=r.json() or {}; fields=j.get("fields") or []; data=j.get("data") or []
    out=[]
    if fields and data:
        for vals in data:
            row=dict(zip(fields,vals)); t=str(row.get("ticker") or "").upper().strip(); ex=str(row.get("exchange") or "")
            if t: out.append({"ticker":t,"name":row.get("name") or row.get("title") or "","exchange":ex,"tradable":True,"shortable":False,"borrow_status":"","has_options":False})
    elif isinstance(j,dict):
        for row in j.values():
            if not isinstance(row,dict): continue
            t=str(row.get("ticker") or "").upper().strip()
            if t: out.append({"ticker":t,"name":row.get("title") or row.get("name") or "","exchange":row.get("exchange") or "","tradable":True,"shortable":False,"borrow_status":"","has_options":False})
    if not out: raise MarketDataError("SEC ticker/exchange mapping returned no usable symbols.")
    return out, "sec_universe"


def _tiingo_market_latest(key: str) -> dict:
    r=requests.get("https://api.tiingo.com/tiingo/daily/prices",headers={"Authorization":f"Token {key}"},timeout=45)
    if r.status_code!=200: raise MarketDataError(f"Tiingo market latest HTTP {r.status_code}: {r.text[:200]}")
    out={}
    for row in r.json() or []:
        t=str(row.get("ticker") or "").upper().strip(); px=_f(row.get("close")); vol=_f(row.get("volume"))
        if not t or px is None: continue
        out[t]={"latestTrade":{"p":px},"dailyBar":{"c":px,"v":vol or 0},"prevDailyBar":{}}
    return out


def get_snapshots(tickers: Iterable[str], feed_mode="auto"):
    """Market-wide snapshot router. Alpaca is preferred; Tiingo EOD is the independent fallback."""
    names=[str(x).upper().strip() for x in tickers if str(x).strip()]
    if not names:return {},"none"
    errors=[]
    try:
        if alpaca_ready():
            return alpaca.get_snapshots(names,feed_mode,chunk_size=80)
    except Exception as exc: errors.append(f"ALPACA: {exc}")
    key=load_market_data_secrets().get("TIINGO_API_KEY")
    if key:
        try:
            allrows=_tiingo_market_latest(key); wanted=set(names)
            return {t:s for t,s in allrows.items() if t in wanted},"tiingo_eod"
        except Exception as exc: errors.append(f"TIINGO: {exc}")
    raise MarketDataError("No market-wide snapshot provider available. " + " | ".join(errors))
