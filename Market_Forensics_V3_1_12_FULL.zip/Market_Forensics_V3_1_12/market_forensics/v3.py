from __future__ import annotations

import html
from urllib.parse import urlparse
from datetime import datetime, timezone, date

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from . import alpaca, backtest, db, decision, discovery, exporter, fundamentals, jobs, opportunity, service, symbols, triangulation, marketdata
from . import workstation as ws
from .config import (DB_PATH, SECRETS_PATH, MARKET_DATA_SECRETS_PATH, alpaca_ready, load_settings, save_settings,
                     load_market_data_secrets, save_market_data_secrets, clear_market_data_secrets,
                     branding_logo_path, save_branding_logo, clear_branding_logo)
from .ui import fnum, fprice, fpct

MF_PLOTLY_COLORS = [
    "#3F78A8", "#1F9D68", "#C99A2E", "#D15353", "#6E8FA8",
    "#2E8894", "#7A8B99", "#7D9B68", "#9AB7CF", "#B6C5D1",
]

VISIBLE_PAGES = [
    ("pages/00_discovery.py", "Discover", ":material/radar:"),
    ("pages/01_coverage_v3.py", "Decision Queue", ":material/bookmarks:"),
    ("pages/02_decide_v3.py", "Decide", ":material/gavel:"),
    ("pages/03_research_v3.py", "Research", ":material/science:"),
    ("pages/04_monitor_v3.py", "Monitor", ":material/monitoring:"),
    ("pages/05_validate_v3.py", "Validate", ":material/history:"),
    ("pages/05_portfolio_v3.py", "Portfolio", ":material/account_balance:"),
    ("pages/06_settings_v3.py", "Settings", ":material/settings:"),
]

DETAIL_PATHS = {
    "Fundamentals": "pages/03_fundamentals.py",
    "Financial Flows": "pages/03_financial_flows.py",
    "Management & Forecast": "pages/04_management_forecast.py",
    "Valuation": "pages/04_valuation.py",
    "Tape": "pages/05_tape.py",
    "Monitoring": "pages/06_monitoring.py",
    "Thesis & Bear Case": "pages/07_thesis.py",
    "Risk & Journal": "pages/08_risk.py",
    "Portfolio Detail": "pages/09_portfolio.py",
    "Sources & Audit": "pages/10_sources.py",
}

ADVANCED_PARENT_BY_SLUG = {
    "advanced-valuation": ("Decide", "Valuation Cases"),
    "advanced-thesis": ("Decide", "Thesis & Bear Case"),
    "advanced-risk": ("Decide", "Risk & Journal"),
    "advanced-fundamentals": ("Research", "Fundamentals"),
    "advanced-financial-flows": ("Research", "Financial Flows"),
    "advanced-management": ("Research", "5Y Operating Forecast"),
    "advanced-tape": ("Research", "Tape & Positioning"),
    "advanced-sources": ("Research", "Sources & Audit"),
    "advanced-monitoring": ("Monitor", "Monitoring & Events"),
    "advanced-portfolio": ("Portfolio", "Portfolio Detail"),
}

GATE_EDIT_TARGETS = {
    "business": ("Thesis & Bear Case", DETAIL_PATHS["Thesis & Bear Case"]),
    "five_year_financials": ("Fundamentals", DETAIL_PATHS["Fundamentals"]),
    "working_capital": ("Fundamentals", DETAIL_PATHS["Fundamentals"]),
    "value_drivers": ("Thesis & Bear Case", DETAIL_PATHS["Thesis & Bear Case"]),
    "expectations": ("Valuation Cases", DETAIL_PATHS["Valuation"]),
    "variant": ("Decide · Variant above", "pages/02_decide_v3.py"),
    "scenarios": ("Valuation Cases", DETAIL_PATHS["Valuation"]),
    "expected_value": ("Valuation Cases", DETAIL_PATHS["Valuation"]),
    "counter_thesis": ("Thesis & Bear Case", DETAIL_PATHS["Thesis & Bear Case"]),
    "catalysts": ("Thesis & Bear Case", DETAIL_PATHS["Thesis & Bear Case"]),
    "invalidation": ("Monitoring · lock KPI", DETAIL_PATHS["Monitoring"]),
    "evidence_to_add": ("Thesis & Bear Case", DETAIL_PATHS["Thesis & Bear Case"]),
    "sizing": ("Risk & Journal", DETAIL_PATHS["Risk & Journal"]),
    "concentration": ("Risk & Journal", DETAIL_PATHS["Risk & Journal"]),
    "sources": ("Sources & Audit", DETAIL_PATHS["Sources & Audit"]),
    "journal": ("Risk & Journal", DETAIL_PATHS["Risk & Journal"]),
}

V3_CSS = r"""
<style>
:root{
 --primary-color:#3F78A8!important;
 --mf-surface:var(--secondary-background-color);
 --mf-panel:color-mix(in srgb,var(--secondary-background-color) 93%,var(--background-color));
 --mf-panel-strong:color-mix(in srgb,var(--secondary-background-color) 82%,var(--background-color));
 --mf-border:color-mix(in srgb,var(--text-color) 17%,transparent);
 --mf-border-strong:color-mix(in srgb,var(--text-color) 26%,transparent);
 --mf-muted:color-mix(in srgb,var(--text-color) 63%,transparent);
 --mf-blue:#3f78a8;--mf-blue-strong:#245f91;--mf-green:#1f9d68;--mf-red:#d15353;--mf-yellow:#c99a2e;
 --mf-shadow:0 5px 18px color-mix(in srgb,#000 10%,transparent);
}
html{scroll-padding-top:5rem}
.stApp{background:var(--background-color);color:var(--text-color)}
.block-container{padding-top:2.65rem;max-width:1580px;padding-bottom:4.3rem}
/* Institutional sidebar */
section[data-testid="stSidebar"]{border-right:1px solid var(--mf-border);background:var(--secondary-background-color)}
section[data-testid="stSidebar"] [data-testid="stSidebarContent"]{padding-top:.5rem}
section[data-testid="stSidebar"] hr{border-color:var(--mf-border);margin:.85rem 0}
section[data-testid="stSidebar"] [data-testid="stPageLink"] a{padding:.56rem .68rem;border:1px solid transparent;border-radius:8px;font-weight:650}
section[data-testid="stSidebar"] [data-testid="stPageLink"] a:hover{background:var(--mf-panel);border-color:var(--mf-border)}
section[data-testid="stSidebar"] [data-testid="stPageLink"] a[aria-current="page"],
section[data-testid="stSidebar"] [data-testid="stPageLink"] a[aria-selected="true"],
section[data-testid="stSidebar"] [data-testid="stPageLink"] a:focus-visible{color:var(--mf-blue)!important;border-color:var(--mf-blue)!important;background:color-mix(in srgb,var(--mf-blue) 11%,transparent)!important;outline-color:var(--mf-blue)!important;box-shadow:0 0 0 1px color-mix(in srgb,var(--mf-blue) 18%,transparent)!important}
button:focus-visible,a:focus-visible,[data-baseweb="select"]>div:focus-within,input:focus,textarea:focus{outline-color:var(--mf-blue)!important;border-color:var(--mf-blue)!important;box-shadow:0 0 0 1px color-mix(in srgb,var(--mf-blue) 20%,transparent)!important}
[data-baseweb="tab"][aria-selected="true"]{color:var(--mf-blue)!important;border-bottom-color:var(--mf-blue)!important}
/* V3.1.12 accent hard-lock: prevent Streamlit/BaseWeb/Plotly fallback purple in menus and states. */
html,body,.stApp,section[data-testid="stSidebar"]{--primary-color:#3F78A8!important;}
section[data-testid="stSidebar"] [data-testid="stPageLink"] a,
section[data-testid="stSidebar"] [data-testid="stPageLink"] a *{color:inherit!important;}
section[data-testid="stSidebar"] [data-testid="stPageLink"] a:hover{color:var(--mf-blue)!important;background:color-mix(in srgb,var(--mf-blue) 9%,var(--mf-panel))!important;border-color:color-mix(in srgb,var(--mf-blue) 48%,var(--mf-border))!important;}
section[data-testid="stSidebar"] [data-testid="stPageLink"] a[aria-current="page"],
section[data-testid="stSidebar"] [data-testid="stPageLink"] a[aria-selected="true"]{color:var(--mf-blue)!important;background:color-mix(in srgb,var(--mf-blue) 12%,var(--mf-panel))!important;border-color:var(--mf-blue)!important;}
[data-testid="stSidebarCollapseButton"] button:hover,[data-testid="stSidebarCollapseButton"] button:focus-visible,
[data-testid="stSidebarCollapsedControl"] button:hover,[data-testid="stSidebarCollapsedControl"] button:focus-visible{color:var(--mf-blue)!important;border-color:var(--mf-blue)!important;background:color-mix(in srgb,var(--mf-blue) 10%,transparent)!important;}
.stButton>button[kind="primary"],.stDownloadButton>button[kind="primary"],button[data-testid="baseButton-primary"]{background:var(--mf-blue)!important;border-color:var(--mf-blue)!important;color:#fff!important;}
.stButton>button[kind="primary"]:hover,.stDownloadButton>button[kind="primary"]:hover,button[data-testid="baseButton-primary"]:hover{background:var(--mf-blue-strong)!important;border-color:var(--mf-blue-strong)!important;color:#fff!important;}
[data-baseweb="menu"] [aria-selected="true"],[role="option"][aria-selected="true"],[data-baseweb="popover"] [aria-selected="true"]{background:color-mix(in srgb,var(--mf-blue) 13%,var(--background-color))!important;color:var(--text-color)!important;}
input[type="checkbox"],input[type="radio"]{accent-color:var(--mf-blue)!important;}
/* Border contrast: subtle in light, visible but quiet in dark. */
@media (prefers-color-scheme: dark){
  :root{--mf-border:color-mix(in srgb,var(--text-color) 24%,transparent);--mf-border-strong:color-mix(in srgb,var(--text-color) 34%,transparent);}
}
html[data-theme="dark"],body[data-theme="dark"],[data-theme="dark"]{--mf-border:color-mix(in srgb,var(--text-color) 24%,transparent);--mf-border-strong:color-mix(in srgb,var(--text-color) 34%,transparent);}
/* Heading hierarchy */
.mf3-kicker{font-size:1.08rem;line-height:1.15;letter-spacing:.08em;color:var(--mf-blue);font-weight:850;text-transform:uppercase;margin-bottom:.18rem}.mf3-kicker.company-ticker{font-size:2.65rem;line-height:1;letter-spacing:-.035em;color:var(--text-color);font-weight:880;text-transform:uppercase;margin:.05rem 0 .32rem}
.mf3-head{font-size:2.15rem;font-weight:790;line-height:1.05;margin:.22rem 0 .4rem;letter-spacing:-.025em}
.mf3-sub{color:var(--mf-muted);font-size:.96rem;max-width:1050px;line-height:1.5}
.mf3-section-title{font-size:.7rem;letter-spacing:.12em;text-transform:uppercase;color:var(--mf-muted);font-weight:800;margin:1.15rem 0 .48rem}
/* True containers */
.mf3-panel,.mf3-section{border:1px solid var(--mf-border);background:var(--mf-panel);border-radius:11px;padding:18px 19px;margin:.6rem 0 1rem;box-shadow:var(--mf-shadow)}
.mf3-decision{border:1px solid var(--mf-border);border-left:5px solid var(--mf-blue);background:var(--mf-panel);border-radius:11px;padding:18px 20px;margin:.8rem 0 1.1rem;box-shadow:var(--mf-shadow)}
.mf3-decision.green{border-left-color:var(--mf-green)}.mf3-decision.red{border-left-color:var(--mf-red)}.mf3-decision.yellow{border-left-color:var(--mf-yellow)}
.mf3-small{color:var(--mf-muted);font-size:.83rem;line-height:1.4}.mf3-big{font-size:1.48rem;font-weight:790;margin:.14rem 0;letter-spacing:-.015em}
.mf3-row{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin:.6rem 0}
.mf3-row4{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:.6rem 0}
.mf3-box{border:1px solid var(--mf-border);border-radius:10px;padding:15px 16px;background:var(--mf-panel);min-height:112px;box-shadow:0 2px 9px color-mix(in srgb,#000 8%,transparent)}
.mf3-box.hero{min-height:122px;background:var(--mf-panel)}
.mf3-box .lbl{font-size:.68rem;letter-spacing:.09em;color:var(--mf-muted);font-weight:780;text-transform:uppercase}
.mf3-box .val{font-size:1.21rem;font-weight:790;margin:.30rem 0;line-height:1.2}.mf3-box.hero .val{font-size:1.48rem}
.mf3-box .why{font-size:.81rem;color:var(--mf-muted);line-height:1.38}
.mf3-callout{border:1px solid var(--mf-border);border-radius:10px;padding:15px 16px;background:var(--mf-panel);min-height:132px;box-shadow:0 2px 9px color-mix(in srgb,#000 7%,transparent)}
.mf3-callout h4{margin:.05rem 0 .5rem;font-size:.9rem}.mf3-callout p{margin:.2rem 0;color:var(--mf-muted);font-size:.84rem;line-height:1.42}
.mf3-signal-pos{border-left:4px solid var(--mf-green)}.mf3-signal-neg{border-left:4px solid var(--mf-red)}.mf3-signal-data{border-left:4px solid var(--mf-yellow)}
/* Native widgets: contained, legible, bank-terminal style */
div[data-testid="stMetric"]{border:1px solid var(--mf-border);background:var(--mf-panel);padding:13px 15px;border-radius:10px;min-height:108px;box-shadow:0 2px 8px color-mix(in srgb,#000 7%,transparent)}
div[data-testid="stMetricLabel"]{color:var(--mf-muted);font-weight:650}
div[data-testid="stMetricValue"]{font-weight:760;letter-spacing:-.015em}
[data-testid="stPlotlyChart"]{border:1px solid var(--mf-border);border-radius:10px;overflow:hidden;background:var(--mf-panel);box-shadow:0 2px 10px color-mix(in srgb,#000 8%,transparent);padding:2px}
[data-testid="stDataFrame"]{border:1px solid var(--mf-border);border-radius:9px;overflow:hidden;box-shadow:0 2px 8px color-mix(in srgb,#000 6%,transparent)}
details[data-testid="stExpander"]{border:1px solid var(--mf-border)!important;border-radius:10px!important;background:var(--mf-panel);margin:.55rem 0!important;box-shadow:0 2px 8px color-mix(in srgb,#000 6%,transparent)}
details[data-testid="stExpander"] summary{font-weight:690;padding:.08rem .15rem}
[data-testid="stForm"]{border:1px solid var(--mf-border);border-radius:10px;padding:16px 16px 8px;background:var(--mf-panel)}
.stButton>button,.stDownloadButton>button{border:1px solid var(--mf-border-strong)!important;border-radius:8px!important;font-weight:680!important;box-shadow:none!important}
.stButton>button:hover,.stDownloadButton>button:hover{border-color:var(--mf-blue)!important;color:var(--mf-blue)!important}
/* Footer */
.mf3-footer{margin-top:2.4rem;padding:1rem 0 .25rem;border-top:1px solid var(--mf-border);text-align:center;color:var(--mf-muted);font-size:.74rem;letter-spacing:.04em;font-weight:650}
/* Collapsed navigation icon rail */
.mf-icon-rail{position:fixed;left:7px;top:86px;z-index:999;width:42px;padding:7px 4px;border:1px solid var(--mf-border);border-radius:10px;background:color-mix(in srgb,var(--background-color) 96%,transparent);box-shadow:0 8px 24px color-mix(in srgb,#000 15%,transparent);backdrop-filter:blur(10px)}
.mf-icon-rail a{display:flex;align-items:center;justify-content:center;width:32px;height:32px;margin:4px auto;border:1px solid transparent;border-radius:7px;color:var(--text-color);text-decoration:none;font-size:17px;font-weight:800}
.mf-icon-rail a:hover{border-color:var(--mf-border-strong);background:var(--mf-panel)}
body:has(section[data-testid="stSidebar"][aria-expanded="true"]) .mf-icon-rail{display:none}
@media(max-width:1100px){.mf3-row4{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:900px){.mf-icon-rail{display:none!important}.mf3-row,.mf3-row4{grid-template-columns:1fr}.mf3-kicker{font-size:.98rem}.mf3-kicker.company-ticker{font-size:2.15rem}.mf3-head{font-size:1.78rem}.block-container{padding-top:2.35rem}}
</style>
"""


def inject_css():
    st.markdown(V3_CSS, unsafe_allow_html=True)
    try:
        dark = st.context.theme.type == "dark"
    except Exception:
        dark = True
    border = "#3A4751" if dark else "#D7DEE4"
    border_strong = "#50606B" if dark else "#C4CDD5"
    st.markdown(
        f"""<style>
        :root,.stApp{{--mf-border:{border}!important;--mf-border-strong:{border_strong}!important;}}
        [data-testid="stVerticalBlockBorderWrapper"],details[data-testid="stExpander"],[data-testid="stForm"],
        [data-baseweb="select"]>div,[data-baseweb="input"]>div,[data-baseweb="textarea"]>div,
        [data-testid="stDataFrame"],[data-testid="stPlotlyChart"],div[data-testid="stMetric"]{{border-color:var(--mf-border)!important;}}
        </style>""",
        unsafe_allow_html=True,
    )


def _age_label(iso_text):
    if not iso_text:
        return "NEVER"
    try:
        dt = datetime.fromisoformat(str(iso_text).replace("Z", "+00:00"))
        if dt.tzinfo is None: dt = dt.replace(tzinfo=timezone.utc)
        h = (datetime.now(timezone.utc)-dt).total_seconds()/3600
        if h < 6: return f"{h:.1f}h"
        if h < 24: return f"{h:.0f}h"
        return f"{h/24:.1f}d OLD"
    except Exception:
        return "UNKNOWN"


def render_sidebar(nav_items, current_page=None):
    """Main navigation only.

    Advanced/detail pages stay out of the sidebar. When one is open, its parent main section is
    marked with a blue dot and a small breadcrumb so hierarchy is obvious without adding another
    menu level. The detail page itself also keeps its Back-to-Parent control at the top.
    """
    saved = db.all_workspace_tickers()
    qp = str(st.query_params.get("ticker") or "").upper().strip()
    current = qp or st.session_state.get("ticker") or (saved[0] if saved else "")
    if current and current not in saved and saved:
        current = saved[0]

    detail_parent = ADVANCED_PARENT_BY_SLUG
    page_url = str(getattr(current_page, "url_path", "") or getattr(current_page, "_url_path", "") or "").strip("/")
    parent_label, detail_label = detail_parent.get(page_url, (None, None))
    parent_slug = next((str(item.get("url_path") or "").strip("/") for item in nav_items if item.get("label") == parent_label), "")

    with st.sidebar:
        if parent_slug:
            # Advanced pages stay hidden from the menu, but their owning primary page is visibly active.
            st.markdown(
                f"""<style>
                section[data-testid=\"stSidebar\"] [data-testid=\"stPageLink\"]:has(a[href$=\"/{html.escape(parent_slug)}\"]) a,
                section[data-testid=\"stSidebar\"] [data-testid=\"stPageLink\"]:has(a[href=\"{html.escape(parent_slug)}\"]) a{{
                    color:var(--mf-blue)!important;
                    border-color:color-mix(in srgb,var(--mf-blue) 62%,var(--mf-border))!important;
                    background:color-mix(in srgb,var(--mf-blue) 11%,var(--mf-panel))!important;
                }}
                </style>""",
                unsafe_allow_html=True,
            )
        logo = branding_logo_path()
        if logo:
            st.image(str(logo), width=170)
            st.markdown("### Market Forensics")
        else:
            st.markdown("### ◈ Market Forensics")
        st.caption("V3.1.12")
        st.caption("by Lose Money Rules")
        if saved:
            selected = st.selectbox("Company", saved, index=saved.index(current) if current in saved else 0, key="mf3_ticker")
            st.session_state["ticker"] = selected
            current = selected
            try:
                st.query_params["ticker"] = current
            except Exception:
                pass
            pos=db.portfolio_position(current)
            cov=db.coverage_row(current)
            status=[]
            if pos: status.append(f"{pos.get('side')} {float(pos.get('shares') or 0):g} sh")
            if cov: status.append(str(cov.get('status') or 'RESEARCH'))
            if status: st.caption(" · ".join(status))
            last = service.last_successful_refresh(current)
            st.caption(f"Data: {_age_label((last or {}).get('completed_at'))}")
        else:
            st.caption("No companies yet. Add a position in Portfolio, or start in Discover/Decision Queue.")
            st.session_state["ticker"] = ""

        st.markdown("---")
        for item in nav_items:
            label=item["label"]
            shown = f"{label}  •" if parent_label == label else label
            st.page_link(item["page"], label=shown, icon=item.get("icon"), width="stretch",
                         disabled=bool(item.get("requires_ticker") and not current))
            if parent_label == label and detail_label:
                st.markdown(f'<div style="margin:-.34rem 0 .35rem 2.55rem;color:#3F78A8;font-size:.76rem;font-weight:750">↳ {html.escape(detail_label)}</div>', unsafe_allow_html=True)

        st.markdown("---")
        if current and st.button("Refresh company", type="primary", width="stretch", key="mf3_refresh"):
            jobs.start_or_enqueue([current], reason="V3_SELECTED", include_flow=True)
            st.toast(f"Refreshing {current} in background.")
        ws.render_background_refresh_monitor()
        dr = discovery.latest_run()
        if dr and dr.get("status") in ("QUEUED","RUNNING"):
            st.caption(f"Discovery: {dr.get('stage')} · {dr.get('current_ticker') or ''}")
        elif dr and dr.get("status") in ("FAIL","INTERRUPTED"):
            st.warning(f"Discovery {dr.get('status')}: {dr.get('error_message') or dr.get('stage') or 'check Discover'}")
    return current



def render_icon_rail(nav_items):
    """Always-available icon rail when the Streamlit sidebar is collapsed.

    Links preserve the selected ticker through the query string, so a direct
    route starts a new Streamlit session without losing company context.
    """
    icons = {"Discover":"◎","Coverage":"▣","Decision Queue":"▣","Decide":"⚖","Research":"◇","Monitor":"↻","Validate":"✓","Portfolio":"▦","Settings":"⚙"}
    current = str(st.session_state.get("ticker") or st.query_params.get("ticker") or "").upper().strip()
    parts=[]
    for item in nav_items:
        slug=item.get("url_path") or ""
        href=("/" if item.get("default") else f"/{slug}")
        if current:
            href += f"?ticker={html.escape(current)}"
        label=html.escape(item.get("label") or "")
        icon=icons.get(item.get("label"),"•")
        parts.append(f'<a href="{href}" target="_self" title="{label}" aria-label="{label}">{icon}</a>')
    st.markdown('<div class="mf-icon-rail">'+''.join(parts)+'</div>',unsafe_allow_html=True)


def _workflow_back(path: str, label: str, context: str = ""):
    c1,c2=st.columns([1.15,4.85])
    c1.page_link(path,label=f"← {label}",width="stretch")
    if context:c2.caption(context)

def render_footer():
    st.markdown('<div class="mf3-footer">Lose Money Rules</div>', unsafe_allow_html=True)


def title(kicker, title, subtitle=""):
    # Company pages use the ticker as a primary visual anchor; workspace labels stay compact.
    workspace_labels={"DISCOVERY","COVERAGE","DECISION QUEUE","VALIDATE","PORTFOLIO","SETTINGS"}
    cls="mf3-kicker" if str(kicker).upper() in workspace_labels else "mf3-kicker company-ticker"
    st.markdown(f'<div class="{cls}">{html.escape(kicker)}</div><div class="mf3-head">{html.escape(title)}</div><div class="mf3-sub">{html.escape(subtitle)}</div>', unsafe_allow_html=True)


def _tone(value):
    v = str(value).upper()
    if any(x in v for x in ("BAD","EXPENSIVE","DEMANDING","NEGATIVE","HOSTILE","FAIL","DATA REVIEW","HIGH","LIMITED")): return "red"
    if any(x in v for x in ("GOOD","ATTRACTIVE","FAVORABLE","POSITIVE EDGE","SUPPORTIVE","READY","CONTROLLED","STRONG")): return "green"
    return "yellow"


def _box(label, value, why="", hero=False, tone_override=None):
    tone=tone_override or _tone(value)
    color={"green":"var(--mf-green)","red":"var(--mf-red)","yellow":"var(--mf-yellow)","neutral":"var(--text-color)"}.get(tone,"var(--text-color)")
    cls="mf3-box hero" if hero else "mf3-box"
    if tone == "neutral":
        style=""
    else:
        style=f"border-color:color-mix(in srgb,{color} 58%,var(--mf-border));box-shadow:inset 4px 0 0 {color},0 1px 0 color-mix(in srgb,var(--text-color) 5%,transparent);"
    return f'<div class="{cls}" style="{style}"><div class="lbl">{html.escape(label)}</div><div class="val" style="color:{color}">{html.escape(str(value))}</div><div class="why">{html.escape(str(why or ""))}</div></div>'


def _chart_template():
    try:
        return "plotly_dark" if st.context.theme.type == "dark" else "plotly_white"
    except Exception:
        return "plotly_dark"


def _style_plot(fig: go.Figure, **layout_kwargs) -> go.Figure:
    base = dict(
        template=_chart_template(),
        colorway=MF_PLOTLY_COLORS,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
    )
    base.update(layout_kwargs)
    fig.update_layout(**base)
    return fig


def _price_chart(state: dict, height=360):
    bars=state.get("bars") or []
    if not bars:
        return None
    df=pd.DataFrame(bars).copy()
    if df.empty or "trade_date" not in df:
        return None
    df["trade_date"]=pd.to_datetime(df["trade_date"])
    df=df.sort_values("trade_date").tail(260)
    fig=go.Figure()
    fig.add_trace(go.Scatter(x=df["trade_date"],y=df["close"],mode="lines",name="Price",line=dict(width=2.2,color="#6E8FA8")))
    sc=state.get("scenarios") or {}
    refs=[("Bear",(sc.get("bear") or {}).get("fair_value"),"dot","#D15353"),("Base",state.get("base_value"),"dash","#AAB6C2"),("Bull",(sc.get("bull") or {}).get("fair_value"),"dot","#1F9D68")]
    for label,val,dash,color in refs:
        if val is not None:
            fig.add_hline(y=float(val),line_dash=dash,line_color=color,line_width=1.5,annotation_text=label,annotation_position="top left",annotation_font_color=color)
    _style_plot(fig,height=height,margin=dict(l=10,r=10,t=42,b=10),title="Price vs valuation range",legend=dict(orientation="h",y=1.02,x=0))
    return fig


def _business_chart(state: dict, height=360):
    rows=[r for r in (state.get("fund_rows") or []) if r.get("period_type")=="FY"]
    if not rows:
        return None
    df=pd.DataFrame(rows).sort_values("fiscal_year").tail(7).copy()
    if df.empty:
        return None
    df["fcf_margin"] = df.apply(lambda r: (r.get("fcf")/r.get("revenue")) if r.get("revenue") not in (None,0) and r.get("fcf") is not None else None,axis=1)
    fig=go.Figure()
    fig.add_trace(go.Bar(x=df["fiscal_year"],y=df["revenue"],name="Revenue",marker_color="#3F78A8"))
    fig.add_trace(go.Scatter(x=df["fiscal_year"],y=df["fcf_margin"]*100,name="FCF margin %",mode="lines+markers",yaxis="y2",line=dict(width=2.2,color="#1F9D68"),marker=dict(color="#1F9D68")))
    _style_plot(fig,height=height,margin=dict(l=10,r=10,t=42,b=10),title="Operating trend",yaxis2=dict(overlaying="y",side="right",ticksuffix="%"),legend=dict(orientation="h",y=1.02,x=0))
    return fig


def _signal_html(title_text, items, css_class, empty_text):
    body=[]
    for x in (items or [])[:4]:
        sig=str(x.get("Signal") or x.get("Title") or "Signal")
        ev=str(x.get("Evidence") or x.get("Detail") or "")
        body.append(f'<p><b>{html.escape(sig)}</b> — {html.escape(ev)}</p>')
    if not body:
        body=[f'<p>{html.escape(empty_text)}</p>']
    return f'<div class="mf3-callout {css_class}"><h4>{html.escape(title_text)}</h4>{"".join(body)}</div>'


def _business_view(state):
    q = state.get("quality_validation") or {}
    score = q.get("score")
    if score is None: return "UNKNOWN", "Need more operating history"
    if score >= 70: return "GOOD", f"Quality validation {score:.0f}/100"
    if score < 45: return "BAD", f"Quality validation {score:.0f}/100"
    return "MIXED", f"Quality validation {score:.0f}/100"


def _value_view(state):
    gap=state.get("upside"); vc=state.get("valuation_confidence") or {}
    if gap is None: return "UNKNOWN", "No usable fair-value range"
    if gap >= .20: return "ATTRACTIVE", f"Base gap {gap:+.0%} · confidence {vc.get('label','LOW')}"
    if gap <= -.20: return "EXPENSIVE", f"Base gap {gap:+.0%} · confidence {vc.get('label','LOW')}"
    return "FAIR", f"Base gap {gap:+.0%}"


def _expectations_view(state):
    """Judge price-implied expectations across growth, profitability and terminal multiple.

    This deliberately avoids letting one driver (historically revenue growth) dominate the label.
    A driver is favorable when the current price requires less than our Base operating case,
    demanding when it requires more, and balanced when the gap is immaterial.
    """
    rec=state.get("price_reconciliation") or {}
    drivers=[]

    def add_driver(label, forecast, implied, threshold, kind="pct"):
        if forecast is None or implied is None:
            return
        try:
            f=float(forecast); i=float(implied)
        except Exception:
            return
        gap=f-i
        if gap >= threshold:
            vote="FAVORABLE"
        elif gap <= -threshold:
            vote="DEMANDING"
        else:
            vote="BALANCED"
        drivers.append({"label":label,"forecast":f,"implied":i,"gap":gap,"vote":vote,"kind":kind})

    add_driver("Revenue CAGR",rec.get("forecast_revenue_cagr"),rec.get("market_implied_revenue_cagr"),.025,"pct")
    add_driver("Net margin",rec.get("forecast_terminal_net_margin"),rec.get("market_implied_net_margin"),.015,"pct")
    add_driver("Exit P/E",rec.get("forecast_exit_pe"),rec.get("market_implied_exit_pe"),2.0,"multiple")
    if len(drivers) < 2:
        return "UNKNOWN", "Need at least two price-implied operating drivers"
    fav=sum(1 for d in drivers if d["vote"]=="FAVORABLE")
    dem=sum(1 for d in drivers if d["vote"]=="DEMANDING")
    if fav >= 2 and fav > dem:
        label="FAVORABLE"
    elif dem >= 2 and dem > fav:
        label="DEMANDING"
    else:
        label="BALANCED"
    compact=[]
    for d in drivers:
        if d["kind"]=="multiple":
            compact.append(f"{d['label']} {d['implied']:.1f}x vs Base {d['forecast']:.1f}x")
        else:
            compact.append(f"{d['label']} {d['implied']:.1%} vs Base {d['forecast']:.1%}")
    return label, " · ".join(compact)

def _variant_view(state):
    v=state.get("variant_case") or {}
    tri=state.get("triangulation") or {}
    market=str(v.get("market_belief") or "").strip(); ours=str(v.get("our_belief") or "").strip()
    if market and ours:
        value=state.get("upside")
        if value is not None and value >= .15: return "POSITIVE EDGE", "Explicit market-vs-us disagreement + valuation support"
        if value is not None and value <= -.15: return "NEGATIVE EDGE", "Explicit disagreement + demanding valuation"
        return "DEFINED / UNPROVEN", "Disagreement is written; evidence/catalyst still decides"
    score=tri.get("score")
    if score is not None and score >= 70 and (state.get("upside") or 0) > .10: return "POSSIBLE POSITIVE EDGE", "Peer triangulation supports the company case"
    if score is not None and score <= 30 and (state.get("upside") or 0) < -.10: return "POSSIBLE NEGATIVE EDGE", "Peer triangulation challenges the company case"
    return "UNPROVEN", "Write what the market believes and why we disagree"


def _path_view(state, focus=""):
    v=state.get("variant_case") or {}
    manual=str(v.get("path_status") or "UNCLEAR").upper()
    if manual in ("SUPPORTIVE","HOSTILE"):
        return manual, v.get("resolution_signal") or "Manual thesis-path assessment"
    research=db.load_research(state["coverage"].get("ticker") or state.get("ticker") or "") if state.get("coverage") else {}
    catalysts=(research or {}).get("catalysts") or ""
    tape=state.get("scores") or {}
    nt=tape.get("Net Tape")
    focus=str(focus or "").upper()
    is_short="SHORT" in focus
    is_long="LONG" in focus
    if nt is not None:
        if is_long and nt >= 58 and catalysts:
            return "SUPPORTIVE", "Catalyst defined and tape supports the long path"
        if is_long and nt < 40:
            return "HOSTILE", "Tape currently opposes the long path"
        if is_short and nt <= 42 and catalysts:
            return "SUPPORTIVE", "Catalyst defined and tape supports the short path"
        if is_short and nt > 60:
            return "HOSTILE", "Tape currently opposes the short path"
    return "UNCLEAR", "The path to close the disagreement is not sufficiently confirmed"

def _risk_view(ticker, state):
    """Risk is controlled only when thesis invalidation and portfolio math are both explicit."""
    ar=state.get("audit") or {}; counts=ar.get("counts") or {}
    if int(counts.get("FAIL",0) or 0)>0:
        return "DATA REVIEW", "Audit failure must be resolved first"
    if state.get("gate_counts",{}).get("FAIL",0):
        return "HIGH", "At least one material investment gate fails"

    kpis=state.get("kpis") or []
    locked=[r for r in kpis if r.get("linked_to")=="INVALIDATION" and r.get("threshold") is not None and int(r.get("locked") or 0)==1]
    if not locked:
        return "UNRESOLVED", "No LOCKED numerical thesis invalidation threshold"

    rp=db.risk_plan(ticker) or {}
    required=(rp.get("portfolio_risk_budget"),rp.get("invalidation_price"),rp.get("max_position_cap"))
    if not all(x is not None for x in required):
        return "UNRESOLVED", "Position-size risk plan is incomplete"

    price=state.get("price")
    bear=(state.get("scenarios") or {}).get("bear",{}).get("fair_value")
    if price not in (None,0) and bear is not None:
        try:
            downside=float(bear)/float(price)-1.0
            if downside <= -.45:
                return "HIGH", f"Bear case implies {downside:.0%} downside; size/event risk must be exceptionally controlled"
        except Exception:
            pass

    m=state.get("metrics") or {}
    nd=m.get("net_debt"); fcf=m.get("fcf"); rev=m.get("revenue")
    try:
        if nd is not None and float(nd)>0:
            if fcf is not None and float(fcf)>0 and float(nd)/float(fcf) > 5:
                return "HIGH", "Net debt exceeds 5x current FCF"
            if (fcf is None or float(fcf)<=0) and rev not in (None,0) and float(nd)/float(rev) > .75:
                return "HIGH", "High net debt with non-positive FCF"
    except Exception:
        pass

    settings=load_settings(); nav=float(settings.get("portfolio_nav") or 0)
    # Portfolio is an independent real-position ledger in V3.1.12; risk must never depend on
    # whether a ticker already has a Coverage thesis. Legacy Coverage is only a compatibility fallback.
    pos=db.portfolio_position(ticker) or {}
    cov=state.get("coverage") or {}
    pos_side=(pos.get("side") or cov.get("portfolio_state") or "").upper()
    pos_shares=pos.get("shares") if pos else cov.get("shares_owned")
    if nav>0 and price not in (None,0):
        try:
            weight=abs(float(pos_shares or 0)*float(price))/nav
            cap=float(rp.get("max_position_cap") or 0)
            if cap>0 and weight > cap*1.05:
                return "HIGH", f"Current position {weight:.1%} exceeds max cap {cap:.1%}"
        except Exception:
            pass

    if not str(rp.get("correlation_notes") or "").strip() and pos_side in ("LONG","SHORT"):
        return "UNRESOLVED", "Correlation / factor concentration has not been documented"
    return "CONTROLLED", f"{len(locked)} locked thesis invalidation rule(s) + sizing plan are in place"

def _model_confidence(ticker, state):
    """Confidence overlay: current valuation evidence + company-specific walk-forward reliability."""
    vc=state.get("valuation_confidence") or {}
    try: vc_score=float(vc.get("score")) if vc.get("score") is not None else None
    except Exception: vc_score=None
    hist=db.latest_validation_result(ticker)
    if not hist:
        return "UNVALIDATED", "Run Validate before treating the model as decision-grade"
    hs=hist.get("summary") or {}
    try: rel=float(hs.get("reliability_score")) if hs.get("reliability_score") is not None else None
    except Exception: rel=None
    sample=str(hs.get("sample_confidence") or "LOW").upper()
    basis=bool(hist.get("price_basis_verified"))
    if not basis:
        return "LIMITED", "Historical corporate-action price basis is unverified"
    if rel is None:
        return "LIMITED", "Historical validation has no usable reliability score"
    if sample=="LOW":
        return "LIMITED", f"Reliability {rel:.0f}/100 but historical sample is LOW"
    if str(vc.get("label") or "LOW").upper()=="LOW" or (vc_score is not None and vc_score<45):
        return "LIMITED", f"Current valuation confidence is {vc.get('label','LOW')}"
    if rel>=70 and sample=="HIGH" and (vc_score is None or vc_score>=65):
        return "STRONG", f"Reliability {rel:.0f}/100 · {sample} sample · valuation confidence {vc.get('label','LOW')}"
    if rel>=50 and (vc_score is None or vc_score>=50):
        return "MODERATE", f"Reliability {rel:.0f}/100 · {sample} sample · valuation confidence {vc.get('label','LOW')}"
    return "LIMITED", f"Reliability {rel:.0f}/100 is not strong enough for decision-grade confidence"


def _shares_compact(v):
    try:
        x=float(v)
        if abs(x)>=1e9:return f"{x/1e9:.3f}B"
        if abs(x)>=1e6:return f"{x/1e6:.2f}M"
        return f"{x:,.0f}"
    except Exception:return "—"


def _scenario_table(state):
    """All inputs and outputs used by the valuation Bear/Base/Bull cases."""
    ass=state.get("assumptions") or {}; sc=state.get("scenarios") or {}
    rows=[]
    specs=[
        ("Probability","prob","pct"),("Forward revenue growth","growth","pct"),
        ("Normalized operating margin","operating_margin","pct"),("Normalized net margin","net_margin","pct"),
        ("Normalized FCF margin","fcf_margin","pct"),("Tax rate","tax_rate","pct"),
        ("P/E multiple","pe","multiple"),("EV / Sales","ev_sales","multiple"),
        ("Target FCF yield","target_fcf_yield","pct"),("FCFE equity discount rate","wacc","pct"),
        ("DCF terminal growth","terminal_growth","pct"),("Manual FV override","manual_override","price"),
    ]
    def fmt(v, kind):
        if v is None: return "—"
        try:
            x=float(v)
            if kind=="pct": return f"{x:.1%}"
            if kind=="multiple": return f"{x:.2f}x"
            if kind=="price": return fprice(x)
            return fnum(x,2)
        except Exception: return str(v)
    for label,key,kind in specs:
        rows.append({"Input / Output":label, **{name.title():fmt((ass.get(name) or {}).get(key),kind) for name in ("bear","base","bull")}})
    # Per-share outputs are only meaningful when the denominator is explicit. Keep current and
    # forward share assumptions in the same case table so buyback/dilution effects are auditable.
    rows.append({"Input / Output":"Current valuation shares", **{name.title():_shares_compact((sc.get(name) or {}).get("current_diluted_shares")) for name in ("bear","base","bull")}})
    rows.append({"Input / Output":"Forward shares used by multiple methods", **{name.title():_shares_compact((sc.get(name) or {}).get("forward_diluted_shares")) for name in ("bear","base","bull")}})
    rows.append({"Input / Output":"Share-basis confidence", **{name.title():str((sc.get(name) or {}).get("share_basis_confidence") or "—") for name in ("bear","base","bull")}})
    outs=[
        ("P/E method value","pe"),("EV/Sales method value","ev_sales"),("FCF-yield method value","fcf_yield"),
        ("DCF cross-check","dcf"),("Method P25","range_low"),("Primary fair value","fair_value"),("Method P75","range_high"),
    ]
    for label,key in outs:
        rows.append({"Input / Output":label, **{name.title():fprice((sc.get(name) or {}).get(key)) for name in ("bear","base","bull")}})
    return pd.DataFrame(rows)


def _position_record(ticker: str, state: dict | None = None):
    pos=db.portfolio_position(ticker)
    if pos:
        return {"side":str(pos.get("side") or "").upper(),"shares":float(pos.get("shares") or 0),"avg_cost":float(pos.get("avg_cost") or 0),"source":"PORTFOLIO"}
    cov=(state or {}).get("coverage") or db.coverage_row(ticker) or {}
    if cov.get("portfolio_state") in ("LONG","SHORT") and float(cov.get("shares_owned") or 0)>0:
        return {"side":cov.get("portfolio_state"),"shares":float(cov.get("shares_owned") or 0),"avg_cost":float(cov.get("avg_cost") or 0),"source":"LEGACY COVERAGE"}
    return {"side":"NO POSITION","shares":0.0,"avg_cost":0.0,"source":"NONE"}


def _valuation_block_reason(state: dict) -> str | None:
    sc=state.get("scenarios") or {}
    vals=[(sc.get(k) or {}).get("fair_value") for k in ("bear","base","bull")]
    if all(v is not None for v in vals):
        return None
    m=state.get("metrics") or {}
    if m.get("valuation_share_basis_usable") is False:
        return str(m.get("valuation_basis_issue") or "No auditable current share denominator is available.")
    if m.get("share_basis_checked") and not m.get("valuation_share_basis_verified",m.get("share_basis_verified")) and "valuation_share_basis_usable" not in m:
        return "Selected SEC share denominator cannot be reconciled to the current split/reverse-split basis."
    if not m.get("revenue"):
        return "TTM revenue is unavailable from SEC fundamentals."
    if not (m.get("valuation_shares") or m.get("diluted_shares") or m.get("shares_outstanding")):
        return "No SEC current-shares or diluted-share denominator is available."
    return "No valuation method has enough valid inputs to produce a positive per-share value. Review the specific method flags in Valuation Cases."


def _invalidation_triggered(state: dict) -> list[str]:
    out=[]
    for r in state.get("kpi_eval") or []:
        if r.get("linked_to")=="INVALIDATION" and r.get("kpi_status")=="TRIGGERED" and int(r.get("locked") or 0)==1:
            out.append(str(r.get("name") or r.get("metric_key") or "Locked invalidation"))
    return out


def _locked_signal(state: dict, linked_to: str, status: str = "PASS") -> list[str]:
    out=[]
    for r in state.get("kpi_eval") or []:
        if str(r.get("linked_to") or "").upper()==linked_to.upper() and r.get("kpi_status")==status and int(r.get("locked") or 0)==1:
            out.append(str(r.get("name") or r.get("metric_key") or linked_to))
    return out


def position_action(ticker: str, state: dict, lens: dict | None = None) -> dict:
    """Translate research state into one explicit action from the position-aware action set."""
    lens=lens or decision_lens(ticker,state)
    pos=_position_record(ticker,state);side=pos["side"]
    decision=str(lens.get("Decision") or "NO EDGE / WAIT")
    model=(lens.get("Model Confidence") or ("UNVALIDATED",))[0]
    price=state.get("price");base=state.get("base_value")
    gap=(float(base)/float(price)-1) if base is not None and price not in (None,0) else None
    inv=_invalidation_triggered(state)
    add_signals=_locked_signal(state,"ADD","PASS")
    reduce_signals=_locked_signal(state,"REDUCE","TRIGGERED")
    block=_valuation_block_reason(state)
    audit=(state.get("audit") or {}).get("counts") or {}
    data_bad=bool(block or int(audit.get("FAIL",0) or 0)>0 or price is None)

    if inv:
        if side=="LONG": return {"action":"SELL","tone":"red","reason":"Locked thesis invalidation triggered: "+", ".join(inv[:2]),"next":"Do not move the invalidation threshold after the fact.","position":side}
        if side=="SHORT": return {"action":"COVER","tone":"green","reason":"Locked thesis invalidation triggered: "+", ".join(inv[:2]),"next":"Do not move the invalidation threshold after the fact.","position":side}
    if data_bad:
        action="WAIT" if side=="NO POSITION" else ("HOLD" if side=="LONG" else "HOLD SHORT")
        _b=str(block or "")
        if any(x in _b.lower() for x in ("share", "split", "denominator")):
            _next="Use Share Basis Recovery below: refresh first; if still unresolved, verify corporate actions and approve the SEC basis or enter verified current-basis shares."
        else:
            _next="Resolve the exact data issue before changing exposure on model output."
        return {"action":action,"tone":"yellow","reason":block or "Data Audit has a FAIL or current price is unavailable.","next":_next,"position":side}

    if side=="NO POSITION":
        if decision=="LONG READY": return {"action":"BUY","tone":"green","reason":"Long edge is decision-ready and risk controls are complete.","next":"Enter within the risk cap; subsequent adds require pre-defined evidence.","position":side}
        if decision=="SHORT READY": return {"action":"SHORT","tone":"red","reason":"Short edge is decision-ready and risk controls are complete.","next":"Enter within the risk cap; define squeeze/catalyst invalidation before entry.","position":side}
        return {"action":"WAIT","tone":"yellow","reason":f"Current research call is {decision}.","next":lens.get("opportunity",{}).get("next_action") or "Do nothing until evidence changes.","position":side}

    if side=="LONG":
        if decision=="SHORT READY" or (gap is not None and gap<=-.20 and model in ("MODERATE","STRONG")):
            return {"action":"SELL","tone":"red","reason":"The long no longer has valuation support; the model points materially against the position.","next":"Exit according to liquidity/tax constraints and freeze the decision in Journal.","position":side}
        if reduce_signals or (gap is not None and gap<=-.10 and decision not in ("LONG READY",)):
            why=("Locked REDUCE condition triggered: "+", ".join(reduce_signals[:2])) if reduce_signals else "Valuation support has weakened materially without a full sell signal."
            return {"action":"REDUCE","tone":"yellow","reason":why,"next":"Reduce toward the risk budget; keep the original invalidation unchanged.","position":side}
        if decision=="LONG READY" and add_signals:
            return {"action":"ADD","tone":"green","reason":"Long thesis is decision-ready and locked ADD evidence is currently satisfied: "+", ".join(add_signals[:2]),"next":"Add only within the position/risk cap.","position":side}
        return {"action":"HOLD","tone":"green" if decision=="LONG READY" else "yellow","reason":f"Existing long remains a hold; current research call is {decision}.","next":"Add only when a pre-defined ADD condition is satisfied; sell/reduce on locked risk evidence.","position":side}

    if side=="SHORT":
        if decision=="LONG READY" or (gap is not None and gap>=.20 and model in ("MODERATE","STRONG")):
            return {"action":"COVER","tone":"green","reason":"The short thesis is contradicted by a decision-ready long valuation/setup.","next":"Cover according to liquidity and record the outcome instead of moving the thesis.","position":side}
        if decision=="SHORT READY" and add_signals:
            return {"action":"ADD SHORT","tone":"red","reason":"Short thesis is decision-ready and locked ADD evidence is currently satisfied: "+", ".join(add_signals[:2]),"next":"Add only within squeeze/borrow/position limits.","position":side}
        return {"action":"HOLD SHORT","tone":"red" if decision=="SHORT READY" else "yellow","reason":f"Existing short remains a hold; current research call is {decision}.","next":"Add only on pre-defined evidence; cover on invalidation or a decision-ready long setup.","position":side}
    return {"action":"WAIT","tone":"yellow","reason":"No position-aware action could be resolved.","next":"Review data and thesis state.","position":side}


def decision_steps(ticker: str, state: dict, lens: dict | None = None):
    lens=lens or decision_lens(ticker,state); action=position_action(ticker,state,lens)
    audit=(state.get("audit") or {}).get("counts") or {}; block=_valuation_block_reason(state)
    data_status="BLOCK" if block or int(audit.get("FAIL",0) or 0)>0 else "PASS"
    gap=state.get("upside")
    value_status="PASS" if gap is not None and abs(float(gap))>=.15 else "WATCH" if gap is not None else "BLOCK"
    business=(lens.get("Business") or ("UNKNOWN",))[0]
    thesis_status="PASS" if business in ("STRONG","SOLID") and (lens.get("Variant") or ("UNPROVEN",))[0] not in ("UNPROVEN","UNCLEAR") else "WATCH"
    path=(lens.get("Path") or ("UNCLEAR",))[0]; timing_status="PASS" if path=="SUPPORTIVE" else "WATCH"
    risk=(lens.get("Risk") or ("UNRESOLVED",))[0]; risk_status="PASS" if risk=="CONTROLLED" else "BLOCK" if risk in ("HIGH","DATA REVIEW") else "WATCH"
    def row(step,status,answer,why): return {"Step":step,"Status":status,"Answer":answer,"Why it matters":why}
    return [
        row("1 · Data",data_status,"Trust inputs" if data_status=="PASS" else "Fix data first",block or f"Audit: {audit.get('PASS',0)} PASS / {audit.get('WARN',0)} WARN / {audit.get('FAIL',0)} FAIL"),
        row("2 · Value",value_status,f"Base gap {fpct(gap)}",f"Bear {fprice(((state.get('scenarios') or {}).get('bear') or {}).get('fair_value'))} · Base {fprice(state.get('base_value'))} · Bull {fprice(((state.get('scenarios') or {}).get('bull') or {}).get('fair_value'))}"),
        row("3 · Thesis",thesis_status,business,(lens.get("Variant") or ("","") )[1] or "Business + variant evidence"),
        row("4 · Timing",timing_status,path,(lens.get("Path") or ("","") )[1] or "Catalyst/path confirmation"),
        row("5 · Risk",risk_status,risk,(lens.get("Risk") or ("","") )[1] or "Invalidation + sizing + concentration"),
        row("6 · Action","ACTION",action["action"],action["reason"]),
    ]


def decision_lens(ticker: str, state: dict):
    opp=opportunity.evaluate(state, service.last_successful_refresh(ticker))
    business=_business_view(state); value=_value_view(state); expectations=_expectations_view(state); variant=_variant_view(state); path=_path_view(state, opp.get("focus")); risk=_risk_view(ticker,state); model_conf=_model_confidence(ticker,state)
    passes=int((state.get("gate_counts") or {}).get("PASS",0) or 0)
    decision_grade=model_conf[0] in ("MODERATE","STRONG")
    if risk[0] == "DATA REVIEW": call="DATA REVIEW"
    elif opp.get("focus") in ("LONG FOCUS","LONG WATCH"):
        call="LONG READY" if passes==16 and decision_grade and variant[0] in ("POSITIVE EDGE","POSSIBLE POSITIVE EDGE") and path[0]=="SUPPORTIVE" and risk[0]=="CONTROLLED" else "LONG WATCH"
    elif opp.get("focus") in ("SHORT FOCUS","SHORT WATCH"):
        call="SHORT READY" if passes==16 and decision_grade and variant[0] in ("NEGATIVE EDGE","POSSIBLE NEGATIVE EDGE") and path[0]=="SUPPORTIVE" and risk[0]=="CONTROLLED" else "SHORT WATCH"
    elif opp.get("focus") == "VALUATION REVIEW": call="VALUATION REVIEW"
    elif opp.get("focus") == "DATA REVIEW": call="DATA REVIEW"
    else: call="NO EDGE / WAIT"
    return {"Business":business,"Value":value,"Expectations":expectations,"Variant":variant,"Path":path,"Risk":risk,"Model Confidence":model_conf,"Decision":call,"opportunity":opp}

def _decision_reasons(ticker, state, lens):
    fs=state.get("forensics") or {}; tri=state.get("triangulation") or {}; research=db.load_research(ticker) or {}; v=state.get("variant_case") or {}
    why=[]
    if state.get("upside") is not None and abs(state["upside"])>=.15: why.append(f"Base value gap is {state['upside']:+.0%}.")
    for s in tri.get("signals",[]):
        if s.get("Type") in ("POSITIVE","NEGATIVE"):
            why.append(f"{s.get('Signal')}: {s.get('Evidence')}")
        if len(why)>=3: break
    for s in fs.get("positives",[])[:2]:
        if len(why)<3: why.append(str(s.get("Signal") or s.get("Title") or s.get("Evidence") or "Positive forensic evidence"))
    blockers=[]
    if state.get("valuation_confidence",{}).get("label") == "LOW": blockers.append("Valuation confidence is LOW.")
    if lens.get("Model Confidence",("UNVALIDATED",))[0] in ("UNVALIDATED","LIMITED"):
        blockers.append("Model confidence: "+lens["Model Confidence"][0]+" — "+lens["Model Confidence"][1])
    if lens["Variant"][0] == "UNPROVEN": blockers.append("Variant perception has not been explicitly defined.")
    if lens["Path"][0] == "UNCLEAR": blockers.append("Catalyst/path is still unclear.")
    miss=[g.get("gate") for g in state.get("gates",[]) if g.get("status") in ("FAIL","INCOMPLETE","WATCH")]
    if miss: blockers.append("Open gates: "+", ".join(miss[:3]))
    changes=[]
    if (v.get("resolution_signal") or "").strip(): changes.append(v["resolution_signal"])
    if (research.get("evidence_to_add") or "").strip(): changes.append(research["evidence_to_add"])
    kills=[]
    for k in state.get("kpis") or []:
        if k.get("linked_to")=="INVALIDATION" and k.get("threshold") is not None and int(k.get("locked") or 0)==1:
            op=k.get("operator") or "?"; unit=k.get("unit") or ""
            kills.append(f"LOCKED: {k.get('name') or k.get('metric_key')} {op} {k.get('threshold')} {unit}".strip())
    if (research.get("invalidation") or "").strip(): kills.append(research["invalidation"])
    if (research.get("primary_risk") or "").strip(): kills.append(research["primary_risk"])
    return why[:3], blockers[:3], changes[:3], kills[:3]

@st.fragment(run_every="3s")
def discovery_monitor():
    r=discovery.latest_run()
    if not r: return
    if r.get("status") in ("QUEUED","RUNNING"):
        st.info(f"Market scan running · {r.get('stage')} · {r.get('current_ticker') or ''}. You can keep navigating.")
    elif r.get("status") == "FAIL":
        st.error(f"Last market scan failed: {r.get('error_message') or 'unknown error'}")


def render_discovery():
    title("DISCOVERY", "Find the disagreement", "Relative peer dislocation first, then an absolute fair-value cross-check. Only aligned long/short edges reach the main queue.")
    rows=db.query("SELECT * FROM discovery_universe")
    run=discovery.latest_run()
    c1,c2,c3,c4=st.columns([1.1,1.1,1.25,2.55])
    if c1.button("Scan Market", type="primary", width="stretch", disabled=discovery.is_running()):
        discovery.start_scan(False); st.rerun()
    if c2.button("Deep Refresh", width="stretch", disabled=discovery.is_running(), help="Forces fresh SEC fundamentals for the liquid discovery universe."):
        discovery.start_scan(True); st.rerun()
    disc_pdf_key="mf3_discovery_pdf"
    disc_pdf=st.session_state.get(disc_pdf_key)
    if c3.button("Prepare Discovery PDF",width="stretch",disabled=not rows,key="mf3_discovery_pdf_prepare"):
        try:
            with st.spinner("Building Discovery Brief..."):
                disc_pdf={"generated_at":datetime.now(timezone.utc).isoformat(),"run_id":(run or {}).get("id"),"data":exporter.discovery_report_pdf()}
                st.session_state[disc_pdf_key]=disc_pdf
        except Exception as e:
            st.warning(f"Discovery PDF unavailable: {e}"); disc_pdf=None
    if disc_pdf:
        if (run or {}).get("id") != disc_pdf.get("run_id"): c3.warning("Newer scan available")
        c3.download_button("Download Discovery PDF",data=disc_pdf["data"],file_name="Market_Forensics_Discovery_Brief.pdf",mime="application/pdf",width="stretch",key="mf3_discovery_pdf_download")
    c4.caption("Stage 1: liquid listed US equities → market snapshots → cached SEC fundamentals → peer-relative dislocation → automatic absolute fair-value gate. Full research starts only after promotion.")
    discovery_monitor()
    if run and run.get("status")=="PASS" and run.get("error_message"):
        st.warning("Latest scan completed with issuer-level refresh warnings: "+str(run.get("error_message")))
    if not rows:
        st.markdown('<div class="mf3-panel"><div class="mf3-big">No market universe yet.</div><div class="mf3-small">Configure Alpaca + SEC in Settings, then run Scan Market. The scan runs in background.</div></div>', unsafe_allow_html=True)
        return

    data_review=[r for r in rows if r.get("lens") in ("DATA REVIEW","FORENSIC REVIEW") or r.get("screen_value_gap") is None]
    if data_review and len(data_review)>=max(10,int(len(rows)*.35)):
        st.warning(f"{len(data_review)} of {len(rows)} screened names still need data/basis review. V3.1.12 automatically refreshes legacy V3.1.2 screener cache on the next Scan Market; use Deep Refresh only if this remains high after one completed scan.")

    interesting=[r for r in rows if r.get("lens") not in (None,"NO EDGE")]
    long_lenses={"QUALITY AT DISCOUNT","FUNDAMENTAL INFLECTION","LONG DISLOCATION"}
    short_lenses={"POTENTIAL SHORT","SHORT DISLOCATION","VALUE TRAP","FORENSIC DIVERGENCE"}
    longs=[r for r in interesting if r.get("lens") in long_lenses]
    shorts=[r for r in interesting if r.get("lens") in short_lenses]
    review=[r for r in interesting if r.get("lens") not in long_lenses | short_lenses]
    a,b,c,d=st.columns(4)
    a.metric("Scanned", len(rows)); b.metric("Long dislocations", len(longs)); c.metric("Short / traps", len(shorts)); d.metric("Last scan", _age_label((run or {}).get("completed_at")))

    # Keep the first read visual: strongest dislocations only, with detailed tables below.
    lc,sc=st.columns(2)
    with lc:
        top=sorted(longs,key=lambda x:-(x.get("long_score") or 0))[:10]
        if top:
            fig=go.Figure(go.Bar(x=[x.get("long_score") or 0 for x in top][::-1],y=[x.get("ticker") for x in top][::-1],orientation="h",name="Long score",marker_color="#3F78A8"))
            _style_plot(fig,height=320,margin=dict(l=10,r=10,t=42,b=10),title="Top long dislocations",xaxis_range=[0,100])
            st.plotly_chart(fig,width="stretch")
        else: st.info("No material long dislocation in the latest scan.")
    with sc:
        top=sorted(shorts,key=lambda x:-(x.get("short_score") or 0))[:10]
        if top:
            fig=go.Figure(go.Bar(x=[x.get("short_score") or 0 for x in top][::-1],y=[x.get("ticker") for x in top][::-1],orientation="h",name="Short score",marker_color="#3F78A8"))
            _style_plot(fig,height=320,margin=dict(l=10,r=10,t=42,b=10),title="Top short / trap dislocations",xaxis_range=[0,100])
            st.plotly_chart(fig,width="stretch")
        else: st.info("No material short dislocation in the latest scan.")

    def frame(items, n=15):
        data=[]
        for r in sorted(items,key=lambda x:(x.get("system_priority",5),-max(x.get("long_score") or 0,x.get("short_score") or 0)))[:n]:
            data.append({"P":f"P{r.get('system_priority',5)}","Ticker":r.get("ticker"),"Lens":r.get("lens"),"Price":r.get("price"),"Screen FV":r.get("screen_base_value"),"FV Gap":r.get("screen_value_gap"),"Long Dislocation":r.get("long_score"),"Short Dislocation":r.get("short_score"),"Quality":r.get("quality_score"),"Trend":r.get("trend_score"),"Relative Value":r.get("valuation_score"),"Reason":r.get("reason")})
        return pd.DataFrame(data)
    lcol,scol=st.columns(2)
    with lcol:
        st.subheader("Long candidates")
        ws.display_table(frame(longs), {"Price":fprice,"Screen FV":fprice,"FV Gap":fpct,"Long Dislocation":lambda x:fnum(x,0),"Short Dislocation":lambda x:fnum(x,0),"Quality":lambda x:fnum(x,0),"Trend":lambda x:fnum(x,0),"Relative Value":lambda x:fnum(x,0)}, height=430)
    with scol:
        st.subheader("Short / trap candidates")
        ws.display_table(frame(shorts), {"Price":fprice,"Screen FV":fprice,"FV Gap":fpct,"Long Dislocation":lambda x:fnum(x,0),"Short Dislocation":lambda x:fnum(x,0),"Quality":lambda x:fnum(x,0),"Trend":lambda x:fnum(x,0),"Relative Value":lambda x:fnum(x,0)}, height=430)

    with st.expander(f"Review / context ({len(review)})", expanded=False):
        if review:
            ws.display_table(frame(review, n=25), {"Price":fprice,"Screen FV":fprice,"FV Gap":fpct,"Long Dislocation":lambda x:fnum(x,0),"Short Dislocation":lambda x:fnum(x,0),"Quality":lambda x:fnum(x,0),"Trend":lambda x:fnum(x,0),"Relative Value":lambda x:fnum(x,0)}, height=320)
        else:
            st.caption("No data-review or context-only names in the latest scan.")

    with st.expander("Inspect / promote a candidate", expanded=False):
        action_pool=longs+shorts
        candidates=[r["ticker"] for r in sorted(action_pool,key=lambda x:(x.get("system_priority",5),-max(x.get("long_score") or 0,x.get("short_score") or 0)))]
        if not candidates:
            st.caption("No material edge detected in the latest scan.")
        else:
            t=st.selectbox("Candidate",candidates,key="mf3_discovery_candidate")
            r=db.discovery_row(t) or {}
            st.write(f"**{r.get('company_name') or t}** · {r.get('lens')} · {r.get('reason')}")
            st.caption(f"Quality {fnum(r.get('quality_score'),0)} · Trend {fnum(r.get('trend_score'),0)} · Relative Value {fnum(r.get('valuation_score'),0)} · Screen FV {fprice(r.get('screen_base_value'))} ({fpct(r.get('screen_value_gap'))}) · Confidence {fnum(r.get('confidence'),0)}")
            if st.button("Promote to Decision Queue + deep refresh",type="primary",width="stretch",key="mf3_promote"):
                db.ensure_coverage(t,"RESEARCH"); st.session_state["ticker"]=t; jobs.start_or_enqueue([t],reason="DISCOVERY_PROMOTE",include_flow=True); st.success(f"{t} added to Decision Queue and full research refresh queued.")

    with st.expander("How Discovery decides", expanded=False):
        st.markdown("""
**QUALITY AT DISCOUNT** — strong economics + cheap relative valuation.  
**FUNDAMENTAL INFLECTION** — operating trend improves before valuation fully reflects it.  
**POTENTIAL SHORT** — demanding valuation + weak/deteriorating economics.  
**VALUE TRAP** — cheap, but quality/trend is weak.  
**FORENSIC DIVERGENCE** — cash/working-capital/share evidence conflicts with the headline story.  
**NO EDGE** — deliberately hidden from the main queue.

**Absolute Value Gate (V3.1.12)** — Top Long requires at least ~10% automatic absolute upside and Top Short requires at least ~10% automatic absolute downside. A name that is only cheap/rich versus peers but sits near our own screening fair value is suppressed as NO EDGE. The Screen FV is an automatic generic cross-check; the full Valuation Cases page remains the decision-grade valuation.

Scores organize evidence; they are not probabilities and never create a capital decision by themselves.
""")


def render_coverage():
    title("DECISION QUEUE", "Decision Queue", "Every researched name and every real position in one list. The output is an action, not just a score.")
    coverage_rows=db.list_coverage(include_archived=False)
    portfolio_rows=db.list_portfolio_positions()
    tickers=sorted(set([r["ticker"] for r in coverage_rows]+[r["ticker"] for r in portfolio_rows]))
    c1,c2,c3=st.columns([1.2,1.2,3])
    if c1.button("Refresh All",type="primary",width="stretch",disabled=not tickers):
        jobs.start_or_enqueue(tickers,reason="V3_1_9_DECISION_QUEUE",include_flow=True); st.rerun()
    stale=jobs.stale_tickers(24,False) if coverage_rows else []
    # Portfolio-only names may not appear in jobs.stale_tickers because they are not Coverage yet.
    for t in tickers:
        if not service.last_successful_refresh(t) and t not in stale: stale.append(t)
    if c2.button("Refresh Stale",width="stretch",disabled=not stale):
        jobs.start_or_enqueue(stale,reason="V3_1_9_QUEUE_STALE",include_flow=True); st.rerun()
    c3.caption("Portfolio positions can exist before a thesis. Research status and position status are independent.")

    with st.expander("Add a company to the research queue",expanded=not tickers):
        with st.form("mf3_add_cov"):
            a,b,c=st.columns(3); t=a.text_input("Ticker"); status=b.selectbox("Status",ws.STATUS_OPTIONS,index=0); ctype=c.selectbox("Company type",ws.COMPANY_TYPES)
            if st.form_submit_button("Add + refresh") and t.strip():
                x=t.strip().upper(); validation=symbols.validate_ticker(x)
                if not validation.valid:
                    st.error(validation.message or "Ticker not found / symbol not recognized.")
                else:
                    db.ensure_coverage(x,status); db.update_coverage(x,status=status,company_type=ctype); st.session_state["ticker"]=x; jobs.start_or_enqueue([x],reason="V3_1_9_ADD",include_flow=True); st.rerun()
    if not tickers:
        st.info("Nothing to decide yet. Add a real position in Portfolio, discover a candidate, or add a company above.")
        return

    rows=[]
    for t in tickers:
        cov=db.coverage_row(t) or {}; pos=db.portfolio_position(t)
        try:
            state=ws.load_state(t); lens=decision_lens(t,state); act=position_action(t,state,lens); sc=state.get("scenarios") or {}
            rows.append({
                "Ticker":t,"Position":(pos or {}).get("side") or "NO POSITION","Action":act["action"],"Research call":lens["Decision"],
                "Price":state.get("price"),"Bear":(sc.get("bear") or {}).get("fair_value"),"Base":state.get("base_value"),"Bull":(sc.get("bull") or {}).get("fair_value"),"Base gap":state.get("upside"),
                "Model":lens["Model Confidence"][0],"Risk":lens["Risk"][0],"Fresh":_age_label((service.last_successful_refresh(t) or {}).get("completed_at")),
                "Next":act["next"],"Research status":cov.get("status") or "NOT RESEARCHED"
            })
        except Exception as e:
            _side=(pos or {}).get("side") or "NO POSITION"
            _action="HOLD" if _side=="LONG" else "HOLD SHORT" if _side=="SHORT" else "WAIT"
            rows.append({"Ticker":t,"Position":_side,"Action":_action,"Research call":"LOAD ERROR","Price":None,"Bear":None,"Base":None,"Bull":None,"Base gap":None,"Model":"UNKNOWN","Risk":"DATA REVIEW","Fresh":"—","Next":"Resolve data load error before changing exposure: "+str(e)[:100],"Research status":cov.get("status") or "NOT RESEARCHED"})

    # Action first: exits/data problems, then buys/shorts, then holds/waits.
    rank={"SELL":0,"COVER":0,"REDUCE":1,"BUY":2,"SHORT":2,"ADD":3,"ADD SHORT":3,"HOLD":4,"HOLD SHORT":4,"WAIT":6}
    rows=sorted(rows,key=lambda r:(rank.get(r.get("Action"),7),r.get("Ticker") or ""))
    urgent=[r for r in rows if rank.get(r.get("Action"),7)<=2]
    a,b,c,d=st.columns(4)
    a.metric("Names",len(rows)); b.metric("Need action",len(urgent)); c.metric("Portfolio positions",len(portfolio_rows)); d.metric("Data review",sum("DATA" in str(r.get("Risk")) or "FIX DATA" in str(r.get("Action")) for r in rows))
    if urgent:
        st.markdown('<div class="mf3-section-title">WHAT NEEDS ATTENTION NOW</div>',unsafe_allow_html=True)
        top=urgent[:4]
        st.markdown('<div class="mf3-row4">'+''.join(_box(r["Ticker"],r["Action"],f"{r['Position']} · {fprice(r['Price'])} · Base {fprice(r['Base'])}",hero=True,tone_override="neutral") for r in top)+'</div>',unsafe_allow_html=True)
    st.markdown('<div class="mf3-section-title">ALL DECISIONS</div>',unsafe_allow_html=True)
    ws.display_table(pd.DataFrame(rows),{"Price":fprice,"Bear":fprice,"Base":fprice,"Bull":fprice,"Base gap":fpct},height=620)
    st.caption("Select a ticker in the sidebar, then open Decide to see the six-step reasoning behind the action. Portfolio entries do not require a pre-existing thesis.")

    if coverage_rows:
        with st.expander("Research queue maintenance",expanded=False):
            t=st.selectbox("Company",[r["ticker"] for r in coverage_rows],key="mf3_cov_manage")
            cov=db.coverage_row(t) or {}; c1,c2=st.columns(2)
            status=c1.selectbox("Research status",ws.STATUS_OPTIONS,index=ws.STATUS_OPTIONS.index(cov.get("status","RESEARCH")),key="mf3_cov_status")
            priority=c2.selectbox("Manual research priority",[1,2,3,4,5],index=max(0,min(4,int(cov.get("priority",3))-1)),key="mf3_cov_pri")
            st.caption("Real position size/cost is edited only in Portfolio so there is one source of truth.")
            a,b=st.columns(2)
            if a.button("Save research status",type="primary",width="stretch",key="mf3_cov_save"):
                db.update_coverage(t,status=status,priority=priority); st.rerun()
            if b.button("Remove from Research Queue",width="stretch",key="mf3_cov_remove"):
                db.remove_from_coverage(t); st.rerun()




def render_decide(ticker: str, state: dict):
    _workflow_back("pages/01_coverage_v3.py","Decision Queue","Queue › Decide")
    title(ticker, "Decision", "One workflow: verify data → value the business → test the thesis → check timing/risk → take one position-aware action.")
    lens=decision_lens(ticker,state); why,blockers,changes,kills=_decision_reasons(ticker,state,lens)
    act=position_action(ticker,state,lens); pos=_position_record(ticker,state)
    st.markdown(f'<div class="mf3-decision {act["tone"]}"><div class="mf3-small">WHAT SHOULD I DO NOW? · POSITION: {html.escape(pos["side"])}</div><div class="mf3-big">{html.escape(act["action"])}</div><div>{html.escape(act["reason"])}</div><div class="mf3-small">NEXT: {html.escape(act["next"])}</div></div>',unsafe_allow_html=True)

    steps=pd.DataFrame(decision_steps(ticker,state,lens))
    st.markdown('<div class="mf3-section-title">STEP-BY-STEP DECISION</div>',unsafe_allow_html=True)
    st.dataframe(steps,width="stretch",hide_index=True,height=286,column_config={"Step":st.column_config.TextColumn(width="small"),"Status":st.column_config.TextColumn(width="small"),"Answer":st.column_config.TextColumn(width="medium"),"Why it matters":st.column_config.TextColumn(width="large")})

    sc=state.get("scenarios") or {}
    ass=state.get("assumptions") or {}
    val_block=_valuation_block_reason(state)
    def scenario_display(name):
        v=(sc.get(name) or {}).get("fair_value")
        return fprice(v) if v is not None else "DATA REVIEW"
    _po=state.get("price_overlay") or {}
    _display_price=state.get("display_price") if state.get("display_price") is not None else state.get("price")
    if _po:
        _mode="VALUATION ACTIVE" if _po.get("valuation_usable") else f"DISPLAY ONLY · valuation uses {fprice(state.get('price'))}"
        _price_detail=f"{_po.get('provider')} · {_po.get('freshness')} · {_po.get('asof') or 'timestamp unavailable'} · {_mode}"
    else:
        _price_detail=f"Last successful full refresh · {_age_label((service.last_successful_refresh(ticker) or {}).get('completed_at'))}"
    price_cards=[
        ("Price",fprice(_display_price),_price_detail),
        ("Bear",scenario_display("bear"),f"Probability {fpct((ass.get('bear') or {}).get('prob'))}" if not val_block else val_block),
        ("Base",scenario_display("base"),f"Probability {fpct((ass.get('base') or {}).get('prob'))} · Gap {fpct(state.get('upside'))}" if not val_block else val_block),
        ("Bull",scenario_display("bull"),f"Probability {fpct((ass.get('bull') or {}).get('prob'))} · EV {fprice(state.get('expected_value'))}" if not val_block else val_block),
    ]
    st.markdown('<div class="mf3-section-title">CORE PRICE CASES</div>',unsafe_allow_html=True)
    st.markdown('<div class="mf3-row4">'+''.join(_box(*x,hero=True,tone_override="neutral") for x in price_cards)+'</div>',unsafe_allow_html=True)
    _m=state.get("metrics") or {}
    def _shares(v):
        try:
            x=float(v)
            if abs(x)>=1e9:return f"{x/1e9:.3f}B"
            if abs(x)>=1e6:return f"{x/1e6:.2f}M"
            return f"{x:,.0f}"
        except Exception:return "—"
    _share_src=str(_m.get("valuation_share_source") or "UNKNOWN").replace("_"," ")
    _basis_status=str(_m.get("valuation_share_basis_status") or ("VERIFIED" if _m.get("valuation_share_basis_verified",_m.get("share_basis_verified")) else "DATA REVIEW"))
    _basis_conf=str(_m.get("valuation_share_confidence") or "LOW")
    st.markdown('<div class="mf3-section-title">SHARE BASIS</div>',unsafe_allow_html=True)
    sb1,sb2,sb3,sb4,sb5,sb6=st.columns(6)
    _raw_share_for_card=_m.get("auto_valuation_share_raw") if _m.get("valuation_basis_override_active") else _m.get("valuation_share_raw")
    _fact_for_card=_m.get("auto_valuation_share_fact_date") if _m.get("valuation_basis_override_active") else _m.get("valuation_share_fact_date")
    _filed_for_card=_m.get("auto_valuation_share_filed_date") if _m.get("valuation_basis_override_active") else _m.get("valuation_share_filed_date")
    sb1.metric("SEC shares",_shares(_raw_share_for_card),str(_m.get("shares_outstanding_method") or _share_src).replace("_"," "))
    sb2.metric("SEC fact date",str(_fact_for_card or "—"),f"Filed {_filed_for_card or '—'}")
    sb3.metric("Split factor",fnum(_m.get("valuation_split_factor"),4,"x"),str(_m.get("corporate_actions_since_share_fact") or "—")[:70])
    sb4.metric("Normalized shares",_shares(_m.get("valuation_shares")),"current share basis")
    sb5.metric("Current price",fprice(_display_price),((_po.get("freshness") or "SNAPSHOT")+" · "+str(_po.get("asof") or "—")+(" · valuation active" if _po.get("valuation_usable") else " · display only")) if _po else str(_m.get("current_price_date") or "—"))
    sb6.metric("Basis",_basis_status,f"Confidence {_basis_conf}")
    _raw_px=fprice(_m.get("latest_raw_close")); _adj_px=fprice(_m.get("latest_split_adjusted_close")); _px_factor=fnum(_m.get("current_price_split_factor"),4,"x")
    _overlay_note=(f" Display price auto-refresh: {_po.get('provider')} · {_po.get('freshness')} · {_po.get('asof')}. {_po.get('basis_note') or ''} The snapshot never rewrites historical bars or SEC facts." if _po else "")
    st.caption(f"Corporate-action basis · {_m.get('corporate_action_basis') or '—'} · Display price {fprice(_display_price)} · valuation/action price {fprice(state.get('price'))} · raw close {_raw_px} · split-adjusted close {_adj_px} · split factor {_px_factor}. Historical raw/adjusted certification is {'VERIFIED' if _m.get('historical_price_basis_verified') else 'SEPARATE / NOT REQUIRED HERE'}; split ledger is {'VERIFIED' if _m.get('split_ledger_verified') else 'UNVERIFIED'}."+_overlay_note)
    if str(_m.get("shares_outstanding_method") or "").endswith("MULTI_CLASS_SUM"):
        try:
            import json as _json
            _parts=_json.loads(_m.get("shares_outstanding_components_json") or "[]")
        except Exception:
            _parts=[]
        st.info("SEC multi-class share fact recovered automatically: "+(" + ".join(_shares(x) for x in _parts)+" = "+_shares(sum(float(x) for x in _parts)) if _parts else "class-level common shares were summed on the same filing/date")+". This prevents fallback to an obsolete single-class fact.")
    if _m.get("valuation_share_source")=="DILUTED_WA_FALLBACK" and not val_block:
        st.info("Price targets shown using verified diluted-share basis. Confidence: MEDIUM. Current shares outstanding were unavailable or not independently reconcilable; the fallback is disclosed rather than hidden.")
    if _m.get("valuation_basis_override_active"):
        st.warning("Price targets are visible using a USER-VERIFIED current share basis (Confidence: MEDIUM). Automatic SEC/split-basis evidence remains preserved underneath for audit; this override is never used by Validate or historical calibration.")
        _note=str(_m.get("valuation_basis_override_note") or "").strip()
        if _note: st.caption("Override evidence: "+_note)
        if st.button("Remove share-basis override and return to automatic verification",width="stretch",key=f"mf318_clear_basis_{ticker}"):
            db.clear_share_basis_override(ticker); st.rerun()
    if val_block:
        _share_block=any(x in str(val_block).lower() for x in ("share", "split", "denominator", "corporate action"))
        cfix, csrc = st.columns(2)
        cfix.warning("DATA REVIEW — "+val_block)
        if csrc.button("Repair / refresh price + SEC basis",type="primary",width="stretch",key=f"mf318_repair_{ticker}"):
            jobs.start_or_enqueue([ticker],reason="V3_1_9_BASIS_REPAIR",include_flow=True); st.toast(f"Repair refresh queued for {ticker}.")
        cfix.page_link(DETAIL_PATHS["Sources & Audit"],label="Open data audit",width="stretch")
        if _share_block:
            with st.expander("Share Basis Recovery — manual, audit logged",expanded=True):
                st.caption("Use this only after the automatic refresh still cannot prove the corporate-action basis. It unlocks current Bear/Base/Bull with MEDIUM confidence; it does not rewrite SEC facts and it is excluded from Validate.")
                _auto_raw=_m.get("valuation_share_raw")
                _auto_fact=str(_m.get("valuation_share_fact_date") or "")[:10]
                _age_days=None
                try:
                    if _auto_fact and _m.get("current_price_date"):
                        _age_days=(date.fromisoformat(str(_m.get("current_price_date"))[:10])-date.fromisoformat(_auto_fact)).days
                except Exception:
                    pass
                _approve_ok=bool(_auto_raw and _auto_fact and _m.get("current_price_date") and _age_days is not None and 0 <= _age_days <= 365)
                _options=["Enter verified current-basis shares manually"]
                if _approve_ok:
                    _options.insert(0,"Approve displayed SEC shares: I verified no split since the SEC fact date")
                _mode=st.selectbox("Recovery method",_options,key=f"mf318_basis_mode_{ticker}")
                if _mode.startswith("Approve"):
                    _manual_shares=float(_auto_raw); _basis_date=_auto_fact
                    st.write(f"Will use **{_shares(_manual_shares)}** shares on current basis, anchored to SEC fact date **{_basis_date}**, with split factor 1.0 based on your verification.")
                    _save_mode="USER_VERIFIED_NO_SPLIT"
                else:
                    _default=float(_auto_raw or _m.get("diluted_shares") or 0.0)
                    _manual_shares=st.number_input("Verified current-basis shares",min_value=0.0,value=_default,step=1_000_000.0,format="%.0f",key=f"mf318_manual_shares_{ticker}")
                    _basis_date=st.text_input("Basis / as-of date (YYYY-MM-DD)",value=str(_m.get("current_price_date") or _auto_fact or ""),key=f"mf318_manual_basis_date_{ticker}")
                    _save_mode="USER_CURRENT_BASIS"
                if not _approve_ok and _auto_fact:
                    st.caption("One-click no-split approval is disabled because the automatic SEC fact is more than one year old or unsuitable. Enter a genuinely current-basis share count instead.")
                _srcnote=st.text_input("Evidence / source note (required)",placeholder="Example: latest 10-Q cover page + corporate actions checked through current quote date",key=f"mf318_basis_note_{ticker}")
                _confirm=st.checkbox("I verified that this share count is already on the same split/reverse-split basis as the current market price.",key=f"mf318_basis_confirm_{ticker}")
                _can=bool(_confirm and str(_srcnote).strip() and float(_manual_shares or 0)>0 and str(_basis_date or "").strip())
                if st.button("Use this basis for current Bear / Base / Bull",type="primary",disabled=not _can,width="stretch",key=f"mf318_basis_save_{ticker}"):
                    db.save_share_basis_override(ticker,_save_mode,float(_manual_shares),str(_basis_date),str(_srcnote),True); st.rerun()

    st.markdown(f'<div class="mf3-panel"><b>Research call:</b> {html.escape(lens["Decision"])} &nbsp;·&nbsp; <b>Setup:</b> {html.escape(lens["opportunity"].get("setup") or "")}<br/><span class="mf3-small">{html.escape(lens["opportunity"].get("next_action") or "")}</span></div>',unsafe_allow_html=True)

    with st.expander("Bear / Base / Bull — ALL valuation assumptions & outputs", expanded=False):
        st.caption("These are the exact three valuation cases used to produce the Bear / Base / Bull fair values above. This is separate from the 5Y Operating Forecast scenarios.")
        ws.display_table(_scenario_table(state),height=610)
        w=ass.get("weights") or {}
        st.caption(f"Primary blend weights · P/E {fpct(w.get('pe'))} · EV/Sales {fpct(w.get('ev_sales'))} · FCF Yield {fpct(w.get('fcf_yield'))} · Horizon {ass.get('horizon_years',5)}Y · Origin {ass.get('origin','AUTO')}")
        st.page_link(DETAIL_PATHS["Valuation"],label="Open / edit all valuation scenario values",icon=":material/tune:",width="stretch")

    st.markdown('<div class="mf3-section-title">ASYMMETRY & POSITION MATH</div>',unsafe_allow_html=True)
    px=state.get("price"); bear=(sc.get("bear") or {}).get("fair_value"); bull=(sc.get("bull") or {}).get("fair_value"); ev=state.get("expected_value")
    def ret(v):
        try: return float(v)/float(px)-1 if v is not None and px not in (None,0) else None
        except Exception: return None
    rp=db.risk_plan(ticker) or {}; suggested=None
    try:
        ref=float(rp.get("invalidation_price")); budget=float(rp.get("portfolio_risk_budget")); haircut=float(rp.get("event_liquidity_haircut") or 0); cap=float(rp.get("max_position_cap"))
        loss=abs(float(px)-ref)/float(px) if px not in (None,0) and ref>0 else None
        suggested=min(cap,budget/(loss+haircut)) if loss is not None and (loss+haircut)>0 else None
    except Exception: suggested=None
    locked_inv=[k for k in (state.get("kpis") or []) if k.get("linked_to")=="INVALIDATION" and k.get("threshold") is not None and int(k.get("locked") or 0)==1]
    a,b,c,d,e,f=st.columns(6)
    a.metric("Bear downside",fpct(ret(bear))); b.metric("Base upside",fpct(state.get("upside"))); c.metric("Bull upside",fpct(ret(bull))); d.metric("Expected-value gap",fpct(ret(ev))); e.metric("Suggested size",fpct(suggested),"risk-budget math"); f.metric("Invalidation","LOCKED" if locked_inv else "NOT LOCKED",f"{len(locked_inv)} numerical rule(s)")

    hist_validation = db.latest_validation_result(ticker)
    if hist_validation:
        hs = hist_validation.get("summary") or {}
        hscore = hs.get("reliability_score")
        hlabel = hs.get("reliability_label") or "NO DATA"
        st.markdown('<div class="mf3-section-title">HISTORICAL MODEL RELIABILITY</div>', unsafe_allow_html=True)
        st.markdown(
            '<div class="mf3-row4">'
            + _box("Reliability", "—" if hscore is None else f"{float(hscore):.0f}/100", f"{hlabel} · {hs.get('complete_tests',0)} completed walk-forwards", hero=True, tone_override="neutral")
            + _box("Valuation", "—" if hs.get("valuation_reliability_score") is None else f"{float(hs.get('valuation_reliability_score')):.0f}/100", "Historical Bear/Base/Bull accuracy", tone_override="neutral")
            + _box("Thesis", "—" if hs.get("thesis_reliability_score") is None else f"{float(hs.get('thesis_reliability_score')):.0f}/100", "Growth + margins versus historical bands", tone_override="neutral")
            + _box("Direction", "—" if hs.get("direction_reliability_score") is None else f"{float(hs.get('direction_reliability_score')):.0f}/100", f"Bias: {hs.get('bias_label','NO DATA')}", tone_override="neutral")
            + '</div>', unsafe_allow_html=True
        )
        st.caption("Historical reliability is evidence about this model/company pair, not a guarantee of future returns. Re-run Validate after material model changes.")
    else:
        st.caption("Historical reliability: not yet validated for this company. Open Validate to run the point-in-time test.")

    primary_dims=[("Business",*lens["Business"]),("Value",*lens["Value"]),("Expectations",*lens["Expectations"]),("Model Confidence",*lens["Model Confidence"])]
    secondary_dims=[("Variant",*lens["Variant"]),("Path",*lens["Path"]),("Risk",*lens["Risk"])]
    st.markdown('<div class="mf3-row4">'+''.join(_box(*x) for x in primary_dims)+'</div>',unsafe_allow_html=True)
    st.markdown('<div class="mf3-row">'+''.join(_box(*x) for x in secondary_dims)+'</div>',unsafe_allow_html=True)

    pfig=_price_chart(state); bfig=_business_chart(state)
    l,r=st.columns([1.15,1])
    with l:
        if pfig is not None: st.plotly_chart(pfig,width="stretch")
        else: st.info("Price history will appear after market data is refreshed.")
    with r:
        if bfig is not None: st.plotly_chart(bfig,width="stretch")
        else: st.info("Operating-history chart will appear after SEC fundamentals are available.")

    q=state.get("quality_validation") or {}; vc=state.get("valuation_confidence") or {}; scores=state.get("scores") or {}; mg=state.get("management") or {}
    m=state.get("metrics") or {}
    st.markdown('<div class="mf3-section-title">CORE SNAPSHOT</div>',unsafe_allow_html=True)
    a,b,c,d,e,f=st.columns(6)
    a.metric("Revenue",ws.money(m.get("revenue")))
    b.metric("FCF margin",fpct(m.get("fcf_margin")))
    c.metric("ROIC",fpct(m.get("roic")))
    d.metric("Valuation confidence",vc.get("label","LOW"),f"{fnum(vc.get('score'),0)}/100")
    e.metric("Net Tape",fnum(scores.get("Net Tape"),0),scores.get("Regime") or "LOW DATA")
    f.metric("Management",mg.get("label","LOW DATA"),f"{fnum(mg.get('score'),0)}/100" if mg.get("score") is not None else "unscored")

    def callout(title_text, items, empty):
        body=''.join(f'<p>• {html.escape(str(x))}</p>' for x in items) if items else f'<p>{html.escape(empty)}</p>'
        return f'<div class="mf3-callout"><h4>{html.escape(title_text)}</h4>{body}</div>'
    st.markdown('<div class="mf3-row">'+callout("Why now",why,"No material dislocation proven yet.")+callout("Why not yet",blockers,"No major process blocker detected.")+callout("What changes the decision",changes,"Define evidence-to-add or a resolution signal.")+'</div>',unsafe_allow_html=True)
    st.markdown('<div class="mf3-row">'+callout("What kills the thesis",kills,"Define numerical/operating invalidation before capital is committed.")+callout("Process readiness",[f"{state.get('gate_counts',{}).get('PASS',0)}/16 investment gates complete", state.get('gate_label') or "RESEARCH INCOMPLETE"],"Research process not initialized.")+callout("Freshness",[f"Last success: {_age_label((service.last_successful_refresh(ticker) or {}).get('completed_at'))}", f"Audit: {(state.get('audit') or {}).get('counts',{}).get('PASS',0)} PASS / {(state.get('audit') or {}).get('counts',{}).get('WARN',0)} WARN / {(state.get('audit') or {}).get('counts',{}).get('FAIL',0)} FAIL"],"No refresh history.")+'</div>',unsafe_allow_html=True)

    fs=state.get("forensics") or {}
    st.markdown('<div class="mf3-section-title">FORENSIC LENS</div>',unsafe_allow_html=True)
    c1,c2,c3=st.columns(3)
    c1.markdown(_signal_html("Positive evidence",fs.get("positives"),"mf3-signal-pos","No material positive rule triggered."),unsafe_allow_html=True)
    c2.markdown(_signal_html("Challenges",fs.get("negatives"),"mf3-signal-neg","No material negative rule triggered."),unsafe_allow_html=True)
    c3.markdown(_signal_html("Data alerts",fs.get("data_alerts"),"mf3-signal-data","No material data-integrity alert detected."),unsafe_allow_html=True)

    rec=state.get("price_reconciliation") or {}
    st.markdown('<div class="mf3-section-title">EXPECTATIONS — WHAT MUST THE MARKET BELIEVE?</div>',unsafe_allow_html=True)
    a,b,c,d=st.columns(4)
    a.metric("Expectations",lens["Expectations"][0],"3-driver price reconciliation")
    b.metric("Revenue CAGR",f"{fpct(rec.get('market_implied_revenue_cagr'))} / {fpct(rec.get('forecast_revenue_cagr'))}","implied / our Base")
    c.metric("Year-5 net margin",f"{fpct(rec.get('market_implied_net_margin'))} / {fpct(rec.get('forecast_terminal_net_margin'))}","implied / our Base")
    d.metric("Year-5 exit P/E",f"{fnum(rec.get('market_implied_exit_pe'),1,'x')} / {fnum(rec.get('forecast_exit_pe'),1,'x')}","implied / our Base")
    st.caption("Expectations is now multi-driver: revenue growth + terminal profitability + exit multiple. No single growth estimate can determine the label by itself.")

    with st.expander("Variant perception + catalyst — edit the disagreement",expanded=lens["Variant"][0]=="UNPROVEN"):
        v=state.get("variant_case") or {}
        with st.form(ws.tk(ticker,"variant_case_v302")):
            a,b=st.columns(2)
            market=a.text_area("Market believes",value=v.get("market_belief") or "",height=110,placeholder="What does today's price / consensus appear to assume?")
            ours=b.text_area("We believe",value=v.get("our_belief") or "",height=110,placeholder="What is different in our view?")
            evidence=st.text_area("Evidence for the disagreement",value=v.get("disagreement_evidence") or "",height=90)
            a,b,c=st.columns([2,1,1]); resolution=a.text_input("What resolves the disagreement?",value=v.get("resolution_signal") or ""); horizon=b.text_input("Horizon",value=v.get("resolution_horizon") or ""); path=c.selectbox("Path",["UNCLEAR","SUPPORTIVE","HOSTILE"],index=["UNCLEAR","SUPPORTIVE","HOSTILE"].index(v.get("path_status") or "UNCLEAR"))
            if st.form_submit_button("Save variant case"):
                db.save_variant_case(ticker,{"market_belief":market,"our_belief":ours,"disagreement_evidence":evidence,"resolution_signal":resolution,"resolution_horizon":horizon,"path_status":path}); st.rerun()

    with st.expander("External triangulation — peers / industry evidence",expanded=False):
        tri=state.get("triangulation") or {}
        st.write(f"**{tri.get('summary','LOW DATA')}**" + (f" · {tri.get('score'):.0f}/100" if tri.get("score") is not None else ""))
        for sig in tri.get("signals",[]): st.write(f"• **{sig.get('Signal')}** — {sig.get('Evidence')}")
        ws.display_table(pd.DataFrame(tri.get("rows") or []),height=330)
        peers=tri.get("peers") or []
        if peers: st.caption("Peers: "+", ".join(p.get("ticker") for p in peers))

    with st.expander("Decision checklist — what is missing & where to edit",expanded=False):
        blockers2=[g for g in state.get("gates",[]) if g.get("status") in ("FAIL","INCOMPLETE","WATCH")]
        if blockers2: st.warning(ws.missing_gate_summary(state.get("gates",[]),limit=8))
        else: st.success("16/16 material process gates complete.")
        st.caption("This checklist is the process discipline behind BUY / SHORT / HOLD / SELL / WAIT. PASS does not itself create a BUY; it means that evidence block is complete enough for the action at the top of Decide to be trusted.")
        for g in state.get("gates",[]):
            target_label,target_path=GATE_EDIT_TARGETS.get(g.get("key"),("Research", "pages/03_research_v3.py"))
            cgate,cstatus,cedit=st.columns([5.5,1.1,1.8],vertical_alignment="center")
            note=(g.get("notes") or "").strip(); manual=" · manual" if g.get("manual") else ""
            cgate.markdown("**"+str(g.get("gate") or "")+"**" + (("  \n"+note) if note else ""))
            cstatus.markdown("**"+str(g.get("status") or "")+"**"+manual)
            cedit.page_link(target_path,label=f"Edit · {target_label}",width="stretch")
        with st.expander("Manual gate annotation / override",expanded=False):
            st.caption("Prefer editing the underlying evidence above. Use an override only when the automatic gate cannot represent the evidence correctly.")
            gate_map={g.get("gate"):g for g in state.get("gates",[])}
            if gate_map:
                glabel=st.selectbox("Gate",list(gate_map),key=ws.tk(ticker,"gate_override_v314"))
                grow=gate_map[glabel]; choices=["AUTO","PASS","WATCH","FAIL","INCOMPLETE"]
                current="AUTO" if not grow.get("manual") else grow.get("status")
                gstatus=st.selectbox("Status",choices,index=choices.index(current) if current in choices else 0,key=ws.tk(ticker,"gate_status_v314"))
                gnotes=st.text_area("Notes",value=grow.get("notes") or "",key=ws.tk(ticker,"gate_notes_v314"))
                if st.button("Save gate annotation",key=ws.tk(ticker,"gate_save_v314")):
                    db.save_gate_override(ticker,grow.get("key"),None if gstatus=="AUTO" else gstatus,gnotes); st.rerun()

    st.markdown('<div class="mf3-section-title">RESEARCH REPORT</div>',unsafe_allow_html=True)
    last_refresh=service.last_successful_refresh(ticker) or {}
    refresh_id=last_refresh.get("id") or last_refresh.get("completed_at") or "none"
    word_key=f"mf3_report_word_{ticker}"; pdf_key=f"mf3_report_pdf_{ticker}"
    word_pack=st.session_state.get(word_key); pdf_pack=st.session_state.get(pdf_key)
    a,b=st.columns(2)
    with a:
        if st.button("Prepare Word report",width="stretch",key=ws.tk(ticker,"generate_v303_word")):
            try:
                with st.spinner("Building editable Word research report..."):
                    word_pack={"refresh_id":refresh_id,"generated_at":datetime.now(timezone.utc).isoformat(),"data":exporter.research_report_docx(ticker,state)}
                    st.session_state[word_key]=word_pack
            except Exception as e: st.warning(f"Word report unavailable: {e}"); word_pack=None
        if word_pack:
            if word_pack.get("refresh_id") != refresh_id: st.warning("Data changed since this Word report was generated.")
            st.download_button("Download Word",data=word_pack["data"],file_name=f"{ticker}_Market_Forensics_Research_Report.docx",mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",width="stretch",key=ws.tk(ticker,"download_v303_docx"))
    with b:
        if st.button("Prepare PDF report",width="stretch",key=ws.tk(ticker,"generate_v303_pdf")):
            try:
                with st.spinner("Building final PDF research report..."):
                    pdf_pack={"refresh_id":refresh_id,"generated_at":datetime.now(timezone.utc).isoformat(),"data":exporter.research_report_pdf(ticker,state)}
                    st.session_state[pdf_key]=pdf_pack
            except Exception as e: st.warning(f"PDF report unavailable: {e}"); pdf_pack=None
        if pdf_pack:
            if pdf_pack.get("refresh_id") != refresh_id: st.warning("Data changed since this PDF report was generated.")
            st.download_button("Download PDF",data=pdf_pack["data"],file_name=f"{ticker}_Market_Forensics_Research_Report.pdf",mime="application/pdf",width="stretch",key=ws.tk(ticker,"download_v303_pdf"))


def render_research(ticker: str, state: dict):
    _workflow_back("pages/02_decide_v3.py","Decide","Decide › Research evidence")
    title(ticker,"Research · Evidence Room","Evidence, audit trails and operating detail. The decision itself lives in Decide; this page exists to prove or disprove it.")
    lens=decision_lens(ticker,state)
    m=state.get("metrics") or {}; scores=state.get("scores") or {}; q=state.get("quality_validation") or {}; mg=state.get("management") or {}; tri=state.get("triangulation") or {}; audit_state=state.get("audit") or {}; vc=state.get("valuation_confidence") or {}

    tri_score=tri.get("score")
    audit_counts=audit_state.get("counts") or {}
    st.markdown('<div class="mf3-row4">'+''.join([
        _box("Business Quality",q.get("label","LOW DATA"),f"{fnum(q.get('score'),0)}/100",hero=True),
        _box("Management",mg.get("label","LOW DATA"),f"{fnum(mg.get('score'),0)}/100" if mg.get("score") is not None else "unscored",hero=True),
        _box("Triangulation",tri.get("summary","LOW DATA"),"—" if tri_score is None else f"{float(tri_score):.0f}/100",hero=True),
        _box("Data Audit",f"{audit_counts.get('PASS',0)} PASS",f"{audit_counts.get('WARN',0)} WARN · {audit_counts.get('FAIL',0)} FAIL",hero=True,tone_override="neutral"),
    ])+'</div>',unsafe_allow_html=True)

    st.markdown('<div class="mf3-section-title">OPERATING EVIDENCE SNAPSHOT</div>',unsafe_allow_html=True)
    a,b,c,d,e,f=st.columns(6)
    a.metric("Revenue",ws.money(m.get("revenue"))); b.metric("Gross margin",fpct(m.get("gross_margin"))); c.metric("Op margin",fpct(m.get("operating_margin"))); d.metric("FCF margin",fpct(m.get("fcf_margin"))); e.metric("ROIC",fpct(m.get("roic"))); f.metric("CCC",fnum(m.get("ccc"),1,"d"))

    with st.expander("1 · Business & numbers",expanded=True):
        st.caption("Reported economics and working-capital evidence. Decision labels are intentionally not repeated here.")
        a,b,c,d=st.columns(4); a.metric("CFO / NI",fnum(m.get("cfo_ni"),2,"x")); b.metric("Net debt",ws.money(m.get("net_debt"))); c.metric("Inventory / Revenue",fpct(m.get("inventory_revenue"))); d.metric("Share change",fpct(m.get("share_change")))
        a_flow,b_flow=st.columns(2)
        a_flow.page_link(DETAIL_PATHS["Fundamentals"],label="Open full Business & Fundamentals",width="stretch")
        b_flow.page_link(DETAIL_PATHS["Financial Flows"],label="Open Financial Flows · Income Statement + Cash Flow",width="stretch")

    with st.expander("2 · External triangulation",expanded=False):
        st.write(f"**{tri.get('summary','LOW DATA')}**" + (f" · {tri.get('score'):.0f}/100" if tri.get("score") is not None else ""))
        for sig in tri.get("signals",[])[:8]: st.write(f"• **{sig.get('Signal')}** — {sig.get('Evidence')}")
        ws.display_table(pd.DataFrame(tri.get("rows") or []),height=320)
        with st.form(ws.tk(ticker,"peer_link_v311")):
            a,b,c=st.columns(3); pt=a.text_input("Add linked ticker"); rel=b.selectbox("Relation",["PEER","CUSTOMER","SUPPLIER","DISTRIBUTOR","INDUSTRY"]); note=c.text_input("Note")
            if st.form_submit_button("Add relation") and pt.strip():
                _peer=symbols.validate_ticker(pt)
                if not _peer.valid: st.error(_peer.message or "Ticker not found / symbol not recognized.")
                else: db.save_peer_link(ticker,_peer.ticker,rel,"MANUAL",1.0,note); st.rerun()

    with st.expander("3 · Management + 5Y operating forecast",expanded=False):
        rec=state.get("price_reconciliation") or {}
        a,b,c,d=st.columns(4)
        a.metric("Management",mg.get("label","LOW DATA"),f"{fnum(mg.get('score'),0)}/100")
        b.metric("Business quality",q.get("label","LOW DATA"),f"{fnum(q.get('score'),0)}/100")
        c.metric("Base revenue CAGR",fpct(rec.get("forecast_revenue_cagr")),"5Y operating path")
        d.metric("Base year-5 net margin",fpct(rec.get("forecast_terminal_net_margin")),"5Y operating path")
        st.info("The 5Y Operating Forecast Bear/Base/Bull is a separate operating-path model. The Bear/Base/Bull fair values shown in Decide come from the Valuation Cases. Both are intentionally labeled separately in V3.1.12.")
        st.page_link(DETAIL_PATHS["Management & Forecast"],label="Open 5Y Operating Forecast scenarios",width="stretch")

    with st.expander("4 · Valuation mechanics & scenario evidence",expanded=False):
        hist=db.latest_validation_result(ticker); hs=(hist or {}).get("summary") or {}
        a,b,c,d=st.columns(4)
        a.metric("Valuation confidence",vc.get("label","LOW"),f"{fnum(vc.get('score'),0)}/100")
        b.metric("Expected value",fprice(state.get("expected_value")),"probability weighted")
        c.metric("Historical reliability","—" if hs.get("reliability_score") is None else f"{float(hs.get('reliability_score')):.0f}/100",hs.get("sample_confidence") or "not validated")
        d.metric("Model confidence",lens["Model Confidence"][0],lens["Model Confidence"][1])
        st.caption("Full Bear/Base/Bull inputs and outputs are visible directly in Decide. Use the advanced valuation page to edit them and inspect historical calibration/method dispersion.")
        st.page_link(DETAIL_PATHS["Valuation"],label="Open Valuation Cases · assumptions, calibration & method outputs",width="stretch")

    with st.expander("5 · Tape & positioning",expanded=False):
        a,b,c,d=st.columns(4); a.metric("Net Tape",fnum(scores.get("Net Tape"),0)); b.metric("Long Demand",fnum(scores.get("Long Demand"),0)); c.metric("Short Pressure",fnum(scores.get("Short Pressure"),0)); d.metric("Absorption",fnum(scores.get("Absorption"),0))
        st.page_link(DETAIL_PATHS["Tape"],label="Open Tape & Positioning",width="stretch")

    with st.expander("6 · Thesis, bear case, invalidation & risk",expanded=False):
        r=db.load_research(ticker) or {}; v=state.get("variant_case") or {}
        st.write("**Market believes:** "+(v.get("market_belief") or "Not written"))
        st.write("**We believe:** "+(v.get("our_belief") or "Not written"))
        locked=[k for k in (state.get("kpis") or []) if k.get("linked_to")=="INVALIDATION" and k.get("threshold") is not None and int(k.get("locked") or 0)==1]
        if locked:
            st.write("**LOCKED thesis invalidation:** "+" · ".join(f"{k.get('name') or k.get('metric_key')} {k.get('operator') or '?'} {k.get('threshold')} {k.get('unit') or ''}".strip() for k in locked[:5]))
        else: st.warning("No LOCKED numerical thesis invalidation threshold yet.")
        st.write("**Primary risk:** "+(r.get("primary_risk") or "Not written"))
        st.write("**Evidence required to ADD:** "+(r.get("evidence_to_add") or "Not written"))
        a,b=st.columns(2); a.page_link(DETAIL_PATHS["Thesis & Bear Case"],label="Open Thesis & Bear Case",width="stretch"); b.page_link(DETAIL_PATHS["Risk & Journal"],label="Open Risk, Sizing & Journal",width="stretch")

    with st.expander("7 · Sources, provenance & revisions",expanded=False):
        st.write(f"Audit: **{audit_counts.get('PASS',0)} PASS · {audit_counts.get('WARN',0)} WARN · {audit_counts.get('FAIL',0)} FAIL · {audit_counts.get('NO DATA',0)} NO DATA**")
        st.caption("Use Sources & Audit for SEC/XBRL tags, revisions, refresh provenance and provider checks. Configuration itself lives only in Settings.")
        st.page_link(DETAIL_PATHS["Sources & Audit"],label="Open Sources & Audit",width="stretch")


def render_monitor(ticker: str, state: dict):
    _workflow_back("pages/02_decide_v3.py","Decide","Decide › Monitor")
    title(ticker,"Monitor","What changed, what matters next, and whether the thesis became stronger or weaker.")
    hist=service.snapshot_history(ticker,10); changed=decision.what_changed(hist); kpis=state.get("kpi_eval") or []; evt=decision.next_event(ticker)
    l,r=st.columns([1.15,1])
    with l:
        fig=_price_chart(state,330)
        if fig is not None: st.plotly_chart(fig,width="stretch")
    with r:
        st.markdown('<div class="mf3-section-title">WHAT CHANGED</div>',unsafe_allow_html=True)
        if changed:
            for x in changed[:6]: st.write("• "+x)
        else: st.caption("Not enough snapshot history yet.")
        if evt: st.info(f"Next event: {evt.get('event_date')} · {evt.get('title')}")
        else: st.caption("No dated catalyst/event saved.")

    bad=[x for x in kpis if x.get("kpi_status") in ("FAIL","WATCH","TRIGGERED")]
    st.markdown('<div class="mf3-section-title">THESIS KPI EXCEPTIONS</div>',unsafe_allow_html=True)
    if bad:
        cols=st.columns(min(3,len(bad)))
        for i,x in enumerate(bad[:6]):
            col=cols[i%len(cols)]
            col.markdown(_box(x.get("name") or "KPI",x.get("kpi_status") or "WATCH",f"Current {x.get('current_value')} · threshold {x.get('operator')} {x.get('threshold')}"),unsafe_allow_html=True)
    elif kpis:
        st.success("No monitored KPI is currently in FAIL/WATCH/TRIGGERED.")
    else:
        st.info("Define only the 3–7 KPIs that can genuinely strengthen, weaken or kill the thesis.")
    st.page_link(DETAIL_PATHS["Monitoring"],label="Open full Monitoring & Events",width="stretch")



def render_validate():
    _workflow_back("pages/02_decide_v3.py","Decide","Decide › Validate")
    title(
        "VALIDATE",
        "Walk-forward evidence",
        "Replay today's model on yesterday's information, then score what actually happened. No future filings, no current saved assumptions, no hindsight edits.",
    )
    ticker = str(st.session_state.get("ticker") or "").upper().strip()
    if not ticker:
        st.warning("Add or select a company first.")
        return

    st.markdown(
        '<div class="mf3-panel"><div class="mf3-big">Point-in-time rule</div>'
        '<div class="mf3-small">For each Dec 31 anchor, Market Forensics rebuilds the company using only SEC facts filed on or before that date and only prices known by then. '
        'The +1Y price and +1Y fundamentals stay hidden until scoring. This is a replay of the current model rules, not a reconstruction of whatever an analyst subjectively believed at the time.</div></div>',
        unsafe_allow_html=True,
    )

    now_year = datetime.now(timezone.utc).year
    default_end = max(2012, now_year - 2)
    default_start = 2009 if default_end >= 2009 else max(2000, default_end - 6)
    c1, c2, c3, c4 = st.columns([1, 1, 1.15, 1.25])
    start_year = int(c1.number_input("First anchor year", min_value=1995, max_value=max(1995, default_end), value=default_start, step=1,
                                     help="Validate will automatically use the earliest year where both point-in-time SEC fundamentals and split-aware price history are available."))
    end_year = int(c2.number_input("Last anchor year", min_value=start_year, max_value=max(start_year, now_year - 1), value=max(start_year, default_end), step=1))
    threshold_pct = float(c3.selectbox("Signal threshold", [10, 15, 20, 25], index=1, help="Base target gap required to label a historical LONG or SHORT call."))
    run = c4.button("Run point-in-time validation", type="primary", width="stretch")

    key = f"mf_validate_{ticker}"
    if run:
        try:
            with st.spinner(f"Replaying {ticker} year by year without look-ahead..."):
                result = backtest.run_validation(
                    ticker,
                    start_year=start_year,
                    end_year=end_year,
                    call_threshold=threshold_pct / 100.0,
                    lookback_days=14610,
                )
            st.session_state[key] = result
        except Exception as exc:
            st.error(f"Validation failed: {exc}")
            return

    result = st.session_state.get(key)
    if not result:
        st.markdown(
            '<div class="mf3-section"><div class="mf3-section-title">What this will test</div>'
            '<p><b>Price validation:</b> historical Bear / Base / Bull target versus the actual market price one year later.</p>'
            '<p><b>Thesis validation:</b> growth, net margin and FCF margin assumptions versus the operating results actually visible one year later.</p>'
            '<p><b>Baseline:</b> whether the Base target was more accurate than simply assuming the stock price would not change.</p>'
            '<p class="mf3-small">The blended valuation engine is tested on a rolling +1Y horizon because its P/E, EV/Sales and FCF-yield target components normalize one forward year. Multi-year reliability is therefore assessed through repeated annual walk-forward tests rather than by leaking future information into one long forecast.</p></div>',
            unsafe_allow_html=True,
        )
        return

    if result.get("start_year") != start_year or result.get("end_year") != end_year or abs(float(result.get("call_threshold") or 0) - threshold_pct / 100.0) > 1e-9:
        st.info("The results below are from the last completed settings. Press Run to refresh them with the controls above.")

    summary = result.get("summary") or {}
    if result.get("persistence_warning"):
        st.warning(result.get("persistence_warning"))
    if result.get("price_basis_verified"):
        st.caption("Corporate-action basis: VERIFIED — stock splits are normalized before historical price scoring.")
    else:
        st.warning("Corporate-action basis is UNVERIFIED for this run. Review split-sensitive years before treating the Reliability Score as decision-grade.")
    earliest = result.get("earliest_modelable_year")
    earliest_complete = result.get("earliest_complete_year")
    history_start = result.get("price_history_start") or "—"
    if earliest is not None:
        st.caption(f"Historical depth: price history starts {history_start} · first modelable anchor {earliest} · first completed +1Y replay {earliest_complete or 'pending/unavailable'}. Provider: {result.get('price_provider') or '—'}.")
        if start_year < int(earliest):
            st.info(f"You requested {start_year}, but {ticker}'s first point-in-time year with sufficient model inputs is {earliest}. Earlier rows remain visible as unavailable rather than being silently excluded.")
    else:
        st.warning(f"No fully modelable historical anchor was found in the requested range. Price history begins {history_start}; SEC point-in-time fundamentals may begin later for this issuer.")
    verdict = summary.get("verdict") or "—"
    tone = "green" if "STRONG" in verdict else "red" if "WEAK" in verdict else "yellow"
    st.markdown(_box("Historical verdict", verdict, f"{summary.get('complete_tests',0)} completed annual replays", hero=True, tone_override=tone), unsafe_allow_html=True)

    reliability = summary.get("reliability_score")
    reliability_label = summary.get("reliability_label") or "NO DATA"
    st.markdown('<div class="mf3-section-title">COMPANY-SPECIFIC RELIABILITY</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="mf3-row4">'
        + _box("Reliability Score", "—" if reliability is None else f"{float(reliability):.0f}/100", f"{reliability_label} · sample confidence {summary.get('sample_confidence','LOW')}", hero=True, tone_override="neutral")
        + _box("Valuation Reliability", "—" if summary.get("valuation_reliability_score") is None else f"{float(summary.get('valuation_reliability_score')):.0f}/100", "Scenario-band hit + Base price accuracy", tone_override="neutral")
        + _box("Thesis Reliability", "—" if summary.get("thesis_reliability_score") is None else f"{float(summary.get('thesis_reliability_score')):.0f}/100", "Operating-driver hit rate + supported years", tone_override="neutral")
        + _box("Direction Reliability", "—" if summary.get("direction_reliability_score") is None else f"{float(summary.get('direction_reliability_score')):.0f}/100", f"Bias control {fnum(summary.get('bias_control_score'),0)}/100 · {summary.get('bias_label','NO DATA')}", tone_override="neutral")
        + '</div>', unsafe_allow_html=True
    )
    st.caption("The composite is deliberately sample-adjusted: fewer than 3 completed replays is LOW SAMPLE; full sample credit is reached at 6 completed annual walk-forwards. It measures historical model/company fit, not certainty about the future.")

    def _pct_or_dash(v, digits=0):
        return "—" if v is None else f"{float(v):.{digits}%}"

    st.markdown(
        '<div class="mf3-row4">'
        + _box("Bear–Bull range hit", _pct_or_dash(summary.get("price_range_hit_rate")), "Actual +1Y price inside the historical scenario band", tone_override="neutral")
        + _box("Direction hit", _pct_or_dash(summary.get("direction_hit_rate")), "LONG finished up / SHORT finished down / NEUTRAL stayed inside threshold", tone_override="neutral")
        + _box("Median Base error", _pct_or_dash(summary.get("median_base_abs_error")), "Absolute error versus realized +1Y price", tone_override="neutral")
        + _box("Thesis drivers hit", _pct_or_dash(summary.get("thesis_driver_hit_rate")), "Growth + net margin + FCF margin inside historical Bear–Bull bands", tone_override="neutral")
        + '</div>',
        unsafe_allow_html=True,
    )
    st.markdown(
        '<div class="mf3-row4">'
        + _box("Beat no-change", _pct_or_dash(summary.get("beat_no_change_rate")), "Base target error smaller than using the anchor price as the forecast", tone_override="neutral")
        + _box("Thesis supported", _pct_or_dash(summary.get("thesis_supported_rate")), "At least 2 of 3 operating drivers landed inside the scenario band", tone_override="neutral")
        + _box("Median bias", _pct_or_dash(summary.get("median_base_signed_error"),1), "Positive = model historically overpredicted price; negative = underpredicted", tone_override="neutral")
        + _box("Calls", f"L {summary.get('long_calls',0)} · N {summary.get('neutral_calls',0)} · S {summary.get('short_calls',0)}", "Historical calls at the selected target-gap threshold", tone_override="neutral")
        + '</div>',
        unsafe_allow_html=True,
    )

    rows = result.get("rows") or []
    complete = [r for r in rows if r.get("status") == "COMPLETE"]
    if complete:
        chart = go.Figure()
        years = [r.get("anchor_year") for r in complete]
        chart.add_trace(go.Scatter(x=years, y=[r.get("bear_target") for r in complete], mode="lines+markers", name="Bear target", line=dict(color="#D15353", dash="dot")))
        chart.add_trace(go.Scatter(x=years, y=[r.get("base_target") for r in complete], mode="lines+markers", name="Base target", line=dict(color="#3F78A8", width=3)))
        chart.add_trace(go.Scatter(x=years, y=[r.get("bull_target") for r in complete], mode="lines+markers", name="Bull target", line=dict(color="#1F9D68", dash="dot")))
        chart.add_trace(go.Scatter(x=years, y=[r.get("outcome_price") for r in complete], mode="lines+markers", name="Comparable +1Y (anchor basis)", line=dict(color="#C99A2E", width=3)))
        _style_plot(chart,
            height=390, margin=dict(l=10, r=10, t=48, b=10),
            title="Historical targets vs +1Y comparable price", xaxis_title="Information cutoff year", yaxis_title="Price",
            legend=dict(orientation="h", y=1.02, x=0),
        )
        st.plotly_chart(chart, width="stretch")

    table_rows = []
    for r in rows:
        ca_warning=r.get("corporate_action_note")
        if not ca_warning and not bool(r.get("price_basis_verified",result.get("price_basis_verified"))):
            ca_warning="PRICE BASIS REVIEW — corporate-action normalization not independently verified"
        elif not ca_warning:
            ca_warning="—"
        table_rows.append({
            "Anchor year": r.get("anchor_year"),
            "Anchor date": r.get("anchor_date") or "—",
            "PIT filing through": r.get("latest_filing_used") or "—",
            "Anchor raw close": r.get("anchor_price"),
            "Anchor market date": r.get("anchor_price_date") or "—",
            "Anchor split factor": r.get("anchor_split_factor"),
            "Call": r.get("model_call") or "—",
            "Bear": r.get("bear_target"),
            "Base": r.get("base_target"),
            "Bull": r.get("bull_target"),
            "+1Y exact market date": r.get("outcome_price_date") or "—",
            "+1Y year-end raw close": r.get("outcome_market_price"),
            "Comparable +1Y (anchor basis)": r.get("outcome_price"),
            "Outcome split factor": r.get("outcome_split_factor"),
            "Basis factor": r.get("share_basis_normalization"),
            "Corporate-action warning": ca_warning,
            "Return": r.get("realized_return"),
            "Range hit": r.get("price_range_hit"),
            "Base error": r.get("base_abs_error"),
            "Direction hit": r.get("direction_hit"),
            "Growth hit": r.get("growth_thesis_hit"),
            "Net margin hit": r.get("net_margin_thesis_hit"),
            "FCF margin hit": r.get("fcf_margin_thesis_hit"),
            "Thesis": r.get("thesis_status") or "—",
            "Valuation confidence": r.get("valuation_confidence") or "—",
            "History pts": r.get("calibration_years"),
            "Status": r.get("status"),
            "Error": r.get("error") or "—",
        })
    df = pd.DataFrame(table_rows)
    st.markdown('<div class="mf3-section-title">Year-by-year replay</div>', unsafe_allow_html=True)
    st.caption("Price convention: Anchor and Year-end raw close are the actual raw/as-traded closes on the last trading day on or before Dec 31 (maximum 10-calendar-day lookup gap). Comparable +1Y rebases that raw outcome price to the anchor-year share basis so stock splits cannot create fake gains/losses. If no split/reverse split occurred, Comparable +1Y and Year-end raw close are the same. Exact quote dates are shown below.")
    st.dataframe(
        df,
        width="stretch",
        hide_index=True,
        column_config={
            "Anchor raw close": st.column_config.NumberColumn(format="$%.2f", help="Actual raw/as-traded close used at the historical anchor; never retroactively split-adjusted by a future corporate action."),
            "Anchor split factor": st.column_config.NumberColumn(format="%.6f", help="Verified cumulative split/reverse-split factor on the anchor market date."),
            "Bear": st.column_config.NumberColumn(format="$%.2f"),
            "Base": st.column_config.NumberColumn(format="$%.2f"),
            "Bull": st.column_config.NumberColumn(format="$%.2f"),
            "+1Y year-end raw close": st.column_config.NumberColumn(format="$%.2f", help="Actual raw/as-traded close on the exact +1Y market date shown. It can differ from the comparable price only when the share basis changed."),
            "Comparable +1Y (anchor basis)": st.column_config.NumberColumn(format="$%.2f", help="The raw +1Y outcome translated back to the anchor-year share basis. This is the apples-to-apples price used for Bear/Base/Bull validation across stock splits."),
            "Outcome split factor": st.column_config.NumberColumn(format="%.6f", help="Verified cumulative split/reverse-split factor on the +1Y market date."),
            "Basis factor": st.column_config.NumberColumn(format="%.4f", help="Multiplier used to translate the raw +1Y quote back to the anchor share basis."),
            "Return": st.column_config.NumberColumn(format="percent"),
            "Base error": st.column_config.NumberColumn(format="percent"),
        },
    )
    st.download_button(
        "Download validation CSV",
        data=df.to_csv(index=False).encode("utf-8"),
        file_name=f"{ticker}_PIT_validation_{result.get('start_year')}_{result.get('end_year')}.csv",
        mime="text/csv",
    )

    with st.expander("Methodology, anti-leakage controls and limitations"):
        m = result.get("methodology") or {}
        st.markdown(
            f"""
**Anchor:** {m.get('anchor','—')}  
**Horizon:** {m.get('horizon','—')}  
**Fundamentals:** {m.get('fundamentals','—')}  
**Assumptions:** {m.get('assumptions','—')}  
**Price scoring:** {m.get('price_scoring','—')}  
**Thesis scoring:** {m.get('thesis_scoring','—')}  
**Reliability:** {m.get('reliability','—')}  
**Price provider:** {result.get('price_provider','—')}  
**Corporate-action basis:** {'VERIFIED' if result.get('price_basis_verified') else 'UNVERIFIED'} — {result.get('price_adjustment_note','—')}

This is a **walk-forward validation of the current V3.1.12 model rules** on historical information. It is not proof that future predictions will be correct. SEC Companyfacts is filtered by original filing date to prevent future filings and later restatements from entering an earlier replay. Current saved valuation assumptions and manual thesis text are excluded to prevent hindsight. Corporate actions should be reviewed when the price provider is not split-adjusted.
            """
        )
        leak = backtest.leakage_self_test()
        if leak.get("pass"):
            st.success("Anti-leakage self-test: PASS — a later restatement is excluded from an earlier cutoff.")
        else:
            st.error("Anti-leakage self-test: FAIL — do not rely on historical validation until fixed.")

def render_portfolio(ticker: str, state: dict):
    _workflow_back("pages/01_coverage_v3.py","Decision Queue","Queue › Portfolio")
    title("PORTFOLIO","Portfolio","Your real positions first. Add or edit holdings even before a thesis exists; research attaches later.")
    positions=db.list_portfolio_positions(); settings=load_settings(); nav=float(settings.get("portfolio_nav") or 0)

    st.markdown('<div class="mf3-section-title">ADD / EDIT REAL POSITION</div>',unsafe_allow_html=True)
    current_pos=db.portfolio_position(ticker) if ticker else None
    with st.form("mf313_position_editor"):
        a,b,c,d=st.columns([1.0,1.0,1.2,1.2])
        pt=a.text_input("Ticker",value=(current_pos or {}).get("ticker") or ticker or "").upper()
        side=b.selectbox("Side",["LONG","SHORT"],index=0 if (current_pos or {}).get("side","LONG")=="LONG" else 1)
        shares=c.number_input("Shares",min_value=0.0,value=float((current_pos or {}).get("shares") or 0.0),step=1.0)
        cost=d.number_input("Average cost",min_value=0.0,value=float((current_pos or {}).get("avg_cost") or 0.0),step=0.01)
        tags=st.text_input("Exposure tags",value=(current_pos or {}).get("tags") or "",placeholder="consumer, China, rates, AI capex")
        notes=st.text_area("Position notes",value=(current_pos or {}).get("notes") or "",height=70)
        if st.form_submit_button("Save position",type="primary"):
            if not pt.strip() or shares<=0:
                st.error("Ticker and shares > 0 are required.")
            else:
                validation=symbols.validate_ticker(pt)
                if not validation.valid:
                    st.error(validation.message or "Ticker not found / symbol not recognized.")
                else:
                    t=validation.ticker; db.upsert_portfolio_position(t,side,shares,cost,tags,notes); st.session_state["ticker"]=t
                    if not service.last_successful_refresh(t): jobs.start_or_enqueue([t],reason="V3_1_9_PORTFOLIO_ADD",include_flow=True)
                    st.success(f"{t} position saved. A thesis is not required to keep it in Portfolio."); st.rerun()

    if positions:
        with st.expander("Remove a position",expanded=False):
            rt=st.selectbox("Ticker to remove",[r["ticker"] for r in positions],key="mf313_remove_pos")
            if st.button("Remove from Portfolio",width="stretch",key="mf313_remove_pos_btn"):
                db.delete_portfolio_position(rt); st.success(f"{rt} removed from Portfolio. Research history was preserved."); st.rerun()

    positions=db.list_portfolio_positions(); data=[]; long_value=0.0; short_value=0.0; total_cost=0.0
    try:
        _portfolio_live=marketdata.current_price_overlays([p.get("ticker") for p in positions],settings.get("alpaca_feed","auto"))
    except Exception:
        _portfolio_live={}
    for p in positions:
        t=p["ticker"]; side=p.get("side") or "LONG"; sh=float(p.get("shares") or 0); avg=float(p.get("avg_cost") or 0)
        bars=db.query("SELECT close,trade_date FROM daily_bars WHERE ticker=? ORDER BY trade_date DESC LIMIT 1",(t,))
        _lq=_portfolio_live.get(t) or {}
        px=float(_lq.get("price")) if _lq.get("price") is not None else (float(bars[0]["close"]) if bars and bars[0].get("close") is not None else None)
        mv=abs(sh*px) if px is not None else None; sign=-1 if side=="SHORT" else 1
        pnl=((px-avg)*sh*sign) if px is not None and avg is not None else None
        total_cost+=abs(sh*avg)
        if mv is not None:
            if side=="LONG": long_value+=mv
            else: short_value+=mv
        cov=db.coverage_row(t); action="RESEARCH NEEDED"; model="UNVALIDATED"; base=None
        if cov or db.query("SELECT 1 FROM fundamentals WHERE ticker=? LIMIT 1",(t,)):
            try:
                s2=ws.load_state(t,live_price=True); lens=decision_lens(t,s2); act=position_action(t,s2,lens); action=act["action"]; model=lens["Model Confidence"][0]; base=s2.get("base_value")
            except Exception:
                action="HOLD" if side=="LONG" else "HOLD SHORT"
        data.append({"Ticker":t,"Side":side,"Shares":sh,"Avg Cost":avg,"Price":px,"Price status":((_lq.get("freshness") or "")+(" · "+str(_lq.get("asof") or "") if _lq else "")).strip(" ·") or "LAST FULL REFRESH","Market Value":mv,"P/L":pnl,"P/L %":((px/avg-1)*sign if px is not None and avg>0 else None),"Weight":(mv/nav) if mv is not None and nav>0 else None,"Action":action,"Base FV":base,"Model":model,"Research":(cov or {}).get("status") or "NOT STARTED","Tags":p.get("tags") or ""})

    a,b,c,d=st.columns(4)
    a.metric("Positions",len(data)); b.metric("Long value",ws.money(long_value)); c.metric("Short value",ws.money(short_value)); d.metric("Gross value",ws.money(long_value+short_value))
    if not data:
        st.info("No positions recorded. Add your current portfolio above — no thesis is required first.")
    else:
        ws.display_table(pd.DataFrame(data),{"Avg Cost":fprice,"Price":fprice,"Market Value":ws.money,"P/L":ws.money,"P/L %":fpct,"Weight":fpct,"Base FV":fprice},height=560)
        st.caption("Prices auto-refresh from the market snapshot while Portfolio is open. Price status shows timestamp/freshness; Action still applies the stricter share-basis rule in Decide.")
    if nav<=0:
        st.warning("Portfolio NAV is optional, but required for position weights/concentration. Set it in Settings.")
    st.page_link(DETAIL_PATHS["Portfolio Detail"],label="Open Portfolio Detail · concentration & exposure",width="stretch")



def render_settings(ticker: str, state: dict):
    title("SETTINGS","Settings & Data","Operational controls, provider resilience and data health. Technical provenance remains one click deeper.")
    settings=load_settings(); backup_secrets=load_market_data_secrets(); providers=marketdata.provider_configuration()

    alp_status="READY" if alpaca_ready() else "MISSING"
    sec_status="READY" if (settings.get("sec_user_agent") and "@" in settings.get("sec_user_agent","")) else "MISSING"
    backup_ready=sum(1 for k in ("TIINGO_API_KEY","ALPHA_VANTAGE_API_KEY","MASSIVE_API_KEY") if backup_secrets.get(k)) + (1 if settings.get("ibkr_enabled") else 0)
    pc=marketdata.latest_price_check(ticker) if ticker else {"status":"NO DATA"}
    st.markdown('<div class="mf3-row4">'+''.join([
        _box("Alpaca",alp_status,"Primary market bars / tape when available",hero=True),
        _box("SEC",sec_status,"Filings, Companyfacts and management history",hero=True),
        _box("Backup providers",f"{backup_ready} configured","IBKR / Tiingo / Alpha Vantage / Massive",hero=True,tone_override="neutral"),
        _box("Price check",pc.get("status") or "NO DATA",pc.get("message") or "Independent reference-price validation",hero=True),
    ])+'</div>',unsafe_allow_html=True)

    st.markdown('<div class="mf3-section-title">BRANDING</div>', unsafe_allow_html=True)
    with st.container(border=True):
        b1,b2=st.columns([1.2,2.8])
        with b1:
            logo=branding_logo_path()
            if logo:
                st.image(str(logo), width=210)
                st.caption("Used in the sidebar and generated reports.")
            else:
                st.markdown("**Market Forensics**")
                st.caption("No custom logo configured. Reports use the MF monogram.")
        with b2:
            uploaded=st.file_uploader("Custom logo",type=["png","jpg","jpeg"],help="PNG with transparent background works best. Stored locally only.",key="mf305_logo_upload")
            c_logo1,c_logo2=st.columns(2)
            if c_logo1.button("Save logo",width="stretch",disabled=uploaded is None,key="mf305_save_logo"):
                try:
                    save_branding_logo(uploaded.getvalue()); st.success("Logo saved locally."); st.rerun()
                except Exception as e:
                    st.error(f"Could not save logo: {e}")
            if c_logo2.button("Remove logo",width="stretch",disabled=branding_logo_path() is None,key="mf305_remove_logo"):
                clear_branding_logo(); st.success("Custom logo removed."); st.rerun()

    st.markdown('<div class="mf3-section-title">CORE CONFIGURATION</div>',unsafe_allow_html=True)
    with st.form("mf303_core_settings"):
        c1,c2,c3,c4=st.columns(4)
        feed=c1.selectbox("Alpaca feed mode",["auto","sip","iex"],index=["auto","sip","iex"].index(settings.get("alpaca_feed","auto")),help="AUTO tries historical SIP first, then falls back to IEX.")
        flow_days=c2.slider("Flow sessions",1,20,int(settings.get("flow_days",5)))
        minimum=c3.number_input("Minimum trade notional",min_value=0.0,value=float(settings.get("minimum_notional",25000.0)),step=5000.0)
        modes=["AUTO","PLAIN","K","M","B"]; mode=str(settings.get("number_display","AUTO")).upper(); number_display=c4.selectbox("Large-number display",modes,index=modes.index(mode) if mode in modes else 0)
        ua=st.text_input("SEC User-Agent",value=settings.get("sec_user_agent", ""),help="Use a truthful identifier including a contact email, e.g. Market Forensics your@email.com")
        c5,c6=st.columns(2)
        nav=c5.number_input("Portfolio NAV (optional)",min_value=0.0,value=float(settings.get("portfolio_nav") or 0.0),step=10000.0)
        mgmt_limit=c6.number_input("Management filing scan",min_value=6,max_value=60,value=int(settings.get("management_filing_limit",18)),step=2)
        if st.form_submit_button("Save core settings",type="primary"):
            settings.update({"alpaca_feed":feed,"flow_days":int(flow_days),"minimum_notional":float(minimum),"number_display":number_display,"sec_user_agent":ua,"portfolio_nav":float(nav),"management_filing_limit":int(mgmt_limit)})
            save_settings(settings); st.success("Core settings saved locally."); st.rerun()

    st.markdown('<div class="mf3-section-title">MARKET-DATA RESILIENCE</div>',unsafe_allow_html=True)
    st.markdown('<div class="mf3-section">'+
        '<b>Daily prices / bars</b><br/>Alpaca → IBKR Gateway → Tiingo → Alpha Vantage → last-good SQLite cache.<br/><br/>'+
        '<b>Full tape</b><br/>Alpaca trades/NBBO → Massive trades/NBBO → LOW DATA. Market Forensics never fabricates a tape score when tick data are unavailable.<br/><br/>'+
        '<b>Discovery universe</b><br/>Alpaca active assets → SEC ticker/exchange map. SEC and FINRA use their official source first, then local last-good data with freshness warnings.'+
        '</div>',unsafe_allow_html=True)
    with st.form("mf303_resilience_settings"):
        a,b=st.columns([1,2])
        ibkr_enabled=a.checkbox("Enable IBKR Client Portal Gateway fallback",value=bool(settings.get("ibkr_enabled",False)),help="Requires an authenticated local IBKR Client Portal Gateway session and relevant market-data entitlements.")
        ibkr_url=b.text_input("IBKR Gateway base URL",value=settings.get("ibkr_base_url","https://localhost:5000/v1/api"))
        c,d,e=st.columns(3)
        cross=c.checkbox("Independent price cross-check",value=bool(settings.get("price_crosscheck_enabled",True)))
        warn=d.number_input("WARN dispersion %",min_value=0.01,max_value=10.0,value=float(settings.get("price_crosscheck_warn_pct",.005))*100,step=.10)
        fail=e.number_input("FAIL dispersion %",min_value=0.10,max_value=25.0,value=float(settings.get("price_crosscheck_fail_pct",.02))*100,step=.25)
        if st.form_submit_button("Save resilience settings"):
            settings.update({"ibkr_enabled":bool(ibkr_enabled),"ibkr_base_url":ibkr_url.strip(),"price_crosscheck_enabled":bool(cross),"price_crosscheck_warn_pct":float(warn)/100,"price_crosscheck_fail_pct":float(fail)/100})
            save_settings(settings); st.success("Market-data resilience settings saved."); st.rerun()

    with st.expander("Optional backup API keys",expanded=False):
        st.caption("Keys are stored only in the local MarketForensics app-data folder. Leave a field blank to keep an existing key. Never paste keys into chat.")
        with st.form("mf303_backup_keys"):
            tkey=st.text_input("Tiingo API key",type="password",placeholder="Configured" if backup_secrets.get("TIINGO_API_KEY") else "Optional")
            akey=st.text_input("Alpha Vantage API key",type="password",placeholder="Configured" if backup_secrets.get("ALPHA_VANTAGE_API_KEY") else "Optional")
            mkey=st.text_input("Massive API key",type="password",placeholder="Configured" if backup_secrets.get("MASSIVE_API_KEY") else "Optional - tape fallback")
            x1,x2,x3=st.columns(3)
            clear_t=x1.checkbox("Clear Tiingo"); clear_a=x2.checkbox("Clear Alpha Vantage"); clear_m=x3.checkbox("Clear Massive")
            if st.form_submit_button("Save backup provider keys"):
                save_market_data_secrets({"TIINGO_API_KEY":tkey,"ALPHA_VANTAGE_API_KEY":akey,"MASSIVE_API_KEY":mkey})
                clears=[]
                if clear_t: clears.append("TIINGO_API_KEY")
                if clear_a: clears.append("ALPHA_VANTAGE_API_KEY")
                if clear_m: clears.append("MASSIVE_API_KEY")
                if clears: clear_market_data_secrets(clears)
                st.success("Backup-provider configuration saved locally."); st.rerun()
        st.caption(f"Backup secrets: {MARKET_DATA_SECRETS_PATH}")

    st.markdown('<div class="mf3-section-title">DISCOVERY CONFIGURATION</div>',unsafe_allow_html=True)
    with st.form("mf303_discovery_settings"):
        a,b,c,d=st.columns(4)
        min_price=a.number_input("Min price",min_value=0.0,value=float(settings.get("discovery_min_price",3.0)),step=1.0)
        min_dv=b.number_input("Min daily $ volume",min_value=0.0,value=float(settings.get("discovery_min_dollar_volume",5_000_000)),step=1_000_000.0)
        max_symbols=c.number_input("Liquid universe size",min_value=100,max_value=2000,value=int(settings.get("discovery_max_symbols",600)),step=100)
        age=d.number_input("SEC cache days",min_value=1,max_value=30,value=int(settings.get("discovery_fundamental_age_days",7)),step=1)
        if st.form_submit_button("Save Discovery settings"):
            settings.update({"discovery_min_price":float(min_price),"discovery_min_dollar_volume":float(min_dv),"discovery_max_symbols":int(max_symbols),"discovery_fundamental_age_days":int(age)})
            save_settings(settings); st.success("Discovery settings saved locally."); st.rerun()

    st.markdown('<div class="mf3-section-title">CONNECTION TESTS & STORAGE</div>',unsafe_allow_html=True)
    c1,c2,c3=st.columns(3)
    with c1:
        if st.button("Test Alpaca",width="stretch",disabled=not alpaca_ready()):
            try:
                res=alpaca.test_connection(settings.get("alpaca_feed","auto")); st.success("Alpaca connection passed."); st.json(res)
            except Exception as e: st.error(str(e))
    with c2:
        if st.button("Test IBKR Gateway",width="stretch",disabled=not settings.get("ibkr_enabled",False)):
            res=marketdata.test_ibkr()
            if res.get("ready"): st.success(res.get("detail") or "IBKR Gateway ready")
            else: st.warning(res.get("detail") or res.get("status"))
    with c3:
        if st.button("Cross-check current price",width="stretch",disabled=not ticker or not state.get("price")):
            try:
                bar=state.get("bar") or {}
                check=marketdata.price_cross_check(ticker,state.get("price"),bar.get("trade_date"),bar.get("feed"))
                marketdata.store_price_check(ticker,check)
                if check.get("status")=="PASS": st.success(check.get("message"))
                elif check.get("status")=="FAIL": st.error(check.get("message"))
                else: st.warning(check.get("message"))
                st.rerun()
            except Exception as e: st.error(str(e))
    st.caption(f"Alpaca secrets: {SECRETS_PATH}")
    st.caption(f"Database: {DB_PATH}")
    st.caption("Appearance: top-right ⋮ → Settings → Theme. Both Light and Dark are supported.")

    if ticker:
        st.markdown('<div class="mf3-section-title">CURRENT COMPANY DATA HEALTH</div>',unsafe_allow_html=True)
        ar=state.get("audit") or {}; counts=ar.get("counts") or {}
        last=service.last_successful_refresh(ticker) or {}; attempt=service.last_refresh(ticker) or {}; price_check=marketdata.latest_price_check(ticker)
        a,b,c,d,e=st.columns(5)
        a.metric("Ticker",ticker); b.metric("Last success",_age_label(last.get("completed_at"))); c.metric("Audit PASS",counts.get("PASS",0)); d.metric("WARN / FAIL",f"{counts.get('WARN',0)} / {counts.get('FAIL',0)}"); e.metric("Price check",price_check.get("status") or "NO DATA")
        if price_check.get("sources"):
            with st.expander("Price cross-check detail",expanded=price_check.get("status") in ("WARN","FAIL")):
                ws.display_table(pd.DataFrame([{"Provider":r.get("provider"),"Price":r.get("price"),"As of":r.get("asof"),"Quality":r.get("quality"),"Comparable":r.get("comparable"),"Deviation":r.get("deviation_pct")} for r in price_check.get("sources")]),{"Price":fprice,"Deviation":fpct},height=260)
                st.caption(price_check.get("message") or "")
        if int(counts.get("FAIL",0) or 0)>0: st.error("Data Audit has at least one FAIL. Review Sources & Audit before trusting modeled outputs.")
        elif int(counts.get("WARN",0) or 0)>0: st.warning("Data Audit has warnings. The model can run, but review provenance before a capital decision.")
        else: st.success("No current Data Audit failure detected.")

    st.markdown('<div class="mf3-section-title">ADVANCED DATA CONTROL</div>',unsafe_allow_html=True)
    st.page_link(DETAIL_PATHS["Sources & Audit"],label="Open Sources, Data Audit, SEC provenance, revisions, source log and backups",width="stretch")

