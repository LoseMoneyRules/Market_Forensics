from __future__ import annotations

import re

import requests
from dataclasses import dataclass

from . import alpaca, db, sec
from .config import load_settings


@dataclass(frozen=True)
class SymbolValidation:
    ticker: str
    status: str  # VALID | INVALID | UNAVAILABLE
    source: str
    name: str = ""
    message: str = ""

    @property
    def valid(self) -> bool:
        return self.status == "VALID"


def normalize_ticker(value: str) -> str:
    return str(value or "").strip().upper()


def _syntax_ok(ticker: str) -> bool:
    # Supports ordinary US symbols plus class/share suffixes such as BRK.B / BF-B.
    return bool(re.fullmatch(r"[A-Z0-9][A-Z0-9.\-]{0,11}", ticker or ""))


def validate_ticker(value: str) -> SymbolValidation:
    """Validate a symbol before it can enter a user-maintained list.

    We deliberately distinguish INVALID from UNAVAILABLE. A temporary provider outage must never
    convert an unknown symbol into a silently accepted record. Existing locally-known symbols are
    accepted because they were already resolved by a prior refresh/discovery run.
    """
    t = normalize_ticker(value)
    if not t:
        return SymbolValidation(t, "INVALID", "syntax", message="Ticker is required.")
    if not _syntax_ok(t):
        return SymbolValidation(t, "INVALID", "syntax", message="Symbol format is not recognized.")

    # Already-resolved local records are authoritative enough to avoid unnecessary network calls.
    if db.query("SELECT company_name FROM company_meta WHERE ticker=? LIMIT 1", (t,)):
        row = db.query("SELECT company_name FROM company_meta WHERE ticker=? LIMIT 1", (t,))[0]
        return SymbolValidation(t, "VALID", "local company metadata", name=row.get("company_name") or "")
    if db.query("SELECT ticker FROM discovery_universe WHERE ticker=? LIMIT 1", (t,)):
        return SymbolValidation(t, "VALID", "validated discovery universe")

    errors = []
    # Alpaca's active US-equity master is the preferred list-validation source because it covers
    # operating companies and exchange-traded products that may not behave like SEC Companyfacts issuers.
    try:
        asset = alpaca.get_asset(t)
        if asset and str(asset.get("ticker") or "").upper() == t:
            return SymbolValidation(t, "VALID", "Alpaca asset master", name=asset.get("name") or "")
        errors.append("Alpaca: no active US-equity match")
    except Exception as exc:
        errors.append(f"Alpaca unavailable: {exc}")

    settings = load_settings()
    ua = str(settings.get("sec_user_agent") or "").strip()
    if ua and "@" in ua:
        try:
            hit = sec.resolve_ticker(t, ua)
            return SymbolValidation(t, "VALID", "SEC ticker mapping", name=hit.get("name") or "")
        except sec.SECError as exc:
            # A clean "not found" response is an invalid symbol only if Alpaca also successfully said
            # no match. If Alpaca was unavailable, SEC alone can still establish invalidity for SEC names.
            errors.append(f"SEC: {exc}")
            if "not found in SEC ticker mapping" in str(exc):
                alpaca_no_match = any(x.startswith("Alpaca: no active") for x in errors)
                if alpaca_no_match:
                    return SymbolValidation(t, "INVALID", "Alpaca + SEC", message="Ticker not found / symbol not recognized.")
        except Exception as exc:
            errors.append(f"SEC unavailable: {exc}")

    # Public market-data fallback prevents valid symbols from being blocked just because local API
    # credentials are not configured. A clean Yahoo chart result is validation evidence only; it is
    # not used as a fundamentals source.
    try:
        ysym=t.replace(".","-")
        r=requests.get(f"https://query1.finance.yahoo.com/v8/finance/chart/{ysym}",params={"range":"5d","interval":"1d","events":"div,splits"},headers={"User-Agent":"Mozilla/5.0 MarketForensics/3.1.12"},timeout=10)
        if r.status_code==200:
            chart=(r.json() or {}).get("chart") or {}
            result=chart.get("result") or []
            if result and (result[0].get("meta") or {}).get("symbol"):
                meta=result[0].get("meta") or {}
                return SymbolValidation(t,"VALID","Yahoo market chart",name=meta.get("longName") or meta.get("shortName") or "")
            err=chart.get("error")
            if err:
                errors.append("Yahoo: no symbol match")
        elif r.status_code in (404,422):
            errors.append("Yahoo: no symbol match")
        else:
            errors.append(f"Yahoo unavailable: HTTP {r.status_code}")
    except Exception as exc:
        errors.append(f"Yahoo unavailable: {exc}")

    if any(x.startswith("Alpaca: no active") for x in errors) and any(x.startswith("Yahoo: no symbol") for x in errors):
        return SymbolValidation(t, "INVALID", "Alpaca + Yahoo", message="Ticker not found / symbol not recognized.")
    return SymbolValidation(
        t,
        "UNAVAILABLE",
        "validation providers",
        message="Ticker could not be validated right now, so it was not saved. Check data connections and try again.",
    )
