from __future__ import annotations

from datetime import datetime, timezone
from threading import Lock, Thread
from typing import Iterable

from . import db, service

_LOCK = Lock()
_THREADS: dict[int, Thread] = {}
_RECOVERED = False


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def recover_orphaned_batches() -> None:
    """Mark batches left RUNNING/QUEUED by a previous Python process as interrupted.

    Called once per process. A live batch created by this process is never touched.
    """
    global _RECOVERED
    if _RECOVERED:
        return
    with _LOCK:
        if _RECOVERED:
            return
        stamp = _now()
        db.execute(
            """UPDATE refresh_batches
               SET status='INTERRUPTED', completed_at=?, error_message=COALESCE(error_message,'App/server restarted before refresh completed')
               WHERE status IN ('QUEUED','RUNNING')""",
            (stamp,),
        )
        db.execute(
            """UPDATE refresh_batch_items
               SET status='INTERRUPTED', completed_at=?, error_message=COALESCE(error_message,'App/server restarted before refresh completed')
               WHERE status IN ('QUEUED','RUNNING')""",
            (stamp,),
        )
        _RECOVERED = True


def _normalize_tickers(tickers: Iterable[str]) -> list[str]:
    out: list[str] = []
    seen = set()
    for raw in tickers:
        t = str(raw or '').upper().strip()
        if t and t not in seen:
            seen.add(t)
            out.append(t)
    return out


def active_batch() -> dict | None:
    rows = db.query(
        """SELECT * FROM refresh_batches
           WHERE status IN ('QUEUED','RUNNING')
           ORDER BY id DESC LIMIT 1"""
    )
    return rows[0] if rows else None


def batch_status(batch_id: int | None = None, include_items: bool = True) -> dict | None:
    if batch_id is None:
        rows = db.query("SELECT * FROM refresh_batches ORDER BY id DESC LIMIT 1")
    else:
        rows = db.query("SELECT * FROM refresh_batches WHERE id=?", (int(batch_id),))
    if not rows:
        return None
    out = dict(rows[0])
    if include_items:
        out['items'] = db.query(
            "SELECT * FROM refresh_batch_items WHERE batch_id=? ORDER BY position,ticker",
            (out['id'],),
        )
    return out


def _insert_or_enqueue(active: dict, tickers: list[str], reason: str, include_flow: bool) -> dict:
    batch_id = int(active['id'])
    existing = {r['ticker'] for r in db.query('SELECT ticker FROM refresh_batch_items WHERE batch_id=?', (batch_id,))}
    new = [t for t in tickers if t not in existing]
    if new:
        positions = db.query('SELECT COALESCE(MAX(position),0) AS max_pos FROM refresh_batch_items WHERE batch_id=?', (batch_id,))
        pos = int((positions[0] or {}).get('max_pos') or 0)
        with db.connect() as con:
            for t in new:
                pos += 1
                con.execute(
                    "INSERT OR IGNORE INTO refresh_batch_items(batch_id,ticker,position,status) VALUES(?,?,?,'QUEUED')",
                    (batch_id, t, pos),
                )
            con.execute(
                """UPDATE refresh_batches
                   SET total=(SELECT COUNT(*) FROM refresh_batch_items WHERE batch_id=?),
                       include_flow=CASE WHEN ?=1 THEN 1 ELSE include_flow END,
                       reason=CASE WHEN reason IS NULL OR reason='' THEN ? ELSE reason END
                   WHERE id=?""",
                (batch_id, 1 if include_flow else 0, reason, batch_id),
            )
    return {'batch_id': batch_id, 'started': False, 'enqueued': len(new), 'already_active': True}


def start_or_enqueue(tickers: Iterable[str], reason: str = 'MANUAL', include_flow: bool = True) -> dict:
    """Start a non-blocking refresh batch, or append names to the active batch.

    The worker never calls Streamlit. UI code can safely rerun/navigate while it writes progress to SQLite.
    Only one batch worker runs at a time to keep API pressure predictable.
    """
    recover_orphaned_batches()
    names = _normalize_tickers(tickers)
    if not names:
        return {'batch_id': None, 'started': False, 'enqueued': 0, 'already_active': False}

    with _LOCK:
        active = active_batch()
        if active:
            return _insert_or_enqueue(active, names, reason, include_flow)

        created = _now()
        with db.connect() as con:
            cur = con.execute(
                """INSERT INTO refresh_batches(created_at,reason,include_flow,status,total,completed,passed,failed)
                   VALUES(?,?,?,'QUEUED',?,0,0,0)""",
                (created, reason, 1 if include_flow else 0, len(names)),
            )
            batch_id = int(cur.lastrowid)
            for pos, t in enumerate(names, start=1):
                con.execute(
                    "INSERT INTO refresh_batch_items(batch_id,ticker,position,status) VALUES(?,?,?,'QUEUED')",
                    (batch_id, t, pos),
                )

        th = Thread(target=_run_batch, args=(batch_id,), name=f'MFRefresh-{batch_id}', daemon=True)
        _THREADS[batch_id] = th
        th.start()
        return {'batch_id': batch_id, 'started': True, 'enqueued': len(names), 'already_active': False}


def _next_queued(batch_id: int) -> dict | None:
    rows = db.query(
        """SELECT * FROM refresh_batch_items
           WHERE batch_id=? AND status='QUEUED'
           ORDER BY position,ticker LIMIT 1""",
        (batch_id,),
    )
    return rows[0] if rows else None


def _recount(batch_id: int) -> None:
    counts = db.query(
        """SELECT COUNT(*) AS total,
                  SUM(CASE WHEN status IN ('PASS','PARTIAL','FAIL','INTERRUPTED') THEN 1 ELSE 0 END) AS completed,
                  SUM(CASE WHEN status='PASS' THEN 1 ELSE 0 END) AS passed,
                  SUM(CASE WHEN status='FAIL' THEN 1 ELSE 0 END) AS failed
           FROM refresh_batch_items WHERE batch_id=?""",
        (batch_id,),
    )[0]
    db.execute(
        "UPDATE refresh_batches SET total=?,completed=?,passed=?,failed=? WHERE id=?",
        (
            int(counts.get('total') or 0),
            int(counts.get('completed') or 0),
            int(counts.get('passed') or 0),
            int(counts.get('failed') or 0),
            batch_id,
        ),
    )


def _run_batch(batch_id: int) -> None:
    db.execute("UPDATE refresh_batches SET status='RUNNING',started_at=? WHERE id=?", (_now(), batch_id))
    try:
        while True:
            item = _next_queued(batch_id)
            if not item:
                # Synchronize the "queue is empty" decision with start_or_enqueue so a ticker
                # cannot be appended in the tiny gap between the final check and batch close.
                with _LOCK:
                    item = _next_queued(batch_id)
                    if not item:
                        _recount(batch_id)
                        final = batch_status(batch_id, include_items=False) or {}
                        total = int(final.get('total') or 0)
                        passed = int(final.get('passed') or 0)
                        failed = int(final.get('failed') or 0)
                        status = 'PASS' if total and passed == total else 'FAIL' if total and failed == total else 'PARTIAL'
                        db.execute(
                            "UPDATE refresh_batches SET status=?,completed_at=?,current_ticker=NULL WHERE id=?",
                            (status, _now(), batch_id),
                        )
                        break
            if not item:
                break
            t = item['ticker']
            db.execute(
                "UPDATE refresh_batches SET current_ticker=? WHERE id=?",
                (t, batch_id),
            )
            db.execute(
                "UPDATE refresh_batch_items SET status='RUNNING',started_at=?,error_message=NULL WHERE batch_id=? AND ticker=?",
                (_now(), batch_id, t),
            )
            try:
                batch = batch_status(batch_id, include_items=False) or {}
                include_flow = bool(int(batch.get('include_flow') or 0))
                result = service.refresh_core(t, include_flow=include_flow)
                item_status = 'PARTIAL' if str(result.get('status') or '').upper() == 'PARTIAL' else 'PASS'
                item_error = ' | '.join(result.get('warnings') or [])[:1000] if item_status == 'PARTIAL' else None
                db.execute(
                    "UPDATE refresh_batch_items SET status=?,completed_at=?,error_message=? WHERE batch_id=? AND ticker=?",
                    (item_status, _now(), item_error, batch_id, t),
                )
            except Exception as exc:
                db.execute(
                    """UPDATE refresh_batch_items
                       SET status='FAIL',completed_at=?,error_message=?
                       WHERE batch_id=? AND ticker=?""",
                    (_now(), str(exc)[:1000], batch_id, t),
                )
            _recount(batch_id)

    except Exception as exc:
        db.execute(
            "UPDATE refresh_batches SET status='FAIL',completed_at=?,error_message=?,current_ticker=NULL WHERE id=?",
            (_now(), str(exc)[:1000], batch_id),
        )
    finally:
        with _LOCK:
            _THREADS.pop(batch_id, None)


def stale_tickers(max_age_hours: float = 24.0, include_archived: bool = False) -> list[str]:
    rows = db.list_coverage(include_archived=include_archived)
    out: list[str] = []
    now = datetime.now(timezone.utc)
    for r in rows:
        t = r['ticker']
        last = service.last_successful_refresh(t)
        stamp = (last or {}).get('completed_at')
        if not stamp:
            out.append(t)
            continue
        try:
            dt = datetime.fromisoformat(str(stamp).replace('Z', '+00:00'))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            if (now - dt).total_seconds() > float(max_age_hours) * 3600:
                out.append(t)
        except Exception:
            out.append(t)
    return out
