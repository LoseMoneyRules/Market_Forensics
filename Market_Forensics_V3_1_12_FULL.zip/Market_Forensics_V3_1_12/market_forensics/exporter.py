from __future__ import annotations

import html
import json
import math
from io import BytesIO
from datetime import datetime, timezone

from . import db, service, fundamentals, opportunity, valuation
from .config import load_settings
from .ui import fmoney, fpct, fprice, fnum


def ticker_dossier(ticker: str, assumptions: dict, gates: list[dict]):
    t=ticker.upper()
    return {
        "ticker":t,
        "coverage":db.coverage_row(t),
        "company_meta":db.query("SELECT * FROM company_meta WHERE ticker=?",(t,)),
        "fundamentals":db.query("SELECT * FROM fundamentals WHERE ticker=? ORDER BY fiscal_year",(t,)),
        "sec_provenance":db.query("SELECT * FROM sec_provenance WHERE ticker=? ORDER BY metric",(t,)),
        "sec_revisions":db.query("SELECT * FROM sec_revisions WHERE ticker=? ORDER BY period_end DESC",(t,)),
        "valuation_assumptions":assumptions,
        "research":db.load_research(t),
        "investment_gates":gates,
        "monitoring_kpis":db.query("SELECT * FROM monitoring_kpis WHERE ticker=? ORDER BY importance DESC,id",(t,)),
        "events":db.query("SELECT * FROM events WHERE ticker=? ORDER BY event_date",(t,)),
        "short_interest":db.query("SELECT * FROM short_interest WHERE ticker=? ORDER BY publication_date",(t,)),
        "decision_journal":db.query("SELECT * FROM decision_journal WHERE ticker=? ORDER BY id",(t,)),
        "source_log":db.query("SELECT * FROM source_log WHERE ticker=? ORDER BY id",(t,)),
        "refresh_runs":db.query("SELECT * FROM refresh_runs WHERE ticker=? ORDER BY id DESC LIMIT 20",(t,)),
        "metric_snapshots":service.snapshot_history(t,20),
        "filing_documents":db.query("SELECT * FROM filing_documents WHERE ticker=? ORDER BY filed DESC, accession DESC, document_type, source_url",(t,)),
        "management_statements":db.query("SELECT * FROM management_statements WHERE ticker=? ORDER BY filed DESC,id DESC",(t,)),
        "forecast_assumptions":db.load_forecast_assumptions(t),
        "variant_case":db.load_variant_case(t),
        "peer_links":db.peer_links(t),
        "discovery":db.discovery_row(t),
    }


def dossier_json(ticker: str, assumptions: dict, gates: list[dict]):
    return json.dumps(ticker_dossier(ticker,assumptions,gates),indent=2,default=str).encode("utf-8")


def _clip(text, n=320):
    text = " ".join(str(text or "").replace("\n", " ").split())
    if not text:
        return "Not defined yet."
    return text if len(text) <= n else text[:n-1].rstrip() + "..."


def _xml(text, n=None):
    value=_clip(text,n) if n else str(text or "")
    return html.escape(value, quote=False)


def _money(x):
    mode=load_settings().get("number_display","AUTO")
    return fmoney(x, mode=mode)


def _compact_num(x):
    if not _finite(x):
        return "—"
    x=float(x); a=abs(x)
    if a>=1e12:return f"{x/1e12:.2f}T"
    if a>=1e9:return f"{x/1e9:.2f}B"
    if a>=1e6:return f"{x/1e6:.1f}M"
    if a>=1e3:return f"{x/1e3:.1f}K"
    return f"{x:,.0f}"


def _finite(x):
    try:
        return x is not None and math.isfinite(float(x))
    except Exception:
        return False


def _safe_div(a,b):
    if not (_finite(a) and _finite(b)) or float(b)==0:
        return None
    return float(a)/float(b)


def _value_tape(state):
    price=state.get("price"); base=state.get("base_value"); upside=state.get("upside")
    scores=state.get("scores") or {}
    if price in (None,0) or base is None or not scores:
        return "LOW DATA"
    cheap=upside is not None and upside>=0.15
    expensive=upside is not None and upside<=-0.15
    supportive=float(scores.get("Net Tape") or 0)>=60 and float(scores.get("Absorption") or 0)>=55
    weak=float(scores.get("Net Tape") or 50)<45 or float(scores.get("Price Resilience") or 50)<45
    if cheap and supportive:return "VALUE + SUPPORTIVE TAPE"
    if cheap and weak:return "VALUE UNDER PRESSURE"
    if expensive and weak:return "EXPENSIVE + WEAK TAPE"
    if expensive and supportive:return "EXPENSIVE BUT SUPPORTED"
    return "MIXED / WAIT FOR CONVERGENCE"


def _financial_history(state: dict, max_years=5):
    rows=state.get("fund_rows") or []
    fys=sorted([r for r in rows if r.get("period_type")=="FY" and r.get("fiscal_year")],key=lambda r:int(r["fiscal_year"]))[-max_years:]
    ttm=next((r for r in rows if r.get("period_type")=="TTM"),None)
    seq=fys + ([ttm] if ttm else [])
    out=[]; prev_rev=None
    for r in seq:
        rev=r.get("revenue")
        growth=(float(rev)/float(prev_rev)-1) if _finite(rev) and _finite(prev_rev) and float(prev_rev)!=0 else None
        out.append({
            "period": "TTM" if r.get("period_type")=="TTM" else str(r.get("fiscal_year")),
            "revenue": rev,
            "growth": growth,
            "gross_margin": _safe_div(r.get("gross_profit"),rev),
            "operating_margin": _safe_div(r.get("operating_income"),rev),
            "net_margin": _safe_div(r.get("net_income"),rev),
            "fcf": r.get("fcf"),
            "fcf_margin": _safe_div(r.get("fcf"),rev),
            "inventory_rev": _safe_div(r.get("inventory"),rev),
            "receivables_rev": _safe_div(r.get("receivables"),rev),
            "shares": r.get("diluted_shares"),
        })
        if r.get("period_type")=="FY" and _finite(rev): prev_rev=rev
    return out


def research_report_payload(ticker: str, state: dict):
    t=ticker.upper()
    meta=(state.get("snap",{}).get("meta") or [{}])[0]
    cov=state.get("coverage") or {}
    research=db.load_research(t)
    variant_case=state.get("variant_case") or db.load_variant_case(t) or {}
    tri=state.get("triangulation") or {}
    metrics=state.get("metrics") or {}
    scores=state.get("scores") or {}
    scenarios=state.get("scenarios") or {}
    counts=state.get("gate_counts") or {}
    gates=state.get("gates") or []
    blockers=[r.get("gate") for r in gates if r.get("status") in ("FAIL","INCOMPLETE","WATCH")]
    fscore,_=fundamentals.fundamental_score(metrics) if metrics else (None,{})
    last=service.last_successful_refresh(t) or {}
    vc=state.get("valuation_confidence") or {}
    fs=state.get("forensics") or {}
    opp=opportunity.evaluate(state,last)
    assumptions=state.get("assumptions") or {}
    calibration=state.get("calibration") or {}
    regime=state.get("valuation_regime") or {}
    current_mult=valuation.current_multiples(metrics,state.get("price"))
    audit=state.get("audit") or {"counts":{}}
    next_evt=db.query("SELECT event_date,title,event_type FROM events WHERE ticker=? AND event_date>=date('now') ORDER BY event_date LIMIT 1",(t,))
    top_kpis=db.query("SELECT name,linked_to,importance,locked FROM monitoring_kpis WHERE ticker=? ORDER BY importance DESC,id LIMIT 5",(t,))
    short=(state.get("snap") or {}).get("short") or {}
    flow=(state.get("snap") or {}).get("flow") or {}
    latest_si=(state.get("snap") or {}).get("latest_si") or {}
    pos=[f"{x.get('Signal')}: {x.get('Evidence')}" for x in fs.get("positives",[])[:4]]
    neg=[f"{x.get('Signal')}: {x.get('Evidence')}" for x in fs.get("negatives",[])[:4]]
    data=[f"{x.get('Signal')}: {x.get('Evidence')}" for x in fs.get("data_alerts",[])[:3]]
    scenario_rows=[]
    for name in ("bear","base","bull"):
        a=assumptions.get(name,{})
        s=scenarios.get(name,{})
        scenario_rows.append({
            "case":name.title(),"prob":a.get("prob"),"growth":a.get("growth"),"net_margin":a.get("net_margin"),
            "fcf_margin":a.get("fcf_margin"),"pe":a.get("pe"),"ev_sales":a.get("ev_sales"),
            "fcf_yield":a.get("target_fcf_yield"),"wacc":a.get("wacc"),"terminal_growth":a.get("terminal_growth"),
            "fair_value":s.get("fair_value"),"dcf":s.get("dcf"),"pe_value":s.get("pe"),
            "ev_sales_value":s.get("ev_sales"),"fcf_yield_value":s.get("fcf_yield"),
        })
    hist_rows=[]
    for key,label,inverse in (("pe","P/E",False),("ev_sales","EV/Sales",False),("fcf_yield","FCF Yield",True)):
        h=calibration.get(key) or {}
        rr=next((r for r in regime.get("rows",[]) if r.get("key")==key),{})
        hist_rows.append({
            "metric":label,"current":current_mult.get(key),"p25":h.get("p25"),"median":h.get("median"),"p75":h.get("p75"),
            "n":h.get("n",0),"severity":rr.get("severity") or "-","interpretation":rr.get("interpretation") or "-","inverse":inverse,
        })
    mg=state.get("management") or {}
    qv=state.get("quality_validation") or {}
    fpack=state.get("forecast_scenarios") or {}
    prec=state.get("price_reconciliation") or {}
    mg_rows=[]
    for r in (mg.get("rows") or []):
        if r.get("target_low") is None or not r.get("target_fiscal_year") or not r.get("score_eligible"):
            continue
        mg_rows.append({
            "filed":r.get("filed"),"metric":r.get("metric_key"),"fy":r.get("target_fiscal_year"),
            "low":r.get("target_low"),"high":r.get("target_high"),"unit":r.get("unit"),
            "actual":r.get("actual_value"),"status":r.get("validation_status"),"statement":r.get("statement"),
        })
        if len(mg_rows)>=8: break
    base_forecast=(fpack.get("base") or {}).get("rows") or []
    quality_checks=[{"name":x.get("name"),"status":x.get("status"),"reason":x.get("reason")} for x in (qv.get("checks") or [])]
    return {
        "ticker":t,"company":meta.get("company_name") or t,"exchange":meta.get("exchange") or "",
        "date":datetime.now(timezone.utc).strftime("%Y-%m-%d"),"status":cov.get("status","RESEARCH"),
        "portfolio":cov.get("portfolio_state","NO POSITION"),"company_type":cov.get("company_type","Generic"),
        "price":state.get("price"),"bear":scenarios.get("bear",{}).get("fair_value"),
        "base":scenarios.get("base",{}).get("fair_value"),"bull":scenarios.get("bull",{}).get("fair_value"),
        "expected_value":state.get("expected_value"),"upside":state.get("upside"),"fundamental_score":fscore,
        "net_tape":scores.get("Net Tape"),"confidence":scores.get("Confidence"),"long_demand":scores.get("Long Demand"),
        "short_pressure":scores.get("Short Pressure"),"absorption":scores.get("Absorption"),"price_resilience":scores.get("Price Resilience"),
        "valuation_confidence":vc.get("label","LOW"),"valuation_confidence_score":vc.get("score"),"valuation_confidence_reasons":vc.get("reasons") or [],
        "regime":scores.get("Regime") or "LOW DATA","rank":scores.get("Rank") or "-",
        "decision_readiness":state.get("gate_label") or "RESEARCH INCOMPLETE","gates_pass":counts.get("PASS",0),"missing_gates":blockers,
        "value_tape":_value_tape(state),"coverage_focus":opp.get("focus"),"coverage_setup":opp.get("setup"),
        "system_priority":opp.get("system_priority"),"long_score":opp.get("long_score"),"short_score":opp.get("short_score"),
        "next_action":opp.get("next_action"),"revenue":metrics.get("revenue"),"fcf":metrics.get("fcf"),
        "gross_margin":metrics.get("gross_margin"),"operating_margin":metrics.get("operating_margin"),"net_margin":metrics.get("net_margin"),
        "fcf_margin":metrics.get("fcf_margin"),"roic":metrics.get("roic"),"ccc":metrics.get("ccc"),"net_debt":metrics.get("net_debt"),
        "dso":metrics.get("dso"),"dio":metrics.get("dio"),"dpo":metrics.get("dpo"),"share_change":metrics.get("share_change"),
        "share_basis_source":metrics.get("valuation_share_source"),"share_basis_status":metrics.get("valuation_share_basis_status"),"share_basis_confidence":metrics.get("valuation_share_confidence"),
        "share_basis_raw":metrics.get("valuation_share_raw"),"share_basis_fact_date":metrics.get("valuation_share_fact_date"),"share_basis_filed_date":metrics.get("valuation_share_filed_date"),
        "share_basis_factor":metrics.get("valuation_split_factor"),"share_basis_actions":metrics.get("corporate_actions_since_share_fact"),"share_basis_normalized":metrics.get("valuation_shares"),
        "share_basis_corporate":metrics.get("corporate_action_basis"),"share_basis_issue":metrics.get("valuation_basis_issue"),"current_price_date":metrics.get("current_price_date"),
        "current_price_source":metrics.get("current_price_source"),"raw_historical_price":metrics.get("latest_raw_close"),
        "split_adjusted_historical_price":metrics.get("latest_split_adjusted_close"),"current_price_split_factor":metrics.get("current_price_split_factor"),
        "historical_price_basis_verified":metrics.get("historical_price_basis_verified"),"split_ledger_verified":metrics.get("split_ledger_verified"),
        "thesis":research.get("thesis_title") or research.get("key_evidence") or "Not defined yet.",
        "business":research.get("business_notes") or "Not defined yet.",
        "variant":((f"Market: {variant_case.get('market_belief')} | We: {variant_case.get('our_belief')} | Resolve: {variant_case.get('resolution_signal')}" if (variant_case.get('market_belief') or variant_case.get('our_belief')) else research.get("variant_view")) or "Not defined yet."),
        "triangulation_summary":tri.get("summary") or "LOW DATA",
        "triangulation_score":tri.get("score"),
        "triangulation_signals":tri.get("signals") or [],
        "peer_tickers":[x.get("ticker") for x in (tri.get("peers") or []) if x.get("ticker")],
        "catalysts":research.get("catalysts") or "Not defined yet.","risk":research.get("primary_risk") or "Not defined yet.",
        "invalidation":research.get("invalidation") or "Not defined yet.","evidence_to_add":research.get("evidence_to_add") or "Not defined yet.",
        "forensic_positive":pos,"forensic_negative":neg,"forensic_data":data,"bars":state.get("bars") or [],
        "financial_history":_financial_history(state),"scenario_rows":scenario_rows,"historical_valuation":hist_rows,
        "audit_counts":audit.get("counts") or {},"sec_revision_count":len(db.query("SELECT 1 FROM sec_revisions WHERE ticker=?",(t,))),
        "last_refresh":last.get("completed_at") or last.get("started_at") or "Never","market_feed":last.get("market_feed") or (state.get("bar") or {}).get("feed") or "-",
        "flow_feed":last.get("flow_feed") or flow.get("feed") or "-","short_pct":short.get("short_pct"),"latest_si":latest_si.get("shares_short"),
        "si_change":(state.get("snap") or {}).get("si_change"),"net_large":flow.get("net_large"),"net_whale":flow.get("net_whale"),
        "next_event":next_evt[0] if next_evt else None,"top_kpis":top_kpis,
        "management_label":mg.get("label","LOW DATA"),"management_score":mg.get("score"),"management_scorable":mg.get("scorable",0),
        "management_met":mg.get("met",0),"management_missed":mg.get("missed",0),"management_rows":mg_rows,
        "quality_label":qv.get("label","LOW DATA"),"quality_score":qv.get("score"),"quality_checks":quality_checks,
        "base_forecast":base_forecast,"forecast_bear":(fpack.get("bear") or {}).get("rows") or [],"forecast_bull":(fpack.get("bull") or {}).get("rows") or [],
        "forecast_base_cagr":(fpack.get("base") or {}).get("expected_cagr"),"forecast_base_pv":(fpack.get("base") or {}).get("present_value"),
        "price_reconciliation":prec,
    }


def _price_chart_png(p: dict, width=8.2, height=2.55):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    from datetime import datetime as _dt
    bars=(p.get("bars") or [])[-260:]
    fig,ax=plt.subplots(figsize=(width,height),dpi=150)
    fig.patch.set_facecolor("white"); ax.set_facecolor("white")
    xs=[]; ys=[]
    for b in bars:
        try:
            xs.append(_dt.fromisoformat(str(b.get("trade_date") or b.get("date"))[:10])); ys.append(float(b.get("close")))
        except Exception: pass
    if xs:
        ax.plot(xs,ys,color="#17365D",linewidth=1.7,label="Price")
        levels=[("Bear",p.get("bear"),"#B94A48","--"),("Base",p.get("base"),"#1F8AAE","-"),("Bull",p.get("bull"),"#2E8B57","--")]
        for label,val,color,ls in levels:
            if _finite(val): ax.axhline(float(val),color=color,linewidth=1.0,linestyle=ls,label=f"{label} {fprice(val)}")
        if _finite(p.get("bear")) and _finite(p.get("bull")):
            ax.fill_between(xs,float(p["bear"]),float(p["bull"]),color="#DDEBF7",alpha=.22)
        ax.xaxis.set_major_locator(mdates.AutoDateLocator(minticks=4,maxticks=7)); ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %y"))
        ax.legend(loc="upper left",fontsize=6.5,ncol=4,frameon=False)
    else:
        ax.text(.5,.5,"Insufficient price history",ha="center",va="center",transform=ax.transAxes,color="#5E6B78")
    ax.set_title("Price history vs current scenario fair values",loc="left",fontsize=9,fontweight="bold",color="#0B1628")
    ax.grid(axis="y",alpha=.18,linewidth=.5); ax.spines[["top","right","left"]].set_visible(False); ax.tick_params(axis="both",labelsize=6.5,colors="#5E6B78")
    ax.set_ylabel("USD",fontsize=6.5,color="#5E6B78")
    fig.tight_layout(pad=.8)
    bio=BytesIO(); fig.savefig(bio,format="png",bbox_inches="tight",facecolor="white"); plt.close(fig); bio.seek(0); return bio


def _fundamental_chart_png(p: dict, width=8.2, height=2.25):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    hist=p.get("financial_history") or []
    fig,ax1=plt.subplots(figsize=(width,height),dpi=150)
    fig.patch.set_facecolor("white"); ax1.set_facecolor("white")
    labels=[x["period"] for x in hist]
    rev=[float(x["revenue"])/1e9 if _finite(x.get("revenue")) else 0 for x in hist]
    fcfm=[float(x["fcf_margin"])*100 if _finite(x.get("fcf_margin")) else float("nan") for x in hist]
    if labels:
        xs=list(range(len(labels)))
        ax1.bar(xs,rev,color="#DDEBF7",edgecolor="#7EA6C8",linewidth=.5,label="Revenue ($B)")
        ax1.set_xticks(xs,labels); ax1.set_ylabel("Revenue ($B)",fontsize=6.5,color="#5E6B78")
        ax2=ax1.twinx(); ax2.plot(xs,fcfm,color="#17365D",marker="o",linewidth=1.5,markersize=3,label="FCF margin")
        ax2.set_ylabel("FCF margin",fontsize=6.5,color="#5E6B78"); ax2.tick_params(axis="y",labelsize=6.5,colors="#5E6B78")
        ax2.spines[["top","left"]].set_visible(False)
        lines,labels1=ax1.get_legend_handles_labels(); lines2,labels2=ax2.get_legend_handles_labels(); ax1.legend(lines+lines2,labels1+labels2,loc="upper left",fontsize=6.5,frameon=False,ncol=2)
    else:
        ax1.text(.5,.5,"Insufficient fundamental history",ha="center",va="center",transform=ax1.transAxes,color="#5E6B78")
    ax1.set_title("Revenue and free-cash-flow margin",loc="left",fontsize=9,fontweight="bold",color="#0B1628")
    ax1.grid(axis="y",alpha=.18,linewidth=.5); ax1.spines[["top","right","left"]].set_visible(False); ax1.tick_params(axis="both",labelsize=6.5,colors="#5E6B78")
    fig.tight_layout(pad=.8)
    bio=BytesIO(); fig.savefig(bio,format="png",bbox_inches="tight",facecolor="white"); plt.close(fig); bio.seek(0); return bio



def _forecast_chart_png(p: dict, width=8.2, height=2.35):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(width,height),dpi=150)
    fig.patch.set_facecolor("white"); ax.set_facecolor("white")
    styles=[("Bear",p.get("forecast_bear") or [],"--"),("Base",p.get("base_forecast") or [],"-"),("Bull",p.get("forecast_bull") or [],"--")]
    colors_map={"Bear":"#B94A48","Base":"#17365D","Bull":"#2E8B57"}
    any_data=False
    for name,rows,ls in styles:
        if not rows: continue
        xs=[int(r.get("year") or 0) for r in rows]; ys=[float(r.get("revenue") or 0)/1e9 for r in rows]
        ax.plot(xs,ys,marker="o",linewidth=1.5,markersize=3,label=name,color=colors_map[name],linestyle=ls); any_data=True
    if any_data:
        ax.legend(loc="upper left",fontsize=6.5,frameon=False,ncol=3); ax.set_xticks(sorted({int(r.get("year") or 0) for rows in [p.get("forecast_bear") or [],p.get("base_forecast") or [],p.get("forecast_bull") or []] for r in rows}))
    else:
        ax.text(.5,.5,"Forecast unavailable",ha="center",va="center",transform=ax.transAxes,color="#5E6B78")
    ax.set_title("Five-year revenue scenarios",loc="left",fontsize=9,fontweight="bold",color="#0B1628")
    ax.set_xlabel("Forecast year",fontsize=6.5,color="#5E6B78"); ax.set_ylabel("Revenue ($B)",fontsize=6.5,color="#5E6B78")
    ax.grid(axis="y",alpha=.18,linewidth=.5); ax.spines[["top","right","left"]].set_visible(False); ax.tick_params(axis="both",labelsize=6.5,colors="#5E6B78")
    fig.tight_layout(pad=.8); bio=BytesIO(); fig.savefig(bio,format="png",bbox_inches="tight",facecolor="white"); plt.close(fig); bio.seek(0); return bio

def _promise_fmt(row: dict, key: str):
    v=row.get(key); unit=row.get("unit")
    if not _finite(v): return "—"
    if unit in {"ratio","ratio_change"}: return fpct(v)
    if unit=="USD_per_share": return fprice(v)
    return _money(v)






# Backward-compatible aliases for older callers/tests.
def one_page_payload(ticker: str, state: dict):
    return research_report_payload(ticker,state)

def one_page_docx(ticker: str, state: dict):
    return research_report_docx(ticker,state)

def one_page_pdf(ticker: str, state: dict):
    return research_report_pdf(ticker,state)


def discovery_report_payload(limit: int = 15):
    """Compact printable snapshot of the latest Discovery universe."""
    rows=[dict(r) for r in db.query("SELECT * FROM discovery_universe")]
    run_rows=db.query("SELECT * FROM discovery_runs ORDER BY id DESC LIMIT 1")
    run=dict(run_rows[0]) if run_rows else {}
    long_lenses={"QUALITY AT DISCOUNT","FUNDAMENTAL INFLECTION","LONG DISLOCATION"}
    short_lenses={"POTENTIAL SHORT","SHORT DISLOCATION","VALUE TRAP","FORENSIC DIVERGENCE"}
    longs=sorted([r for r in rows if r.get("lens") in long_lenses], key=lambda r:(int(r.get("system_priority") or 5),-float(r.get("long_score") or 0)))[:limit]
    shorts=sorted([r for r in rows if r.get("lens") in short_lenses], key=lambda r:(int(r.get("system_priority") or 5),-float(r.get("short_score") or 0)))[:limit]
    review=sorted([r for r in rows if r.get("lens") not in long_lenses|short_lenses and r.get("lens") not in (None,"NO EDGE")], key=lambda r:(int(r.get("system_priority") or 5),-max(float(r.get("long_score") or 0),float(r.get("short_score") or 0))))[:10]
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "run": run,
        "universe_count": len(rows),
        "long_count": sum(1 for r in rows if r.get("lens") in long_lenses),
        "short_count": sum(1 for r in rows if r.get("lens") in short_lenses),
        "review_count": sum(1 for r in rows if r.get("lens") not in long_lenses|short_lenses and r.get("lens") not in (None,"NO EDGE")),
        "longs": longs,
        "shorts": shorts,
        "review": review,
    }


def _discovery_bar_png(rows: list[dict], score_key: str, title_text: str, width=8.2, height=2.45):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    data=list(rows or [])[:10]
    fig,ax=plt.subplots(figsize=(width,height),dpi=150)
    fig.patch.set_facecolor("white"); ax.set_facecolor("white")
    if data:
        data=list(reversed(data))
        labels=[str(x.get("ticker") or "") for x in data]
        vals=[float(x.get(score_key) or 0) for x in data]
        ax.barh(labels,vals,color="#DDEBF7",edgecolor="#7EA6C8",linewidth=.6)
        ax.set_xlim(0,100)
        for y,v in enumerate(vals):
            ax.text(min(v+1,97),y,f"{v:.0f}",va="center",fontsize=6.4,color="#17365D")
    else:
        ax.text(.5,.5,"No material candidates in the latest scan",ha="center",va="center",transform=ax.transAxes,color="#5E6B78")
        ax.set_xlim(0,100)
    ax.set_title(title_text,loc="left",fontsize=9,fontweight="bold",color="#0B1628")
    ax.grid(axis="x",alpha=.16,linewidth=.5); ax.spines[["top","right","left"]].set_visible(False); ax.tick_params(axis="both",labelsize=6.5,colors="#5E6B78")
    ax.set_xlabel("Opportunity score (ranking aid, not probability)",fontsize=6.2,color="#5E6B78")
    fig.tight_layout(pad=.8)
    bio=BytesIO(); fig.savefig(bio,format="png",bbox_inches="tight",facecolor="white"); plt.close(fig); bio.seek(0); return bio



# ---------------------------------------------------------------------------
# V3.1.2 institutional report layout overrides
# ---------------------------------------------------------------------------

def _branding_logo():
    try:
        from .config import branding_logo_path
        return branding_logo_path()
    except Exception:
        return None


def research_report_docx(ticker: str, state: dict):
    """Four-page institutional research report with larger, readable tables."""
    from docx import Document
    from docx.shared import Inches, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    p = research_report_payload(ticker, state)
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Inches(.48); sec.bottom_margin = Inches(.48)
    sec.left_margin = Inches(.52); sec.right_margin = Inches(.52)
    styles = doc.styles
    styles['Normal'].font.name = 'Arial'; styles['Normal'].font.size = Pt(9.2)
    styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), 'Arial')

    NAVY='11263A'; BLUE='2F618C'; STEEL='567B9B'; PALE='EEF3F7'; LIGHT='F7F9FB'
    LINE='C5D0D9'; DARK='172431'; MUTED='65727E'; WHITE='FFFFFF'; GREEN='1E875E'; RED='C44E4E'; AMBER='B98522'

    def shade(cell, fill):
        tcPr=cell._tc.get_or_add_tcPr(); shd=tcPr.find(qn('w:shd'))
        if shd is None: shd=OxmlElement('w:shd'); tcPr.append(shd)
        shd.set(qn('w:fill'), fill)

    def borders(cell, color=LINE, size='7'):
        tcPr=cell._tc.get_or_add_tcPr(); tcBorders=tcPr.first_child_found_in('w:tcBorders')
        if tcBorders is None: tcBorders=OxmlElement('w:tcBorders'); tcPr.append(tcBorders)
        for edge in ('top','left','bottom','right','insideH','insideV'):
            tag=qn(f'w:{edge}'); el=tcBorders.find(tag)
            if el is None: el=OxmlElement(f'w:{edge}'); tcBorders.append(el)
            el.set(qn('w:val'),'single'); el.set(qn('w:sz'),size); el.set(qn('w:color'),color)

    def margins(cell, top=75, start=85, bottom=75, end=85):
        tcPr=cell._tc.get_or_add_tcPr(); tcMar=tcPr.first_child_found_in('w:tcMar')
        if tcMar is None: tcMar=OxmlElement('w:tcMar'); tcPr.append(tcMar)
        for name,val in [('top',top),('start',start),('bottom',bottom),('end',end)]:
            node=tcMar.find(qn(f'w:{name}'))
            if node is None: node=OxmlElement(f'w:{name}'); tcMar.append(node)
            node.set(qn('w:w'),str(val)); node.set(qn('w:type'),'dxa')

    def set_cell(cell, text, size=8.1, bold=False, color=DARK, bg=None, align=WD_ALIGN_PARAGRAPH.LEFT):
        cell.text=''; para=cell.paragraphs[0]; para.paragraph_format.space_after=Pt(0); para.alignment=align
        r=para.add_run(str(text)); r.bold=bold; r.font.name='Arial'; r.font.size=Pt(size); r.font.color.rgb=RGBColor.from_string(color)
        cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
        margins(cell); borders(cell)
        if bg: shade(cell,bg)

    def width_table(table, widths):
        table.autofit=False
        for i,w in enumerate(widths):
            for cell in table.columns[i].cells: cell.width=Inches(w)

    def section_title(text):
        q=doc.add_paragraph(); q.paragraph_format.space_before=Pt(8); q.paragraph_format.space_after=Pt(3)
        r=q.add_run(text.upper()); r.bold=True; r.font.size=Pt(8.8); r.font.color.rgb=RGBColor.from_string(BLUE)

    def metric_cell(cell, label, value, detail=''):
        cell.text=''; margins(cell,80,95,75,95); borders(cell); shade(cell,LIGHT)
        q=cell.paragraphs[0]; q.paragraph_format.space_after=Pt(0)
        r=q.add_run(label.upper()); r.bold=True; r.font.size=Pt(7.4); r.font.color.rgb=RGBColor.from_string(MUTED)
        q2=cell.add_paragraph(); q2.paragraph_format.space_after=Pt(0)
        r=q2.add_run(str(value)); r.bold=True; r.font.size=Pt(12); r.font.color.rgb=RGBColor.from_string(DARK)
        if detail:
            q3=cell.add_paragraph(); q3.paragraph_format.space_after=Pt(0)
            r=q3.add_run(str(detail)); r.font.size=Pt(7.6); r.font.color.rgb=RGBColor.from_string(MUTED)

    def header(label):
        t=doc.add_table(rows=1, cols=2); width_table(t,[1.05,6.40])
        c0,c1=t.rows[0].cells
        logo=_branding_logo()
        c0.text=''; q=c0.paragraphs[0]; q.alignment=WD_ALIGN_PARAGRAPH.CENTER
        if logo:
            q.add_run().add_picture(str(logo), width=Inches(.78))
        else:
            rr=q.add_run('MF'); rr.bold=True; rr.font.size=Pt(15); rr.font.color.rgb=RGBColor.from_string(WHITE); shade(c0,NAVY)
        margins(c0,70,70,70,70); borders(c0,NAVY)
        c1.text=''; margins(c1,65,90,60,90); borders(c1)
        q=c1.paragraphs[0]; q.paragraph_format.space_after=Pt(0)
        r=q.add_run('MARKET FORENSICS'); r.bold=True; r.font.size=Pt(12.5); r.font.color.rgb=RGBColor.from_string(NAVY)
        r=q.add_run(f'   |   {label}'); r.font.size=Pt(9); r.font.color.rgb=RGBColor.from_string(BLUE)
        q2=c1.add_paragraph(); q2.paragraph_format.space_after=Pt(0)
        rr=q2.add_run(f"{p['date']}  |  Internal decision support  |  Last refresh {p['last_refresh']}"); rr.font.size=Pt(7); rr.font.color.rgb=RGBColor.from_string(MUTED)

    # document footer: only requested brand line
    fq=sec.footer.paragraphs[0]; fq.alignment=WD_ALIGN_PARAGRAPH.CENTER
    fr=fq.add_run('Lose Money Rules'); fr.font.name='Arial'; fr.font.size=Pt(7); fr.font.color.rgb=RGBColor.from_string(MUTED)

    # PAGE 1 - Executive investment view
    header('INVESTMENT VIEW')
    q=doc.add_paragraph(); q.paragraph_format.space_before=Pt(8); q.paragraph_format.space_after=Pt(2)
    r=q.add_run(p['ticker']); r.bold=True; r.font.size=Pt(23); r.font.color.rgb=RGBColor.from_string(NAVY)
    r=q.add_run(f"   {p['company']}"); r.font.size=Pt(12); r.font.color.rgb=RGBColor.from_string(MUTED)
    q2=doc.add_paragraph(); q2.paragraph_format.space_after=Pt(6)
    rr=q2.add_run(f"P{p['system_priority']} {p['coverage_focus']}   |   {p['coverage_setup']}   |   {p['status']}   |   {p['portfolio']}"); rr.bold=True; rr.font.size=Pt(9); rr.font.color.rgb=RGBColor.from_string(BLUE)

    t=doc.add_table(rows=2,cols=4); width_table(t,[1.86]*4)
    metrics=[('Price',fprice(p['price']),f"Base gap {fpct(p['upside'])}"),('Base Target',fprice(p['base']),f"Expected value {fprice(p['expected_value'])}"),('Bear / Bull',f"{fprice(p['bear'])} / {fprice(p['bull'])}",'Scenario range'),('Valuation Confidence',f"{p['valuation_confidence']} {fnum(p['valuation_confidence_score'],0)}/100",'Model reliability'),('Fundamental',f"{fnum(p['fundamental_score'],2)}/5",'Business consistency'),('Tape',f"{fnum(p['net_tape'],0)} / 100",p['regime']),('Decision Readiness',f"{p['gates_pass']}/16",p['decision_readiness']),('System Scores',f"L {fnum(p['long_score'],0)} / S {fnum(p['short_score'],0)}",_clip(p['next_action'],55))]
    for c,(lab,val,det) in zip([c for row in t.rows for c in row.cells],metrics): metric_cell(c,lab,val,det)

    doc.add_picture(_price_chart_png(p,width=8.2,height=2.7),width=Inches(7.35))
    section_title('Investment thesis and disagreement')
    tv=doc.add_table(rows=1,cols=2); width_table(tv,[3.70,3.70])
    for c,title_text,text in [(tv.cell(0,0),'THESIS',p['thesis']),(tv.cell(0,1),'VARIANT VIEW',p['variant'])]:
        c.text=''; borders(c); shade(c,PALE); margins(c,90,100,90,100)
        q=c.paragraphs[0]; q.paragraph_format.space_after=Pt(2); r=q.add_run(title_text); r.bold=True; r.font.size=Pt(7.5); r.font.color.rgb=RGBColor.from_string(BLUE)
        q2=c.add_paragraph(); q2.paragraph_format.space_after=Pt(0); rr=q2.add_run(_clip(text,430)); rr.font.size=Pt(8.2); rr.font.color.rgb=RGBColor.from_string(DARK)
    section_title('Catalyst / risk / invalidation')
    cr=doc.add_table(rows=1,cols=3); width_table(cr,[2.47,2.47,2.47])
    for c,title_text,text in [(cr.cell(0,0),'CATALYSTS',p['catalysts']),(cr.cell(0,1),'PRIMARY RISK',p['risk']),(cr.cell(0,2),'INVALIDATION',p['invalidation'])]:
        c.text=''; borders(c); shade(c,LIGHT); margins(c,80,90,80,90)
        q=c.paragraphs[0]; q.paragraph_format.space_after=Pt(2); r=q.add_run(title_text); r.bold=True; r.font.size=Pt(7.2); r.font.color.rgb=RGBColor.from_string(BLUE)
        qq=c.add_paragraph(); qq.paragraph_format.space_after=Pt(0); rr=qq.add_run(_clip(text,205)); rr.font.size=Pt(7.8); rr.font.color.rgb=RGBColor.from_string(DARK)

    # PAGE 2 - Operating and valuation
    doc.add_page_break(); header('OPERATING & VALUATION')
    section_title('Business snapshot')
    bt=doc.add_table(rows=1,cols=6); width_table(bt,[1.23]*6)
    for c,(lab,val) in zip(bt.rows[0].cells,[('Revenue',_money(p['revenue'])),('Gross M',fpct(p['gross_margin'])),('FCF M',fpct(p['fcf_margin'])),('ROIC',fpct(p['roic'])),('CCC',fnum(p['ccc'],1,'d')),('Net Debt',_money(p['net_debt']))]): metric_cell(c,lab,val,'')
    # Keep page 2 stable at four report pages even when current-basis disclosure wraps.  The
    # chart remains readable at this width and buys enough vertical room to keep the historical
    # regime table from spilling onto a fifth Word page.
    doc.add_picture(_fundamental_chart_png(p,width=8.2,height=2.30),width=Inches(6.00))

    section_title('Financial history')
    headers=['Period','Revenue','Growth','Gross M','Op M','Net M','FCF M','Inv/Rev','Shares']
    ht=doc.add_table(rows=1,cols=len(headers)); width_table(ht,[.55,1.0,.74,.76,.73,.73,.73,.78,1.0])
    for c,h in zip(ht.rows[0].cells,headers): set_cell(c,h,7.6,True,WHITE,BLUE,WD_ALIGN_PARAGRAPH.CENTER)
    for idx,row in enumerate(p['financial_history']):
        vals=[row['period'],_money(row['revenue']),fpct(row['growth']),fpct(row['gross_margin']),fpct(row['operating_margin']),fpct(row['net_margin']),fpct(row['fcf_margin']),fpct(row['inventory_rev']),_compact_num(row['shares'])]
        for c,v in zip(ht.add_row().cells,vals): set_cell(c,v,7.5,False,DARK,LIGHT if idx%2==0 else WHITE,WD_ALIGN_PARAGRAPH.CENTER)

    section_title('Scenario valuation bridge')
    headers=['Case','Prob','Growth','Net M','FCF M','P/E','EV/Sales','FCF Yld','FCFE Disc.','Fair Value','DCF']
    vt=doc.add_table(rows=1,cols=len(headers)); width_table(vt,[.58,.58,.68,.68,.68,.48,.65,.65,.60,.82,.82])
    for c,h in zip(vt.rows[0].cells,headers): set_cell(c,h,7.1,True,WHITE,BLUE,WD_ALIGN_PARAGRAPH.CENTER)
    for row in p['scenario_rows']:
        vals=[row['case'],fpct(row['prob']),fpct(row['growth']),fpct(row['net_margin']),fpct(row['fcf_margin']),fnum(row['pe'],1),fnum(row['ev_sales'],2),fpct(row['fcf_yield']),fpct(row['wacc']),fprice(row['fair_value']),fprice(row['dcf'])]
        for c,v in zip(vt.add_row().cells,vals): set_cell(c,v,7.2,False,DARK,LIGHT,WD_ALIGN_PARAGRAPH.CENTER)

    section_title('Current per-share basis')
    sb=doc.add_table(rows=2,cols=4); width_table(sb,[1.86]*4)
    sbvals=[('SEC shares',_compact_num(p.get('share_basis_raw')),str(p.get('share_basis_source') or '-').replace('_',' ')),
            ('Fact / filed',p.get('share_basis_fact_date') or '-',f"Filed {p.get('share_basis_filed_date') or '-'}"),
            ('Normalized shares',_compact_num(p.get('share_basis_normalized')),f"Split factor {fnum(p.get('share_basis_factor'),4,'x')}"),
            ('Basis',p.get('share_basis_status') or '-',f"Confidence {p.get('share_basis_confidence') or '-'}"),
            ('Corporate actions',_clip(p.get('share_basis_actions') or '-',34),_clip(p.get('share_basis_corporate') or '-',54)),
            ('Current price',fprice(p.get('price')),f"{p.get('current_price_date') or '-'} · {p.get('current_price_source') or '-'}"),
            ('Bear / Base',f"{fprice(p.get('bear'))} / {fprice(p.get('base'))}",'Per-share targets'),
            ('Bull',fprice(p.get('bull')),_clip(p.get('share_basis_issue') or 'Auditable current basis',52))]
    for c,(lab,val,det) in zip([c for row in sb.rows for c in row.cells],sbvals): metric_cell(c,lab,val,det)

    section_title('Historical valuation regime')
    h2=['Metric','Current','P25','Median','P75','Obs','Flag','Interpretation']; ht2=doc.add_table(rows=1,cols=len(h2)); width_table(ht2,[.78,.65,.61,.67,.61,.42,.62,2.98])
    for c,h in zip(ht2.rows[0].cells,h2): set_cell(c,h,7.2,True,WHITE,BLUE,WD_ALIGN_PARAGRAPH.CENTER)
    for row in p['historical_valuation']:
        ff=(lambda x:fpct(x)) if row['metric']=='FCF Yield' else (lambda x:fnum(x,2))
        vals=[row['metric'],ff(row['current']),ff(row['p25']),ff(row['median']),ff(row['p75']),str(row['n']),row['severity'],_clip(row['interpretation'],90)]
        for j,(c,v) in enumerate(zip(ht2.add_row().cells,vals)): set_cell(c,v,7.1,False,DARK,LIGHT,WD_ALIGN_PARAGRAPH.LEFT if j==7 else WD_ALIGN_PARAGRAPH.CENTER)

    # PAGE 3 - Management and forecast
    doc.add_page_break(); header('MANAGEMENT & 5Y OPERATING FORECAST')
    section_title('Management and quality scorecard')
    mt=doc.add_table(rows=1,cols=4); width_table(mt,[1.85]*4)
    vals=[('Management Delivery',f"{p['management_label']} {fnum(p['management_score'],0)}/100" if _finite(p['management_score']) else p['management_label'],f"{p['management_scorable']} scorable - {p['management_met']} met - {p['management_missed']} missed"),('Business Quality',f"{p['quality_label']} {fnum(p['quality_score'],0)}/100" if _finite(p['quality_score']) else p['quality_label'],'Independent cross-checks'),('Base Forecast CAGR',fpct(p['forecast_base_cagr']),'5Y terminal-price CAGR'),('Forecast PV',fprice(p['forecast_base_pv']),'Discounted terminal value')]
    for c,(lab,val,det) in zip(mt.rows[0].cells,vals): metric_cell(c,lab,val,det)

    section_title('Management promise scorecard')
    ph=['Filed','Metric','FY','Target','Actual','Result']; pt=doc.add_table(rows=1,cols=6); width_table(pt,[1.0,1.35,.55,1.45,1.45,1.0])
    for c,h in zip(pt.rows[0].cells,ph): set_cell(c,h,7.6,True,WHITE,BLUE,WD_ALIGN_PARAGRAPH.CENTER)
    if p['management_rows']:
        for idx,row in enumerate(p['management_rows'][:8]):
            target=_promise_fmt(row,'low') if not (_finite(row.get('high')) and row.get('high')!=row.get('low')) else f"{_promise_fmt(row,'low')} - {_promise_fmt(row,'high')}"
            vals=[row.get('filed') or '-',row.get('metric') or '-',str(row.get('fy') or '-'),target,_promise_fmt(row,'actual'),row.get('status') or '-']
            for c,v in zip(pt.add_row().cells,vals): set_cell(c,v,7.5,False,DARK,LIGHT if idx%2==0 else WHITE,WD_ALIGN_PARAGRAPH.CENTER)
    else:
        row=pt.add_row().cells; set_cell(row[0],'No scorable explicit numeric management promises extracted yet.',7.2,False,MUTED,LIGHT)
        for c in row[1:]: set_cell(c,'',7.2,False,MUTED,LIGHT)

    section_title('Independent quality validation')
    qt=doc.add_table(rows=1,cols=3); width_table(qt,[1.85,.90,4.65])
    for c,h in zip(qt.rows[0].cells,['Check','Status','Evidence']): set_cell(c,h,7.6,True,WHITE,BLUE,WD_ALIGN_PARAGRAPH.CENTER)
    for idx,row in enumerate(p['quality_checks'][:7]):
        vals=[row.get('name') or '',row.get('status') or '',_clip(row.get('reason'),130)]
        for j,(c,v) in enumerate(zip(qt.add_row().cells,vals)): set_cell(c,v,7.5,False,DARK,LIGHT if idx%2==0 else WHITE,WD_ALIGN_PARAGRAPH.LEFT if j==2 else WD_ALIGN_PARAGRAPH.CENTER)

    doc.add_picture(_forecast_chart_png(p,width=8.2,height=2.20),width=Inches(7.35))
    section_title('Base operating forecast')
    fh=['Year','Revenue','Growth','Gross M','Op M','Net M','FCF M','EPS']; ft=doc.add_table(rows=1,cols=8); width_table(ft,[.55,1.05,.82,.82,.82,.82,.82,.78])
    for c,h in zip(ft.rows[0].cells,fh): set_cell(c,h,7.4,True,WHITE,BLUE,WD_ALIGN_PARAGRAPH.CENTER)
    for row in p['base_forecast'][:5]:
        vals=[f"Y{row.get('year')}",_money(row.get('revenue')),fpct(row.get('growth')),fpct(row.get('gross_margin')),fpct(row.get('operating_margin')),fpct(row.get('net_margin')),fpct(row.get('fcf_margin')),fprice(row.get('eps'))]
        for c,v in zip(ft.add_row().cells,vals): set_cell(c,v,7.5,False,DARK,LIGHT,WD_ALIGN_PARAGRAPH.CENTER)

    # PAGE 4 - Market evidence, process, reconciliation
    doc.add_page_break(); header('MARKET EVIDENCE & DECISION CONTROL')
    section_title('Price reconciliation - what must the market believe?')
    pr=p.get('price_reconciliation') or {}; rt=doc.add_table(rows=1,cols=4); width_table(rt,[1.45,1.4,1.7,2.85])
    for c,h in zip(rt.rows[0].cells,['Driver','Our Base','Implied by Price','Decision question']): set_cell(c,h,7.5,True,WHITE,BLUE,WD_ALIGN_PARAGRAPH.CENTER)
    rec=[('Revenue CAGR',fpct(pr.get('forecast_revenue_cagr')),fpct(pr.get('market_implied_revenue_cagr')),'Growth expectation gap'),('Year-5 Net Margin',fpct(pr.get('forecast_terminal_net_margin')),fpct(pr.get('market_implied_net_margin')),'Profitability embedded in price'),('Year-5 Exit P/E',fnum(pr.get('forecast_exit_pe'),1,'x'),fnum(pr.get('market_implied_exit_pe'),1,'x'),'Multiple required for target return')]
    for rr in rec:
        for j,(c,v) in enumerate(zip(rt.add_row().cells,rr)): set_cell(c,v,7.8,False,DARK,LIGHT,WD_ALIGN_PARAGRAPH.LEFT if j==3 else WD_ALIGN_PARAGRAPH.CENTER)

    section_title('Market positioning')
    pos=doc.add_table(rows=2,cols=5); width_table(pos,[1.48]*5)
    vals=[('Long Demand',fnum(p['long_demand'],0)),('Short Pressure',fnum(p['short_pressure'],0)),('Absorption',fnum(p['absorption'],0)),('Price Resilience',fnum(p['price_resilience'],0)),('Daily Short %',fpct(p['short_pct'])),('Short Interest',_money(p['latest_si'])),('SI Change',fpct(p['si_change'])),('Net Large Flow',_money(p['net_large'])),('Net Whale Flow',_money(p['net_whale'])),('Feed',f"{p['market_feed']} / {p['flow_feed']}")]
    for c,(lab,val) in zip([c for row in pos.rows for c in row.cells],vals): metric_cell(c,lab,val,'')

    section_title('Forensic lens')
    fs=doc.add_table(rows=1,cols=3); width_table(fs,[2.47]*3)
    groups=[('POSITIVE EVIDENCE',p['forensic_positive'][:4],GREEN,'No material positive rule triggered.'),('CHALLENGES',p['forensic_negative'][:4],RED,'No material challenge triggered.'),('DATA ALERTS',p['forensic_data'][:4],AMBER,'No material data alert triggered.')]
    for c,(title_text,items,color,empty) in zip(fs.rows[0].cells,groups):
        c.text=''; borders(c); shade(c,LIGHT); margins(c,85,95,85,95)
        q=c.paragraphs[0]; r=q.add_run(title_text); r.bold=True; r.font.size=Pt(7.2); r.font.color.rgb=RGBColor.from_string(color)
        for item in (items or [empty]):
            qq=c.add_paragraph(); qq.paragraph_format.space_after=Pt(1); rr=qq.add_run('- '+_clip(item,145)); rr.font.size=Pt(7.4); rr.font.color.rgb=RGBColor.from_string(DARK)

    section_title('Data quality and research process')
    ac=p['audit_counts']; dq=doc.add_table(rows=2,cols=4); width_table(dq,[1.85]*4)
    dvals=[('Audit PASS',ac.get('PASS',0),'Validated checks'),('Audit WARN',ac.get('WARN',0),'Review before capital'),('Audit FAIL',ac.get('FAIL',0),'Resolve before trust'),('SEC Revisions',p['sec_revision_count'],'Reported corrections'),('Triangulation',p['triangulation_summary'],f"Score {fnum(p['triangulation_score'],0)}/100"),('Peer Set',', '.join(p['peer_tickers'][:5]) or 'Low data','External comparison'),('Decision Gates',f"{p['gates_pass']}/16",p['decision_readiness']),('Next Action',_clip(p['next_action'],200),'Process output')]
    for c,(lab,val,det) in zip([c for row in dq.rows for c in row.cells],dvals): metric_cell(c,lab,val,det)

    q=doc.add_paragraph(); q.paragraph_format.space_before=Pt(8); q.paragraph_format.space_after=Pt(0)
    r=q.add_run('Data scope: SEC EDGAR/XBRL, FINRA, configured market-data providers and Market Forensics internal models. Scenario and forecast values are model outputs, not observed market facts.')
    r.font.size=Pt(7.2); r.font.color.rgb=RGBColor.from_string(MUTED)

    out=BytesIO(); doc.save(out); return out.getvalue()


def research_report_pdf(ticker: str, state: dict):
    """Four-page institutional PDF with a restrained bank-research layout."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak, Image
    from reportlab.lib.enums import TA_CENTER, TA_LEFT

    p=research_report_payload(ticker,state); out=BytesIO()
    doc=SimpleDocTemplate(out,pagesize=letter,rightMargin=.48*inch,leftMargin=.48*inch,topMargin=.40*inch,bottomMargin=.50*inch)
    NAVY=colors.HexColor('#11263A'); BLUE=colors.HexColor('#2F618C'); STEEL=colors.HexColor('#567B9B'); PALE=colors.HexColor('#EEF3F7'); LIGHT=colors.HexColor('#F7F9FB'); MUTED=colors.HexColor('#65727E'); LINE=colors.HexColor('#C5D0D9'); DARK=colors.HexColor('#172431'); GREEN=colors.HexColor('#1E875E'); RED=colors.HexColor('#C44E4E'); AMBER=colors.HexColor('#B98522')
    styles=getSampleStyleSheet()
    body=ParagraphStyle('mf_body_305',parent=styles['Normal'],fontName='Helvetica',fontSize=8.2,leading=9.9,textColor=DARK)
    small=ParagraphStyle('mf_small_305',parent=body,fontSize=7.2,leading=8.5,textColor=MUTED)
    label=ParagraphStyle('mf_label_305',parent=body,fontName='Helvetica-Bold',fontSize=7.0,leading=7.9,textColor=MUTED)
    big=ParagraphStyle('mf_big_305',parent=body,fontName='Helvetica-Bold',fontSize=11.3,leading=12.2,textColor=DARK)
    section=ParagraphStyle('mf_sec_305',parent=body,fontName='Helvetica-Bold',fontSize=8.4,leading=9.5,textColor=BLUE,spaceBefore=7,spaceAfter=4)
    title=ParagraphStyle('mf_title_305',parent=body,fontName='Helvetica-Bold',fontSize=20,leading=21,textColor=NAVY)
    story=[]

    def page_footer(canvas, _doc):
        canvas.saveState(); canvas.setFont('Helvetica',7); canvas.setFillColor(MUTED)
        canvas.drawCentredString(letter[0]/2, .23*inch, 'Lose Money Rules')
        canvas.restoreState()

    def logo_flowable():
        logo=_branding_logo()
        if not logo:
            return Paragraph('<b>MF</b>',ParagraphStyle('mf_logo_305',parent=big,textColor=colors.white,fontSize=13,alignment=TA_CENTER))
        try:
            from PIL import Image as PILImage
            with PILImage.open(logo) as im:
                w,h=im.size
            maxw=.88*inch; maxh=.27*inch; ratio=min(maxw/w,maxh/h)
            return Image(str(logo),width=w*ratio,height=h*ratio)
        except Exception:
            return Paragraph('<b>MF</b>',ParagraphStyle('mf_logo_fallback_305',parent=big,textColor=colors.white,fontSize=13,alignment=TA_CENTER))

    def header(page_label):
        left=logo_flowable(); right=Paragraph(f'<b>MARKET FORENSICS</b>&nbsp;&nbsp;<font color="#2F618C">| {page_label}</font><br/><font size="6.4" color="#65727E">{p["date"]} | Internal decision support | Last refresh {p["last_refresh"]}</font>',body)
        t=Table([[left,right]],colWidths=[1.05*inch,6.45*inch],rowHeights=[.43*inch])
        styles_t=[('VALIGN',(0,0),(-1,-1),'MIDDLE'),('BOX',(0,0),(-1,-1),.65,LINE),('INNERGRID',(0,0),(-1,-1),.4,LINE),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4)]
        if not _branding_logo(): styles_t.append(('BACKGROUND',(0,0),(0,0),NAVY))
        t.setStyle(TableStyle(styles_t)); story.append(t)

    metric_long=ParagraphStyle('mf_metric_long_312',parent=big,fontSize=8.7,leading=9.8)
    def metric(lab,val,det=''):
        txt=str(val)
        # Narrative process outputs (notably NEXT ACTION) must wrap inside the cell rather than
        # overflowing a fixed-height KPI box. Numerical KPI values keep the larger face.
        value_style=metric_long if len(txt)>22 else big
        return [Paragraph(str(lab).upper(),label),Paragraph(_xml(txt,220),value_style),Paragraph(_xml(str(det or ''),120),small)]

    def metric_table(items, cols):
        rows=[items[i:i+cols] for i in range(0,len(items),cols)]
        widths=[7.52/cols*inch]*cols
        # Do not force rowHeights: ReportLab must be free to expand a row when text wraps.
        t=Table(rows,colWidths=widths)
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),LIGHT),('BOX',(0,0),(-1,-1),.55,LINE),('INNERGRID',(0,0),(-1,-1),.45,LINE),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)])); return t

    def std_table(data,widths,font=7.6,left_cols=None):
        wrapped=[]
        for ri,row in enumerate(data):
            if ri==0: wrapped.append([Paragraph(f'<b>{_xml(v)}</b>',ParagraphStyle(f'h{ri}_{i}_{len(story)}',parent=body,fontName='Helvetica-Bold',fontSize=font,leading=font+1,textColor=colors.white,alignment=TA_CENTER)) for i,v in enumerate(row)])
            else:
                new=[]
                for i,v in enumerate(row):
                    align=TA_LEFT if left_cols and i in left_cols else TA_CENTER
                    new.append(Paragraph(_xml(v),ParagraphStyle(f'c{ri}_{i}_{len(story)}',parent=body,fontSize=font,leading=font+1.8,textColor=DARK,alignment=align)))
                wrapped.append(new)
        t=Table(wrapped,colWidths=widths,repeatRows=1)
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),BLUE),('BACKGROUND',(0,1),(-1,-1),LIGHT),('BOX',(0,0),(-1,-1),.55,LINE),('INNERGRID',(0,0),(-1,-1),.4,LINE),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),4),('RIGHTPADDING',(0,0),(-1,-1),4),('TOPPADDING',(0,0),(-1,-1),4.2),('BOTTOMPADDING',(0,0),(-1,-1),4.2)])); return t

    # Page 1
    header('INVESTMENT VIEW'); story.append(Spacer(1,5))
    story.append(Paragraph(f'{p["ticker"]}&nbsp;&nbsp;<font size="11" color="#65727E">{_xml(p["company"],80)}</font>',title))
    story.append(Paragraph(f'<b><font color="#2F618C">P{p["system_priority"]} {p["coverage_focus"]}</font></b> &nbsp;|&nbsp; {_xml(p["coverage_setup"],70)} &nbsp;|&nbsp; {p["status"]} &nbsp;|&nbsp; {p["portfolio"]}',body)); story.append(Spacer(1,5))
    items=[metric('Price',fprice(p['price']),f"Base gap {fpct(p['upside'])}"),metric('Base Target',fprice(p['base']),f"Expected value {fprice(p['expected_value'])}"),metric('Bear / Bull',f"{fprice(p['bear'])} / {fprice(p['bull'])}",'Scenario range'),metric('Valuation Confidence',f"{p['valuation_confidence']} {fnum(p['valuation_confidence_score'],0)}/100",'Model reliability'),metric('Fundamental',f"{fnum(p['fundamental_score'],2)}/5",'Business consistency'),metric('Tape',f"{fnum(p['net_tape'],0)} / 100",p['regime']),metric('Decision Readiness',f"{p['gates_pass']}/16",p['decision_readiness']),metric('System Scores',f"L {fnum(p['long_score'],0)} / S {fnum(p['short_score'],0)}",_clip(p['next_action'],55))]
    story.append(metric_table(items,4)); story.append(Spacer(1,5)); story.append(Image(_price_chart_png(p,width=8.2,height=2.7),width=7.52*inch,height=2.47*inch))
    story.append(Paragraph('INVESTMENT THESIS & DISAGREEMENT',section))
    tv=Table([[Paragraph('<b>THESIS</b><br/>'+_xml(p['thesis'],430),body),Paragraph('<b>VARIANT VIEW</b><br/>'+_xml(p['variant'],430),body)]],colWidths=[3.76*inch]*2)
    tv.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),PALE),('BOX',(0,0),(-1,-1),.55,LINE),('INNERGRID',(0,0),(-1,-1),.4,LINE),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)])); story.append(tv)
    story.append(Paragraph('CATALYST / RISK / INVALIDATION',section))
    cr=Table([[Paragraph('<b>CATALYSTS</b><br/>'+_xml(p['catalysts'],205),body),Paragraph('<b>PRIMARY RISK</b><br/>'+_xml(p['risk'],205),body),Paragraph('<b>INVALIDATION</b><br/>'+_xml(p['invalidation'],205),body)]],colWidths=[2.506*inch]*3)
    cr.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),LIGHT),('BOX',(0,0),(-1,-1),.55,LINE),('INNERGRID',(0,0),(-1,-1),.4,LINE),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)])); story.append(cr)

    # Page 2
    story.append(PageBreak()); header('OPERATING & VALUATION')
    story.append(Paragraph('BUSINESS SNAPSHOT',section))
    story.append(metric_table([metric('Revenue',_money(p['revenue'])),metric('Gross M',fpct(p['gross_margin'])),metric('FCF M',fpct(p['fcf_margin'])),metric('ROIC',fpct(p['roic'])),metric('CCC',fnum(p['ccc'],1,'d')),metric('Net Debt',_money(p['net_debt']))],6))
    story.append(Spacer(1,4)); story.append(Image(_fundamental_chart_png(p,width=8.2,height=2.45),width=7.52*inch,height=2.15*inch))
    story.append(Paragraph('FINANCIAL HISTORY',section)); h=[['Period','Revenue','Growth','Gross M','Op M','Net M','FCF M','Inv/Rev','Shares']]
    for r in p['financial_history']: h.append([r['period'],_money(r['revenue']),fpct(r['growth']),fpct(r['gross_margin']),fpct(r['operating_margin']),fpct(r['net_margin']),fpct(r['fcf_margin']),fpct(r['inventory_rev']),_compact_num(r['shares'])])
    story.append(std_table(h,[.55*inch,1.03*inch,.75*inch,.75*inch,.72*inch,.72*inch,.72*inch,.78*inch,1.00*inch],font=7.3))
    story.append(Paragraph('SCENARIO VALUATION BRIDGE',section)); sd=[['Case','Prob','Growth','Net M','FCF M','P/E','EV/Sales','FCF Yld','FCFE Disc.','Fair Value','DCF']]
    for r in p['scenario_rows']: sd.append([r['case'],fpct(r['prob']),fpct(r['growth']),fpct(r['net_margin']),fpct(r['fcf_margin']),fnum(r['pe'],1),fnum(r['ev_sales'],2),fpct(r['fcf_yield']),fpct(r['wacc']),fprice(r['fair_value']),fprice(r['dcf'])])
    story.append(std_table(sd,[.55*inch,.55*inch,.65*inch,.65*inch,.65*inch,.48*inch,.64*inch,.64*inch,.57*inch,.80*inch,.80*inch],font=6.9))
    story.append(Paragraph('CURRENT PER-SHARE BASIS',section))
    sbitems=[metric('SEC shares',_compact_num(p.get('share_basis_raw')),str(p.get('share_basis_source') or '-').replace('_',' ')),
             metric('Fact / filed',p.get('share_basis_fact_date') or '-',f"Filed {p.get('share_basis_filed_date') or '-'}"),
             metric('Normalized shares',_compact_num(p.get('share_basis_normalized')),f"Factor {fnum(p.get('share_basis_factor'),4,'x')}"),
             metric('Basis',p.get('share_basis_status') or '-',f"Confidence {p.get('share_basis_confidence') or '-'}"),
             metric('Corporate actions',_clip(p.get('share_basis_actions') or '-',42),_clip(p.get('share_basis_corporate') or '-',62)),
             metric('Current price',fprice(p.get('price')),f"{p.get('current_price_date') or '-'} · {p.get('current_price_source') or '-'}"),
             metric('Bear / Base',f"{fprice(p.get('bear'))} / {fprice(p.get('base'))}",'Per-share targets'),
             metric('Bull',fprice(p.get('bull')),_clip(p.get('share_basis_issue') or 'Auditable current basis',60))]
    story.append(metric_table(sbitems,4))
    story.append(Paragraph('HISTORICAL VALUATION REGIME',section)); vd=[['Metric','Current','P25','Median','P75','Obs','Flag','Interpretation']]
    for r in p['historical_valuation']:
        ff=(lambda x:fpct(x)) if r['metric']=='FCF Yield' else (lambda x:fnum(x,2)); vd.append([r['metric'],ff(r['current']),ff(r['p25']),ff(r['median']),ff(r['p75']),str(r['n']),r['severity'],_clip(r['interpretation'],92)])
    story.append(std_table(vd,[.75*inch,.62*inch,.58*inch,.64*inch,.58*inch,.40*inch,.58*inch,3.37*inch],font=7.0,left_cols={7}))

    # Page 3
    story.append(PageBreak()); header('MANAGEMENT & 5Y OPERATING FORECAST')
    story.append(Paragraph('MANAGEMENT AND QUALITY SCORECARD',section))
    m=[metric('Management Delivery',f"{p['management_label']} {fnum(p['management_score'],0)}/100" if _finite(p['management_score']) else p['management_label'],f"{p['management_scorable']} scorable - {p['management_met']} met - {p['management_missed']} missed"),metric('Business Quality',f"{p['quality_label']} {fnum(p['quality_score'],0)}/100" if _finite(p['quality_score']) else p['quality_label'],'Independent cross-checks'),metric('Base Forecast CAGR',fpct(p['forecast_base_cagr']),'5Y terminal-price CAGR'),metric('Forecast PV',fprice(p['forecast_base_pv']),'Discounted terminal value')]
    story.append(metric_table(m,4)); story.append(Paragraph('MANAGEMENT PROMISE SCORECARD',section)); pd=[['Filed','Metric','FY','Target','Actual','Result']]
    for row in p['management_rows'][:8]:
        target=_promise_fmt(row,'low') if not (_finite(row.get('high')) and row.get('high')!=row.get('low')) else f"{_promise_fmt(row,'low')} - {_promise_fmt(row,'high')}"; pd.append([row.get('filed') or '-',row.get('metric') or '-',str(row.get('fy') or '-'),target,_promise_fmt(row,'actual'),row.get('status') or '-'])
    if len(pd)==1: pd.append(['No scorable promises','','','','',''])
    story.append(std_table(pd,[1.00*inch,1.35*inch,.55*inch,1.45*inch,1.45*inch,1.05*inch],font=7.3))
    story.append(Paragraph('INDEPENDENT QUALITY VALIDATION',section)); qd=[['Check','Status','Evidence']]+[[x.get('name') or '',x.get('status') or '',_clip(x.get('reason'),135)] for x in p['quality_checks'][:7]]
    story.append(std_table(qd,[1.85*inch,.90*inch,4.77*inch],font=7.2,left_cols={2})); story.append(Spacer(1,4)); story.append(Image(_forecast_chart_png(p,width=8.2,height=2.45),width=7.52*inch,height=2.12*inch))
    story.append(Paragraph('BASE OPERATING FORECAST',section)); fd=[['Year','Revenue','Growth','Gross M','Op M','Net M','FCF M','EPS']]
    for row in p['base_forecast'][:5]: fd.append([f"Y{row.get('year')}",_money(row.get('revenue')),fpct(row.get('growth')),fpct(row.get('gross_margin')),fpct(row.get('operating_margin')),fpct(row.get('net_margin')),fpct(row.get('fcf_margin')),fprice(row.get('eps'))])
    story.append(std_table(fd,[.55*inch,1.05*inch,.82*inch,.82*inch,.82*inch,.82*inch,.82*inch,.82*inch],font=7.2))

    # Page 4
    story.append(PageBreak()); header('MARKET EVIDENCE & DECISION CONTROL')
    story.append(Paragraph('PRICE RECONCILIATION - WHAT MUST THE MARKET BELIEVE?',section)); pr=p.get('price_reconciliation') or {}; rd=[['Driver','Our Base','Implied by Price','Decision question'],['Revenue CAGR',fpct(pr.get('forecast_revenue_cagr')),fpct(pr.get('market_implied_revenue_cagr')),'Growth expectation gap'],['Year-5 Net Margin',fpct(pr.get('forecast_terminal_net_margin')),fpct(pr.get('market_implied_net_margin')),'Profitability embedded in price'],['Year-5 Exit P/E',fnum(pr.get('forecast_exit_pe'),1,'x'),fnum(pr.get('market_implied_exit_pe'),1,'x'),'Multiple required for target return']]
    story.append(std_table(rd,[1.45*inch,1.40*inch,1.70*inch,2.97*inch],font=7.6,left_cols={3}))
    story.append(Paragraph('MARKET POSITIONING',section)); story.append(metric_table([metric('Long Demand',fnum(p['long_demand'],0)),metric('Short Pressure',fnum(p['short_pressure'],0)),metric('Absorption',fnum(p['absorption'],0)),metric('Price Resilience',fnum(p['price_resilience'],0)),metric('Daily Short %',fpct(p['short_pct'])),metric('Short Interest',_money(p['latest_si'])),metric('SI Change',fpct(p['si_change'])),metric('Net Large Flow',_money(p['net_large'])),metric('Net Whale Flow',_money(p['net_whale'])),metric('Feed',f"{p['market_feed']} / {p['flow_feed']}")],5))
    story.append(Paragraph('FORENSIC LENS',section)); pos='<br/>'.join('- '+_xml(x,145) for x in p['forensic_positive'][:4]) or 'No material positive rule triggered.'; neg='<br/>'.join('- '+_xml(x,145) for x in p['forensic_negative'][:4]) or 'No material challenge triggered.'; dat='<br/>'.join('- '+_xml(x,145) for x in p['forensic_data'][:4]) or 'No material data alert triggered.'
    ft=Table([[Paragraph('<b><font color="#1E875E">POSITIVE EVIDENCE</font></b><br/>'+pos,body),Paragraph('<b><font color="#C44E4E">CHALLENGES</font></b><br/>'+neg,body),Paragraph('<b><font color="#B98522">DATA ALERTS</font></b><br/>'+dat,body)]],colWidths=[2.506*inch]*3)
    ft.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),LIGHT),('BOX',(0,0),(-1,-1),.55,LINE),('INNERGRID',(0,0),(-1,-1),.4,LINE),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)])); story.append(ft)
    story.append(Paragraph('DATA QUALITY & RESEARCH PROCESS',section)); ac=p['audit_counts']; process=[metric('Audit PASS',ac.get('PASS',0),'Validated checks'),metric('Audit WARN',ac.get('WARN',0),'Review before capital'),metric('Audit FAIL',ac.get('FAIL',0),'Resolve before trust'),metric('SEC Revisions',p['sec_revision_count'],'Reported corrections'),metric('Triangulation',p['triangulation_summary'],f"Score {fnum(p['triangulation_score'],0)}/100"),metric('Peer Set',', '.join(p['peer_tickers'][:5]) or 'Low data','External comparison'),metric('Decision Gates',f"{p['gates_pass']}/16",p['decision_readiness']),metric('Next Action',_clip(p['next_action'],200),'Process output')]
    story.append(metric_table(process,4)); story.append(Spacer(1,6)); story.append(Paragraph('Data scope: SEC EDGAR/XBRL, FINRA, configured market-data providers and Market Forensics internal models. Scenario and forecast values are model outputs, not observed market facts.',small))

    doc.build(story,onFirstPage=page_footer,onLaterPages=page_footer)
    return out.getvalue()


def discovery_report_pdf(limit: int = 12):
    """Two-page landscape Discovery brief optimized for print legibility."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter, landscape
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak, Image
    from reportlab.lib.enums import TA_CENTER, TA_LEFT

    p=discovery_report_payload(limit); out=BytesIO(); pagesize=landscape(letter)
    doc=SimpleDocTemplate(out,pagesize=pagesize,rightMargin=.42*inch,leftMargin=.42*inch,topMargin=.38*inch,bottomMargin=.50*inch)
    NAVY=colors.HexColor('#11263A'); BLUE=colors.HexColor('#2F618C'); LIGHT=colors.HexColor('#F7F9FB'); MUTED=colors.HexColor('#65727E'); LINE=colors.HexColor('#C5D0D9'); DARK=colors.HexColor('#172431')
    styles=getSampleStyleSheet(); body=ParagraphStyle('d_body_305',parent=styles['Normal'],fontName='Helvetica',fontSize=8.0,leading=9.6,textColor=DARK); small=ParagraphStyle('d_small_305',parent=body,fontSize=7.1,leading=8.3,textColor=MUTED); big=ParagraphStyle('d_big_305',parent=body,fontName='Helvetica-Bold',fontSize=11.5,leading=12.5,textColor=DARK); section=ParagraphStyle('d_sec_305',parent=body,fontName='Helvetica-Bold',fontSize=8.7,leading=9.8,textColor=BLUE,spaceBefore=5,spaceAfter=3); title=ParagraphStyle('d_title_305',parent=body,fontName='Helvetica-Bold',fontSize=20,leading=21,textColor=NAVY); story=[]

    def footer(canvas,_doc):
        canvas.saveState(); canvas.setFont('Helvetica',7); canvas.setFillColor(MUTED); canvas.drawCentredString(pagesize[0]/2,.22*inch,'Lose Money Rules'); canvas.restoreState()
    def header(label):
        logo=_branding_logo()
        if logo:
            try:
                from PIL import Image as PILImage
                with PILImage.open(logo) as im:w,h=im.size
                ratio=min(.95*inch/w,.28*inch/h); left=Image(str(logo),width=w*ratio,height=h*ratio)
            except Exception: left=Paragraph('<b>MF</b>',ParagraphStyle('d_mf_fallback',parent=big,textColor=colors.white,fontSize=13,alignment=TA_CENTER))
        else:left=Paragraph('<b>MF</b>',ParagraphStyle('d_mf',parent=big,textColor=colors.white,fontSize=13,alignment=TA_CENTER))
        right=Paragraph(f'<b>MARKET FORENSICS</b>&nbsp;&nbsp;<font color="#2F618C">| DISCOVERY BRIEF | {label}</font><br/><font size="6.5" color="#65727E">Generated {p["generated_at"][:19].replace("T"," ")} UTC | Latest stored scan</font>',body)
        t=Table([[left,right]],colWidths=[1.15*inch,9.0*inch],rowHeights=[.44*inch]); commands=[('VALIGN',(0,0),(-1,-1),'MIDDLE'),('BOX',(0,0),(-1,-1),.6,LINE),('INNERGRID',(0,0),(-1,-1),.4,LINE),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7)]
        if not logo: commands.append(('BACKGROUND',(0,0),(0,0),NAVY))
        t.setStyle(TableStyle(commands)); story.append(t)
    def metric(lab,val,det=''):
        return [Paragraph(str(lab).upper(),small),Paragraph(str(val),big),Paragraph(str(det),small)]
    def candidate_table(rows,side):
        score='long_score' if side=='Long' else 'short_score'; data=[['P','Ticker','Lens','Price','FV Gap',side,'Quality','Trend','Confidence','Reason']]
        for r in (rows or [])[:10]: data.append([f"P{int(r.get('system_priority') or 5)}",r.get('ticker') or '',r.get('lens') or '',fprice(r.get('price')),fpct(r.get('screen_value_gap')),fnum(r.get(score),0),fnum(r.get('quality_score'),0),fnum(r.get('trend_score'),0),fnum(r.get('confidence'),0),_clip(r.get('reason'),120)])
        if len(data)==1:data.append(['-','None','','','','','','','','No material candidate in the latest scan'])
        wrapped=[]
        for ri,row in enumerate(data):
            vals=[]
            for ci,v in enumerate(row):
                align=TA_LEFT if ci in {2,9} else TA_CENTER
                style=ParagraphStyle(f'dt_{side}_{ri}_{ci}',parent=body,fontName='Helvetica-Bold' if ri==0 else 'Helvetica',fontSize=7.3 if ri==0 else 7.1,leading=8.5,textColor=colors.white if ri==0 else DARK,alignment=align)
                vals.append(Paragraph(_xml(v),style))
            wrapped.append(vals)
        t=Table(wrapped,colWidths=[.38*inch,.55*inch,1.35*inch,.65*inch,.52*inch,.58*inch,.55*inch,.55*inch,.68*inch,4.12*inch],repeatRows=1)
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),BLUE),('BACKGROUND',(0,1),(-1,-1),LIGHT),('BOX',(0,0),(-1,-1),.55,LINE),('INNERGRID',(0,0),(-1,-1),.4,LINE),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),4),('RIGHTPADDING',(0,0),(-1,-1),4),('TOPPADDING',(0,0),(-1,-1),4.3),('BOTTOMPADDING',(0,0),(-1,-1),4.3)])); return t

    header('OPPORTUNITY MAP'); story.append(Spacer(1,5)); story.append(Paragraph('Market Discovery',title)); run=p.get('run') or {}; story.append(Paragraph(f'<b>Latest scan:</b> {run.get("status") or "NO RUN"} &nbsp;|&nbsp; {run.get("completed_at") or run.get("started_at") or "Never"} &nbsp;|&nbsp; Stage {run.get("stage") or "-"}',body)); story.append(Spacer(1,5))
    items=[metric('Scanned',p['universe_count'],'stored universe'),metric('Long dislocations',p['long_count'],'material long lenses'),metric('Short / traps',p['short_count'],'short + trap lenses'),metric('Review',p['review_count'],'context / data review')]
    mt=Table([items],colWidths=[2.54*inch]*4,rowHeights=[.64*inch]); mt.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),LIGHT),('BOX',(0,0),(-1,-1),.55,LINE),('INNERGRID',(0,0),(-1,-1),.4,LINE),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7)])); story.append(mt)
    story.append(Paragraph('TOP LONG DISLOCATIONS',section)); story.append(Image(_discovery_bar_png(p['longs'],'long_score','Long dislocation - strongest stored signals',width=10.7,height=2.2),width=10.15*inch,height=1.95*inch)); story.append(candidate_table(p['longs'],'Long'))

    story.append(PageBreak()); header('SHORT / REVIEW MAP'); story.append(Paragraph('TOP SHORT / TRAP DISLOCATIONS',section)); story.append(Image(_discovery_bar_png(p['shorts'],'short_score','Short / trap opportunity - strongest stored dislocations',width=10.7,height=2.2),width=10.15*inch,height=1.95*inch)); story.append(candidate_table(p['shorts'],'Short')); story.append(Paragraph('REVIEW / CONTEXT',section))
    data=[['P','Ticker','Lens','Long','Short','Reason']]
    for r in p['review'][:8]: data.append([f"P{int(r.get('system_priority') or 5)}",r.get('ticker') or '',r.get('lens') or '',fnum(r.get('long_score'),0),fnum(r.get('short_score'),0),_clip(r.get('reason'),160)])
    if len(data)==1:data.append(['-','None','','','','No context-only names in the latest scan'])
    wrapped=[]
    for ri,row in enumerate(data):
        wrapped.append([Paragraph(_xml(v),ParagraphStyle(f'dr_{ri}_{ci}',parent=body,fontName='Helvetica-Bold' if ri==0 else 'Helvetica',fontSize=6.9,leading=8.2,textColor=colors.white if ri==0 else DARK,alignment=TA_LEFT if ci in {2,5} else TA_CENTER)) for ci,v in enumerate(row)])
    rt=Table(wrapped,colWidths=[.45*inch,.65*inch,1.55*inch,.65*inch,.65*inch,6.2*inch],repeatRows=1); rt.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),BLUE),('BACKGROUND',(0,1),(-1,-1),LIGHT),('BOX',(0,0),(-1,-1),.55,LINE),('INNERGRID',(0,0),(-1,-1),.4,LINE),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),4),('RIGHTPADDING',(0,0),(-1,-1),4),('TOPPADDING',(0,0),(-1,-1),4.5),('BOTTOMPADDING',(0,0),(-1,-1),4.5)])); story.append(rt); story.append(Spacer(1,7)); story.append(Paragraph('Discovery is a research triage system, not a recommendation engine. Promote candidates only after data-quality, peer, valuation and risk review.',small))
    doc.build(story,onFirstPage=footer,onLaterPages=footer); return out.getvalue()
