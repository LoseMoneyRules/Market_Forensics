from __future__ import annotations

from datetime import date, datetime, timezone
from .config import load_settings
from . import db, finra, sec, fundamentals, flow, management, valuation, discovery, marketdata


def refresh_core(ticker: str, include_flow: bool = True):
    t = ticker.upper().strip()
    if not t:
        raise ValueError("Ticker is required.")
    db.ensure_coverage(t)
    settings = load_settings()
    feed_mode = settings.get("alpaca_feed", "auto")
    started = db.now_utc()
    with db.connect() as con:
        cur = con.execute(
            "INSERT INTO refresh_runs(ticker,started_at,status) VALUES(?,?,?)",
            (t, started, "RUNNING"),
        )
        run_id = cur.lastrowid

    try:
        warnings=[]
        lookback=max(int(settings.get("daily_lookback_days",500)), int(settings.get("valuation_history_days",3650)))
        bars, market_feed = marketdata.get_daily_bars(t, lookback, feed_mode)
        now = db.now_utc()
        # Last-good SQLite bars are continuity data, not a fresh market observation.
        # Never rewrite their timestamps/feed just because a new refresh attempt used the cache.
        if market_feed == "sqlite_cache":
            warnings.append("Market providers unavailable: using last-good SQLite daily bars")
            # Corporate-action metadata may still have been independently repaired (Yahoo split ledger).
            # Persist only the split-basis fields so a refresh can unblock per-share valuation without
            # pretending the cached quote itself is fresh.
            with db.connect() as _con:
                _con.executemany(
                    "UPDATE daily_bars SET split_factor=?, split_factor_verified=? WHERE ticker=? AND trade_date=?",
                    [(b.get("split_factor",1.0),1 if (b.get("split_factor_verified") or b.get("basis_verified")) else 0,t,b["date"]) for b in bars],
                )
        if market_feed != "sqlite_cache":
            db.upsert_many(
                "daily_bars",
                [{
                    "ticker": t, "trade_date": b["date"], "open": b.get("open"), "high": b.get("high"), "low": b.get("low"),
                    "close": b.get("close"), "raw_close": b.get("raw_close"), "split_adjusted_close": b.get("split_adjusted_close"),
                    "split_factor": b.get("split_factor",1.0), "basis_verified": 1 if b.get("basis_verified") else 0,
                    "split_factor_verified": 1 if (b.get("split_factor_verified") or b.get("basis_verified")) else 0,
                    "price_basis": b.get("price_basis") or "", "volume": b.get("volume"), "trade_count": b.get("trade_count"), "vwap": b.get("vwap"),
                    "feed": market_feed, "updated_at": now,
                } for b in bars],
                ["ticker", "trade_date"],
            )

        price_check = {"status": "DISABLED", "sources": []}
        if settings.get("price_crosscheck_enabled", True) and bars:
            try:
                price_check = marketdata.price_cross_check(t, bars[-1].get("close"), bars[-1].get("date"), market_feed)
                marketdata.store_price_check(t, price_check)
            except Exception as _pc_exc:
                price_check = {"status": "WARN", "sources": [], "message": f"Price cross-check unavailable: {_pc_exc}"}

        short = []
        try:
            short = finra.get_daily_short_volume(t, 45)
            db.upsert_many(
                "finra_short_volume",
                [{"ticker": t, **r, "updated_at": now} for r in short],
                ["ticker", "trade_date"],
            )
        except Exception as _finra_exc:
            warnings.append(f"FINRA live refresh unavailable; retained local last-good data: {_finra_exc}")

        ua = settings.get("sec_user_agent", "")
        frows = []
        management_scan = {"documents":0,"statements":0,"skipped":0,"errors":[]}
        if ua and "@" in ua:
            meta={"ticker":t}
            try:
                meta = sec.company_metadata(t, ua)
                db.upsert_many("company_meta", [{**meta, "updated_at": now}], ["ticker"])
                facts = sec.get_companyfacts(meta["cik"], ua)
                cover_share_fact=None
                try:
                    cover_share_fact=sec.latest_cover_page_shares(t,ua,limit=3,cik=meta.get("cik"))
                except Exception as _cover_exc:
                    # Do not fail a fundamentally valid refresh just because the cover-page recovery
                    # path is unavailable. Companyfacts and the diluted-share fallback still run.
                    cover_share_fact=None
                frows = fundamentals.build_fundamentals(t, facts, current_share_fact=cover_share_fact)
                db.upsert_many("fundamentals", frows, ["ticker", "period_key"])
                # Current valuation corporate-action evidence is independent from historical OHLC
                # calibration. Verify only the interval from the exact SEC share fact to the quote.
                ttm_row=next((dict(r) for r in frows if r.get("period_key")=="TTM"),{})
                price_date=str((bars[-1] if bars else {}).get("date") or "")[:10] or None
                # Split history cannot correct intervening buybacks/issuance. If exact outstanding
                # shares are stale, verify the recent diluted denominator instead so current targets
                # can still use the disclosed MEDIUM-confidence fallback.
                share_anchor=fundamentals.current_valuation_share_anchor(ttm_row,price_date)
                if share_anchor and price_date:
                    basis_evidence=marketdata.current_split_basis_evidence(t,share_anchor,price_date)
                    db.save_current_share_basis_evidence(t,basis_evidence)
                provrows = fundamentals.provenance_rows(t, facts, meta.get("cik"))
                db.upsert_many("sec_provenance", provrows, ["ticker", "metric"])
                revrows = fundamentals.revision_rows(t, facts)
                db.upsert_many("sec_revisions", revrows, ["ticker","metric","period_end","first_filed","latest_filed"])
                try:
                    management_scan = management.refresh_management_documents(t, ua, filing_limit=int(settings.get("management_filing_limit",18)), include_exhibits=True)
                except Exception as _mgmt_exc:
                    management_scan = {"documents":0,"statements":0,"skipped":0,"errors":[str(_mgmt_exc)]}
                    warnings.append(f"Management filing refresh partial: {_mgmt_exc}")
            except Exception as _sec_exc:
                # Some exchange-traded products / fund structures have a valid SEC CIK but no
                # operating-company Companyfacts endpoint. A confirmed 404 is N/A, not a broken
                # issuer refresh; market data and any cached local research remain usable.
                if not (isinstance(_sec_exc, sec.SECError) and "SEC HTTP 404" in str(_sec_exc) and sec.companyfacts_not_applicable(meta)):
                    warnings.append(f"SEC live refresh unavailable; retained local last-good fundamentals: {_sec_exc}")
        else:
            warnings.append("SEC User-Agent not configured; retained any local fundamentals")

        flow_count = 0
        flow_feed = "none"
        if include_flow and bars:
            n_days = max(1, int(settings.get("flow_days", 5)))
            trading_dates = [date.fromisoformat(b["date"]) for b in bars][-n_days:]
            for d in trading_dates:
                key = d.isoformat()
                exists = db.query("SELECT 1 FROM flow_daily WHERE ticker=? AND trade_date=?", (t, key))
                if exists and d != trading_dates[-1]:
                    continue
                trades, quotes, actual_feed = marketdata.get_session_trades_quotes(t, d, feed_mode)
                flow_feed = actual_feed
                if actual_feed == "none" or not trades or not quotes:
                    if not any("Tape unavailable" in w for w in warnings):
                        warnings.append("Tape unavailable: neither Alpaca nor Massive supplied usable trades/NBBO; retained local flow history")
                    continue
                agg = flow.classify_session(
                    trades,
                    quotes,
                    float(settings.get("minimum_notional", 25000)),
                    float(settings.get("large_percentile", .75)),
                    float(settings.get("very_large_percentile", .90)),
                    float(settings.get("whale_percentile", .99)),
                )
                row = {"ticker": t, "trade_date": key, "feed": actual_feed, "updated_at": now}
                row.update({k: v for k, v in agg.items() if k != "rows"})
                db.upsert_many("flow_daily", [row], ["ticker", "trade_date"])
                flow_count += 1

        completed = db.now_utc()
        refresh_status = "PARTIAL" if warnings else "PASS"
        db.execute(
            """UPDATE refresh_runs SET completed_at=?,status=?,bars_rows=?,finra_rows=?,
            fundamental_periods=?,flow_dates=?,market_feed=?,flow_feed=?,error_message=? WHERE id=?""",
            (completed, refresh_status, len(bars), len(short), len(frows), flow_count, market_feed, flow_feed, " | ".join(warnings)[:1000] if warnings else None, run_id),
        )
        capture_snapshot(t)
        try:
            discovery.sync_ticker_from_local(t)
        except Exception:
            pass
        return {
            "bars": len(bars), "finra": len(short), "fundamentals": len(frows), "flow_dates": flow_count,
            "market_feed": market_feed, "flow_feed": flow_feed, "run_id": run_id,
            "management_documents": management_scan.get("documents",0), "management_statements": management_scan.get("statements",0),
            "management_errors": management_scan.get("errors",[]),
            "price_check": price_check, "status": refresh_status, "warnings": warnings,
        }
    except Exception as e:
        db.execute(
            "UPDATE refresh_runs SET completed_at=?,status='FAIL',error_message=? WHERE id=?",
            (db.now_utc(), str(e)[:1000], run_id),
        )
        raise


def latest_snapshot(ticker: str):
    t = ticker.upper()
    bars = db.query("SELECT * FROM daily_bars WHERE ticker=? ORDER BY trade_date", (t,))
    # V3.1.8 self-heal: old/local price caches can be perfectly usable yet lack the narrower
    # split-factor verification required to reconcile SEC share facts. Repair that metadata once
    # from an independent split-event ledger; do not change the stored close or freshness.
    if bars and not all(bool(((dict(x)).get("split_factor_verified") or (dict(x)).get("basis_verified"))) for x in bars):
        try:
            repaired, ok = marketdata.ensure_split_factor_verification(t, [dict(x) | {"date":x.get("trade_date")} for x in bars])
            if ok:
                with db.connect() as con:
                    con.executemany(
                        "UPDATE daily_bars SET split_factor=?, split_factor_verified=? WHERE ticker=? AND trade_date=?",
                        [(r.get("split_factor",1.0),1,t,str(r.get("date") or r.get("trade_date"))[:10]) for r in repaired],
                    )
                bars = db.query("SELECT * FROM daily_bars WHERE ticker=? ORDER BY trade_date", (t,))
        except Exception:
            pass
    flows = db.query("SELECT * FROM flow_daily WHERE ticker=? ORDER BY trade_date", (t,))
    shorts = db.query("SELECT * FROM finra_short_volume WHERE ticker=? ORDER BY trade_date", (t,))
    si = db.query("SELECT * FROM short_interest WHERE ticker=? ORDER BY publication_date", (t,))
    fund = db.query("SELECT * FROM fundamentals WHERE ticker=? ORDER BY fiscal_year", (t,))
    meta = db.query("SELECT * FROM company_meta WHERE ticker=?", (t,))
    if not bars:
        return {"ticker": t, "bars": [], "flows": flows, "shorts": shorts, "si": si, "fund": fund, "meta": meta}
    b = dict(bars[-1])
    prev = bars[-2] if len(bars) > 1 else None
    b["return"] = b["close"] / prev["close"] - 1 if prev and prev["close"] else 0
    flow_row = next((x for x in reversed(flows) if x["trade_date"] == b["trade_date"]), flows[-1] if flows else {})
    sh = next((x for x in reversed(shorts) if x["trade_date"] == b["trade_date"]), shorts[-1] if shorts else None)

    latest_si = prev_si = None
    for x in si:
        if x["publication_date"] <= b["trade_date"]:
            prev_si, latest_si = latest_si, x
    si_change = None
    if latest_si and prev_si and prev_si["shares_short"]:
        si_change = latest_si["shares_short"] / prev_si["shares_short"] - 1

    recent_flows = [x for x in flows[-5:] if x.get("net_large") is not None]
    persistence = (
        sum(1 if x["net_large"] > 0 else -1 if x["net_large"] < 0 else 0 for x in recent_flows) / len(recent_flows)
        if recent_flows else 0
    )
    feed = flow_row.get("feed") or b.get("feed") or "iex"
    scores = flow.tape_scores(b, flow_row, sh["short_pct"] if sh else None, si_change, feed, persistence)
    return {
        "ticker": t, "bars": bars, "flows": flows, "shorts": shorts, "si": si, "fund": fund, "meta": meta,
        "bar": b, "flow": flow_row, "short": sh, "latest_si": latest_si, "si_change": si_change,
        "scores": scores,
    }


def capture_snapshot(ticker: str):
    t = ticker.upper()
    snap = latest_snapshot(t)
    bar = snap.get("bar")
    if not bar:
        return
    fund_rows = snap.get("fund") or []
    metrics = fundamentals.metrics_from_rows(fund_rows, bar.get("close"), bars=snap.get("bars") or [], current_basis_evidence=db.current_share_basis_evidence(t)) if fund_rows else {}
    cov=db.coverage_row(t) or {}
    assumptions, calibration, _legacy = valuation.resolve_assumptions(
        db.load_json_assumptions(t), metrics, fund_rows, snap.get("bars") or [], cov.get("company_type","Generic")
    )
    scenarios, expected_value = valuation.scenario_values(metrics, assumptions) if metrics else ({}, None)
    base_value = scenarios.get("base", {}).get("fair_value") if scenarios else None
    fscore, _ = fundamentals.fundamental_score(metrics) if metrics else (None, {})
    scores = snap.get("scores") or {}
    flow_row = snap.get("flow") or {}
    short_row = snap.get("short") or {}
    db.execute(
        """INSERT INTO metric_snapshots(
        ticker,captured_at,trade_date,price,base_value,expected_value,fundamental_score,institutional_flow,
        long_demand,short_pressure,absorption,battle_intensity,price_resilience,net_tape,confidence,regime,
        net_large,net_whale,short_pct,roic,fcf_margin,ccc
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            t, db.now_utc(), bar.get("trade_date"), bar.get("close"), base_value, expected_value, fscore,
            scores.get("Institutional Flow"), scores.get("Long Demand"), scores.get("Short Pressure"),
            scores.get("Absorption"), scores.get("Battle Intensity"), scores.get("Price Resilience"),
            scores.get("Net Tape"), scores.get("Confidence"), scores.get("Regime"),
            flow_row.get("net_large"), flow_row.get("net_whale"), short_row.get("short_pct"),
            metrics.get("roic"), metrics.get("fcf_margin"), metrics.get("ccc"),
        ),
    )


def snapshot_history(ticker: str, limit: int = 10):
    rows = db.query(
        "SELECT * FROM metric_snapshots WHERE ticker=? ORDER BY id DESC LIMIT ?",
        (ticker.upper(), int(limit)),
    )
    return list(reversed(rows))


def last_refresh(ticker: str):
    """Latest refresh attempt, PASS or FAIL."""
    rows = db.query(
        "SELECT * FROM refresh_runs WHERE ticker=? ORDER BY id DESC LIMIT 1",
        (ticker.upper(),),
    )
    return rows[0] if rows else None


def last_successful_refresh(ticker: str):
    """Latest refresh that actually updated the local dataset successfully."""
    rows = db.query(
        "SELECT * FROM refresh_runs WHERE ticker=? AND status='PASS' AND COALESCE(market_feed,'')!='sqlite_cache' ORDER BY id DESC LIMIT 1",
        (ticker.upper(),),
    )
    return rows[0] if rows else None


def coverage_summary_row(ticker: str):
    t = ticker.upper()
    cov = db.coverage_row(t) or {}
    snap = latest_snapshot(t)
    bar = snap.get("bar") or {}
    fund_rows = snap.get("fund") or []
    metrics = fundamentals.metrics_from_rows(fund_rows, bar.get("close"), bars=snap.get("bars") or [], current_basis_evidence=db.current_share_basis_evidence(t)) if fund_rows else {}
    ass, calibration, _legacy = valuation.resolve_assumptions(
        db.load_json_assumptions(t), metrics, fund_rows, snap.get("bars") or [], cov.get("company_type","Generic")
    )
    scenarios, ev = valuation.scenario_values(metrics, ass) if metrics else ({}, None)
    base = scenarios.get("base", {}).get("fair_value") if scenarios else None
    price = bar.get("close")
    upside = base / price - 1 if base is not None and price not in (None, 0) else None
    fscore, _ = fundamentals.fundamental_score(metrics) if metrics else (None, {})
    scores = snap.get("scores") or {}
    last = last_successful_refresh(t) or {}
    latest_attempt = last_refresh(t) or {}
    event = db.query(
        "SELECT * FROM events WHERE ticker=? AND status!='DONE' ORDER BY event_date LIMIT 1",
        (t,),
    )
    return {
        "Ticker": t,
        "Status": cov.get("status", "RESEARCH"),
        "Portfolio": cov.get("portfolio_state", "NO POSITION"),
        "Priority": cov.get("priority", 3),
        "Price": price,
        "Base FV": base,
        "Upside": upside,
        "Fundamental": fscore,
        "Net Tape": scores.get("Net Tape"),
        "Confidence": scores.get("Confidence"),
        "Regime": scores.get("Regime") or "LOW DATA",
        "Last Refresh": last.get("completed_at") or last.get("started_at"),
        "Refresh Status": latest_attempt.get("status") or "NEVER",
        "Next Event": event[0].get("event_date") if event else None,
    }
