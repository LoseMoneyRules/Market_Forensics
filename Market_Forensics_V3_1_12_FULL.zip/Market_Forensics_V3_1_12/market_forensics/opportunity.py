from __future__ import annotations

import math
from datetime import datetime, timezone


def _f(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def _clamp(x, lo=0.0, hi=100.0):
    return max(lo, min(hi, float(x)))


def _severity_weight(rows: list[dict] | None) -> float:
    weights = {'HIGH': 3.0, 'MEDIUM': 2.0, 'LOW': 1.0}
    return sum(weights.get(str(r.get('Severity') or '').upper(), 1.0) for r in (rows or []))


def _age_hours(timestamp: str | None) -> float | None:
    if not timestamp:
        return None
    try:
        dt = datetime.fromisoformat(str(timestamp).replace('Z', '+00:00'))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return max(0.0, (datetime.now(timezone.utc) - dt).total_seconds() / 3600.0)
    except Exception:
        return None


def freshness(timestamp: str | None) -> dict:
    age = _age_hours(timestamp)
    if age is None:
        return {'age_hours': None, 'status': 'NEVER', 'label': '🔴 NEVER', 'factor': 0.45}
    if age <= 6:
        return {'age_hours': age, 'status': 'FRESH', 'label': f'🟢 {age:.1f}h', 'factor': 1.00}
    if age <= 24:
        return {'age_hours': age, 'status': 'TODAY', 'label': f'🟡 {age:.0f}h', 'factor': 0.97}
    if age <= 72:
        return {'age_hours': age, 'status': 'STALE', 'label': f'🔴 {age/24:.1f}d OLD', 'factor': 0.82}
    return {'age_hours': age, 'status': 'VERY STALE', 'label': f'🔴 {age/24:.1f}d OLD', 'factor': 0.62}


def _gap_score(gap: float | None, long_side: bool) -> float:
    if gap is None:
        return 50.0
    # +/- 33% from fair value maps close to the score extremes.
    signed = float(gap) if long_side else -float(gap)
    return _clamp(50.0 + 150.0 * signed)


def _quality_score(fundamental_score) -> float:
    f = _f(fundamental_score)
    if f is None:
        return 50.0
    return _clamp((f - 1.0) / 4.0 * 100.0)


def evaluate(state: dict, last_successful_refresh: dict | None = None) -> dict:
    """Coverage intelligence: prioritize what deserves research attention.

    This is deliberately NOT a buy/sell recommendation. It ranks research attention by combining
    company quality, valuation gap, forensic evidence, tape confirmation, confidence and freshness.
    """
    price = _f(state.get('price'))
    base = _f(state.get('base_value'))
    ev = _f(state.get('expected_value'))
    scenarios = state.get('scenarios') or {}
    metrics = state.get('metrics') or {}
    scores = state.get('scores') or {}
    fs = state.get('forensics') or {}
    audit = state.get('audit') or {}
    vc = state.get('valuation_confidence') or {}
    gate_counts = state.get('gate_counts') or {}
    valuation_regime = state.get('valuation_regime') or {}
    regime_high = int(valuation_regime.get('high_count', 0) or 0)
    regime_medium = int(valuation_regime.get('medium_count', 0) or 0)

    try:
        from . import fundamentals
        fundamental_score, _ = fundamentals.fundamental_score(metrics) if metrics else (None, {})
    except Exception:
        fundamental_score = None

    last_ts = None
    if last_successful_refresh:
        last_ts = last_successful_refresh.get('completed_at') or last_successful_refresh.get('started_at')
    fresh = freshness(last_ts)

    base_gap = (base / price - 1.0) if price not in (None, 0) and base is not None else None
    ev_gap = (ev / price - 1.0) if price not in (None, 0) and ev is not None else None
    if base_gap is not None and ev_gap is not None:
        valuation_gap = 0.65 * base_gap + 0.35 * ev_gap
    else:
        valuation_gap = base_gap if base_gap is not None else ev_gap

    quality = _quality_score(fundamental_score)
    qv = state.get('quality_validation') or {}
    qv_score = _f(qv.get('score'))
    if qv_score is not None:
        quality = _clamp(0.65 * quality + 0.35 * qv_score)
    mg = state.get('management') or {}
    mg_score = _f(mg.get('score'))
    # Management delivery is a modest modifier, never a substitute for business economics.
    if mg_score is not None and int(mg.get('scorable',0) or 0) >= 3:
        quality = _clamp(quality + (mg_score - 50.0) * 0.08)
    long_value = _gap_score(valuation_gap, True)
    short_value = _gap_score(valuation_gap, False)

    pos_w = _severity_weight(fs.get('positives'))
    neg_w = _severity_weight(fs.get('negatives'))
    evidence_long = _clamp(50 + 7.5 * (pos_w - neg_w))
    evidence_short = _clamp(50 + 7.5 * (neg_w - pos_w))

    tape_conf = _f(scores.get('Confidence'))
    net_tape = _f(scores.get('Net Tape'))
    if tape_conf is None or tape_conf < 30 or net_tape is None:
        tape_long = tape_short = 50.0
    else:
        tape_long = _clamp(net_tape)
        # A bearish tape is more convincing when pressure is high and absorption is poor.
        pressure = _f(scores.get('Short Pressure'))
        absorption = _f(scores.get('Absorption'))
        bearish_extra = 0.0
        if pressure is not None and absorption is not None:
            bearish_extra = max(0.0, pressure - absorption) * 0.15
        tape_short = _clamp(100.0 - net_tape + bearish_extra)

    val_conf = _clamp(_f(vc.get('score')) if _f(vc.get('score')) is not None else 35.0)
    audit_counts = audit.get('counts') or {}
    audit_fail = int(audit_counts.get('FAIL', 0) or 0)
    audit_warn = int(audit_counts.get('WARN', 0) or 0)
    high_data = sum(1 for x in fs.get('data_alerts', []) if str(x.get('Severity')).upper() == 'HIGH')
    data_quality = _clamp(100 - audit_fail * 30 - audit_warn * 6 - high_data * 18)

    raw_long = (
        0.38 * long_value +
        0.26 * quality +
        0.14 * evidence_long +
        0.10 * tape_long +
        0.12 * val_conf
    )
    raw_short = (
        0.38 * short_value +
        0.26 * (100 - quality) +
        0.14 * evidence_short +
        0.10 * tape_short +
        0.12 * val_conf
    )

    # Stale data does not erase a setup; it pulls its score back toward neutral until refreshed.
    freshness_factor = float(fresh['factor'])
    long_score = 50 + (raw_long - 50) * freshness_factor
    short_score = 50 + (raw_short - 50) * freshness_factor
    # Data quality has a similar confidence effect but never fabricates an opposite thesis.
    quality_factor = 0.55 + 0.45 * (data_quality / 100.0)
    long_score = 50 + (long_score - 50) * quality_factor
    short_score = 50 + (short_score - 50) * quality_factor
    long_score = _clamp(long_score)
    short_score = _clamp(short_score)

    pass_gates = int(gate_counts.get('PASS', 0) or 0)
    if pass_gates >= 15:
        actionability = 'DECISION READY'
    elif pass_gates >= 11:
        actionability = 'ADVANCED RESEARCH'
    else:
        actionability = 'RESEARCH FIRST'

    # Setup label describes the fundamental/value relationship, independent of timing.
    if price is None or base is None or fundamental_score is None:
        setup = 'LOW DATA'
    elif valuation_gap is not None and valuation_gap >= 0.30:
        setup = 'SOLID + DEEPLY ATTRACTIVE' if quality >= 70 else 'ATTRACTIVE / VERIFY QUALITY' if quality >= 52 else 'CHEAP / QUALITY RISK'
    elif valuation_gap is not None and valuation_gap >= 0.15:
        setup = 'SOLID + ATTRACTIVE' if quality >= 70 else 'ATTRACTIVE / NEEDS PROOF' if quality >= 52 else 'CHEAP / QUALITY RISK'
    elif valuation_gap is not None and valuation_gap <= -0.30:
        setup = 'WEAK + EXTREME OVERVALUATION' if quality < 50 else 'EXTREME OVERVALUATION / STRONG BUSINESS' if quality >= 72 else 'EXTREME OVERVALUATION'
    elif valuation_gap is not None and valuation_gap <= -0.15:
        setup = 'WEAK + EXPENSIVE' if quality < 50 else 'RICH BUT STRONG' if quality >= 72 else 'EXPENSIVE / WATCH'
    else:
        setup = 'FAIR / NO EDGE'

    data_review = audit_fail > 0 or high_data > 0
    if data_review:
        focus = 'DATA REVIEW'
        system_priority = 1
    elif regime_high > 0:
        focus = 'VALUATION REVIEW'
        system_priority = 1
    elif setup == 'LOW DATA':
        focus = 'LOW DATA'
        system_priority = 5
    elif long_score >= 76 and long_score - short_score >= 10 and val_conf >= 50:
        focus = 'LONG FOCUS'
        system_priority = 1
    elif short_score >= 76 and short_score - long_score >= 10 and val_conf >= 50:
        focus = 'SHORT FOCUS'
        system_priority = 1
    elif long_score >= 64 and long_score - short_score >= 7:
        focus = 'LONG WATCH'
        system_priority = 2
    elif short_score >= 64 and short_score - long_score >= 7:
        focus = 'SHORT WATCH'
        system_priority = 2
    elif abs((valuation_gap or 0.0)) >= 0.15:
        focus = 'VALUATION WATCH'
        system_priority = 3
    else:
        focus = 'NO EDGE'
        system_priority = 4

    # Freshness can demote actionable setups, but never hides DATA REVIEW.
    if focus != 'DATA REVIEW' and fresh['status'] in ('STALE', 'VERY STALE'):
        system_priority = min(5, system_priority + 1)

    reasons: list[str] = []
    if valuation_gap is not None:
        reasons.append(f"value gap {valuation_gap:+.0%}")
    if fundamental_score is not None:
        reasons.append(f"fundamental {fundamental_score:.2f}/5")
    if qv_score is not None:
        reasons.append(f"quality validation {qv_score:.0f}/100")
    if mg_score is not None and int(mg.get('scorable',0) or 0) >= 3:
        reasons.append(f"management delivery {mg_score:.0f}/100")
    if pos_w or neg_w:
        reasons.append(f"forensic +{int(pos_w)}/-{int(neg_w)}")
    if net_tape is not None:
        reasons.append(f"tape {net_tape:.0f}")
    if data_review:
        reasons.insert(0, f"data flags {audit_fail + high_data}")
    elif regime_high:
        reasons.insert(0, f"valuation regime break {regime_high}")
    elif regime_medium:
        reasons.insert(0, f"valuation divergence {regime_medium}")

    next_action = {
        'LONG FOCUS': 'Prioritize long thesis / catalysts / invalidation',
        'LONG WATCH': 'Finish evidence before considering a long',
        'SHORT FOCUS': 'Prioritize bear case / catalyst / squeeze risk',
        'SHORT WATCH': 'Build the short case; valuation alone is not enough',
        'DATA REVIEW': 'Verify source data before trusting valuation or trend',
        'VALUATION REVIEW': 'Explain the current-vs-history multiple regime break before acting',
        'VALUATION WATCH': 'Monitor for evidence/tape convergence',
        'NO EDGE': 'Deprioritize until price or evidence changes',
        'LOW DATA': 'Refresh / complete data first',
    }.get(focus, 'Review')

    return {
        'setup': setup,
        'focus': focus,
        'system_priority': int(system_priority),
        'long_score': round(long_score, 1),
        'short_score': round(short_score, 1),
        'quality_score': round(quality, 1),
        'fundamental_score': fundamental_score,
        'valuation_gap': valuation_gap,
        'base_gap': base_gap,
        'expected_gap': ev_gap,
        'valuation_confidence': val_conf,
        'data_quality': round(data_quality, 1),
        'freshness': fresh,
        'actionability': actionability,
        'reason': ' · '.join(reasons[:4]),
        'next_action': next_action,
    }
