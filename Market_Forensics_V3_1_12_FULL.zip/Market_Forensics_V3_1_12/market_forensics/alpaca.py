from __future__ import annotations

import requests
import time
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from .config import load_alpaca_secrets

BASE = "https://data.alpaca.markets"


class AlpacaError(RuntimeError):
    pass


def _headers():
    s = load_alpaca_secrets()
    if not s:
        raise AlpacaError("Alpaca credentials are missing from the local secrets file.")
    return {"APCA-API-KEY-ID": s["key"], "APCA-API-SECRET-KEY": s["secret"]}


def _get(path, params=None, attempts=4):
    url = BASE + path
    last = None
    for i in range(attempts):
        r = requests.get(url, headers=_headers(), params=params or {}, timeout=45)
        if r.status_code == 200:
            return r.json()
        last = f"HTTP {r.status_code}: {r.text[:500]}"
        if r.status_code in (429, 500, 502, 503, 504):
            time.sleep(1.5 * (i + 1))
            continue
        raise AlpacaError(last)
    raise AlpacaError(last or "Alpaca request failed")


def _feed_candidates(feed_mode: str):
    mode = (feed_mode or "auto").lower()
    if mode == "auto":
        return ["sip", "iex"]
    if mode in ("sip", "iex"):
        return [mode]
    return ["iex"]


def test_connection(feed_mode="auto"):
    account_url = "https://paper-api.alpaca.markets/v2/account"
    r1 = requests.get(account_url, headers=_headers(), timeout=20)
    yesterday = datetime.now(timezone.utc).date() - timedelta(days=2)
    start = yesterday.isoformat()
    end = (yesterday + timedelta(days=1)).isoformat()
    results = {"paper_status": r1.status_code}
    for feed in _feed_candidates(feed_mode):
        r = requests.get(
            f"{BASE}/v2/stocks/NKE/bars",
            headers=_headers(),
            params={"timeframe": "1Day", "start": start, "end": end, "feed": feed, "limit": 5},
            timeout=20,
        )
        results[f"{feed}_historical_status"] = r.status_code
        if r.status_code == 200:
            results["historical_feed"] = feed
            break
    return results



def get_split_events(ticker: str, start_date: str, end_date: str | None = None):
    """Return Alpaca corporate-action split events as ``[(ex_date, ratio), ...]``.

    A successful empty response is meaningful: it verifies that Alpaca's corporate-action ledger
    contains no forward/reverse split for the requested symbol/date range.  The ratio is always
    ``new_rate / old_rate`` so a 4:1 split is 4.0 and a 1:4 reverse split is 0.25.
    """
    t=str(ticker or "").upper().strip()
    if not t:
        return []
    try:
        requested_start=datetime.fromisoformat(str(start_date)[:10]).date()
    except Exception:
        raise AlpacaError("Invalid corporate-action start date")
    try:
        requested_end=(datetime.fromisoformat(str(end_date)[:10]).date() if end_date else datetime.now(timezone.utc).date())
    except Exception:
        requested_end=datetime.now(timezone.utc).date()
    # Alpaca's endpoint filters the request window by process_date, while share-basis logic cares
    # about ex_date. A split can be announced/processed before the SEC share fact but become
    # effective afterward. Query a conservative lookback buffer, then filter returned events by
    # ex_date below. Without this, a pre-announced future split could be silently missed.
    query_start=(requested_start-timedelta(days=400)).isoformat()
    query_end=requested_end.isoformat()
    token=None; out=[]
    while True:
        params={
            "symbols":t, "types":"forward_split,reverse_split",
            "start":query_start, "end":query_end, "limit":1000, "sort":"asc",
            "data_quality":"complete",
        }
        if token: params["page_token"]=token
        j=_get("/v1/corporate-actions",params)
        ca=(j or {}).get("corporate_actions") or {}
        for key in ("forward_splits","reverse_splits"):
            for ev in ca.get(key) or []:
                if str(ev.get("symbol") or "").upper()!=t:
                    continue
                ds=str(ev.get("ex_date") or ev.get("process_date") or "")[:10]
                try:
                    d=datetime.fromisoformat(ds).date()
                    new=float(ev.get("new_rate")); old=float(ev.get("old_rate"))
                    ratio=new/old if old else None
                except Exception:
                    continue
                if ratio and ratio>0 and requested_start <= d <= requested_end:
                    out.append((d,float(ratio)))
        token=(j or {}).get("next_page_token")
        if not token: break
        time.sleep(.05)
    # De-duplicate identical events in case an API page overlaps during an update.
    dedup=[]
    for item in sorted(out,key=lambda x:(x[0],x[1])):
        if item not in dedup: dedup.append(item)
    return dedup

def get_daily_bars(ticker: str, lookback_days=500, feed_mode="auto", adjustment="split"):
    # Historical SIP is attempted first. Alpaca documents that historical SIP can be
    # queried without a live SIP subscription when the end is sufficiently delayed.
    end_dt = datetime.now(timezone.utc) - timedelta(minutes=16)
    start = (end_dt.date() - timedelta(days=lookback_days)).isoformat()
    last_error = None
    for feed in _feed_candidates(feed_mode):
        try:
            j = _get(
                f"/v2/stocks/{ticker.upper()}/bars",
                {
                    "timeframe": "1Day",
                    "start": start,
                    "end": end_dt.isoformat().replace("+00:00", "Z"),
                    "adjustment": str(adjustment or "split"),
                    "feed": feed,
                    "limit": 10000,
                    "sort": "asc",
                },
            )
            out = []
            for b in j.get("bars", []) or []:
                out.append(
                    {
                        "date": b["t"][:10],
                        "open": float(b["o"]), "high": float(b["h"]), "low": float(b["l"]),
                        "close": float(b["c"]), "volume": float(b["v"]),
                        "trade_count": float(b.get("n") or 0), "vwap": float(b.get("vw") or b["c"]),
                    }
                )
            return out, feed
        except AlpacaError as e:
            last_error = e
            continue
    raise last_error or AlpacaError("No Alpaca feed was available.")


def _paged(ticker, kind, start_utc, end_utc, feed):
    token = None
    out = []
    while True:
        params = {
            "start": start_utc.isoformat().replace("+00:00", "Z"),
            "end": end_utc.isoformat().replace("+00:00", "Z"),
            "feed": feed,
            "limit": 10000,
            "sort": "asc",
        }
        if token:
            params["page_token"] = token
        j = _get(f"/v2/stocks/{ticker.upper()}/{kind}", params)
        out.extend(j.get(kind, []) or [])
        token = j.get("next_page_token")
        if not token:
            break
    return out


def regular_session_utc(day):
    eastern = ZoneInfo("America/New_York")
    local_start = datetime(day.year, day.month, day.day, 9, 30, tzinfo=eastern)
    local_end = datetime(day.year, day.month, day.day, 16, 0, tzinfo=eastern)
    return local_start.astimezone(timezone.utc), local_end.astimezone(timezone.utc)


def get_session_trades_quotes(ticker: str, day, feed_mode="auto"):
    start, session_end = regular_session_utc(day)
    delayed_now = datetime.now(timezone.utc) - timedelta(minutes=16)
    end = min(session_end, delayed_now)
    if end <= start:
        return [], [], "none"
    last_error = None
    for feed in _feed_candidates(feed_mode):
        try:
            trades = _paged(ticker, "trades", start, end, feed)
            quotes = _paged(ticker, "quotes", start, end, feed)
            return trades, quotes, feed
        except AlpacaError as e:
            last_error = e
            continue
    raise last_error or AlpacaError("No Alpaca feed was available for trades/quotes.")



def get_asset(ticker: str):
    """Resolve one US-equity symbol against Alpaca's asset master. Returns None on a clean 404."""
    t=str(ticker or "").upper().strip()
    if not t:
        return None
    url=f"https://paper-api.alpaca.markets/v2/assets/{t}"
    r=requests.get(url,headers=_headers(),timeout=20)
    if r.status_code==404:
        return None
    if r.status_code!=200:
        raise AlpacaError(f"Asset HTTP {r.status_code}: {r.text[:300]}")
    x=r.json() or {}
    return {
        "ticker":str(x.get("symbol") or t).upper(),
        "name":x.get("name") or "",
        "exchange":x.get("exchange") or "",
        "status":x.get("status") or "",
        "tradable":bool(x.get("tradable",True)),
    }

def get_active_us_assets():
    """Return Alpaca's current active US-equity master list.

    Uses the Trading API, which is a better universe source than guessing exchanges from ticker text.
    """
    url = "https://paper-api.alpaca.markets/v2/assets"
    r = requests.get(url, headers=_headers(), params={"status": "active", "asset_class": "us_equity"}, timeout=45)
    if r.status_code != 200:
        raise AlpacaError(f"Assets HTTP {r.status_code}: {r.text[:500]}")
    out = []
    for x in r.json() or []:
        symbol = str(x.get("symbol") or "").upper().strip()
        if not symbol:
            continue
        attrs = x.get("attributes") or []
        out.append({
            "ticker": symbol,
            "name": x.get("name") or "",
            "exchange": x.get("exchange") or "",
            "tradable": bool(x.get("tradable", True)),
            "shortable": bool(x.get("shortable", False)),
            "borrow_status": x.get("borrow_status") or ("EASY" if x.get("easy_to_borrow") else ""),
            "has_options": "has_options" in attrs,
        })
    return out


def get_snapshots(tickers, feed_mode="auto", chunk_size=100):
    """Latest multi-symbol stock snapshots with automatic SIP->IEX fallback.

    Returns (mapping, feed). The mapping is keyed by uppercase ticker.
    """
    names = []
    seen = set()
    for raw in tickers:
        t = str(raw or "").upper().strip()
        if t and t not in seen:
            seen.add(t); names.append(t)
    if not names:
        return {}, "none"
    last_error = None
    for feed in _feed_candidates(feed_mode):
        try:
            merged = {}
            for i in range(0, len(names), max(1, int(chunk_size))):
                chunk = names[i:i+max(1, int(chunk_size))]
                j = _get("/v2/stocks/snapshots", {"symbols": ",".join(chunk), "feed": feed})
                # Alpaca has returned both direct symbol maps and {snapshots:{...}} across SDK/docs eras.
                data = j.get("snapshots") if isinstance(j, dict) and isinstance(j.get("snapshots"), dict) else j
                for t, snap in (data or {}).items():
                    merged[str(t).upper()] = snap or {}
                if i + chunk_size < len(names):
                    time.sleep(0.08)
            return merged, feed
        except AlpacaError as e:
            last_error = e
            continue
    raise last_error or AlpacaError("No Alpaca snapshot feed was available.")
