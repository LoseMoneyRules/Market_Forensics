from __future__ import annotations
import json, os
from pathlib import Path

APP_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "MarketForensics"
APP_DIR.mkdir(parents=True, exist_ok=True)
SECRETS_PATH = APP_DIR / "alpaca_secrets.json"
MARKET_DATA_SECRETS_PATH = APP_DIR / "market_data_secrets.json"
SETTINGS_PATH = APP_DIR / "settings.json"
DB_PATH = APP_DIR / "market_forensics.sqlite"
BRAND_DIR = APP_DIR / "branding"
BRAND_DIR.mkdir(parents=True, exist_ok=True)
BRAND_LOGO_PATH = BRAND_DIR / "logo.png"

DEFAULT_SETTINGS = {
    "alpaca_feed": "auto",
    "sec_user_agent": "",
    "flow_days": 5,
    "large_percentile": 0.75,
    "very_large_percentile": 0.90,
    "whale_percentile": 0.99,
    "minimum_notional": 25000.0,
    "daily_lookback_days": 500,
    "valuation_history_days": 3650,
    "portfolio_nav": 0.0,
    "number_display": "AUTO",
    "management_filing_limit": 18,
    "discovery_min_price": 3.0,
    "discovery_min_dollar_volume": 5000000.0,
    "discovery_max_symbols": 600,
    "discovery_fundamental_age_days": 7,
    "discovery_hide_no_edge": True,
    "market_data_order": ["ALPACA", "IBKR", "TIINGO", "ALPHA_VANTAGE"],
    "ibkr_enabled": False,
    "ibkr_base_url": "https://localhost:5000/v1/api",
    "price_crosscheck_enabled": True,
    "price_crosscheck_warn_pct": 0.005,
    "price_crosscheck_fail_pct": 0.02,
}

def _clamp_int(value, default: int, lo: int, hi: int) -> int:
    try:
        return max(lo, min(hi, int(value)))
    except (TypeError, ValueError):
        return default

def _clamp_float(value, default: float, lo: float | None = None, hi: float | None = None) -> float:
    try:
        out = float(value)
    except (TypeError, ValueError):
        out = default
    if lo is not None:
        out = max(lo, out)
    if hi is not None:
        out = min(hi, out)
    return out

def normalize_settings(settings: dict | None) -> dict:
    """Return settings that are always safe for current UI/widget bounds.

    Older builds and synthetic tests may persist values outside newer widget
    ranges. Normalizing at the configuration boundary prevents Streamlit from
    failing before the user has a chance to correct the setting.
    """
    raw = dict(settings or {})
    out = dict(DEFAULT_SETTINGS)
    out.update(raw)

    feed = str(out.get("alpaca_feed", "auto")).lower()
    out["alpaca_feed"] = feed if feed in {"auto", "sip", "iex"} else "auto"
    mode = str(out.get("number_display", "AUTO")).upper()
    out["number_display"] = mode if mode in {"AUTO", "PLAIN", "K", "M", "B"} else "AUTO"

    out["flow_days"] = _clamp_int(out.get("flow_days"), 5, 1, 20)
    out["management_filing_limit"] = _clamp_int(out.get("management_filing_limit"), 18, 6, 60)
    out["discovery_max_symbols"] = _clamp_int(out.get("discovery_max_symbols"), 600, 100, 2000)
    out["discovery_fundamental_age_days"] = _clamp_int(out.get("discovery_fundamental_age_days"), 7, 1, 30)

    out["price_crosscheck_warn_pct"] = _clamp_float(out.get("price_crosscheck_warn_pct"), 0.005, 0.0001, 0.10)
    out["price_crosscheck_fail_pct"] = _clamp_float(out.get("price_crosscheck_fail_pct"), 0.02, 0.001, 0.25)
    if out["price_crosscheck_fail_pct"] < out["price_crosscheck_warn_pct"]:
        out["price_crosscheck_fail_pct"] = max(0.02, out["price_crosscheck_warn_pct"] * 2)
    order = out.get("market_data_order")
    allowed = ["ALPACA", "IBKR", "TIINGO", "ALPHA_VANTAGE"]
    if not isinstance(order, list):
        order = allowed
    cleaned = [str(x).upper() for x in order if str(x).upper() in allowed]
    out["market_data_order"] = cleaned + [x for x in allowed if x not in cleaned]
    out["ibkr_enabled"] = bool(out.get("ibkr_enabled", False))
    out["ibkr_base_url"] = str(out.get("ibkr_base_url") or "https://localhost:5000/v1/api").strip()
    out["price_crosscheck_enabled"] = bool(out.get("price_crosscheck_enabled", True))

    out["minimum_notional"] = _clamp_float(out.get("minimum_notional"), 25000.0, 0.0)
    out["portfolio_nav"] = _clamp_float(out.get("portfolio_nav"), 0.0, 0.0)
    out["discovery_min_price"] = _clamp_float(out.get("discovery_min_price"), 3.0, 0.0)
    out["discovery_min_dollar_volume"] = _clamp_float(out.get("discovery_min_dollar_volume"), 5_000_000.0, 0.0)
    return out

def load_settings() -> dict:
    stored = {}
    if SETTINGS_PATH.exists():
        try:
            stored = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
        except Exception:
            stored = {}
    return normalize_settings(stored)

def save_settings(settings: dict) -> None:
    SETTINGS_PATH.write_text(json.dumps(normalize_settings(settings), indent=2), encoding="utf-8")

def load_alpaca_secrets() -> dict:
    if not SECRETS_PATH.exists():
        return {}
    try:
        data = json.loads(SECRETS_PATH.read_text(encoding="utf-8-sig"))
        key = str(data.get("ALPACA_API_KEY", "")).strip()
        secret = str(data.get("ALPACA_SECRET_KEY", "")).strip()
        if not key or not secret or key.startswith("YOUR_") or secret.startswith("YOUR_"):
            return {}
        return {"key": key, "secret": secret}
    except Exception:
        return {}

def alpaca_ready() -> bool:
    s = load_alpaca_secrets()
    return bool(s.get("key") and s.get("secret"))


def load_market_data_secrets() -> dict:
    if not MARKET_DATA_SECRETS_PATH.exists():
        return {}
    try:
        raw = json.loads(MARKET_DATA_SECRETS_PATH.read_text(encoding="utf-8-sig"))
    except Exception:
        return {}
    out = {}
    for key in ("TIINGO_API_KEY", "ALPHA_VANTAGE_API_KEY", "MASSIVE_API_KEY"):
        value = str(raw.get(key, "") or "").strip()
        if value and not value.startswith("YOUR_"):
            out[key] = value
    return out

def save_market_data_secrets(values: dict) -> None:
    current = load_market_data_secrets()
    for key in ("TIINGO_API_KEY", "ALPHA_VANTAGE_API_KEY", "MASSIVE_API_KEY"):
        value = str((values or {}).get(key, "") or "").strip()
        if value:
            current[key] = value
    MARKET_DATA_SECRETS_PATH.write_text(json.dumps(current, indent=2), encoding="utf-8")


def clear_market_data_secrets(keys=None) -> None:
    current = load_market_data_secrets()
    targets = set(keys or current.keys())
    for key in list(current):
        if key in targets:
            current.pop(key, None)
    MARKET_DATA_SECRETS_PATH.write_text(json.dumps(current, indent=2), encoding="utf-8")


def branding_logo_path():
    """Return the persisted user logo path when configured and readable."""
    try:
        return BRAND_LOGO_PATH if BRAND_LOGO_PATH.exists() and BRAND_LOGO_PATH.stat().st_size > 0 else None
    except Exception:
        return None

def save_branding_logo(data: bytes) -> Path:
    """Persist a PNG/JPEG image as a normalized PNG for app/report branding."""
    from io import BytesIO
    from PIL import Image
    raw = bytes(data or b"")
    if not raw:
        raise ValueError("Logo file is empty.")
    with Image.open(BytesIO(raw)) as im:
        im = im.convert("RGBA")
        # Keep reports fast and deterministic while preserving enough detail for logos.
        im.thumbnail((1600, 600))
        canvas = Image.new("RGBA", im.size, (255,255,255,0))
        canvas.alpha_composite(im)
        canvas.save(BRAND_LOGO_PATH, format="PNG", optimize=True)
    return BRAND_LOGO_PATH

def clear_branding_logo() -> None:
    try:
        BRAND_LOGO_PATH.unlink(missing_ok=True)
    except Exception:
        pass
