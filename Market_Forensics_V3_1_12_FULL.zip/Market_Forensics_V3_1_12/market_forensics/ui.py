from __future__ import annotations
import math
import pandas as pd


def missing(x) -> bool:
    if x is None:
        return True
    try:
        return bool(pd.isna(x))
    except Exception:
        return False


def fnum(x, decimals=1, suffix=""):
    if missing(x): return "—"
    try: return f"{float(x):,.{decimals}f}{suffix}"
    except Exception: return "—"


def fpct(x, decimals=1):
    if missing(x): return "—"
    try: return f"{100*float(x):.{decimals}f}%"
    except Exception: return "—"


def fmoney(x, decimals_small=0, mode="AUTO"):
    if missing(x): return "—"
    try: x=float(x)
    except Exception: return "—"
    mode=str(mode or "AUTO").upper()
    scales={"K":1e3,"M":1e6,"B":1e9,"T":1e12}
    if mode == "PLAIN":
        return f"${x:,.{decimals_small}f}"
    if mode in scales:
        scale=scales[mode]
        return f"${x/scale:,.2f}{mode}"
    a=abs(x)
    if a>=1e12:return f"${x/1e12:.2f}T"
    if a>=1e9:return f"${x/1e9:.2f}B"
    if a>=1e6:return f"${x/1e6:.1f}M"
    if a>=1e3:return f"${x/1e3:.1f}K"
    return f"${x:,.{decimals_small}f}"


def fprice(x):
    if missing(x): return "—"
    try:return f"${float(x):,.2f}"
    except Exception:return "—"


def status_icon(status: str) -> str:
    return {"PASS":"●", "WATCH":"●", "FAIL":"●", "INCOMPLETE":"○", "TRIGGERED":"●", "MISS":"●", "NO DATA":"○"}.get(status or "", "○")


def safe_float(x, default=None):
    try:
        v=float(x)
        return v if math.isfinite(v) else default
    except Exception:return default
