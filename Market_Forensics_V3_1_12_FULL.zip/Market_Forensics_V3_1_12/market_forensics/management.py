from __future__ import annotations

import hashlib
import html as html_lib
import math
import re
from dataclasses import dataclass
from datetime import date, datetime, timezone
from html.parser import HTMLParser

from . import db, fundamentals, sec


PARSER_VERSION = 5

# Candidate language can be broad, but only explicit forward guidance below is allowed to become
# a scored numeric management promise.
_GUIDANCE_WORDS = re.compile(
    r"\b(expect|expects|expected|anticipate|anticipates|forecast|forecasts|guidance|target|targets|"
    r"outlook|project|projects|projected|estimate|estimates|estimated|guide|guides)\b",
    re.I,
)
_STRONG_GUIDANCE = re.compile(
    r"\b(?:we|management|the company|company|our team)?\s*(?:expect|anticipate|forecast|project|target|estimate|guide)s?\b|"
    r"\b(?:our\s+)?(?:guidance|outlook)\b|\b(?:is|are)\s+expected\s+to\b",
    re.I,
)
_NUMERIC = re.compile(r"(?:\$\s*)?\d+(?:\.\d+)?\s*(?:%|percent|bps|basis points|million|billion|mm|bn|m|b)?", re.I)
_YEAR4 = re.compile(r"\b(?:FY\s*|fiscal(?:\s+year)?\s*)?(20\d{2})\b", re.I)
_YEAR2 = re.compile(r"\bFY\s*['’]?\s*(\d{2})\b", re.I)
_NONCOMPARABLE_BASIS = re.compile(r"\b(adjusted|non[- ]?gaap|organic|constant[- ]currency|constant currency|comparable|excluding|ex[- ]fx|fx[- ]neutral)\b", re.I)
_INTERIM_PERIOD = re.compile(r"\b(q[1-4]|first quarter|second quarter|third quarter|fourth quarter|quarterly|first half|second half|half[- ]year|six months|nine months)\b", re.I)

_METRICS = [
    ("revenue_growth", re.compile(r"\b(revenue|revenues|sales|net sales)\b.{0,80}\b(grow|growth|increase|decline|decrease)\b|\b(grow|growth)\b.{0,80}\b(revenue|sales)\b", re.I)),
    ("gross_margin", re.compile(r"\bgross\s+margin\b", re.I)),
    ("operating_margin", re.compile(r"\b(operating|ebit)\s+margin\b", re.I)),
    ("net_margin", re.compile(r"\bnet\s+(income|profit)\s+margin\b", re.I)),
    ("fcf_margin", re.compile(r"\bfree\s+cash\s+flow\s+margin\b", re.I)),
    ("fcf", re.compile(r"\bfree\s+cash\s+flow\b", re.I)),
    ("capex", re.compile(r"\b(capex|capital expenditures?|capital spending)\b", re.I)),
    ("eps", re.compile(r"\b(diluted\s+)?(eps|earnings per share)\b", re.I)),
    ("revenue", re.compile(r"\b(revenue|revenues|net sales|sales)\b", re.I)),
    ("buybacks", re.compile(r"\b(share repurchases?|stock repurchases?|buybacks?)\b", re.I)),
]


class _TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        if tag.lower() in {"script", "style", "noscript"}:
            self._skip += 1
        elif tag.lower() in {"p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4"}:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag.lower() in {"script", "style", "noscript"} and self._skip:
            self._skip -= 1
        elif tag.lower() in {"p", "div", "li", "tr"}:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self._skip:
            self.parts.append(data)


def html_to_text(raw: str) -> str:
    p = _TextExtractor()
    try:
        p.feed(raw or "")
        text = " ".join(p.parts)
    except Exception:
        text = re.sub(r"<[^>]+>", " ", raw or "")
    text = html_lib.unescape(text)
    text = re.sub(r"[\t\r\f\v]+", " ", text)
    text = re.sub(r" +", " ", text)
    text = re.sub(r"\n\s*\n+", "\n", text)
    return text.strip()


def _metric_keys(sentence: str) -> list[str]:
    keys=[key for key,pat in _METRICS if pat.search(sentence or "")]
    # Remove generic parents when a more specific metric was identified.
    if "revenue_growth" in keys and "revenue" in keys: keys.remove("revenue")
    if "fcf_margin" in keys and "fcf" in keys: keys.remove("fcf")
    return list(dict.fromkeys(keys))


def _metric_key(sentence: str) -> str | None:
    keys=_metric_keys(sentence)
    return keys[0] if len(keys)==1 else None


def _guidance_clause(sentence: str) -> str | None:
    """Return the forward-guidance clause while preserving a preposed target-FY label.

    Filings commonly say ``For fiscal 2026, we expect ...`` or ``Fiscal 2026 guidance: we
    expect ...``.  Starting exactly at ``we expect`` loses the target year.  Conversely a
    historical lead-in such as ``Revenue grew in fiscal 2024; we expect fiscal 2025 ...`` must
    not contaminate the target.  Preserve only an immediately-adjacent *forward label*; discard
    all other prefix text.
    """
    text=sentence or ""
    m=_STRONG_GUIDANCE.search(text)
    if not m:return None
    prefix=text[max(0,m.start()-90):m.start()]
    keep=""
    # Safe preposed forms only.  Do not accept generic ``in fiscal 2024`` because that is often
    # a historical comparison rather than the guidance period.
    # Check interim forms BEFORE the generic fiscal-year suffix; otherwise ``For Q1 fiscal 2026``
    # would collapse to just ``fiscal 2026`` and lose the quarterly warning.
    pm=re.search(r"((?:for\s+(?:the\s+)?)?(?:q[1-4]|first\s+quarter|second\s+quarter|third\s+quarter|fourth\s+quarter|first\s+half|second\s+half)(?:\s+of)?\s+(?:fiscal(?:\s+year)?\s+20\d{2}|FY\s*['’]?\s*\d{2})\s*[,;:]?\s*)$",prefix,re.I)
    if not pm:
        pm=re.search(r"((?:for\s+)?(?:fiscal(?:\s+year)?\s+20\d{2}|FY\s*['’]?\s*\d{2})\s*[,;:]?\s*)$",prefix,re.I)
    if not pm:
        pm=re.search(r"((?:fiscal(?:\s+year)?\s+20\d{2}|FY\s*['’]?\s*\d{2})\s+(?:guidance|outlook)\s*[:;,]?\s*)$",prefix,re.I)
    if pm:keep=pm.group(1)
    return (keep+text[m.start():].strip())[:700]


def _normalize_year_token(token: str) -> int | None:
    try:y=int(token)
    except Exception:return None
    return 2000+y if 0 <= y <= 99 else y


def _target_year(clause: str, filed: str) -> int | None:
    """Return one unambiguous target fiscal year, excluding comparison years."""
    text=clause or ""
    try:filed_year=int(str(filed)[:4])
    except Exception:filed_year=0
    def norm(raw):
        y=_normalize_year_token(raw)
        return y if y is not None and y >= filed_year-1 and y <= filed_year+5 else None

    # Strongest evidence: an explicit period label at the start of the preserved guidance clause.
    for rx in (
        re.compile(r"^\s*(?:for\s+)?fiscal(?:\s+year)?\s+(20\d{2})\b",re.I),
        re.compile(r"^\s*(?:for\s+)?FY\s*['’]?\s*(\d{2})\b",re.I),
        re.compile(r"^\s*fiscal(?:\s+year)?\s+(20\d{2})\s+(?:guidance|outlook)\b",re.I),
        re.compile(r"^\s*FY\s*['’]?\s*(\d{2})\s+(?:guidance|outlook)\b",re.I),
    ):
        m=rx.search(text)
        if m:
            return norm(m.group(1))

    # Comparison tails must never supply the target FY. Search only the forward side of the clause.
    forward=re.split(r"\b(?:vs\.?|versus|compared\s+(?:with|to)|against)\b",text,maxsplit=1,flags=re.I)[0]
    candidates=[]
    for rx,short in ((_YEAR4,False),(_YEAR2,True)):
        for m in rx.finditer(forward):
            y=_normalize_year_token(m.group(1)) if short else int(m.group(1))
            if norm(str(y)) is not None:candidates.append(y)
    candidates=list(dict.fromkeys(candidates))
    return candidates[0] if len(candidates)==1 else None


def _scale_number(value: float, suffix: str | None) -> float:
    s = (suffix or "").lower().replace(" ", "")
    if s in {"billion", "bn", "b"}: return value * 1_000_000_000
    if s in {"million", "mm", "m"}: return value * 1_000_000
    return value


def _direction_sign(text: str) -> float | None:
    if re.search(r"\b(expand|expansion|improve|improvement|increase|up)\b",text,re.I):return 1.0
    if re.search(r"\b(contract|contraction|decline|decrease|down|compress|compression)\b",text,re.I):return -1.0
    return None


def _kind_from_language(text: str) -> str:
    if re.search(r"\b(at least|not less than|more than|greater than|above)\b",text,re.I):return "AT_LEAST"
    if re.search(r"\b(at most|not more than|less than|below|no more than)\b",text,re.I):return "AT_MOST"
    return "APPROX"


def _extract_target(clause: str, metric_key: str | None) -> dict:
    out={"target_low":None,"target_high":None,"target_kind":"QUALITATIVE","unit":""}
    if not metric_key or not clause:return out

    # Basis-point guidance is a CHANGE in a margin/growth rate, not an absolute margin level.
    if metric_key in {"revenue_growth","gross_margin","operating_margin","net_margin","fcf_margin"}:
        bpr=re.search(r"(\d+(?:\.\d+)?)\s*(?:to|through|[-–—])\s*(\d+(?:\.\d+)?)\s*(?:bps|basis\s+points?)",clause,re.I)
        bps=re.search(r"(\d+(?:\.\d+)?)\s*(?:bps|basis\s+points?)",clause,re.I)
        if bpr or bps:
            sign=_direction_sign(clause)
            if sign is None:return out
            lo=float((bpr or bps).group(1))/10000.0
            hi=float(bpr.group(2))/10000.0 if bpr else lo
            vals=sorted([sign*lo,sign*hi])
            out.update(target_low=vals[0],target_high=vals[1],target_kind="RANGE_CHANGE" if bpr else "APPROX_CHANGE",unit="ratio_change")
            return out

    # Percentage ranges/levels. Require both endpoints to display percent on a range.
    rp=re.search(r"(\d+(?:\.\d+)?)\s*%\s*(?:to|through|[-–—])\s*(\d+(?:\.\d+)?)\s*%",clause,re.I)
    if rp and metric_key in {"revenue_growth","gross_margin","operating_margin","net_margin","fcf_margin"}:
        lo,hi=sorted([float(rp.group(1))/100.0,float(rp.group(2))/100.0])
        out.update(target_low=lo,target_high=hi,target_kind="RANGE",unit="ratio");return out
    sp=re.search(r"(?<!\d)(\d+(?:\.\d+)?)\s*%",clause,re.I)
    if sp and metric_key in {"revenue_growth","gross_margin","operating_margin","net_margin","fcf_margin"}:
        val=float(sp.group(1))/100.0
        # For revenue growth, explicit decline/decrease means a negative rate.
        if metric_key=="revenue_growth" and re.search(r"\b(decline|decrease|down)\b",clause,re.I):val=-val
        out.update(target_low=val,target_high=val,target_kind=_kind_from_language(clause),unit="ratio");return out

    # EPS dollars: explicit $ range/single; no scale suffix. This avoids interpreting years as EPS.
    if metric_key=="eps":
        er=re.search(r"\$\s*(\d+(?:\.\d+)?)\s*(?:to|through|[-–—])\s*\$?\s*(\d+(?:\.\d+)?)",clause,re.I)
        if not er and re.search(r"\b(?:gaap\s+)?(?:diluted\s+)?(?:eps|earnings per share)\b",clause,re.I):
            er=re.search(r"(?:eps|earnings per share).{0,50}?(\d+(?:\.\d+)?)\s*(?:to|through|[-–—]|and)\s*(\d+(?:\.\d+)?)",clause,re.I)
        if er:
            lo,hi=sorted([float(er.group(1)),float(er.group(2))])
            if 0 <= lo < 100 and 0 < hi < 100:
                out.update(target_low=lo,target_high=hi,target_kind="RANGE",unit="USD_per_share");return out
        es=re.search(r"\$\s*(\d+(?:\.\d+)?)",clause,re.I)
        if not es and re.search(r"\b(?:gaap\s+)?diluted\s+(?:eps|earnings per share)\b",clause,re.I):
            es=re.search(r"(?:eps|earnings per share).{0,40}?(\d+(?:\.\d+)?)",clause,re.I)
        if es:
            val=float(es.group(1))
            if 0 < val < 100:
                out.update(target_low=val,target_high=val,target_kind=_kind_from_language(clause),unit="USD_per_share");return out
        return out

    # Monetary levels need currency/scale markers. Buyback authorization caps ('up to') are not
    # delivery promises and intentionally remain unscored.
    if metric_key=="buybacks" and re.search(r"\b(up to|authorization|authorized|authorize)\b",clause,re.I):
        return out
    mr=re.search(r"\$?\s*(\d+(?:\.\d+)?)\s*(billion|million|bn|mm|b|m)\s*(?:to|through|[-–—])\s*\$?\s*(\d+(?:\.\d+)?)\s*(billion|million|bn|mm|b|m)",clause,re.I)
    if mr and metric_key in {"revenue","fcf","capex","buybacks"}:
        lo=_scale_number(float(mr.group(1)),mr.group(2));hi=_scale_number(float(mr.group(3)),mr.group(4));lo,hi=sorted([lo,hi])
        out.update(target_low=lo,target_high=hi,target_kind="RANGE",unit="USD");return out
    ms=re.search(r"\$\s*(\d+(?:\.\d+)?)\s*(billion|million|bn|mm|b|m)?",clause,re.I)
    if ms and metric_key in {"revenue","fcf","capex","buybacks"}:
        val=_scale_number(float(ms.group(1)),ms.group(2));out.update(target_low=val,target_high=val,target_kind=_kind_from_language(clause),unit="USD");return out
    return out


def _statement_sentences(text: str):
    # SEC documents can be huge. Retain sentence-like chunks with context but cap pathological lengths.
    chunks = re.split(r"(?<=[.!?])\s+(?=[A-Z0-9])|\n+", text)
    for raw in chunks:
        s = re.sub(r"\s+", " ", raw).strip()
        if 40 <= len(s) <= 900:
            yield s


def extract_management_statements(text: str, *, ticker: str, form: str, filed: str, source_url: str, accession: str = "", document_type: str = "PRIMARY", max_candidates: int = 120) -> list[dict]:
    rows=[];seen=set()
    for sentence in _statement_sentences(text):
        if not _GUIDANCE_WORDS.search(sentence):continue
        clause=_guidance_clause(sentence)
        full_keys=_metric_keys(sentence);clause_keys=_metric_keys(clause or "")
        metric=clause_keys[0] if len(clause_keys)==1 else None
        has_number=bool(_NUMERIC.search(clause or sentence))
        if not full_keys and not has_number:continue
        norm=sentence.lower();sig=hashlib.sha1((ticker.upper()+"|v5|"+norm).encode("utf-8","ignore")).hexdigest()
        if sig in seen:continue
        seen.add(sig)
        target=_extract_target(clause or "",metric) if clause else {"target_low":None,"target_high":None,"target_kind":"QUALITATIVE","unit":""}
        target_fy=_target_year(clause or "",filed) if clause else None
        # Fail closed: a numeric score requires one unambiguous metric, annual scope, comparable
        # GAAP/reporting basis, explicit forward language, one target FY and a parsed target.
        # Management-defined FCF often differs from CFO-capex; keep it as evidence unless a future
        # definition-reconciliation layer can prove comparability.
        basis_safe=not bool(_NONCOMPARABLE_BASIS.search(clause or ""))
        annual_scope=not bool(_INTERIM_PERIOD.search(clause or ""))
        eps_safe=(metric!="eps") or bool(re.search(r"\b(?:gaap\s+)?diluted\s+(?:eps|earnings per share)\b|\bgaap\s+eps\b",clause or "",re.I))
        definition_safe=metric not in {"fcf","fcf_margin"}
        scorable=bool(clause and metric and len(clause_keys)==1 and target_fy and target["target_low"] is not None
                      and basis_safe and annual_scope and eps_safe and definition_safe)
        confidence=0.35
        if clause:confidence+=0.15
        if metric:confidence+=0.15
        if target["target_low"] is not None:confidence+=0.18
        if target_fy:confidence+=0.12
        if re.search(r"\b(we expect|we anticipate|we forecast|we project|we target|guidance|our outlook)\b",clause or "",re.I):confidence+=0.10
        if len(clause_keys)>1:confidence=min(confidence,0.49)
        if not scorable:confidence=min(confidence,0.79)
        confidence=min(confidence,0.98)
        rows.append({
            "ticker":ticker.upper(),"statement_hash":sig,"form":form,"filed":filed,"accession":accession,
            "document_type":document_type,"source_url":source_url,"statement":sentence,
            "metric_key":metric or "","target_fiscal_year":target_fy,"target_low":target["target_low"],"target_high":target["target_high"],
            "target_kind":target["target_kind"],"unit":target["unit"],"extract_confidence":confidence,"created_at":db.now_utc(),
        })
        if len(rows)>=max_candidates:break
    return rows


def _annual_rows(ticker: str) -> list[dict]:
    rows = db.query("SELECT * FROM fundamentals WHERE ticker=? AND period_type='FY' ORDER BY fiscal_year", (ticker.upper(),))
    return rows


def _bar_factor_at(ticker: str, iso_date: str | None):
    if not iso_date:return None
    rows=db.query("SELECT trade_date,split_factor,split_factor_verified,basis_verified FROM daily_bars WHERE ticker=? AND trade_date<=? ORDER BY trade_date DESC LIMIT 1",(ticker.upper(),str(iso_date)[:10]))
    if not rows:return None
    r=rows[0]
    # Management EPS comparability needs only the verified split ledger, not proof of historical
    # raw-vs-adjusted OHLC semantics. Historical price validation remains stricter elsewhere.
    if not bool(r.get("split_factor_verified") or r.get("basis_verified")):return None
    try:f=float(r.get("split_factor") or 1.0)
    except Exception:return None
    return f if f>0 else None


def _reported(row: dict, key: str, *, strict_pit: bool = True):
    """Annual value on the original-publication basis.

    Management delivery must not be rewritten by later comparative restatements.  Therefore
    scoring is fail-closed by default: if the first-reported PIT value is unavailable, return
    None instead of silently substituting today's restated value.
    """
    if not row:
        return None
    pit=row.get(f"pit_{key}")
    if pit is not None:
        return pit
    return None if strict_pit else row.get(key)


def _annual_metric(row: dict, metric: str):
    # Management delivery is judged on the result originally reported for that fiscal year.
    # Later comparative-period restatements must not silently rewrite the score.
    rev=_reported(row,"revenue")
    if metric=="revenue":return rev,"USD"
    if metric=="fcf":return _reported(row,"fcf"),"USD"
    if metric=="capex":return _reported(row,"capex"),"USD"
    if metric=="buybacks":return _reported(row,"buybacks"),"USD"
    gp=_reported(row,"gross_profit"); oi=_reported(row,"operating_income"); ni=_reported(row,"net_income"); fcf=_reported(row,"fcf")
    if metric=="gross_margin" and rev:return ((gp/rev) if gp is not None else None),"ratio"
    if metric=="operating_margin" and rev:return ((oi/rev) if oi is not None else None),"ratio"
    if metric=="net_margin" and rev:return ((ni/rev) if ni is not None else None),"ratio"
    if metric=="fcf_margin" and rev:return ((fcf/rev) if fcf is not None else None),"ratio"
    return None,None


def _actual_for_statement(stmt: dict, annual_rows: list[dict], ticker: str | None = None):
    fy=stmt.get("target_fiscal_year")
    if not fy:return None,None
    by={int(r.get("fiscal_year")):r for r in annual_rows if r.get("fiscal_year") is not None};row=by.get(int(fy))
    if not row:return None,None
    metric=stmt.get("metric_key");unit=stmt.get("unit") or ""
    if metric=="eps":
        # Use the EPS actually reported for that FY, not NI / one share-count snapshot. Compare on
        # the share basis that existed when management issued the guidance.
        eps=row.get("pit_diluted_eps") if row.get("pit_diluted_eps") is not None else row.get("diluted_eps_reported")
        eps_filed=row.get("pit_diluted_eps_filed") or row.get("diluted_eps_filed") or row.get("period_filed")
        if eps is None:return None,"USD_per_share"
        if ticker:
            sf=_bar_factor_at(ticker,stmt.get("filed"));af=_bar_factor_at(ticker,eps_filed)
            if sf is None or af is None:return None,"USD_per_share"
            eps=float(eps)*sf/af
        return float(eps),"USD_per_share"
    if metric=="revenue_growth":
        prev=by.get(int(fy)-1)
        prev_rev=_reported(prev or {},"revenue"); cur_rev=_reported(row,"revenue")
        if prev_rev not in (None,0) and cur_rev is not None:
            return float(cur_rev)/float(prev_rev)-1,"ratio"
        return None,"ratio"
    if unit=="ratio_change" and metric in {"gross_margin","operating_margin","net_margin","fcf_margin"}:
        prev=by.get(int(fy)-1);curv,_=_annual_metric(row,metric);prevv,_=_annual_metric(prev or {},metric)
        if curv is not None and prevv is not None:return float(curv)-float(prevv),"ratio_change"
        return None,"ratio_change"
    return _annual_metric(row,metric)


def _evaluate(actual, low, high, kind, unit):
    if actual is None or low is None:return "UNVERIFIED",None
    a=float(actual);lo=float(low);hi=float(high if high is not None else low)
    if lo>hi:lo,hi=hi,lo
    # Tolerance is deliberately tight and unit-aware. 'NEAR' is reported separately and receives
    # only partial credit; it is never silently counted as MET.
    if unit in {"ratio","ratio_change"}:tol=max(0.0015,abs((lo+hi)/2)*0.03)
    elif unit=="USD_per_share":tol=max(0.03,abs((lo+hi)/2)*0.025)
    else:tol=max(1.0,abs((lo+hi)/2)*0.02)
    if kind in {"AT_LEAST","AT_LEAST_CHANGE"}:
        if a+tol>=lo:return "MET",100.0
        if a+2*tol>=lo:return "NEAR",60.0
        return "MISSED",0.0
    if kind in {"AT_MOST","AT_MOST_CHANGE"}:
        if a-tol<=hi:return "MET",100.0
        if a-2*tol<=hi:return "NEAR",60.0
        return "MISSED",0.0
    if lo-tol<=a<=hi+tol:return "MET",100.0
    gap=min(abs(a-lo),abs(a-hi));scale=max(abs((lo+hi)/2),0.01 if unit in {"ratio","ratio_change"} else 0.10)
    if gap/scale<=0.08:return "NEAR",60.0
    return "MISSED",0.0




def _scoreability_note(stmt: dict) -> str:
    text=str(stmt.get("statement") or "")
    metric=str(stmt.get("metric_key") or "")
    conf=float(stmt.get("extract_confidence") or 0)
    if _NONCOMPARABLE_BASIS.search(text):
        return "Evidence only: adjusted/non-GAAP/organic basis is not directly comparable to SEC GAAP actuals."
    if _INTERIM_PERIOD.search(text):
        return "Evidence only: interim/quarter guidance is not scored against a full-year actual."
    if metric in {"fcf","fcf_margin"}:
        return "Evidence only: management-defined FCF is not assumed to equal CFO minus capex without definition reconciliation."
    if metric=="eps" and not re.search(r"\b(?:gaap\s+)?diluted\s+(?:eps|earnings per share)\b|\bgaap\s+eps\b",text,re.I):
        return "Evidence only: EPS basis is not explicitly GAAP/diluted."
    if not metric:
        return "Evidence only: metric association is ambiguous."
    if stmt.get("target_fiscal_year") is None:
        return "Evidence only: annual target fiscal year is ambiguous."
    if stmt.get("target_low") is None:
        return "Evidence only: numeric target could not be associated safely with the metric."
    if conf < .80:
        return "Evidence only: extraction confidence is below the scoring threshold."
    return "Not included in the delivery score."

def evaluate_statements(ticker: str) -> list[dict]:
    statements=db.query("SELECT * FROM management_statements WHERE ticker=? ORDER BY filed ASC,id ASC",(ticker.upper(),))
    annual=_annual_rows(ticker);latest_fy=max((r.get("fiscal_year") or 0 for r in annual),default=0);out=[]
    by_fy={int(r.get("fiscal_year")):r for r in annual if r.get("fiscal_year") is not None}
    for s in statements:
        x=dict(s);conf=float(s.get("extract_confidence") or 0)
        fy=int(s.get("target_fiscal_year") or 0); target_row=by_fy.get(fy)
        # A statement published after the target fiscal period ended is retrospective, not a forecast.
        retrospective=False
        if target_row and target_row.get("period_end") and s.get("filed"):
            retrospective=str(s.get("filed"))[:10] > str(target_row.get("period_end"))[:10]
        if not s.get("metric_key") or s.get("target_low") is None or not s.get("target_fiscal_year") or conf<0.80:
            x.update(validation_status="UNVERIFIED",actual_value=None,delivery_score=None,score_eligible=False,score_note=_scoreability_note(x))
        elif retrospective:
            x.update(validation_status="UNVERIFIED",actual_value=None,delivery_score=None,score_eligible=False,score_note="Evidence only: statement was filed after the target fiscal period ended; it is not scored as forward guidance.")
        elif int(s["target_fiscal_year"])>latest_fy:
            x.update(validation_status="PENDING",actual_value=None,delivery_score=None,score_eligible=False,score_note="Target fiscal year has not completed yet.")
        else:
            actual,unit=_actual_for_statement(s,annual,ticker=ticker)
            status,score=_evaluate(actual,s.get("target_low"),s.get("target_high"),s.get("target_kind"),s.get("unit") or unit)
            note=""
            if status=="UNVERIFIED":
                note="Reported actual is unavailable on a comparable point-in-time / share basis; no MET/MISS is assigned."
            x.update(validation_status=status,actual_value=actual,delivery_score=score,score_eligible=False,score_note=note)
        out.append(x)
    # Score management on the earliest high-confidence numeric promise for each metric/target FY.
    # Later revisions remain visible but cannot improve the score by moving the goalposts.
    claimed=set()
    for x in out:
        if x.get("delivery_score") is None:continue
        key=(x.get("metric_key"),int(x.get("target_fiscal_year") or 0))
        if key not in claimed:
            x["score_eligible"]=True;claimed.add(key)
        else:
            x["score_eligible"]=False;x["score_note"]="Later guidance/revision excluded from delivery score"
    out.sort(key=lambda r:(str(r.get("filed") or ""),int(r.get("id") or 0)),reverse=True)
    return out


def credibility_summary(ticker: str) -> dict:
    rows=evaluate_statements(ticker);scorable=[r for r in rows if r.get("score_eligible") and r.get("delivery_score") is not None]
    if not scorable:
        return {"score":None,"label":"LOW DATA","scorable":0,"met":0,"near":0,"missed":0,"pending":sum(r.get("validation_status")=="PENDING" for r in rows),"unverified":sum(r.get("validation_status")=="UNVERIFIED" for r in rows),"rows":rows}
    weighted=[];today=date.today().year
    for r in scorable:
        fy=int(r.get("target_fiscal_year") or today);recency=1.0 if fy>=today-2 else 0.8 if fy>=today-4 else 0.6
        weight=max(0.80,float(r.get("extract_confidence") or 0.80))*recency;weighted.append((float(r["delivery_score"]),weight))
    score=sum(v*w for v,w in weighted)/sum(w for _,w in weighted)
    label="HIGH" if score>=80 and len(scorable)>=3 else "GOOD" if score>=65 and len(scorable)>=3 else "MIXED" if score>=45 else "POOR"
    if len(scorable)<3:label="LOW DATA"
    return {"score":score,"label":label,"scorable":len(scorable),"met":sum(r["validation_status"]=="MET" for r in scorable),"near":sum(r["validation_status"]=="NEAR" for r in scorable),"missed":sum(r["validation_status"]=="MISSED" for r in scorable),"pending":sum(r.get("validation_status")=="PENDING" for r in rows),"unverified":sum(r.get("validation_status")=="UNVERIFIED" for r in rows),"rows":rows}


def quality_cross_checks(ticker: str, metrics: dict, forensic_pack: dict | None = None, management_summary: dict | None = None) -> dict:
    forensic_pack=forensic_pack or {}
    management_summary=management_summary or credibility_summary(ticker)
    checks=[]
    def add(name,status,reason,weight=1.0): checks.append({"name":name,"status":status,"reason":reason,"weight":weight})

    roic=metrics.get("roic")
    add("Returns on capital", "PASS" if roic is not None and roic>=0.12 else "WATCH" if roic is not None and roic>=0.06 else "FAIL" if roic is not None else "LOW DATA", f"ROIC {roic:.1%}" if roic is not None else "ROIC unavailable", 1.2)
    conv=metrics.get("cfo_ni")
    add("Cash earnings", "PASS" if conv is not None and 0.9<=conv<=2.5 else "WATCH" if conv is not None and conv>=0.65 else "FAIL" if conv is not None else "LOW DATA", f"CFO / Net Income {conv:.2f}x" if conv is not None else "Cash conversion unavailable", 1.2)
    nd=metrics.get("net_debt"); rev=metrics.get("revenue")
    leverage=(nd/rev) if nd is not None and rev else None
    add("Balance sheet", "PASS" if leverage is not None and leverage<=0.25 else "WATCH" if leverage is not None and leverage<=0.75 else "FAIL" if leverage is not None else "LOW DATA", f"Net debt / revenue {leverage:.2f}x" if leverage is not None else "Net debt ratio unavailable", 1.0)
    share=metrics.get("share_change")
    add("Dilution / buyback reality", "PASS" if share is not None and share<=0 else "WATCH" if share is not None and share<=0.02 else "FAIL" if share is not None else "LOW DATA", f"Diluted share trend {share:+.1%}" if share is not None else "Share trend unavailable", 0.9)
    ccc=metrics.get("ccc")
    add("Working-capital discipline", "PASS" if ccc is not None and ccc<90 else "WATCH" if ccc is not None and ccc<150 else "FAIL" if ccc is not None else "LOW DATA", f"CCC {ccc:.0f} days" if ccc is not None else "CCC unavailable", 0.8)
    mc=management_summary.get("score")
    ml=management_summary.get("label")
    add("Management delivery", "PASS" if ml in {"HIGH","GOOD"} else "WATCH" if ml in {"MIXED","LOW DATA"} else "FAIL", f"Promise score {mc:.0f}/100 ({ml})" if mc is not None else "Too few scorable numeric promises", 1.1)
    data_alerts=len((forensic_pack or {}).get("data_alerts") or [])
    add("Data / accounting consistency", "PASS" if data_alerts==0 else "WATCH" if data_alerts<=2 else "FAIL", f"{data_alerts} forensic data alert(s)", 1.1)

    score_map={"PASS":100,"WATCH":55,"FAIL":10,"LOW DATA":50}
    score=sum(score_map[c["status"]]*c["weight"] for c in checks)/sum(c["weight"] for c in checks)
    label="STRONG" if score>=82 else "SOLID" if score>=68 else "MIXED" if score>=50 else "WEAK"
    fails=[c for c in checks if c["status"]=="FAIL"]
    watches=[c for c in checks if c["status"]=="WATCH"]
    return {"score":score,"label":label,"checks":checks,"fails":fails,"watches":watches}


def refresh_management_documents(ticker: str, user_agent: str, *, filing_limit: int = 18, include_exhibits: bool = True) -> dict:
    """Fetch/reparse official SEC management documents using the current conservative parser.

    Parser upgrades are versioned. Cached filings parsed by an older version are fetched once more,
    their old extracted statements are replaced, and the filing cache is stamped with the new
    parser version. This prevents stale false MET/MISS labels from surviving an application update.
    """
    ticker=ticker.upper();records=sec.recent_filing_records(ticker,user_agent,forms=("10-K","10-Q","8-K"),limit=filing_limit)
    docs=0;statements=0;skipped=0;errors=[]

    def process(rec, document_type, url):
        nonlocal docs,statements,skipped
        cached=db.query("SELECT parser_version FROM filing_documents WHERE ticker=? AND accession=? AND document_type=? AND source_url=?",
                        (ticker,rec["accession"],document_type,url))
        if cached and int(cached[0].get("parser_version") or 1)>=PARSER_VERSION:
            skipped+=1;return
        try:
            raw=sec.fetch_filing_primary(rec,user_agent) if document_type=="PRIMARY" else sec._get_text(url,user_agent)
            text=html_to_text(raw);sha=hashlib.sha1(text.encode("utf-8","ignore")).hexdigest()
            db.execute("DELETE FROM management_statements WHERE ticker=? AND accession=? AND document_type=? AND source_url=?",
                       (ticker,rec["accession"],document_type,url))
            db.execute("""INSERT INTO filing_documents(ticker,accession,document_type,form,filed,report_date,source_url,content_sha1,parser_version,extracted_at)
                          VALUES(?,?,?,?,?,?,?,?,?,?)
                          ON CONFLICT(ticker,accession,document_type,source_url) DO UPDATE SET
                          form=excluded.form,filed=excluded.filed,report_date=excluded.report_date,content_sha1=excluded.content_sha1,
                          parser_version=excluded.parser_version,extracted_at=excluded.extracted_at""",
                       (ticker,rec["accession"],document_type,rec["form"],rec["filed"],rec.get("report_date"),url,sha,PARSER_VERSION,db.now_utc()))
            rows=extract_management_statements(text,ticker=ticker,form=rec["form"],filed=rec["filed"],source_url=url,
                                               accession=rec["accession"],document_type=document_type)
            db.upsert_many("management_statements",rows,["ticker","statement_hash"])
            docs+=1;statements+=len(rows)
        except Exception as e:
            errors.append(f"{rec['form']} {rec['filed']} {document_type.lower()}: {e}")

    for rec in records:
        process(rec,"PRIMARY",rec["primary_url"])
        if include_exhibits and rec["form"]=="8-K":
            try:links=sec.filing_exhibit_links(rec,user_agent)
            except Exception:links=[]
            for j,url in enumerate(links,1):process(rec,f"EXHIBIT_{j}",url)
    return {"documents":docs,"statements":statements,"skipped":skipped,"errors":errors,"parser_version":PARSER_VERSION}

