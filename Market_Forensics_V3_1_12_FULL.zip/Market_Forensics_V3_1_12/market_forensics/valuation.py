from __future__ import annotations

import math
from datetime import date, timedelta
from statistics import median


def clamp(x, a, b):
    return max(a, min(b, x))


def _finite(x):
    try:
        return x is not None and math.isfinite(float(x))
    except Exception:
        return False


def _safe_div(a, b):
    if not (_finite(a) and _finite(b)) or float(b) == 0:
        return None
    return float(a) / float(b)


def _quantile(values, q):
    vals = sorted(float(x) for x in values if _finite(x))
    if not vals:
        return None
    if len(vals) == 1:
        return vals[0]
    pos = (len(vals) - 1) * float(q)
    lo = int(math.floor(pos)); hi = int(math.ceil(pos))
    if lo == hi:
        return vals[lo]
    w = pos - lo
    return vals[lo] * (1 - w) + vals[hi] * w


def _mad_filter(values, floor=None, ceil=None):
    """Conservative robust filter for small historical multiple samples."""
    vals = [float(x) for x in values if _finite(x)]
    if floor is not None:
        vals = [x for x in vals if x >= floor]
    if ceil is not None:
        vals = [x for x in vals if x <= ceil]
    if len(vals) < 4:
        return vals
    med = median(vals)
    deviations = [abs(x - med) for x in vals]
    mad = median(deviations)
    if mad <= 1e-12:
        return vals
    # 3.5 MAD is deliberately permissive because the sample is annual and small.
    return [x for x in vals if abs(x - med) / (1.4826 * mad) <= 3.5]


# These are fallbacks only. Company history takes precedence when enough observations exist.
TYPE_PRIORS = {
    "Generic": {
        "pe": (12.0, 18.0, 24.0), "ev_sales": (0.8, 1.5, 2.4), "fcf_yield": (0.080, 0.055, 0.040)
    },
    "Consumer / Brand": {
        "pe": (15.0, 21.0, 27.0), "ev_sales": (0.9, 1.8, 3.0), "fcf_yield": (0.070, 0.050, 0.035)
    },
    "Industrial": {
        "pe": (13.0, 18.0, 24.0), "ev_sales": (0.7, 1.4, 2.2), "fcf_yield": (0.080, 0.060, 0.042)
    },
    "Software": {
        "pe": (20.0, 30.0, 42.0), "ev_sales": (3.0, 6.0, 9.0), "fcf_yield": (0.055, 0.038, 0.025)
    },
    "Semiconductor / AI": {
        "pe": (16.0, 24.0, 34.0), "ev_sales": (2.0, 4.5, 7.5), "fcf_yield": (0.065, 0.045, 0.030)
    },
    "Auto / EV": {
        "pe": (8.0, 14.0, 22.0), "ev_sales": (0.35, 0.80, 1.50), "fcf_yield": (0.110, 0.075, 0.045)
    },
    "Financial / REIT": {
        # Generic operating-company EV/Sales/FCF models are not appropriate here.
        "pe": (8.0, 12.0, 16.0), "ev_sales": (0.7, 1.0, 1.4), "fcf_yield": (0.090, 0.070, 0.050)
    },
}


def _prior(company_type: str, key: str):
    return TYPE_PRIORS.get(company_type, TYPE_PRIORS["Generic"])[key]


def _bar_on_or_before(bars: list[dict], iso_date: str | None, max_gap_days=14):
    if not iso_date or not bars:
        return None
    try:
        target = date.fromisoformat(str(iso_date)[:10])
    except Exception:
        return None
    best = None
    for b in bars:
        try:
            d = date.fromisoformat(str(b.get("trade_date") or b.get("date"))[:10])
        except Exception:
            continue
        if d <= target and (best is None or d > best[0]):
            best = (d, b)
    if best is None or (target - best[0]).days > max_gap_days:
        return None
    return best[1]


def _bar_basis_factor(bars: list[dict], iso_date: str | None, max_gap_days=14):
    b=_bar_on_or_before(bars,iso_date,max_gap_days=max_gap_days)
    if not b or not bool(b.get("basis_verified")):
        return None
    try:
        f=float(b.get("split_factor") or 1.0)
        return f if f>0 else None
    except Exception:
        return None


def _filing_price_window(bars: list[dict], iso_date: str | None, calendar_days=35, min_points=5):
    """Point-in-time filing price on the filing-date share basis.

    Historical calibration must not mix today's split-adjusted quote with old SEC share counts.
    We therefore use each session's contemporaneous `raw_close`, then translate sessions after a
    split back to the filing-date basis using verified split factors.  If the raw/split mapping is
    not verified, the observation is rejected rather than guessed.
    """
    if not iso_date or not bars:return None
    try:target=date.fromisoformat(str(iso_date)[:10])
    except Exception:return None
    anchor_factor=_bar_basis_factor(bars,iso_date,max_gap_days=14)
    if anchor_factor is None:
        # Filing on a non-trading day: use first verified session after filing for the basis factor.
        candidates=[]
        for b in bars:
            try:d=date.fromisoformat(str(b.get("trade_date") or b.get("date"))[:10])
            except Exception:continue
            if d>=target and bool(b.get("basis_verified")):
                try:f=float(b.get("split_factor") or 1.0)
                except Exception:continue
                if f>0:candidates.append((d,f))
        candidates.sort()
        if candidates and (candidates[0][0]-target).days<=7:anchor_factor=candidates[0][1]
    if anchor_factor is None:return None
    end=target+timedelta(days=int(calendar_days));pts=[]
    for b in bars:
        try:
            d=date.fromisoformat(str(b.get("trade_date") or b.get("date"))[:10])
            raw=float(b.get("raw_close"))
            f=float(b.get("split_factor") or 1.0)
        except Exception:continue
        if target<=d<=end and bool(b.get("basis_verified")) and math.isfinite(raw) and raw>0 and f>0:
            comparable=raw*anchor_factor/f
            pts.append((d,comparable))
    pts.sort(key=lambda x:x[0]);pts=pts[:21]
    if len(pts)>=min_points:
        return {"price":median([x[1] for x in pts]),"price_date":f"{pts[0][0]}..{pts[-1][0]}",
                "price_method":f"median {len(pts)} raw sessions normalized to filing-date share basis",
                "split_factor":anchor_factor,"basis_verified":True}
    prior=_bar_on_or_before(bars,iso_date)
    if prior and bool(prior.get("basis_verified")) and _finite(prior.get("raw_close")):
        return {"price":float(prior["raw_close"]),"price_date":prior.get("trade_date") or prior.get("date"),
                "price_method":"raw close on/before filing","split_factor":float(prior.get("split_factor") or 1.0),"basis_verified":True}
    return None


def historical_calibration(fund_rows: list[dict], bars: list[dict]) -> dict:
    """True point-in-time historical multiple calibration.

    Each observation uses (1) only the values first available in the original annual filing and
    (2) a raw market quote on that filing-date share basis.  Later restatements and today's
    split-adjusted price basis therefore cannot rewrite history.
    """
    fys=sorted([r for r in fund_rows if r.get("period_type")=="FY" and r.get("fiscal_year")],key=lambda r:int(r["fiscal_year"]))
    observations=[]
    for r in fys:
        anchor=r.get("period_filed") or r.get("period_end");px=_filing_price_window(bars,anchor)
        if not px:continue
        price=px.get("price");eps_shares=r.get("pit_diluted_shares")
        rev=r.get("pit_revenue");ni=r.get("pit_net_income");fcf=r.get("pit_fcf")
        cash=r.get("pit_cash");debt=r.get("pit_debt")
        if not (_finite(price) and _finite(eps_shares) and float(eps_shares)>0):continue
        # Market cap requires point-in-time shares outstanding. If that instant fact predates a
        # split that occurred before the filing, move it onto the filing share basis.
        mcap_shares=r.get("pit_shares_outstanding")
        mcap_basis="OUTSTANDING"
        if _finite(mcap_shares) and float(mcap_shares)>0 and r.get("pit_shares_outstanding_date"):
            fact_factor=_bar_basis_factor(bars,r.get("pit_shares_outstanding_date"),max_gap_days=14)
            anchor_factor=px.get("split_factor")
            if fact_factor is not None and _finite(anchor_factor) and float(anchor_factor)>0:
                mcap_shares=float(mcap_shares)*float(fact_factor)/float(anchor_factor)
            else:
                mcap_shares=None
        if not _finite(mcap_shares) or float(mcap_shares)<=0:
            # Keep the fallback visible for audit, but do not use a weighted-average diluted
            # denominator as if it were an exact point-in-time market-cap share count.
            mcap_shares=float(eps_shares);mcap_basis="DILUTED_FALLBACK"
        market_cap=float(price)*float(mcap_shares)
        # Net debt is essential for EV/Sales.  Missing debt/cash must not silently become zero:
        # that would manufacture an equity value while the other valuation methods are still
        # perfectly capable of standing on their own.
        net_debt=(float(debt)-float(cash)) if _finite(debt) and _finite(cash) else None
        # P/E uses the diluted EPS actually reported in that original filing when available.
        # NI / weighted-average shares is only a labelled fallback because convertibles/two-class
        # allocation can make it differ from GAAP diluted EPS.
        diluted_eps=r.get("pit_diluted_eps")
        eps_source="REPORTED_DILUTED_EPS" if _finite(diluted_eps) else "UNAVAILABLE"
        # P/E is calibrated only from GAAP diluted EPS actually reported at the time. Net income
        # divided by one weighted-average share observation can diverge under two-class methods,
        # convertibles, buybacks or issuance, so it is audit information rather than calibration.
        pe=float(price)/float(diluted_eps) if _finite(diluted_eps) and float(diluted_eps)>0 else None
        # EV/Sales and FCF yield need an actual instant share count. If unavailable, fail closed
        # rather than calibrating those multiples from weighted-average diluted shares.
        mcap_exact=(mcap_basis=="OUTSTANDING")
        evs=(market_cap+float(net_debt))/float(rev) if mcap_exact and _finite(net_debt) and _finite(rev) and float(rev)>0 else None
        fyld=float(fcf)/market_cap if mcap_exact and _finite(fcf) and float(fcf)>0 and market_cap>0 else None
        om=_safe_div(r.get("pit_operating_income"),rev);nm=_safe_div(ni,rev);fm=_safe_div(fcf,rev)
        observations.append({
            "fiscal_year":int(r["fiscal_year"]),"anchor_date":anchor,"price_date":px.get("price_date"),
            "price_method":px.get("price_method"),"price":float(price),"price_basis":"RAW_AT_FILING",
            "pe":pe,"ev_sales":evs,"fcf_yield":fyld,"operating_margin":om,"net_margin":nm,"fcf_margin":fm,
            "revenue":rev,"eps_shares":eps_shares,"diluted_eps":diluted_eps,"eps_source":eps_source,
            "market_cap_shares":mcap_shares,"market_cap_share_basis":mcap_basis,
        })
    prev=None
    for o in observations:
        growth=None
        if prev and _finite(prev.get("revenue")) and float(prev["revenue"])>0 and _finite(o.get("revenue")) and float(o["revenue"])>0:
            gap=max(1,int(o["fiscal_year"])-int(prev["fiscal_year"]))
            growth=(float(o["revenue"])/float(prev["revenue"]))**(1/gap)-1
        o["revenue_growth"]=growth
        prev=o
    pe_vals=_mad_filter([x.get("pe") for x in observations],3.0,80.0);evs_vals=_mad_filter([x.get("ev_sales") for x in observations],0.05,30.0)
    fy_vals=_mad_filter([x.get("fcf_yield") for x in observations],0.002,0.30);growth_vals=_mad_filter([x.get("revenue_growth") for x in observations],-0.50,1.00)
    om_vals=_mad_filter([x.get("operating_margin") for x in observations],-0.50,0.80);nm_vals=_mad_filter([x.get("net_margin") for x in observations],-0.50,0.80);fm_vals=_mad_filter([x.get("fcf_margin") for x in observations],-0.50,0.80)
    def qs(vals):return {"n":len(vals),"p25":_quantile(vals,.25),"median":_quantile(vals,.50),"p75":_quantile(vals,.75),"min":min(vals) if vals else None,"max":max(vals) if vals else None}
    return {"observations":observations,"pe":qs(pe_vals),"ev_sales":qs(evs_vals),"fcf_yield":qs(fy_vals),"revenue_growth":qs(growth_vals),"operating_margin":qs(om_vals),"net_margin":qs(nm_vals),"fcf_margin":qs(fm_vals),"basis":"POINT_IN_TIME_RAW"}


def _trend(values):
    vals = [float(v) for v in values if _finite(v)]
    if len(vals) < 2:
        return 0.0
    return vals[-1] - vals[-2]


def _normalized_center(current, hist_median, recent_trend, default):
    if not _finite(current) and not _finite(hist_median):
        return default
    if not _finite(current):
        return float(hist_median)
    if not _finite(hist_median):
        return float(current)
    current = float(current); hist_median = float(hist_median)
    gap = hist_median - current
    # If the latest direction is moving toward the historic norm, allow more reversion.
    toward = (gap > 0 and recent_trend > 0) or (gap < 0 and recent_trend < 0)
    away = (gap > 0 and recent_trend < 0) or (gap < 0 and recent_trend > 0)
    factor = 0.55 if toward else 0.25 if away else 0.35
    return current + factor * gap


def smart_assumptions(metrics: dict, fund_rows: list[dict] | None = None, bars: list[dict] | None = None, company_type="Generic"):
    fund_rows = fund_rows or []
    bars = bars or []
    cal = historical_calibration(fund_rows, bars)

    cagr = metrics.get("cagr3") if _finite(metrics.get("cagr3")) else 0.05
    cagr = clamp(float(cagr), -0.15, 0.30)
    om = metrics.get("operating_margin") if _finite(metrics.get("operating_margin")) else 0.10
    nm = metrics.get("net_margin") if _finite(metrics.get("net_margin")) else (float(om) * 0.79)
    fm = metrics.get("fcf_margin") if _finite(metrics.get("fcf_margin")) else 0.08
    tax = metrics.get("tax_rate") if _finite(metrics.get("tax_rate")) else 0.21

    obs = cal["observations"]
    om_trend = _trend([x.get("operating_margin") for x in obs[-3:]])
    nm_trend = _trend([x.get("net_margin") for x in obs[-3:]])
    fm_trend = _trend([x.get("fcf_margin") for x in obs[-3:]])
    growth_trend = _trend([x.get("revenue_growth") for x in obs[-3:]])

    growth_med = cal["revenue_growth"]["median"]
    base_growth = _normalized_center(cagr, growth_med, growth_trend, 0.05)
    gp25 = cal["revenue_growth"]["p25"]
    gp75 = cal["revenue_growth"]["p75"]
    bear_growth = min(base_growth - 0.035, gp25 if _finite(gp25) else base_growth - 0.05)
    bull_growth = max(base_growth + 0.035, gp75 if _finite(gp75) else base_growth + 0.05)

    base_om = _normalized_center(om, cal["operating_margin"]["median"], om_trend, float(om))
    omp25, omp75 = cal["operating_margin"]["p25"], cal["operating_margin"]["p75"]
    bear_om = min(base_om - 0.02, omp25 if _finite(omp25) else base_om - 0.03)
    bull_om = max(base_om + 0.02, omp75 if _finite(omp75) else base_om + 0.03)

    base_nm = _normalized_center(nm, cal["net_margin"]["median"], nm_trend, float(nm))
    nmp25, nmp75 = cal["net_margin"]["p25"], cal["net_margin"]["p75"]
    bear_nm = min(base_nm - 0.015, nmp25 if _finite(nmp25) else base_nm - 0.025)
    bull_nm = max(base_nm + 0.015, nmp75 if _finite(nmp75) else base_nm + 0.025)

    base_fm = _normalized_center(fm, cal["fcf_margin"]["median"], fm_trend, float(fm))
    fmp25, fmp75 = cal["fcf_margin"]["p25"], cal["fcf_margin"]["p75"]
    bear_fm = min(base_fm - 0.02, fmp25 if _finite(fmp25) else base_fm - 0.03)
    bull_fm = max(base_fm + 0.02, fmp75 if _finite(fmp75) else base_fm + 0.03)

    def multiple_triplet(key):
        h = cal[key]
        prior = _prior(company_type, key)
        if h["n"] >= 4 and all(_finite(h[k]) for k in ("p25", "median", "p75")):
            return float(h["p25"]), float(h["median"]), float(h["p75"]), "company history"
        if h["n"] >= 2 and _finite(h["median"]):
            # Sparse company history is blended with the company-type prior rather than trusted blindly.
            hist_med = float(h["median"])
            return (
                0.55 * (float(h["p25"]) if _finite(h["p25"]) else hist_med) + 0.45 * prior[0],
                0.65 * hist_med + 0.35 * prior[1],
                0.55 * (float(h["p75"]) if _finite(h["p75"]) else hist_med) + 0.45 * prior[2],
                "sparse history + type prior",
            )
        return prior[0], prior[1], prior[2], "type prior fallback"

    pe_b, pe_m, pe_u, pe_src = multiple_triplet("pe")
    ev_b, ev_m, ev_u, ev_src = multiple_triplet("ev_sales")
    # FCF yield is inverse-valued: a high yield is bearish/cheap, a low yield is bullish/rich.
    f = cal["fcf_yield"]
    prior_f = _prior(company_type, "fcf_yield")
    if f["n"] >= 4 and all(_finite(f[k]) for k in ("p25", "median", "p75")):
        fy_b, fy_m, fy_u, fy_src = float(f["p75"]), float(f["median"]), float(f["p25"]), "company history"
    elif f["n"] >= 2 and _finite(f["median"]):
        med = float(f["median"])
        fy_b = 0.55 * (float(f["p75"]) if _finite(f["p75"]) else med) + 0.45 * prior_f[0]
        fy_m = 0.65 * med + 0.35 * prior_f[1]
        fy_u = 0.55 * (float(f["p25"]) if _finite(f["p25"]) else med) + 0.45 * prior_f[2]
        fy_src = "sparse history + type prior"
    else:
        fy_b, fy_m, fy_u = prior_f
        fy_src = "type prior fallback"

    # Dynamic method weights. Methods with non-positive or unstable economics are not allowed to dominate.
    weights = {"pe": .40, "ev_sales": .25, "fcf_yield": .35}
    if not _finite(metrics.get("net_income")) or float(metrics.get("net_income") or 0) <= 0:
        weights["pe"] = 0.0
    # If SEC-reported diluted EPS materially disagrees with NI/share proxy, trust the reported EPS
    # for today's P/E but reduce earnings-method weight until the reconciliation is understood.
    eps_gap=metrics.get("eps_reconciliation_gap")
    if _finite(eps_gap):
        if abs(float(eps_gap)) > .30:
            weights["pe"] *= .25
        elif abs(float(eps_gap)) > .15:
            weights["pe"] *= .50
    if not _finite(metrics.get("fcf")) or float(metrics.get("fcf") or 0) <= 0:
        weights["fcf_yield"] = 0.0
    # EV/Sales is much less informative when historical operating margins are unstable.
    om_hist = cal.get("operating_margin", {})
    if om_hist.get("n", 0) >= 4 and _finite(om_hist.get("p25")) and _finite(om_hist.get("p75")):
        if float(om_hist["p75"]) - float(om_hist["p25"]) > .10:
            weights["ev_sales"] *= .50
    # Weak cash conversion reduces confidence in earnings-based valuation; stable FCF gets more weight.
    cfo_ni = metrics.get("cfo_ni")
    if _finite(cfo_ni) and (float(cfo_ni) < .70 or float(cfo_ni) > 1.80):
        weights["pe"] *= .75
    fm_hist = cal.get("fcf_margin", {})
    if fm_hist.get("n", 0) >= 4 and _finite(fm_hist.get("p25")) and _finite(fm_hist.get("p75")):
        if float(fm_hist["p75"]) - float(fm_hist["p25"]) <= .05 and weights["fcf_yield"] > 0:
            weights["fcf_yield"] *= 1.15
    if company_type == "Financial / REIT":
        weights = {"pe": 1.0, "ev_sales": 0.0, "fcf_yield": 0.0}

    # Historical multiples should not be applied mechanically when today's economics are
    # materially better or worse than the historical regime. Apply only a modest adjustment
    # to avoid double-counting growth/margins that already enter the scenario math.
    regime_parts=[]
    def _scaled_delta(cur, hist, scale):
        if not (_finite(cur) and _finite(hist)):
            return None
        return clamp((float(cur)-float(hist))/float(scale), -1.0, 1.0)
    for cur,hist,scale,w in (
        (base_growth, cal["revenue_growth"].get("median"), .08, .35),
        (base_nm, cal["net_margin"].get("median"), .04, .35),
        (base_fm, cal["fcf_margin"].get("median"), .04, .30),
    ):
        d=_scaled_delta(cur,hist,scale)
        if d is not None:
            regime_parts.append((d,w))
    regime_score=(sum(d*w for d,w in regime_parts)/sum(w for _,w in regime_parts)) if regime_parts else 0.0
    pe_factor=1.0 + 0.08*regime_score
    ev_factor=1.0 + 0.12*regime_score
    fy_factor=1.0 - 0.08*regime_score  # better regime -> lower required FCF yield
    pe_b,pe_m,pe_u=[x*pe_factor for x in (pe_b,pe_m,pe_u)]
    ev_b,ev_m,ev_u=[x*ev_factor for x in (ev_b,ev_m,ev_u)]
    fy_b,fy_m,fy_u=[x*fy_factor for x in (fy_b,fy_m,fy_u)]

    # Current market price is diagnostic evidence, not an input to automatic fair value.
    # Earlier builds partially pulled Bear/Base/Bull multiples toward today's observed multiple
    # during a regime break. That creates circularity: a richer market price can mechanically
    # raise the model's own fair value (and vice versa). Keep the regime comparison for the
    # Expectations/diagnostic layer, but do not let current price rewrite intrinsic-value inputs.
    current_price = next((float(r.get("close")) for r in reversed(bars) if _finite(r.get("close"))), None)
    regime_break = multiple_regime_diagnostics(metrics, current_price, cal) if current_price else {"rows": []}
    anchor_notes=[]
    for r in regime_break.get("rows", []):
        anchor_notes.append({
            "metric":r.get("metric"),"severity":r.get("severity"),"current":r.get("current"),
            "historical_median":r.get("historical_median"),"base_anchor_weight":0.0,
            "interpretation":r.get("interpretation"),"diagnostic_only":True,
        })

    out = {
        "bear": {
            "growth": clamp(bear_growth, -0.30, 0.30),
            "operating_margin": clamp(bear_om, -0.20, 0.50),
            "net_margin": clamp(bear_nm, -0.20, 0.50),
            "fcf_margin": clamp(bear_fm, -0.20, 0.50),
            "tax_rate": float(tax), "pe": clamp(pe_b, 3, 80), "ev_sales": clamp(ev_b, .05, 30),
            "target_fcf_yield": clamp(fy_b, .005, .30), "wacc": .11, "terminal_growth": .015,
            "prob": .25, "manual_override": None,
        },
        "base": {
            "growth": clamp(base_growth, -0.20, 0.35),
            "operating_margin": clamp(base_om, -0.15, 0.60),
            "net_margin": clamp(base_nm, -0.15, 0.60),
            "fcf_margin": clamp(base_fm, -0.15, 0.60),
            "tax_rate": float(tax), "pe": clamp(pe_m, 3, 80), "ev_sales": clamp(ev_m, .05, 30),
            "target_fcf_yield": clamp(fy_m, .005, .30), "wacc": .10, "terminal_growth": .025,
            "prob": .50, "manual_override": None,
        },
        "bull": {
            "growth": clamp(bull_growth, -0.10, 0.50),
            "operating_margin": clamp(bull_om, -0.10, 0.70),
            "net_margin": clamp(bull_nm, -0.10, 0.70),
            "fcf_margin": clamp(bull_fm, -0.10, 0.70),
            "tax_rate": float(tax), "pe": clamp(pe_u, 3, 80), "ev_sales": clamp(ev_u, .05, 30),
            "target_fcf_yield": clamp(fy_u, .005, .30), "wacc": .09, "terminal_growth": .030,
            "prob": .25, "manual_override": None,
        },
        "weights": weights,
        "horizon_years": 5,
        "origin": "AUTO_HISTORY_CALIBRATED",
        "calibration": {
            "pe_source": pe_src, "ev_sales_source": ev_src, "fcf_yield_source": fy_src,
            "historical_years": len(obs), "regime_score": regime_score,
            "regime_adjustment": {"pe_factor":pe_factor,"ev_sales_factor":ev_factor,"fcf_yield_factor":fy_factor},
            "market_regime_anchor": anchor_notes,  # compatibility key; V3.1.2 entries are diagnostic-only
            "market_regime_diagnostic": anchor_notes,
            "pe_n": cal["pe"]["n"], "ev_sales_n": cal["ev_sales"]["n"], "fcf_yield_n": cal["fcf_yield"]["n"],
        },
    }
    return out, cal


def default_assumptions(metrics: dict):
    # Backward-compatible fallback when history/company type is unavailable.
    return smart_assumptions(metrics, [], [], "Generic")[0]


def normalize_assumptions(payload: dict | None, metrics: dict, fallback: dict | None = None) -> dict:
    base = fallback if isinstance(fallback, dict) else default_assumptions(metrics)
    # deep-ish copy without importing json
    base = {
        "bear": dict(base["bear"]), "base": dict(base["base"]), "bull": dict(base["bull"]),
        "weights": dict(base.get("weights", {})), "horizon_years": base.get("horizon_years", 5),
        "origin": base.get("origin", "AUTO"), "calibration": dict(base.get("calibration", {})),
    }
    if not isinstance(payload, dict):
        return base
    for scenario in ("bear", "base", "bull"):
        incoming = payload.get(scenario, {}) if isinstance(payload.get(scenario), dict) else {}
        for k, v in incoming.items():
            if k in base[scenario]:
                base[scenario][k] = v
    if isinstance(payload.get("weights"), dict):
        for k in ("pe", "ev_sales", "fcf_yield"):
            if k in payload["weights"]:
                base["weights"][k] = payload["weights"][k]
    if "horizon_years" in payload:
        base["horizon_years"] = payload["horizon_years"]
    for k in ("reviewed_at", "origin", "calibration", "review_note"):
        if k in payload:
            base[k] = payload[k]
    return base


def pe_value(revenue, growth, net_margin, pe, shares):
    """P/E valuation on normalized forward net income, consistent with historical P/E calibration."""
    if not all(_finite(x) for x in (revenue, growth, net_margin, pe, shares)) or float(shares) == 0:
        return None
    forward_revenue = float(revenue) * (1 + float(growth))
    earnings = forward_revenue * float(net_margin)
    v = earnings / float(shares) * float(pe)
    return v if v > 0 else None


def ev_sales_value(revenue, growth, ev_sales, net_debt, shares):
    if not all(_finite(x) for x in (revenue, growth, ev_sales, net_debt, shares)) or float(shares) == 0:
        return None
    enterprise_value = float(revenue) * (1 + float(growth)) * float(ev_sales)
    equity_value = enterprise_value - float(net_debt)
    v = equity_value / float(shares)
    return v if v > 0 else None


def fcf_yield_value(revenue, growth, fcf_margin, target_yield, shares):
    if not all(_finite(x) for x in (revenue, growth, fcf_margin, target_yield, shares)):
        return None
    if float(shares) == 0 or float(target_yield) <= 0:
        return None
    normalized_fcf = float(revenue) * (1 + float(growth)) * float(fcf_margin)
    v = (normalized_fcf / float(target_yield)) / float(shares)
    return v if v > 0 else None


def dcf_value(revenue, growth, fcf_margin, wacc, terminal_growth, years, net_debt, shares):
    """FCFE-style equity cash-flow cross-check.

    The app defines FCF as CFO - capex, which is a levered/equity cash-flow proxy.  Discounting it
    with WACC and then subtracting net debt again would mix FCFE and FCFF frameworks and can
    double-count leverage.  For backward compatibility the persisted field is still named `wacc`,
    but in V3.1.2 it is explicitly interpreted as the **equity discount rate** for this cross-check.
    `net_debt` is retained in the signature for saved-model/API compatibility and is intentionally
    not subtracted here.
    """
    if not all(_finite(x) for x in (revenue,growth,fcf_margin,wacc,terminal_growth,years,shares)):
        return None
    discount=float(wacc);tg=float(terminal_growth)
    if float(shares)<=0 or discount<=tg or discount<=0:return None
    rev=float(revenue);pv=0.0;years=int(years)
    for y in range(1,years+1):
        rev*=1+float(growth);fcfe=rev*float(fcf_margin);pv+=fcfe/((1+discount)**y)
    terminal_fcfe=rev*(1+tg)*float(fcf_margin);tv=terminal_fcfe/(discount-tg);pv+=tv/((1+discount)**years)
    v=pv/float(shares)
    return v if v>0 else None


def _robust_blend(components: dict, weights: dict):
    valid = [(k, float(v)) for k, v in components.items() if _finite(v) and float(v) > 0]
    if not valid:
        return None, {}, []
    vals = [v for _, v in valid]
    med = median(vals)
    adj = {}
    flags = []
    for k, v in valid:
        w = max(0.0, float(weights.get(k, 0)))
        if med > 0 and abs(v / med - 1) > .45 and len(valid) >= 3:
            w *= .30
            flags.append(f"{k} is >45% away from the cross-method median; weight reduced")
        adj[k] = w
    total = sum(adj.values())
    if total <= 0:
        adj = {k: 1.0 for k, _ in valid}; total = len(valid)
    blend = sum(v * adj[k] for k, v in valid) / total
    return blend, {k: adj[k] / total for k in adj}, flags


def scenario_values(metrics: dict, assumptions: dict):
    assumptions=normalize_assumptions(assumptions,metrics,fallback=assumptions if assumptions else None)
    rev=metrics.get("revenue");shares=metrics.get("valuation_shares") or metrics.get("diluted_shares");nd=metrics.get("net_debt")
    # V3.1.8 current-valuation gate: publish per-share targets whenever the *selected current
    # valuation denominator* is usable on today's corporate-action basis. Historical OHLC
    # certification belongs to Historical Calibration / Validate and must never block current
    # Bear/Base/Bull by itself. Verified diluted-WA fallback is intentionally allowed.
    if "valuation_share_basis_usable" in metrics:
        basis_blocked=not bool(metrics.get("valuation_share_basis_usable"))
    else:
        # Compatibility for synthetic/legacy callers.
        basis_blocked=bool(metrics.get("share_basis_checked")) and not bool(metrics.get("valuation_share_basis_verified",metrics.get("share_basis_verified")))
    basis_issue=str(metrics.get("valuation_basis_issue") or "Selected share denominator cannot be reconciled to the current split/reverse-split basis.")
    share_change=metrics.get("share_change") if metrics.get("share_change_verified") else 0.0
    try:share_change=clamp(float(share_change or 0),-.15,.15)
    except Exception:share_change=0.0
    forward_shares=float(shares)*(1+share_change) if _finite(shares) and float(shares)>0 else shares
    raw_weights={k:max(0.0,float(assumptions.get("weights",{}).get(k,0))) for k in ("pe","ev_sales","fcf_yield")};total_w=sum(raw_weights.values()) or 1.0
    weights={k:v/total_w for k,v in raw_weights.items()};years=int(assumptions.get("horizon_years",5));out={}
    for name in ("bear","base","bull"):
        a=assumptions[name];net_margin=a.get("net_margin")
        if not _finite(net_margin):net_margin=float(a.get("operating_margin") or 0)*(1-float(a.get("tax_rate") or .21))
        if basis_blocked:
            pe=evs=fy=dcf=None
            components={"pe":None,"ev_sales":None,"fcf_yield":None}
            blend,effective_weights,flags=None,{},["DATA REVIEW: "+basis_issue]
        else:
            pe=pe_value(rev,a["growth"],net_margin,a["pe"],forward_shares)
            evs=ev_sales_value(rev,a["growth"],a["ev_sales"],nd,forward_shares)
            fy=fcf_yield_value(rev,a["growth"],a["fcf_margin"],a["target_fcf_yield"],forward_shares)
            # DCF is a present equity value. Keep its current-share denominator separate from
            # one-year-forward multiple methods so buybacks/dilution are not counted twice.
            dcf=dcf_value(rev,a["growth"],a["fcf_margin"],a["wacc"],a["terminal_growth"],years,nd,shares)
            components={"pe":pe,"ev_sales":evs,"fcf_yield":fy};blend,effective_weights,flags=_robust_blend(components,weights)
        if str(metrics.get("share_denominator_kind") or "").startswith("BASIC"):flags.append("diluted shares unavailable; basic-share fallback used")
        if metrics.get("valuation_share_source")=="DILUTED_WA_FALLBACK":
            flags.append("Price targets shown using verified diluted-share basis; confidence MEDIUM")
        if str(metrics.get("valuation_share_source") or "").startswith("USER_"):
            flags.append("Price targets shown using user-verified current share basis; confidence MEDIUM; automatic SEC/corporate-action diagnosis remains preserved for audit")
        if not metrics.get("share_change_verified") and metrics.get("share_change") is None:flags.append("forward share change not verified; held flat")
        override=a.get("manual_override")
        if not basis_blocked and _finite(override) and float(override)>0:
            blend=float(override);flags.append("manual fair-value override active")
        elif basis_blocked and _finite(override) and float(override)>0:
            flags.append("manual override suppressed until an auditable current share basis is available")
        valid_vals=[float(v) for v in components.values() if _finite(v) and float(v)>0];low=_quantile(valid_vals,.25) if valid_vals else None;high=_quantile(valid_vals,.75) if valid_vals else None
        out[name]={"pe":pe,"ev_sales":evs,"fcf_yield":fy,"dcf":dcf,"fair_value":blend,"range_low":low,"range_high":high,
                   "prob":float(a.get("prob",0)),"effective_weights":effective_weights,"flags":flags,
                   "current_diluted_shares":shares,"forward_diluted_shares":forward_shares,
                   "current_share_basis":metrics.get("valuation_share_source"),"share_basis_confidence":metrics.get("valuation_share_confidence"),
                   "current_equity_value":(blend*float(shares)) if _finite(blend) and _finite(shares) else None}
    probs=sum(max(0.0,x["prob"]) for x in out.values());ev=None
    if probs>0 and all(_finite(x["fair_value"]) for x in out.values()):ev=sum(float(x["fair_value"])*max(0.0,x["prob"]) for x in out.values())/probs
    return out,ev


def current_multiples(metrics: dict, price):
    """Current valuation multiples on an explicitly declared share basis.

    Exact current outstanding shares are preferred. A verified diluted weighted-average share
    denominator is allowed as a MEDIUM-confidence proxy instead of suppressing all multiples.
    P/E remains separately gated by a verified SEC GAAP diluted-EPS basis.
    """
    shares=metrics.get("valuation_shares") or metrics.get("diluted_shares")
    basis_checked=bool(metrics.get("share_basis_checked"))
    if "valuation_share_basis_usable" in metrics:
        valuation_basis_ok=bool(metrics.get("valuation_share_basis_usable"))
    else:
        valuation_basis_ok=(not basis_checked) or bool(metrics.get("valuation_share_basis_verified",metrics.get("share_basis_verified")))
    market_cap_basis_ok=bool(metrics.get("market_cap_basis_usable",metrics.get("market_cap_basis_verified",valuation_basis_ok)))
    basis_conf=str(metrics.get("valuation_share_confidence") or ("HIGH" if metrics.get("market_cap_basis_verified") else "LOW"))
    share_source=str(metrics.get("valuation_share_source") or "UNKNOWN")
    if not _finite(price):
        return {"pe":None,"ev_sales":None,"fcf_yield":None,"market_cap":None,"basis_status":"NO PRICE","basis_confidence":basis_conf,"share_basis":share_source}

    diluted_eps_sec=metrics.get("diluted_eps_sec")
    if _finite(diluted_eps_sec):
        diluted_eps=float(diluted_eps_sec);eps_source="SEC_REPORTED_GAAP_DILUTED"
    elif not basis_checked:
        ni=metrics.get("net_income");diluted_eps=(float(ni)/float(shares)) if _finite(ni) and _finite(shares) and float(shares)>0 else None
        eps_source="NI_OVER_SHARES_FALLBACK"
    else:
        diluted_eps=None;eps_source="UNAVAILABLE"
    eps_basis_ok=(not basis_checked) or (eps_source=="SEC_REPORTED_GAAP_DILUTED" and bool(metrics.get("eps_basis_verified")))
    pe=float(price)/float(diluted_eps) if eps_basis_ok and _finite(diluted_eps) and float(diluted_eps)>0 else None

    market_cap=None;ev_sales=None;fcf_yield=None
    if _finite(shares) and float(shares)>0 and valuation_basis_ok and market_cap_basis_ok:
        market_cap=float(price)*float(shares)
        revenue=metrics.get("revenue");fcf=metrics.get("fcf");nd=metrics.get("net_debt")
        enterprise_value=(market_cap+float(nd)) if _finite(nd) else None
        ev_sales=float(enterprise_value)/float(revenue) if _finite(enterprise_value) and _finite(revenue) and float(revenue)>0 else None
        fcf_yield=float(fcf)/market_cap if _finite(fcf) and market_cap>0 else None
    else:
        enterprise_value=None

    if not valuation_basis_ok or not market_cap_basis_ok:
        status="DATA REVIEW"
    elif share_source=="DILUTED_WA_FALLBACK":
        status="VERIFIED FALLBACK"
    else:
        status="VERIFIED" if (not basis_checked or bool(metrics.get("valuation_share_basis_verified",True))) else "DATA REVIEW"
    return {"pe":pe,"ev_sales":ev_sales,"fcf_yield":fcf_yield,"market_cap":market_cap,"enterprise_value":enterprise_value,
            "diluted_eps":diluted_eps,"eps_source":eps_source,"eps_basis_verified":eps_basis_ok,
            "basis_status":status,"basis_confidence":basis_conf,"share_basis":share_source,
            "market_cap_basis":"CURRENT OUTSTANDING" if share_source=="CURRENT_OUTSTANDING" else "DILUTED-WA PROXY" if share_source=="DILUTED_WA_FALLBACK" else share_source}



def multiple_regime_diagnostics(metrics: dict, price, calibration: dict | None) -> dict:
    """Compare today's valuation multiples with the company's own historical regime.

    A large gap is *not* automatically cheap/expensive. We explicitly ask whether the
    underlying economics changed enough to justify the re-rating or de-rating.
    """
    calibration = calibration or {}
    current = current_multiples(metrics or {}, price)

    def f(x):
        return float(x) if _finite(x) else None

    hist_growth = f((calibration.get("revenue_growth") or {}).get("median"))
    hist_nm = f((calibration.get("net_margin") or {}).get("median"))
    hist_fm = f((calibration.get("fcf_margin") or {}).get("median"))
    cur_growth = f((metrics or {}).get("cagr3"))
    cur_nm = f((metrics or {}).get("net_margin"))
    cur_fm = f((metrics or {}).get("fcf_margin"))

    weaker = 0
    stronger = 0
    comparisons = []
    for name, cur, hist, threshold in (
        ("growth", cur_growth, hist_growth, .05),
        ("net margin", cur_nm, hist_nm, .03),
        ("FCF margin", cur_fm, hist_fm, .03),
    ):
        if cur is None or hist is None:
            continue
        delta = cur - hist
        comparisons.append((name, delta))
        if delta <= -threshold:
            weaker += 1
        elif delta >= threshold:
            stronger += 1

    if weaker >= 2:
        economics = "WEAKER"
    elif stronger >= 2:
        economics = "STRONGER"
    else:
        economics = "SIMILAR / MIXED"

    rows = []
    specs = (("pe", "P/E", False), ("ev_sales", "EV/Sales", False), ("fcf_yield", "FCF Yield", True))
    for key, label, inverse in specs:
        hist = calibration.get(key) or {}
        n = int(hist.get("n") or 0)
        med = f(hist.get("median"))
        cur = f(current.get(key))
        if n < 4 or med in (None, 0) or cur is None or cur <= 0:
            continue
        ratio = cur / med
        if 0.65 < ratio < 1.55:
            continue
        severity = "HIGH" if ratio <= 0.40 or ratio >= 2.50 else "MEDIUM"
        cheaper = ratio < 1.0 if not inverse else ratio > 1.0
        distance = ratio - 1.0

        if cheaper:
            if economics == "WEAKER":
                interpretation = "DE-RATING MAY BE JUSTIFIED"
                direction = "NEGATIVE"
                explanation = "The stock is much cheaper than its historical regime, but current growth/margins are materially weaker. Do not assume mean reversion without evidence that the business regime is stabilizing."
            elif key == "pe" and cur_nm is not None and hist_nm is not None and cur_nm >= hist_nm + .03:
                interpretation = "LOW P/E MAY REFLECT ELEVATED EARNINGS"
                direction = "NEGATIVE"
                explanation = "Current earnings margin is well above its historical median, so the low P/E may partly reflect a temporarily enlarged earnings denominator rather than a durable valuation bargain."
            else:
                interpretation = "POTENTIAL DE-RATING OPPORTUNITY — EXPLAIN THE GAP"
                direction = "POSITIVE"
                explanation = "Valuation is far below the company's historical regime without equally clear operating deterioration. This can be opportunity, but only after identifying why the market changed the multiple."
        else:
            if economics == "STRONGER":
                interpretation = "PREMIUM MAY BE PARTLY JUSTIFIED"
                direction = "POSITIVE"
                explanation = "The market pays a much richer multiple than history, but current economics are stronger. The premium still requires durability and execution."
            else:
                interpretation = "HISTORICAL PREMIUM REQUIRES PROOF"
                direction = "NEGATIVE"
                explanation = "Valuation is far above the historical regime without a comparably strong improvement in operating economics. The market may be pricing unusually demanding expectations."

        rows.append({
            "key": key, "metric": label, "severity": severity, "direction": direction,
            "current": cur, "historical_median": med, "ratio_to_history": ratio,
            "distance_pct": distance, "observations": n, "economics": economics, "cheaper": cheaper,
            "interpretation": interpretation, "explanation": explanation,
        })

    return {
        "rows": rows,
        "high_count": sum(1 for r in rows if r["severity"] == "HIGH"),
        "medium_count": sum(1 for r in rows if r["severity"] == "MEDIUM"),
        "economics": economics,
        "economics_deltas": {k: v for k, v in comparisons},
        "current": current,
    }

def valuation_confidence(metrics: dict, scenarios: dict, calibration: dict, company_type="Generic", audit_summary: dict | None = None, reviewed=False, revision_count=0, regime_breaks: dict | None = None):
    score = 35.0
    reasons = []
    years = len(calibration.get("observations", [])) if calibration else 0
    score += min(20, years * 3)
    if years < 4:
        reasons.append(f"only {years} usable annual history points")
    method_counts = [calibration.get(k, {}).get("n", 0) for k in ("pe", "ev_sales", "fcf_yield")] if calibration else [0,0,0]
    strong_methods = sum(1 for n in method_counts if n >= 4)
    score += strong_methods * 5
    if strong_methods < 2:
        reasons.append("historical multiple calibration is sparse")

    base = scenarios.get("base", {}) if scenarios else {}
    bear_fv = (scenarios.get("bear") or {}).get("fair_value") if scenarios else None
    base_fv = base.get("fair_value")
    bull_fv = (scenarios.get("bull") or {}).get("fair_value") if scenarios else None
    if all(_finite(x) for x in (bear_fv, base_fv, bull_fv)):
        if float(bear_fv) <= float(base_fv) <= float(bull_fv):
            score += 5
        else:
            score -= 20
            reasons.append("Bear/Base/Bull fair values are not monotonically ordered")
    vals = [base.get(k) for k in ("pe", "ev_sales", "fcf_yield", "dcf") if _finite(base.get(k)) and float(base.get(k)) > 0]
    if len(vals) >= 3:
        med = median(float(x) for x in vals)
        spread = (max(vals) - min(vals)) / med if med else 99
        if spread <= .35:
            score += 15
        elif spread <= .70:
            score += 7
            reasons.append("valuation methods have moderate dispersion")
        else:
            score -= 8
            reasons.append("valuation methods disagree materially")
    else:
        score -= 5; reasons.append("fewer than three usable valuation methods")

    if _finite(metrics.get("net_income")) and float(metrics.get("net_income")) > 0:
        score += 4
    else:
        reasons.append("non-positive earnings reduce P/E reliability")
    if _finite(metrics.get("fcf")) and float(metrics.get("fcf")) > 0:
        score += 4
    else:
        reasons.append("non-positive FCF reduces FCF-yield reliability")
    if reviewed:
        score += 5
    else:
        reasons.append("auto assumptions have not been reviewed/saved")
    regime_score = None
    try:
        # smart_assumptions stores this on its saved assumptions, while calibration itself
        # can be reconstructed independently. Callers may optionally copy it in.
        regime_score = calibration.get("regime_score")
    except Exception:
        regime_score = None
    if _finite(regime_score) and abs(float(regime_score)) >= .65:
        score -= 5
        reasons.append("current economics differ materially from the historical valuation regime")
    if int(revision_count or 0) > 0:
        penalty=min(10, 2*int(revision_count))
        score -= penalty
        reasons.append(f"{int(revision_count)} SEC comparative-period revision alert(s) require review")
    rb = regime_breaks or {}
    high_breaks = int(rb.get("high_count", 0) or 0)
    medium_breaks = int(rb.get("medium_count", 0) or 0)
    if high_breaks:
        score -= min(18, 10 + 4 * (high_breaks - 1))
        reasons.append(f"{high_breaks} major current-vs-history multiple regime break(s) require explanation")
    elif medium_breaks:
        score -= min(8, 4 * medium_breaks)
        reasons.append(f"{medium_breaks} material current-vs-history multiple divergence(s)")
    basis_usable=metrics.get("valuation_share_basis_usable")
    if basis_usable is False:
        score -= 25
        reasons.append(str(metrics.get("valuation_basis_issue") or "current valuation share basis is not auditable"))
    elif metrics.get("valuation_share_source")=="DILUTED_WA_FALLBACK":
        score -= 8
        reasons.append("price targets use a verified diluted weighted-average share fallback (MEDIUM basis confidence)")
    elif str(metrics.get("valuation_share_source") or "").startswith("USER_"):
        score -= 12
        reasons.append("price targets use a user-verified current share-basis override; automatic basis proof is still unresolved")
    if metrics.get("eps_basis_warning"):
        gap=metrics.get("eps_reconciliation_gap")
        penalty=10 if _finite(gap) and abs(float(gap))>.30 else 6
        score-=penalty
        reasons.append("SEC diluted EPS and NI/share proxy diverge materially; earnings-method confidence reduced")
    if metrics.get("market_cap_share_kind") == "MISSING":
        score -= 20
        reasons.append("current market-cap share count is unavailable")
    if str(metrics.get("share_denominator_kind") or "").startswith("BASIC"):
        score -= 6
        reasons.append("basic-share fallback used because diluted weighted-average shares are unavailable")
    if company_type == "Financial / REIT":
        score = min(score, 45); reasons.append("specialized bank/REIT model is required")
    if audit_summary:
        score -= 8 * int(audit_summary.get("FAIL", 0))
        score -= 2 * int(audit_summary.get("WARN", 0))
        if audit_summary.get("FAIL"):
            reasons.append("data audit contains FAIL items")
    score = clamp(score, 0, 100)
    label = "HIGH" if score >= 75 else "MEDIUM" if score >= 55 else "LOW"
    return {"score": score, "label": label, "reasons": reasons[:6]}


def implied_growth_for_price(price, metrics, base_assumptions):
    rev = metrics.get("revenue"); shares = metrics.get("valuation_shares") or metrics.get("diluted_shares"); nd = metrics.get("net_debt") or 0
    if not all(_finite(x) for x in (price, rev, shares)) or float(shares) == 0:
        return None
    a = base_assumptions; lo, hi = -0.30, 0.60
    vlo = dcf_value(rev, lo, a["fcf_margin"], a["wacc"], a["terminal_growth"], 5, nd, shares)
    vhi = dcf_value(rev, hi, a["fcf_margin"], a["wacc"], a["terminal_growth"], 5, nd, shares)
    if not _finite(vlo) or not _finite(vhi):
        return None
    target = float(price)
    if target < min(vlo, vhi) or target > max(vlo, vhi):
        return None
    for _ in range(80):
        mid = (lo + hi) / 2
        v = dcf_value(rev, mid, a["fcf_margin"], a["wacc"], a["terminal_growth"], 5, nd, shares)
        if not _finite(v):
            return None
        if float(v) < target: lo = mid
        else: hi = mid
    return (lo + hi) / 2


def resolve_assumptions(saved_payload: dict | None, metrics: dict, fund_rows: list[dict], bars: list[dict], company_type="Generic"):
    """Resolve V2.5 assumptions without silently carrying older valuation logic forward."""
    auto, calibration = smart_assumptions(metrics, fund_rows, bars, company_type)
    if isinstance(saved_payload, dict) and str(saved_payload.get("model_version")) == "2.5":
        resolved = normalize_assumptions(saved_payload, metrics, fallback=auto)
        resolved["model_version"] = "2.5"
        return resolved, calibration, False
    auto["model_version"] = "2.5"
    return auto, calibration, bool(saved_payload)
