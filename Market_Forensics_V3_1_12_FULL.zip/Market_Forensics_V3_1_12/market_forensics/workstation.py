from __future__ import annotations

import html
import json
import math
from datetime import date, datetime, timezone

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from market_forensics import alpaca, audit, db, decision, exporter, financial_flows, flow, forecast, forensics, fundamentals, jobs, management, marketdata, opportunity, sec, service, symbols, valuation, triangulation
from market_forensics.config import DB_PATH, SECRETS_PATH, alpaca_ready, load_settings, save_settings, branding_logo_path
from market_forensics.ui import missing, fmoney, fnum, fpct, fprice, safe_float

MF_PLOTLY_COLORS = [
    "#3F78A8", "#1F9D68", "#C99A2E", "#D15353", "#6E8FA8",
    "#2E8894", "#7A8B99", "#7D9B68", "#9AB7CF", "#B6C5D1",
]

APP_CSS = r"""
<style>
:root{
  --mf-line:color-mix(in srgb,var(--text-color) 34%,transparent);
  --mf-line-strong:color-mix(in srgb,var(--text-color) 50%,transparent);
  --mf-muted:color-mix(in srgb,var(--text-color) 58%,transparent);
  --mf-card:color-mix(in srgb,var(--secondary-background-color) 94%,var(--background-color));
  --mf-card-2:color-mix(in srgb,var(--secondary-background-color) 86%,var(--background-color));
  --primary-color:#3F78A8!important;--mf-cyan:#3F78A8;--mf-green:#21b873;--mf-red:#e45555;--mf-yellow:#d6a91f;
}
html{scroll-padding-top:5rem}
.stApp{background:var(--background-color);color:var(--text-color)}
.block-container{padding-top:3.65rem;padding-bottom:3rem;max-width:1650px}
section[data-testid="stSidebar"]{background:var(--secondary-background-color);border-right:1px solid var(--mf-line)}
section[data-testid="stSidebar"] [data-testid="stSidebarContent"]{padding-top:.55rem}
section[data-testid="stSidebar"] hr{margin:.75rem 0}
div[data-testid="stMetric"]{background:var(--mf-card);border:1px solid var(--mf-line);padding:13px 15px;border-radius:13px;min-height:112px}
div[data-testid="stMetricLabel"]{color:var(--mf-muted)}
.mf-hero{border:1px solid var(--mf-line);background:var(--mf-card);padding:20px 22px;border-radius:16px;margin:.25rem 0 16px}
.mf-eyebrow{font-size:.76rem;letter-spacing:.12em;color:var(--mf-cyan);text-transform:uppercase;font-weight:650}
.mf-title{font-size:2rem;font-weight:720;color:var(--text-color);margin:.15rem 0}.mf-ticker-symbol{font-size:3.05rem;line-height:1;font-weight:850;letter-spacing:-.035em}.mf-company-name{font-size:1.32rem;font-weight:430;color:var(--mf-muted)}
.mf-sub{color:var(--mf-muted);font-size:.94rem}
.mf-card{border:1px solid var(--mf-line);background:var(--mf-card);padding:15px 16px;border-radius:13px;min-height:116px;height:116px;display:flex;flex-direction:column;justify-content:space-between;box-sizing:border-box}
.mf-card-lg{min-height:168px;height:168px}
.mf-label{color:var(--mf-muted);font-size:.76rem;text-transform:uppercase;letter-spacing:.08em;font-weight:650}
.mf-value{color:var(--text-color);font-size:1.34rem;line-height:1.16;font-weight:720;margin:.22rem 0}
.mf-detail{color:var(--mf-muted);font-size:.83rem;line-height:1.35}
.mf-green{color:var(--mf-green)}.mf-red{color:var(--mf-red)}.mf-yellow{color:var(--mf-yellow)}.mf-cyan{color:var(--mf-cyan)}.mf-muted{color:var(--mf-muted)}
.mf-rule{border-top:1px solid var(--mf-line);margin:12px 0}
.small-note{color:var(--mf-muted);font-size:.84rem}
[data-testid="stDataFrame"]{border:1px solid var(--mf-line);border-radius:10px;overflow:hidden}
[data-testid="stPlotlyChart"]{border:1px solid var(--mf-line);border-radius:12px;overflow:hidden}
/* True page-link navigation: one click, no radio/select state. */
section[data-testid="stSidebar"] div[data-testid="stSelectbox"]{margin-bottom:.35rem}
section[data-testid="stSidebar"] div[data-testid="stButton"] button{min-height:2.35rem}
.mf-nav-label{font-size:.68rem;letter-spacing:.12em;color:var(--mf-muted);font-weight:700;margin:.75rem 0 .25rem}
section[data-testid="stSidebar"] [data-testid="stPageLink"] a{border-radius:8px;padding:.42rem .55rem;font-size:.91rem;text-decoration:none}
section[data-testid="stSidebar"] [data-testid="stPageLink"] a:hover{color:#3F78A8!important;background:color-mix(in srgb,#3F78A8 9%,transparent)!important;border-color:color-mix(in srgb,#3F78A8 48%,var(--mf-line))!important}
section[data-testid="stSidebar"] [data-testid="stPageLink"] a[aria-current="page"],section[data-testid="stSidebar"] [data-testid="stPageLink"] a[aria-selected="true"],section[data-testid="stSidebar"] [data-testid="stPageLink"] a:focus-visible{color:#3F78A8!important;border-color:#3F78A8!important;background:color-mix(in srgb,#3F78A8 12%,transparent)!important;outline-color:#3F78A8!important;box-shadow:0 0 0 1px color-mix(in srgb,#3F78A8 20%,transparent)!important}
.stButton>button[kind="primary"],.stDownloadButton>button[kind="primary"],button[data-testid="baseButton-primary"]{background:#3F78A8!important;border-color:#3F78A8!important;color:#fff!important}
[data-baseweb="menu"] [aria-selected="true"],[role="option"][aria-selected="true"]{background:color-mix(in srgb,#3F78A8 13%,var(--background-color))!important;color:var(--text-color)!important}
input[type="checkbox"],input[type="radio"]{accent-color:#3F78A8!important}
@media (max-width: 900px){.block-container{padding-top:3.2rem}.mf-title{font-size:1.65rem}.mf-ticker-symbol{font-size:2.35rem}.mf-company-name{font-size:1.08rem}.mf-card{height:auto;min-height:104px}}
</style>
"""

def inject_css():
    st.markdown(APP_CSS, unsafe_allow_html=True)
    # Streamlit's theme selector is not guaranteed to map to CSS media queries.
    # Set explicit border tokens from the active app theme so light/dark both stay legible.
    try:
        dark = st.context.theme.type == "dark"
    except Exception:
        dark = True
    line = "#3A4751" if dark else "#D7DEE4"
    strong = "#50606B" if dark else "#C4CDD5"
    st.markdown(
        f"""<style>
        :root,.stApp{{--mf-line:{line}!important;--mf-line-strong:{strong}!important;}}
        [data-testid="stVerticalBlockBorderWrapper"],details[data-testid="stExpander"],[data-testid="stForm"],
        [data-baseweb="select"]>div,[data-baseweb="input"]>div,[data-baseweb="textarea"]>div{{border-color:var(--mf-line)!important;}}
        </style>""",
        unsafe_allow_html=True,
    )

STATUS_OPTIONS = ["RESEARCH", "WATCHLIST", "POSITION", "EXITED", "AVOID", "ARCHIVED"]
PORTFOLIO_OPTIONS = ["NO POSITION", "LONG", "SHORT"]
COMPANY_TYPES = list(decision.COMPANY_TEMPLATES.keys())


def tk(ticker: str, *parts) -> str:
    """Ticker-scoped widget key. Prevents Streamlit Session State leaking across companies."""
    safe_ticker = "".join(ch if ch.isalnum() else "_" for ch in str(ticker).upper())
    tail = "_".join(str(x).replace(" ", "_") for x in parts)
    return f"mf_{safe_ticker}_{tail}"


def display_table(df: pd.DataFrame, formatters: dict | None = None, height=None):
    if df is None or df.empty:
        st.caption("No rows available.")
        return
    out = df.copy()
    for col, func in (formatters or {}).items():
        if col in out.columns:
            out[col] = out[col].map(func)
    kwargs = {"width": "stretch", "hide_index": True}
    if height:
        kwargs["height"] = height
    st.dataframe(out, **kwargs)


def chart_template():
    try:
        return "plotly_dark" if st.context.theme.type == "dark" else "plotly_white"
    except Exception:
        return "plotly_dark"


def style_plot(fig: go.Figure, **layout_kwargs) -> go.Figure:
    """Institutional chart defaults with an explicit non-purple colorway.

    Plotly's own first categorical color is violet-blue; any trace without a color
    used to leak that default into Advanced pages. Centralizing the palette prevents
    the fallback from ever surfacing again.
    """
    base = dict(
        template=chart_template(),
        colorway=MF_PLOTLY_COLORS,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
    )
    base.update(layout_kwargs)
    fig.update_layout(**base)
    return fig


def money(x, decimals_small=0):
    mode=load_settings().get("number_display","AUTO")
    return fmoney(x, decimals_small=decimals_small, mode=mode)


def card_html(label, value, detail="", tone="", large=False):
    cls = f"mf-card{' mf-card-lg' if large else ''}"
    tone_cls = f" mf-{tone}" if tone in {"green", "red", "yellow", "cyan"} else ""
    return (
        f'<div class="{cls}">'
        f'<div class="mf-label">{html.escape(str(label))}</div>'
        f'<div class="mf-value{tone_cls}">{html.escape(str(value))}</div>'
        f'<div class="mf-detail">{html.escape(str(detail or ""))}</div>'
        f'</div>'
    )


def missing_gate_summary(gates, limit=5):
    items = [r["gate"] for r in gates if r.get("status") in ("FAIL", "INCOMPLETE", "WATCH")]
    if not items:
        return "All 16 material process gates are complete."
    shown = items[:limit]
    suffix = f" +{len(items)-limit} more" if len(items) > limit else ""
    return "Missing / watch: " + " · ".join(shown) + suffix


def _date10(value):
    if not value:
        return None
    text=str(value).strip()
    try:
        return datetime.fromisoformat(text.replace("Z","+00:00")).date().isoformat()
    except Exception:
        try:
            return date.fromisoformat(text[:10]).isoformat()
        except Exception:
            return None


def load_state(ticker: str, live_price: bool = False):
    snap = service.latest_snapshot(ticker)
    bars = snap.get("bars", [])
    fund_rows = snap.get("fund", [])
    bar = snap.get("bar")
    scores = snap.get("scores") or {}
    model_price = bar.get("close") if bar else None
    basis_evidence = db.current_share_basis_evidence(ticker)
    override = db.share_basis_override(ticker)

    metrics = fundamentals.metrics_from_rows(
        fund_rows, model_price, bars=bars, current_basis_evidence=basis_evidence
    ) if fund_rows else {}
    # Current-only, user-audited recovery. Never enters Validate/backtest or mutates SEC facts.
    metrics = fundamentals.apply_share_basis_override(metrics, override) if metrics else metrics

    price_overlay = None
    if live_price:
        try:
            price_overlay = marketdata.current_price_overlay(ticker, load_settings().get("alpaca_feed", "auto"))
        except Exception:
            price_overlay = None

    display_price = (price_overlay or {}).get("price") or model_price
    valuation_price = model_price
    live_price_for_valuation = False
    live_price_basis_note = ""

    if price_overlay and price_overlay.get("price") not in (None, 0):
        overlay_date = _date10(price_overlay.get("asof"))
        if not fund_rows:
            # Portfolio-only names have no per-share fundamental denominator to reconcile yet.
            valuation_price = price_overlay.get("price")
            live_price_for_valuation = True
            live_price_basis_note = "No fundamental share denominator is in use yet."
        elif overlay_date:
            if override and int(override.get("confirmed") or 0) == 1:
                # A manual current-basis share count is only certified as of the date the user supplied.
                # Never roll it through a later quote automatically; a split after that date would require
                # changing the manual share count itself, not merely accepting a new price.
                override_date = _date10(override.get("basis_date"))
                if override_date and overlay_date <= override_date:
                    valuation_price = price_overlay.get("price")
                    live_price_for_valuation = True
                    live_price_basis_note = "Live quote date is within the user-verified share-basis date."
                else:
                    live_price_basis_note = "Display-only quote: manual share-basis approval predates this market quote. Refresh or re-verify the basis before using the newer price in valuation."
            else:
                ev = basis_evidence or {}
                verified_through = _date10(ev.get("verified_through"))
                evidence_ok = str(ev.get("status") or "").upper() == "VERIFIED" and verified_through and verified_through >= overlay_date
                if not evidence_ok:
                    anchor = _date10((metrics or {}).get("valuation_share_fact_date") or (metrics or {}).get("diluted_shares_date"))
                    if anchor:
                        try:
                            fresh_ev = marketdata.current_split_basis_evidence(ticker, anchor, overlay_date)
                            if str(fresh_ev.get("status") or "").upper() == "VERIFIED":
                                db.save_current_share_basis_evidence(ticker, fresh_ev)
                                basis_evidence = fresh_ev
                                evidence_ok = True
                        except Exception as exc:
                            live_price_basis_note = f"Display-only quote: corporate-action verification through {overlay_date} is unavailable ({exc})."
                if evidence_ok:
                    # Recompute all current price-dependent ratios on the recent quote while retaining the
                    # exact same SEC fundamentals and historical bars. Intrinsic assumptions remain sourced
                    # from the normal valuation engine; only the current market observation changes.
                    metrics = fundamentals.metrics_from_rows(
                        fund_rows, price_overlay.get("price"), bars=bars, current_basis_evidence=basis_evidence
                    )
                    valuation_price = price_overlay.get("price")
                    live_price_for_valuation = True
                    live_price_basis_note = f"Corporate-action/share basis verified through {overlay_date}."
                elif not live_price_basis_note:
                    live_price_basis_note = f"Display-only quote: share basis is not verified through {overlay_date}."
        else:
            live_price_basis_note = "Display-only quote: provider timestamp is unavailable, so valuation remains on the last verified model price."

    if price_overlay is not None:
        price_overlay = dict(price_overlay)
        price_overlay["valuation_usable"] = bool(live_price_for_valuation)
        price_overlay["basis_note"] = live_price_basis_note
        price_overlay["display_price"] = display_price
        price_overlay["valuation_price"] = valuation_price

    coverage = db.coverage_row(ticker) or {}
    assumptions, calibration, legacy_valuation = valuation.resolve_assumptions(
        db.load_json_assumptions(ticker), metrics, fund_rows, bars, coverage.get("company_type","Generic")
    )
    scenarios, expected_value = valuation.scenario_values(metrics, assumptions) if metrics else ({}, None)
    base_value = scenarios.get("base", {}).get("fair_value") if scenarios else None
    price = valuation_price
    upside = (base_value / price - 1) if base_value is not None and price not in (None, 0) else None
    kpis = db.query("SELECT * FROM monitoring_kpis WHERE ticker=? ORDER BY importance DESC,id", (ticker.upper(),))
    kpi_eval = []
    for row in kpis:
        value, status = decision.kpi_status(row, metrics, snap)
        kpi_eval.append({**row, "current_value": value, "kpi_status": status})
    state = {
        "snap": snap, "bars": bars, "fund_rows": fund_rows, "bar": bar, "scores": scores,
        "metrics": metrics, "assumptions": assumptions, "scenarios": scenarios,
        "expected_value": expected_value, "base_value": base_value, "price": price, "display_price": display_price,
        "model_price": model_price, "price_overlay": price_overlay, "upside": upside,
        "coverage": coverage, "gates": [], "gate_counts": {"PASS":0,"WATCH":0,"FAIL":0,"INCOMPLETE":16}, "gate_label": "RESEARCH INCOMPLETE",
        "kpis": kpis, "kpi_eval": kpi_eval, "calibration": calibration, "legacy_valuation": legacy_valuation,
    }
    ar = audit.build_audit(ticker, state)
    state["audit"] = ar
    # Carry the V2.3 regime diagnostic into the calibration object used by confidence scoring.
    calibration_for_conf = dict(calibration or {})
    calibration_for_conf["regime_score"] = (assumptions.get("calibration") or {}).get("regime_score")
    state["valuation_regime"] = valuation.multiple_regime_diagnostics(metrics, price, calibration)
    revision_count = len(db.query("SELECT 1 FROM sec_revisions WHERE ticker=?", (ticker.upper(),)))
    state["valuation_confidence"] = valuation.valuation_confidence(
        metrics, scenarios, calibration_for_conf, coverage.get("company_type","Generic"), ar.get("counts"),
        reviewed=bool(assumptions.get("reviewed_at")), revision_count=revision_count,
        regime_breaks=state["valuation_regime"],
    )
    state["forensics"] = forensics.build_forensic_signals(ticker, state, calibration, ar)
    state["management"] = management.credibility_summary(ticker)
    state["quality_validation"] = management.quality_cross_checks(ticker, metrics, state["forensics"], state["management"])
    f_auto = forecast.auto_assumptions(metrics, fund_rows, assumptions) if metrics else {"model_version":"2.7","years":5,"bear":{},"base":{},"bull":{},"reviewed_at":None}
    state["forecast_assumptions"] = forecast.normalize_assumptions(db.load_forecast_assumptions(ticker), f_auto)
    state["forecast_scenarios"] = forecast.scenario_summary(metrics, state["forecast_assumptions"], price) if metrics else {}
    state["price_reconciliation"] = forecast.price_reconciliation(price, metrics, state["forecast_assumptions"], state["forecast_scenarios"]) if metrics and price else {}
    state["variant_case"] = db.load_variant_case(ticker)
    state["triangulation"] = triangulation.compare(ticker)
    # Gates are calculated last so Expectations and Variant use the same canonical state shown in Decide.
    gates = decision.investment_gates(ticker, metrics, scenarios, expected_value, coverage, state=state)
    gate_counts, gate_label = decision.gate_summary(gates)
    state["gates"] = gates
    state["gate_counts"] = gate_counts
    state["gate_label"] = gate_label
    return state

def hero(ticker: str, state: dict, subtitle: str):
    meta = (state["snap"].get("meta") or [{}])[0]
    cov = state["coverage"]
    st.markdown(
        f"""<div class="mf-hero"><div class="mf-eyebrow">MARKET FORENSICS V3.1.12 · {cov.get('status','RESEARCH')} · {cov.get('portfolio_state','NO POSITION')}</div>
        <div class="mf-title"><span class="mf-ticker-symbol">{ticker}</span> <span class="mf-company-name">{meta.get('company_name') or ''}</span></div>
        <div class="mf-sub">{subtitle}</div></div>""",
        unsafe_allow_html=True,
    )


def safe_age(iso_text):
    if not iso_text:
        return None
    try:
        dt = datetime.fromisoformat(str(iso_text).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return datetime.now(timezone.utc) - dt
    except Exception:
        return None


def freshness_label(last_refresh):
    stamp = None
    if last_refresh:
        stamp = last_refresh.get("completed_at") or last_refresh.get("started_at")
    return opportunity.freshness(stamp)["label"]


def last_updated_label(last_refresh):
    if not last_refresh:
        return "Never"
    stamp = last_refresh.get("completed_at") or last_refresh.get("started_at")
    if not stamp:
        return "Never"
    try:
        dt = datetime.fromisoformat(str(stamp).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        # Render in the computer's local timezone; SQLite keeps the canonical UTC value.
        return dt.astimezone().strftime("%Y-%m-%d %H:%M")
    except Exception:
        return str(stamp)


def start_background_refresh(tickers, reason="MANUAL"):
    result = jobs.start_or_enqueue(tickers, reason=reason, include_flow=True)
    if result.get("batch_id"):
        st.session_state["mf_refresh_batch_id"] = int(result["batch_id"])
        st.session_state["mf_batch_needs_reload"] = int(result["batch_id"])
    return result


def render_background_refresh_monitor():
    """Sidebar monitor for a non-blocking refresh batch.

    The worker is a plain Python daemon thread and never calls Streamlit. This fragment only polls
    SQLite, so the user can move between pages while the refresh continues.
    """
    active = jobs.active_batch()
    remembered = st.session_state.get("mf_refresh_batch_id")
    batch_id = int(active["id"]) if active else int(remembered) if remembered else None
    if not batch_id:
        return
    run_every = "2s" if active else None

    @st.fragment(run_every=run_every)
    def _monitor():
        batch = jobs.batch_status(batch_id, include_items=True)
        if not batch:
            return
        status = str(batch.get("status") or "").upper()
        total = int(batch.get("total") or 0)
        completed = int(batch.get("completed") or 0)
        passed = int(batch.get("passed") or 0)
        failed = int(batch.get("failed") or 0)
        if status in ("QUEUED", "RUNNING"):
            st.caption(f"Background refresh · {completed}/{total} · {batch.get('current_ticker') or 'starting…'}")
            st.progress((completed / total) if total else 0.0)
            st.caption("You can keep navigating while this runs.")
        else:
            partial_items = [x for x in (batch.get("items") or []) if x.get("status") == "PARTIAL"]
            if status == "PASS":
                st.success(f"Refresh complete · {passed}/{total}")
            elif status == "PARTIAL":
                st.warning(f"Refresh complete · {passed} full · {len(partial_items)} partial · {failed} fail")
            elif status in ("FAIL", "INTERRUPTED"):
                st.error(f"Refresh {status.lower()} · {passed} pass · {failed} fail")
            failed_items = [x for x in (batch.get("items") or []) if x.get("status") == "FAIL"]
            if partial_items:
                st.caption("Partial: " + ", ".join(x.get("ticker", "?") for x in partial_items[:6]))
            if failed_items:
                st.caption("Failed: " + ", ".join(x.get("ticker", "?") for x in failed_items[:6]))
            if st.session_state.get("mf_batch_needs_reload") == batch_id:
                # One full rerun when the batch finishes refreshes Coverage values without trapping the UI.
                st.session_state["mf_batch_needs_reload"] = None
                st.rerun()

    _monitor()

def grouped_gate_state(gates):
    groups = {
        "BUSINESS": ["business", "five_year_financials", "working_capital", "value_drivers"],
        "VALUE": ["expectations", "variant", "scenarios", "expected_value"],
        "BEAR / CATALYST": ["counter_thesis", "catalysts", "invalidation", "evidence_to_add"],
        "RISK / PROCESS": ["sizing", "concentration", "sources", "journal"],
    }
    by = {r["key"]: r["status"] for r in gates}
    out = {}
    for name, keys in groups.items():
        vals = [by.get(k, "INCOMPLETE") for k in keys]
        if "FAIL" in vals:
            out[name] = "FAIL"
        elif "INCOMPLETE" in vals:
            out[name] = "INCOMPLETE"
        elif "WATCH" in vals:
            out[name] = "WATCH"
        else:
            out[name] = "PASS"
    return out


def process_call(state):
    triggered = [x for x in state["kpi_eval"] if x["kpi_status"] == "TRIGGERED"]
    if triggered:
        return "THESIS / RISK TRIGGER", "One or more REDUCE / EXIT / INVALIDATION monitoring rules are currently breached.", "red"
    label = state["gate_label"]
    if label == "PROCESS BLOCKED":
        return label, "A material gate is marked FAIL. Do not hide it inside an average score.", "red"
    if label == "RESEARCH INCOMPLETE":
        return label, "The research process is not complete enough for a capital decision.", "yellow"
    if label == "WATCH / NEED EVIDENCE":
        return label, "Most of the process is built, but important evidence is still missing or on WATCH.", "yellow"
    return "PROCESS COMPLETE", "All material gates are complete. The decision still depends on value, evidence, timing and risk.", "green"


def value_tape_call(state):
    price, base, upside, scores = state["price"], state["base_value"], state["upside"], state["scores"]
    if price in (None, 0) or base is None or not scores:
        return "LOW DATA", "Need both fundamental valuation and tape data."
    cheap = upside is not None and upside >= 0.15
    expensive = upside is not None and upside <= -0.15
    supportive = scores.get("Net Tape", 0) >= 60 and scores.get("Absorption", 0) >= 55
    weak = scores.get("Net Tape", 50) < 45 or scores.get("Price Resilience", 50) < 45
    if cheap and supportive:
        return "VALUE + SUPPORTIVE TAPE", "Value and market response are aligned. Any ADD still requires evidence defined before the move."
    if cheap and weak:
        return "VALUE UNDER PRESSURE", "The valuation case may be attractive, but sellers still control price response. Separate opportunity from timing."
    if expensive and weak:
        return "EXPENSIVE + WEAK TAPE", "Both valuation and tape challenge the current price. Shorting still requires catalyst, invalidation and sizing."
    if expensive and supportive:
        return "EXPENSIVE BUT SUPPORTED", "Expectations look demanding, but flows/resilience remain supportive. Do not short valuation alone."
    return "MIXED / WAIT FOR CONVERGENCE", "No dominant alignment between value and tape."


def render_sidebar(nav_items):
    """Common workstation frame with true page links (not radio/select navigation)."""
    settings = load_settings()
    rows = db.list_coverage()
    saved = [r["ticker"] for r in rows]
    current = st.session_state.get("ticker")
    if saved:
        if current not in saved:
            current = saved[0]
    else:
        current = ""

    with st.sidebar:
        logo = branding_logo_path()
        if logo:
            st.image(str(logo), width=170)
            st.markdown("### Market Forensics")
        else:
            st.markdown("### ◈ Market Forensics")
        st.caption("V3.1.12 · Advanced detail")

        if saved:
            selected = st.selectbox(
                "Ticker", saved,
                index=saved.index(current) if current in saved else 0,
                key="saved_ticker_select",
            )
            st.session_state["ticker"] = selected
            current = selected
        else:
            st.caption("No saved Coverage tickers yet.")
            st.session_state["ticker"] = ""

        st.markdown("<div class='mf-nav-label'>WORKSPACE</div>", unsafe_allow_html=True)
        for item in nav_items:
            st.page_link(
                item["page"],
                label=item["label"],
                icon=item.get("icon"),
                width="stretch",
                disabled=bool(item.get("requires_ticker", True) and not saved),
            )

        if st.button("Refresh selected", type="primary", width="stretch", key="refresh_selected", disabled=not bool(current)):
            result = start_background_refresh([current], reason="SELECTED")
            if result.get("already_active"):
                st.toast(f"{current} queued into the active refresh batch.")
            else:
                st.toast(f"Refreshing {current} in background.")
            st.rerun()

        render_background_refresh_monitor()

        st.markdown("---")
        st.caption("Appearance: top-right ⋮ → Settings → Theme (Light / Dark).")
        if not alpaca_ready():
            st.error("Alpaca: MISSING")
        else:
            st.success("Alpaca: READY")
        if not settings.get("sec_user_agent") or "@" not in settings.get("sec_user_agent", ""):
            st.warning("SEC not configured → Settings")
        if current:
            last = service.last_successful_refresh(current)
            latest_attempt = service.last_refresh(current)
            st.caption(f"Last successful refresh: {freshness_label(last)}")
            if latest_attempt and latest_attempt.get("status") == "FAIL":
                st.error("Latest refresh attempt failed. Data freshness was not reset.")
    return current


def render_footer():
    st.markdown('<div class="mf3-footer">Lose Money Rules</div>', unsafe_allow_html=True)


def run_company_page(renderer, page_name: str):
    ticker = st.session_state.get("ticker") or ""
    if not ticker:
        st.warning("Select a company first. You can add a real position directly in Portfolio, even before writing a thesis.")
        return
    # Advanced pages always belong visibly to one parent workflow. This replaces the old feeling
    # of entering a dead-end subpage with no way back.
    parent_map={
        "Business & Fundamentals":("pages/03_research_v3.py","Research"),
        "Financial Flows":("pages/03_research_v3.py","Research"),
        "Management & 5Y Operating Forecast":("pages/03_research_v3.py","Research"),
        "Valuation Cases & Expectations":("pages/02_decide_v3.py","Decide"),
        "Tape & Positioning":("pages/03_research_v3.py","Research"),
        "Monitoring & Events":("pages/04_monitor_v3.py","Monitor"),
        "Thesis & Bear Case":("pages/02_decide_v3.py","Decide"),
        "Risk & Journal":("pages/02_decide_v3.py","Decide"),
        "Portfolio & Exposure":("pages/05_portfolio_v3.py","Portfolio"),
        "Sources & Audit":("pages/03_research_v3.py","Research"),
    }
    if page_name in parent_map:
        parent_path,parent_label=parent_map[page_name]
        c1,c2=st.columns([1.0,4.0])
        c1.page_link(parent_path,label=f"← Back to {parent_label}",width="stretch")
        c2.caption(f"{parent_label}  ›  {page_name}")
    # Do not force a Coverage record: portfolio-only companies are valid before research starts.
    try:
        state = load_state(ticker, live_price=True)
    except Exception as e:
        st.error(f"Could not load {ticker}: {e}")
        state={"snap":{},"bars":[],"fund_rows":[],"bar":None,"scores":{},"metrics":{},"assumptions":valuation.default_assumptions({}),"scenarios":{},"expected_value":None,"base_value":None,"price":None,"model_price":None,"price_overlay":None,"upside":None,"coverage":db.coverage_row(ticker) or {},"gates":[],"gate_counts":{"PASS":0,"WATCH":0,"FAIL":0,"INCOMPLETE":16},"gate_label":"RESEARCH INCOMPLETE","kpis":[],"kpi_eval":[],"calibration":{"observations":[]},"legacy_valuation":False,"audit":{"counts":{}},"valuation_confidence":{"label":"LOW","score":0,"reasons":["load failed"]},"valuation_regime":{"rows":[],"high_count":0,"medium_count":0,"economics":"UNKNOWN"},"forensics":{"all":[],"positives":[],"negatives":[],"data_alerts":[]}}
    try:
        renderer(ticker, state)
    except Exception as e:
        st.error(f"{page_name} hit an error. Use the parent link above or the sidebar to continue.")
        with st.expander("Technical details"):
            st.exception(e)
    render_footer()


def render_coverage(selected_ticker):
    st.markdown('<div class="mf-eyebrow">HOME · OPPORTUNITY RADAR</div>', unsafe_allow_html=True)
    st.title("Coverage")
    st.caption("A research-priority radar: find the names with the strongest long/short edge, see what is stale, and ignore the middle until something changes.")

    message = st.session_state.pop("coverage_message", None)
    if message:
        st.info(message)

    rows = db.list_coverage(include_archived=True)

    # Background controls are intentionally above the table: one click can refresh the whole list
    # while the user continues to navigate other pages.
    rc1, rc2, rc3 = st.columns([1.25, 1.0, 2.75])
    if rc1.button("Refresh All Coverage", type="primary", width="stretch", disabled=not bool(rows), help="Refreshes every non-archived covered ticker, including flow. Runs in background one ticker at a time."):
        targets = [r["ticker"] for r in rows if r.get("status") != "ARCHIVED"]
        result = start_background_refresh(targets, reason="REFRESH_ALL")
        st.session_state["coverage_message"] = f"Background refresh started/updated for {len(targets)} ticker(s). You can keep navigating."
        st.rerun()
    stale_now = jobs.stale_tickers(max_age_hours=24, include_archived=False) if rows else []
    if rc2.button("Refresh Stale", width="stretch", disabled=not bool(stale_now), help="Refreshes only names whose last successful refresh is older than 24 hours or missing."):
        start_background_refresh(stale_now, reason="REFRESH_STALE")
        st.session_state["coverage_message"] = f"Queued {len(stale_now)} stale ticker(s) for background refresh."
        st.rerun()
    rc3.caption("Freshness is based on the last SUCCESSFUL refresh. Older than 24h is red; a failed attempt never makes stale data look fresh.")

    with st.expander("Add company to Coverage", expanded=not rows):
        with st.form("add_cov"):
            c1, c2, c3, c4 = st.columns(4)
            t = c1.text_input("Ticker", value="")
            status = c2.selectbox("Status", STATUS_OPTIONS, index=0)
            ctype = c3.selectbox("Company type", COMPANY_TYPES)
            priority = c4.selectbox("Manual Priority", [1, 2, 3, 4, 5], index=2, help="Your own override/reference. Coverage is sorted by dynamic System Priority by default.")
            tags = st.text_input("Factor / exposure tags", placeholder="consumer, China, rates, AI capex")
            if st.form_submit_button("Add to Coverage") and t.strip():
                validation = symbols.validate_ticker(t)
                if not validation.valid:
                    st.error(validation.message or "Ticker not found / symbol not recognized.")
                else:
                    tick = validation.ticker
                    db.ensure_coverage(tick, status)
                    db.update_coverage(tick, status=status, company_type=ctype, priority=priority, tags=tags)
                    st.session_state["ticker"] = tick
                    start_background_refresh([tick], reason="AUTO_ADD")
                    st.session_state["coverage_message"] = f"{tick} added. Its first full refresh started automatically in the background."
                    st.rerun()

    if not rows:
        st.info("Add your first ticker. Market Forensics will refresh it automatically after it is added.")
        return

    data = []
    intelligence = {}
    for r in rows:
        s = service.coverage_summary_row(r["ticker"])
        last_ok = service.last_successful_refresh(r["ticker"])
        latest_attempt = service.last_refresh(r["ticker"])
        try:
            state = load_state(r["ticker"])
            counts = state["gate_counts"]
            readiness = f"{counts['PASS']}/16 PASS"
            process_state = state["gate_label"]
            vc = state.get("valuation_confidence") or {}
            s["Valuation Confidence"] = f"{vc.get('label','LOW')} {fnum(vc.get('score'),0)}/100"
            fc = (state.get("forensics") or {}).get("counts", {})
            s["Forensics"] = f"+{fc.get('POSITIVE',0)} / -{fc.get('NEGATIVE',0)} / data {fc.get('DATA',0)}"
            qv = state.get("quality_validation") or {}
            mg = state.get("management") or {}
            s["Quality"] = f"{qv.get('label','LOW DATA')} {fnum(qv.get('score'),0)}/100"
            s["Management"] = f"{mg.get('label','LOW DATA')} {fnum(mg.get('score'),0)}/100" if mg.get('score') is not None else "LOW DATA"
            intel = opportunity.evaluate(state, last_ok)
        except Exception as exc:
            readiness = "—"
            process_state = "LOAD ERROR"
            s["Valuation Confidence"] = "—"
            s["Forensics"] = "—"
            s["Quality"] = "—"
            s["Management"] = "—"
            intel = {
                "setup": "DATA REVIEW", "focus": "DATA REVIEW", "system_priority": 1,
                "long_score": 50.0, "short_score": 50.0, "valuation_gap": None,
                "actionability": "RESEARCH FIRST", "reason": f"load error: {str(exc)[:80]}",
                "next_action": "Fix data/model load before using this name",
                "freshness": opportunity.freshness((last_ok or {}).get("completed_at")),
            }
        intelligence[r["ticker"]] = intel
        fresh = intel.get("freshness") or opportunity.freshness((last_ok or {}).get("completed_at"))
        latest_status = (latest_attempt or {}).get("status") or "NEVER"
        if latest_status == "FAIL":
            latest_status = "⚠ FAIL"
        elif latest_status == "RUNNING":
            latest_status = "↻ RUNNING"
        elif latest_status == "PASS":
            latest_status = "PASS"

        s["System Priority"] = f"P{intel.get('system_priority',5)}"
        s["Focus"] = intel.get("focus", "LOW DATA")
        s["Setup"] = intel.get("setup", "LOW DATA")
        s["Long Score"] = intel.get("long_score")
        s["Short Score"] = intel.get("short_score")
        s["System View"] = intel.get("reason", "")
        s["Next Action"] = intel.get("next_action", "")
        s["Freshness"] = fresh.get("label")
        s["Last Updated"] = last_updated_label(last_ok)
        s["Latest Attempt"] = latest_status
        s["Manual Priority"] = r.get("priority", 3)
        s["Research Gates"] = readiness
        s["Process"] = process_state
        data.append(s)

    long_focus = sum(1 for x in intelligence.values() if str(x.get("focus", "")).startswith("LONG"))
    short_focus = sum(1 for x in intelligence.values() if str(x.get("focus", "")).startswith("SHORT"))
    data_review = sum(1 for x in intelligence.values() if x.get("focus") == "DATA REVIEW")
    stale_count = sum(1 for x in intelligence.values() if (x.get("freshness") or {}).get("status") in ("STALE", "VERY STALE", "NEVER"))
    a, b, c, d, e = st.columns(5)
    a.metric("Covered", len(rows))
    b.metric("Long focus/watch", long_focus)
    c.metric("Short focus/watch", short_focus)
    d.metric("Data review", data_review)
    e.metric("Stale >24h", stale_count)

    f1, f2, f3, f4 = st.columns([1.3, 1.5, 1.3, 2.2])
    status_filter = f1.multiselect("Filter status", STATUS_OPTIONS, default=[])
    focus_options = sorted({str(x.get("focus")) for x in intelligence.values() if x.get("focus")})
    focus_filter = f2.multiselect("Filter focus", focus_options, default=[])
    portfolio_filter = f3.multiselect("Filter portfolio", PORTFOLIO_OPTIONS, default=[])
    search_filter = f4.text_input("Search Coverage", "", placeholder="ticker / setup / focus / regime / status")

    df = pd.DataFrame(data)
    if not df.empty:
        df["_SystemSort"] = df["System Priority"].astype(str).str.replace("P", "", regex=False).astype(float)
        df["_EdgeSort"] = df[["Long Score", "Short Score"]].max(axis=1)
        df = df.sort_values(["_SystemSort", "_EdgeSort", "Ticker"], ascending=[True, False, True])
    if status_filter:
        df = df[df["Status"].isin(status_filter)]
    if focus_filter:
        df = df[df["Focus"].isin(focus_filter)]
    if portfolio_filter:
        df = df[df["Portfolio"].isin(portfolio_filter)]
    if search_filter.strip():
        q = search_filter.strip().lower()
        mask = df.astype(str).apply(lambda col: col.str.lower().str.contains(q, regex=False)).any(axis=1)
        df = df[mask]

    preferred = [
        "System Priority", "Ticker", "Focus", "Setup", "Long Score", "Short Score",
        "Price", "Base FV", "Upside", "Fundamental", "Quality", "Management", "Valuation Confidence", "Net Tape",
        "Freshness", "Last Updated", "Latest Attempt", "Research Gates", "Process",
        "Manual Priority", "Portfolio", "Status", "Regime", "System View", "Next Action",
    ]
    preferred = [c for c in preferred if c in df.columns]
    display_table(
        df[preferred],
        {
            "Price": fprice, "Base FV": fprice, "Upside": fpct, "Fundamental": lambda x: fnum(x, 2),
            "Net Tape": lambda x: fnum(x, 0), "Long Score": lambda x: fnum(x, 0),
            "Short Score": lambda x: fnum(x, 0),
        },
        height=560,
    )
    st.caption("System Priority is dynamic and recalculates after refresh: P1 = strongest research attention (or urgent DATA REVIEW), P5 = low-data/deprioritized. It does not overwrite your Manual Priority and is not a trade instruction.")

    st.subheader("Open / manage a covered company")
    tickers = [r["ticker"] for r in rows]
    open_ticker = st.selectbox("Ticker", tickers, index=tickers.index(selected_ticker) if selected_ticker in tickers else 0, key="coverage_open")
    c1, c2 = st.columns([1, 4])
    if c1.button("Open Command Center", width="stretch"):
        st.session_state["ticker"] = open_ticker
        st.session_state["page"] = "Command Center"
        st.rerun()
    selected_intel = intelligence.get(open_ticker) or {}
    c2.info(f"{selected_intel.get('focus','LOW DATA')} · {selected_intel.get('setup','LOW DATA')} · {selected_intel.get('next_action','Refresh / review data')}")

    cov = db.coverage_row(open_ticker) or {}
    with st.expander(f"Coverage settings · {open_ticker}"):
        with st.form(tk(open_ticker,"manage_cov")):
            c1, c2, c3, c4 = st.columns(4)
            status = c1.selectbox("Research status", STATUS_OPTIONS, index=STATUS_OPTIONS.index(cov.get("status", "RESEARCH")))
            pstate = c2.selectbox("Portfolio state", PORTFOLIO_OPTIONS, index=PORTFOLIO_OPTIONS.index(cov.get("portfolio_state", "NO POSITION")))
            ctype = c3.selectbox("Company type", COMPANY_TYPES, index=COMPANY_TYPES.index(cov.get("company_type", "Generic")) if cov.get("company_type", "Generic") in COMPANY_TYPES else 0)
            priority = c4.selectbox("Manual Priority", [1,2,3,4,5], index=max(0, min(4, int(cov.get("priority",3))-1)), help="Your own priority. System Priority remains automatic.")
            p1, p2, p3 = st.columns(3)
            shares = p1.number_input("Shares", value=float(cov.get("shares_owned") or 0), step=1.0)
            avg = p2.number_input("Average cost", value=float(cov.get("avg_cost") or 0), step=1.0)
            horizon = p3.number_input("Thesis horizon (months)", value=int(cov.get("thesis_horizon_months") or 24), min_value=1, step=1)
            tags = st.text_input("Factor / exposure tags", value=cov.get("tags", ""))
            notes = st.text_area("Coverage notes", value=cov.get("notes", ""))
            if st.form_submit_button("Save Coverage settings"):
                db.update_coverage(open_ticker, status=status, portfolio_state=pstate, company_type=ctype, priority=priority, shares_owned=shares, avg_cost=avg, thesis_horizon_months=horizon, tags=tags, notes=notes)
                st.success("Saved.")
                st.rerun()

        st.markdown("**Remove from Coverage**")
        st.caption("Removes the ticker from the Coverage list but keeps all downloaded market data, research, journal and history locally. Re-adding it later restores access to that history.")
        remove_confirm = st.checkbox(f"I want to remove {open_ticker} from Coverage", key=f"remove_cov_confirm_{open_ticker}")
        if st.button(f"Remove {open_ticker} from Coverage", disabled=not remove_confirm, key=f"remove_cov_{open_ticker}"):
            db.remove_from_coverage(open_ticker)
            remaining = [r["ticker"] for r in db.list_coverage()]
            st.session_state["ticker"] = remaining[0] if remaining else ""
            st.session_state["page"] = "Coverage"
            st.session_state["coverage_message"] = f"{open_ticker} removed from Coverage. Its local history was kept."
            st.rerun()

def render_command_center(ticker, state):
    hero(ticker, state, "One screen: business, value, expectations, tape, risk, gates and the next evidence that matters.")
    last = service.last_successful_refresh(ticker)
    latest_attempt = service.last_refresh(ticker)
    process, process_desc, tone = process_call(state)
    vt, vt_desc = value_tape_call(state)
    next_evt = decision.next_event(ticker)
    fscore, _ = fundamentals.fundamental_score(state["metrics"]) if state["metrics"] else (None, {})

    vc=state.get("valuation_confidence") or {}
    top_cards = [
        ("Price", fprice(state["price"]), fpct(state["bar"].get("return"), 2) if state["bar"] else "", ""),
        ("Bear Fair Value", fprice(state["scenarios"].get("bear",{}).get("fair_value")), "Downside case", "red"),
        ("Base Fair Value", fprice(state["base_value"]), fpct(state["upside"]) if state["upside"] is not None else "", "cyan"),
        ("Bull Fair Value", fprice(state["scenarios"].get("bull",{}).get("fair_value")), "Upside case", "green"),
        ("Expected Value", fprice(state["expected_value"]), "Probability weighted", ""),
        ("Valuation Confidence", vc.get("label","LOW"), f"{fnum(vc.get('score'),0)}/100", "green" if vc.get("label")=="HIGH" else "yellow"),
        ("Net Tape", fnum(state["scores"].get("Net Tape"), 0), f"{state['scores'].get('Regime') or 'LOW DATA'} · Data {fnum(state['scores'].get('Confidence'),0)}/100", ""),
        ("Research Gates", f"{state['gate_counts']['PASS']}/16", state.get("gate_label", ""), "green" if state["gate_counts"]["PASS"] == 16 else "yellow"),
    ]
    for batch in (top_cards[:4], top_cards[4:]):
        cols = st.columns(4)
        for c, item in zip(cols, batch):
            c.markdown(card_html(*item), unsafe_allow_html=True)

    data_audit = state.get("audit") or audit.build_audit(ticker, state)
    ac = data_audit["counts"]
    st.caption(f"Data Audit: {ac.get('PASS',0)} PASS · {ac.get('WARN',0)} WARN · {ac.get('FAIL',0)} FAIL · {ac.get('NO DATA',0)} NO DATA. PASS means internal reconciliation succeeded; it is not a claim that an external filing can never contain an error.")

    opp = opportunity.evaluate(state, service.last_successful_refresh(ticker))
    opp_tone = "red" if opp.get("focus") in ("SHORT FOCUS", "DATA REVIEW") else "green" if opp.get("focus") == "LONG FOCUS" else "yellow"
    st.markdown(
        card_html(
            "Coverage Opportunity Radar",
            f"P{opp.get('system_priority',5)} · {opp.get('focus','LOW DATA')}",
            f"{opp.get('setup','LOW DATA')} · Long {fnum(opp.get('long_score'),0)} / Short {fnum(opp.get('short_score'),0)} · {opp.get('next_action','')}",
            opp_tone,
            large=True,
        ),
        unsafe_allow_html=True,
    )

    fs=state.get("forensics") or {"positives":[],"negatives":[],"data_alerts":[],"counts":{}}
    st.subheader("Forensic Signals")
    st.caption("Rule-based evidence review: data inconsistencies are separated from business/valuation positives and negatives. Signals are prompts to investigate, not trade instructions.")
    if fs.get("data_alerts"):
        high=[x for x in fs["data_alerts"] if x.get("Severity")=="HIGH"]
        text=" · ".join(x.get("Signal","") for x in (high or fs["data_alerts"])[:3])
        if high:
            st.error(f"Data review required: {text}")
        else:
            st.warning(f"Data review: {text}")
    pcol,ncol=st.columns(2)
    with pcol:
        st.markdown(f"**Positive evidence · {len(fs.get('positives',[]))} signals**")
        if fs.get("positives"):
            for x in fs["positives"][:5]:
                st.success(f"{x['Signal']} — {x['Evidence']}")
        else: st.caption("No material positive rule triggered yet.")
    with ncol:
        st.markdown(f"**Negative / challenge evidence · {len(fs.get('negatives',[]))} signals**")
        if fs.get("negatives"):
            for x in fs["negatives"][:5]:
                st.warning(f"{x['Signal']} — {x['Evidence']}")
        else: st.caption("No material negative rule triggered yet.")
    with st.expander("Full forensic evidence table"):
        display_table(pd.DataFrame(fs.get("all",[])),height=420)

    st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)
    l, r = st.columns(2)
    with l:
        st.markdown(
            card_html(
                "Decision Readiness",
                f"{process} · {state['gate_counts']['PASS']}/16",
                f"{process_desc} {missing_gate_summary(state['gates'])}",
                tone,
                large=True,
            ),
            unsafe_allow_html=True,
        )
    with r:
        regime_detail = f"Regime {state['scores'].get('Regime')} · Confidence {fnum(state['scores'].get('Confidence'),0)}/100" if state["scores"] else "Need both valuation and tape data."
        st.markdown(card_html("Value × Tape", vt, f"{vt_desc} {regime_detail}", "cyan", large=True), unsafe_allow_html=True)

    grouped = grouped_gate_state(state["gates"])
    cards = st.columns(4)
    for c, (name, status) in zip(cards, grouped.items()):
        tone_name = "green" if status == "PASS" else "red" if status == "FAIL" else "yellow"
        c.markdown(card_html(name, status, "Process gate", tone_name), unsafe_allow_html=True)

    left, right = st.columns([1.55, 1])
    with left:
        if state["bars"]:
            df = pd.DataFrame(state["bars"])
            df["trade_date"] = pd.to_datetime(df["trade_date"])
            fig = go.Figure()
            fig.add_trace(go.Candlestick(
                x=df["trade_date"], open=df["open"], high=df["high"], low=df["low"], close=df["close"], name="Price",
                increasing_line_color="#1F9D68", increasing_fillcolor="#1F9D68",
                decreasing_line_color="#D15353", decreasing_fillcolor="#D15353",
            ))
            if state["base_value"] is not None:
                fig.add_hline(y=state["base_value"], line_dash="dash", line_color="#3F78A8", annotation_font_color="#3F78A8", annotation_text="Base FV")
            style_plot(fig, height=420, margin=dict(l=10,r=10,t=35,b=10), xaxis_rangeslider_visible=False, title="Price vs Base Fair Value")
            st.plotly_chart(fig, width="stretch")
    with right:
        st.subheader("What changed?")
        history = service.snapshot_history(ticker, 10)
        for item in decision.what_changed(history):
            st.write(f"• {item}")
        st.subheader("What would change the tape regime?")
        for item in flow.regime_requirements(state["scores"]):
            st.write(f"• {item}")

    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Business reality")
        m = state["metrics"]
        facts = [
            ("Revenue TTM", money(m.get("revenue"))), ("FCF TTM", money(m.get("fcf"))),
            ("FCF Margin", fpct(m.get("fcf_margin"))), ("ROIC proxy", fpct(m.get("roic"))),
            ("Cash Conversion Cycle", fnum(m.get("ccc"),1," days")), ("Share count change", fpct(m.get("share_change"))),
        ]
        for k,v in facts: st.write(f"**{k}:** {v}")
    with c2:
        st.subheader("Next evidence / event")
        research = db.load_research(ticker)
        st.write("**Evidence required to ADD**")
        st.write(research.get("evidence_to_add") or "Not defined yet.")
        st.write("**Next catalyst**")
        if next_evt:
            st.write(f"{next_evt['event_date']} · {next_evt['title']} ({next_evt['event_type']})")
        else:
            st.write(research.get("catalysts") or "No dated event saved.")
        st.write("**Last successful refresh**")
        st.write((last or {}).get("completed_at") or "Never")
        if latest_attempt and latest_attempt.get("status") == "FAIL":
            st.error("Latest refresh attempt failed; the successful-data timestamp above was not reset.")

    st.subheader("5Y Operating Forecast Lens")
    mg = state.get("management") or {}
    qv = state.get("quality_validation") or {}
    pr = state.get("price_reconciliation") or {}
    mc1, mc2, mc3, mc4 = st.columns(4)
    mc1.metric("Management Delivery", mg.get("label","LOW DATA"), f"{fnum(mg.get('score'),0)}/100 · {mg.get('scorable',0)} scorable" if mg.get("score") is not None else "numeric promises not yet sufficient")
    mc2.metric("Business Quality", qv.get("label","LOW DATA"), f"{fnum(qv.get('score'),0)}/100")
    mc3.metric("Our Base Revenue CAGR", fpct(pr.get("forecast_revenue_cagr")), "5Y operating forecast")
    mc4.metric("Implied by Price", fpct(pr.get("market_implied_revenue_cagr")), "growth needed for required return")
    if pr.get("forecast_revenue_cagr") is not None and pr.get("market_implied_revenue_cagr") is not None:
        gap = pr["forecast_revenue_cagr"] - pr["market_implied_revenue_cagr"]
        st.caption(f"Expectation gap: {gap:+.1%}. Read the dedicated 5Y Operating Forecast page before treating this as investment edge; price reconciliation depends on margin, exit multiple and required-return assumptions.")

    st.subheader("Investment Gate — 16 checks")
    blockers=[r for r in state["gates"] if r["status"] in ("FAIL","INCOMPLETE","WATCH")]
    if blockers:
        st.warning(missing_gate_summary(state["gates"], limit=8))
    else:
        st.success("16/16 complete. Process readiness does not replace judgment on value, evidence, timing or risk.")
    gdf = pd.DataFrame([{"Gate": r["gate"], "Status": r["status"], "Auto": r["auto_status"], "Manual override": "YES" if r["manual"] else "", "Notes": r["notes"]} for r in state["gates"]])
    display_table(gdf, height=480)
    with st.expander("Override / annotate an Investment Gate"):
        gate_map={r["gate"]:r for r in state["gates"]}
        glabel=st.selectbox("Gate",list(gate_map),key=tk(ticker,"gate_override_label"))
        grow=gate_map[glabel]
        choices=["AUTO","PASS","WATCH","FAIL","INCOMPLETE"]
        current="AUTO" if not grow["manual"] else grow["status"]
        gstatus=st.selectbox("Status",choices,index=choices.index(current) if current in choices else 0,key=tk(ticker,"gate_override_status"))
        gnotes=st.text_area("Override notes",value=grow.get("notes", ""),key=tk(ticker,"gate_override_notes"))
        if st.button("Save gate override"):
            db.save_gate_override(ticker,grow["key"],None if gstatus=="AUTO" else gstatus,gnotes)
            st.success("Gate annotation saved.")
            st.rerun()

    st.subheader("PM Brief · 2-minute structure")
    research=db.load_research(ticker)
    pm1,pm2,pm3,pm4=st.columns(4)
    pm1.markdown("**0–30 sec · Business + why now**");pm1.write(research.get("business_notes") or "Not written yet.")
    pm2.markdown("**30–60 sec · Variant**");pm2.write(research.get("variant_view") or "Not written yet.")
    pm3.markdown("**60–90 sec · Value + catalyst**");pm3.write(f"Base {fprice(state['base_value'])} · {research.get('catalysts') or 'Catalyst not defined.'}")
    pm4.markdown("**90–120 sec · Risk + invalidation**");pm4.write(research.get("invalidation") or research.get("primary_risk") or "Not written yet.")

    st.subheader("Institutional Equity Research Report")
    st.caption("Three-page bank-style research report: investment view; financial/valuation detail; and Management Accountability & Forecast with promises vs actuals, independent quality checks, 5Y operating scenarios and price reconciliation. Word is editable; PDF is presentation-ready.")
    try:
        report_docx = exporter.research_report_docx(ticker, state)
        report_pdf = exporter.research_report_pdf(ticker, state)
        r1, r2 = st.columns(2)
        r1.download_button("Download Word research report", data=report_docx, file_name=f"{ticker}_Market_Forensics_Research_Report.docx", mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document", width="stretch")
        r2.download_button("Download PDF research report", data=report_pdf, file_name=f"{ticker}_Market_Forensics_Research_Report.pdf", mime="application/pdf", width="stretch")
    except Exception as e:
        st.warning(f"Research report could not be generated: {e}")


def render_fundamentals(ticker, state):
    hero(ticker, state, "Operating reality first. Price target comes later.")
    if not state["fund_rows"]:
        st.warning("No SEC fundamentals yet. Configure the SEC User-Agent in Settings and refresh.")
        return
    m = state["metrics"]
    fy = [r for r in state["fund_rows"] if r.get("period_type") == "FY"]
    df = pd.DataFrame(fy).sort_values("fiscal_year") if fy else pd.DataFrame()
    cols = st.columns(7)
    for c,(label,val) in zip(cols,[
        ("Revenue",money(m.get("revenue"))), ("Gross Margin",fpct(m.get("gross_margin"))),
        ("Operating Margin",fpct(m.get("operating_margin"))), ("FCF Margin",fpct(m.get("fcf_margin"))),
        ("ROIC",fpct(m.get("roic"))), ("CFO / NI",fnum(m.get("cfo_ni"),2,"x")),
        ("Net Debt",money(m.get("net_debt"))) ]): c.metric(label,val)

    if not df.empty:
        fig = go.Figure()
        fig.add_trace(go.Bar(x=df["fiscal_year"], y=df["revenue"], name="Revenue", marker_color="#3F78A8"))
        fig.add_trace(go.Scatter(x=df["fiscal_year"], y=df["fcf"], name="FCF", yaxis="y2", mode="lines+markers", line=dict(color="#1F9D68"), marker=dict(color="#1F9D68")))
        style_plot(fig, height=380, title="Revenue & Free Cash Flow", yaxis2=dict(overlaying="y",side="right"), margin=dict(l=10,r=10,t=40,b=10))
        st.plotly_chart(fig, width="stretch")

    st.subheader("Working Capital Forensics")
    wc = st.columns(6)
    wc[0].metric("DSO", fnum(m.get("dso"),1,"d")); wc[1].metric("DIO",fnum(m.get("dio"),1,"d")); wc[2].metric("DPO",fnum(m.get("dpo"),1,"d")); wc[3].metric("CCC",fnum(m.get("ccc"),1,"d")); wc[4].metric("Inventory / Revenue",fpct((m.get("inventory")/m.get("revenue")) if m.get("inventory") is not None and m.get("revenue") else None)); wc[5].metric("Share Count YoY",fpct(m.get("share_change")))

    hist=[]
    for _,r in df.iterrows():
        rev=r.get("revenue"); gp=r.get("gross_profit"); cogs=(rev-gp) if pd.notna(rev) and pd.notna(gp) else None
        dso=(365*r.get("receivables")/rev) if pd.notna(r.get("receivables")) and rev else None
        dio=(365*r.get("inventory")/cogs) if pd.notna(r.get("inventory")) and cogs else None
        dpo=(365*r.get("payables")/cogs) if pd.notna(r.get("payables")) and cogs else None
        hist.append({"FY":r.get("fiscal_year"),"DSO":dso,"DIO":dio,"DPO":dpo,"CCC":(dso+dio-dpo) if None not in (dso,dio,dpo) else None,"Inventory/Revenue":(r.get("inventory")/rev) if pd.notna(r.get("inventory")) and rev else None,"Receivables/Revenue":(r.get("receivables")/rev) if pd.notna(r.get("receivables")) and rev else None})
    display_table(pd.DataFrame(hist), {"DSO":lambda x:fnum(x,1),"DIO":lambda x:fnum(x,1),"DPO":lambda x:fnum(x,1),"CCC":lambda x:fnum(x,1),"Inventory/Revenue":fpct,"Receivables/Revenue":fpct})

    fscore, dims = fundamentals.fundamental_score(m)
    st.subheader(f"Fundamental consistency score · {fscore:.2f}/5")
    display_table(pd.DataFrame([{"Dimension":k,"Score":v} for k,v in dims.items()]), {"Score":lambda x:fnum(x,2)})
    st.caption("This score is not a buy/sell signal. Moat and management remain evidence-driven, not inferred from accounting ratios.")

    st.subheader("Operating Forensics · positive and negative evidence")
    business_categories={"Business","Working capital","Cash quality","Capital allocation"}
    sig=[x for x in (state.get("forensics") or {}).get("all",[]) if x.get("Category") in business_categories]
    if sig:
        display_table(pd.DataFrame(sig),height=360)
    else:
        st.caption("No material operating forensic rule triggered from the available history.")

    st.subheader("Company-specific research overlay")
    ctype = state["coverage"].get("company_type", "Generic")
    st.write(f"**Template:** {ctype}")
    for item in decision.COMPANY_TEMPLATES.get(ctype, decision.COMPANY_TEMPLATES["Generic"]):
        st.write(f"• {item}")
    if ctype == "Financial / REIT":
        st.warning("Standard FCF/EV valuation is not automatically appropriate for banks, insurers or many REITs. Use the manual Bear/Base/Bull override in Valuation until a specialized model is supplied.")

    st.subheader("Primary financial history")
    show=["fiscal_year","revenue","gross_profit","operating_income","net_income","cfo","capex","fcf","sbc","buybacks","diluted_shares","cash","debt","receivables","inventory","payables"]
    history_df=df[[c for c in show if c in df.columns]].copy()
    money_cols={"revenue","gross_profit","operating_income","net_income","cfo","capex","fcf","sbc","buybacks","cash","debt","receivables","inventory","payables"}
    formatters={c:money for c in history_df.columns if c in money_cols}
    display_table(history_df, formatters, height=430)



def _financial_flow_figure(pack: dict, title_text: str):
    labels=pack.get("labels") or []
    links=pack.get("links") or []
    # Persistent semantic palette; deliberately excludes purple.
    node_colors=[MF_PLOTLY_COLORS[i % len(MF_PLOTLY_COLORS)] for i in range(len(labels))]
    fig=go.Figure(go.Sankey(
        arrangement="snap",
        node=dict(
            pad=18,
            thickness=18,
            line=dict(color="rgba(120,130,140,.35)",width=.7),
            label=labels,
            color=node_colors,
            hovertemplate="%{label}<extra></extra>",
        ),
        link=dict(
            source=[x[0] for x in links],
            target=[x[1] for x in links],
            value=[x[2] for x in links],
            customdata=[money(x[2]) for x in links],
            color="rgba(63,120,168,.24)",
            hovertemplate="%{source.label} → %{target.label}<br>%{customdata}<extra></extra>",
        ),
    ))
    style_plot(fig,height=520,title=title_text,margin=dict(l=10,r=10,t=48,b=10),font=dict(size=13))
    return fig


def render_financial_flows(ticker, state):
    hero(ticker,state,"See where reported revenue becomes earnings, and where reported earnings become cash. Every bridge is tied to stored FY SEC data.")
    rows=financial_flows.annual_rows(state.get("fund_rows") or [])
    if not rows:
        st.warning("No annual SEC fundamentals are available yet. Refresh the company first.")
        return
    years=[r["fiscal_year"] for r in rows]
    latest=years[-1]
    selected=st.segmented_control("Fiscal year",years,default=latest,selection_mode="single",key=tk(ticker,"financial_flow_year"))
    if selected is None: selected=latest
    row=next((r for r in rows if r["fiscal_year"]==int(selected)),rows[-1])

    st.caption("Year selector changes both views. Sankey widths represent reported dollars; they are not margin estimates. Hover a flow to inspect its amount.")
    tab_income,tab_cash=st.tabs(["Income Statement","Cash Flow"])
    with tab_income:
        pack=financial_flows.income_statement_flow(row)
        a,b,c,d=st.columns(4)
        rev=row.get("revenue"); gp=row.get("gross_profit"); ni=row.get("net_income")
        oi=(pack.get("resolved") or {}).get("operating_income") if pack.get("ok") else (row.get("flow_operating_income") if row.get("flow_operating_income") is not None else row.get("operating_income"))
        a.metric("Revenue",money(rev))
        if rev and gp is not None:
            b.metric("Gross margin",fpct(gp/rev))
        else:
            b.metric("Gross margin","N/A", "not presented by filer")
        c.metric("Operating margin",fpct((oi/rev) if rev and oi is not None else None)); d.metric("Net margin",fpct((ni/rev) if rev and ni is not None else None))
        if pack.get("ok"):
            st.plotly_chart(_financial_flow_figure(pack,f"FY {selected} · Revenue to Net Result"),width="stretch",key=tk(ticker,"income_sankey",selected))
            st.caption(pack.get("basis") or "")
            idf=pd.DataFrame(pack.get("rows") or [])
            display_table(idf,{"Amount":money,"% Revenue":fpct})
        else:
            st.warning("DATA REVIEW — "+str(pack.get("reason") or "Income-statement flow cannot be represented safely."))
            st.info("Financial Flows now treats Gross Profit, Operating Income, Pretax and Tax as optional presentation layers. DATA REVIEW here means an essential anchor such as annual Revenue or Net Income/Loss is unavailable, not merely that a filer uses a different income-statement layout.")
            st.caption("The underlying FY numbers remain available in Business & Fundamentals. Optional subtotals are bypassed rather than guessed.")

    with tab_cash:
        pack=financial_flows.cash_flow_flow(row)
        a,b,c,d=st.columns(4)
        cfo=row.get("cfo"); capex=row.get("capex"); fcf=row.get("fcf"); ni=row.get("net_income")
        a.metric("Net income",money(ni)); b.metric("Cash from operations",money(cfo),f"CFO / NI {fnum((cfo/ni) if ni and cfo is not None else None,2,'x')}"); c.metric("Capex",money(capex)); d.metric("Free cash flow",money(fcf),f"FCF margin {fpct((fcf/row.get('revenue')) if row.get('revenue') and fcf is not None else None)}")
        if pack.get("ok"):
            st.plotly_chart(_financial_flow_figure(pack,f"FY {selected} · Earnings to Free Cash Flow & Capital Returns"),width="stretch",key=tk(ticker,"cash_sankey",selected))
            st.caption(pack.get("basis") or "")
            cdf=pd.DataFrame(pack.get("rows") or [])
            display_table(cdf,{"Amount":money,"% CFO":fpct})
            if (pack.get("rows") or []) and any((x.get("Line") or "").startswith("External financing") and (x.get("Amount") or 0)>0 for x in pack.get("rows") or []):
                st.info("Disclosed buybacks/dividends exceeded FCF in this year. The diagram shows the shortfall as external financing / cash draw; it does not guess which exact financing source funded it.")
        else:
            st.warning("DATA REVIEW — "+str(pack.get("reason") or "Cash-flow path cannot be represented safely."))
            st.caption("Cash Flow now supports negative CFO/FCF with explicit deficit/funding nodes. DATA REVIEW is reserved for a genuinely missing CFO anchor.")

    st.info("Interpretation rule: Financial Flows is a visualization layer only. It does not change valuation, Bear/Base/Bull, Validate, or any stored SEC fact.")


def render_management_forecast(ticker, state):
    hero(ticker, state, "Management accountability, business-quality triangulation, and a five-year operating forecast reconciled to the market price.")
    mg = state.get("management") or {}
    qv = state.get("quality_validation") or {}
    fr = state.get("forecast_assumptions") or {}
    pack = state.get("forecast_scenarios") or {}
    rec = state.get("price_reconciliation") or {}

    top = st.columns(6)
    top[0].metric("Management Delivery", mg.get("label","LOW DATA"), f"{fnum(mg.get('score'),0)}/100" if mg.get("score") is not None else "not enough scored promises")
    top[1].metric("Scorable promises", mg.get("scorable",0), f"{mg.get('met',0)} met · {mg.get('missed',0)} missed")
    top[2].metric("Business Quality", qv.get("label","LOW DATA"), f"{fnum(qv.get('score'),0)}/100")
    top[3].metric("Base 5Y CAGR", fpct(pack.get("base",{}).get("expected_cagr")), "terminal-price CAGR")
    top[4].metric("Market-implied growth", fpct(rec.get("market_implied_revenue_cagr")), "for required return")
    top[5].metric("Model growth", fpct(rec.get("forecast_revenue_cagr")), "5Y revenue CAGR")

    st.caption("Management Delivery scores only the earliest high-confidence numeric promise for each metric/target FY. Later revisions remain visible but cannot move the goalposts. Ambiguous/multi-metric statements stay evidence-only and do not receive invented pass/fail grades.")

    tabs = st.tabs(["Management Accountability", "Quality Validation", "5Y Operating Forecast & Price Reconciliation"])

    with tabs[0]:
        ua = load_settings().get("sec_user_agent","")
        c1,c2 = st.columns([1.2,3.8])
        if c1.button("Deep-scan SEC management history", width="stretch", disabled=not bool(ua and "@" in ua), help="Fetches up to 40 recent 10-K/10-Q/8-K filings and official 8-K exhibits, re-parsing cached documents automatically when the management parser has been upgraded."):
            try:
                with st.spinner("Reading new SEC filings and extracting verifiable management statements..."):
                    result=management.refresh_management_documents(ticker,ua,filing_limit=40,include_exhibits=True)
                st.success(f"Scan complete: {result.get('documents',0)} new document(s), {result.get('statements',0)} candidate statement(s).")
                if result.get("errors"):
                    st.warning("Some documents could not be read: "+" · ".join(result["errors"][:3]))
                st.rerun()
            except Exception as e:
                st.error(f"Management-history scan failed: {e}")
        c2.caption(f"Normal Refresh scans the recent official filings. Deep scan extends the history. SEC EDGAR only · conservative parser v{management.PARSER_VERSION}. Parser upgrades force cached filings to be re-parsed before new MET/MISS labels are trusted.")

        rows=management.evaluate_statements(ticker)
        numeric=[r for r in rows if r.get("target_low") is not None and r.get("target_fiscal_year")]
        def target_text(r):
            lo=r.get("target_low"); hi=r.get("target_high"); unit=r.get("unit")
            if lo is None:return "—"
            if unit in {"ratio","ratio_change"}: return f"{lo:+.1%}" if unit=="ratio_change" and hi in (None,lo) else (f"{lo:+.1%}–{hi:+.1%}" if unit=="ratio_change" else (f"{lo:.1%}" if hi in (None,lo) else f"{lo:.1%}–{hi:.1%}"))
            if unit=="USD_per_share": return f"${lo:.2f}" if hi in (None,lo) else f"${lo:.2f}–${hi:.2f}"
            return money(lo) if hi in (None,lo) else f"{money(lo)}–{money(hi)}"
        def actual_text(r):
            a=r.get("actual_value"); unit=r.get("unit")
            if a is None:return "—"
            if unit in {"ratio","ratio_change"}:return fpct(a)
            if unit=="USD_per_share":return fprice(a)
            return money(a)
        if numeric:
            table=[]
            for r in numeric[:120]:
                table.append({"Filed":r.get("filed"),"Form":r.get("form"),"Metric":r.get("metric_key"),"Target FY":r.get("target_fiscal_year"),"Promise":target_text(r),"Actual":actual_text(r),"Result":r.get("validation_status"),"Score use":"YES" if r.get("score_eligible") else "NO","Why / note":r.get("score_note") or "","Extract confidence":r.get("extract_confidence"),"Statement":r.get("statement"),"Source":r.get("source_url")})
            display_table(pd.DataFrame(table),{"Extract confidence":fpct},height=520)
        else:
            st.info("No explicit numeric management promise with a recognized metric + fiscal year has been extracted yet. Run a refresh/deep scan or review the qualitative candidates below.")

        unverified=[r for r in rows if r.get("validation_status") in ("UNVERIFIED","PENDING")]
        with st.expander(f"Qualitative / pending statements ({len(unverified)})"):
            if unverified:
                display_table(pd.DataFrame([{"Filed":r.get("filed"),"Form":r.get("form"),"Status":r.get("validation_status"),"Metric":r.get("metric_key") or "—","Statement":r.get("statement"),"Source":r.get("source_url")} for r in unverified[:150]]),height=460)
            else:
                st.caption("No pending or qualitative candidates stored.")

    with tabs[1]:
        st.subheader(f"Independent business-quality cross-check · {qv.get('label','LOW DATA')} {fnum(qv.get('score'),0)}/100")
        st.caption("This triangulates management delivery with ROIC, cash conversion, balance sheet, dilution, working capital and data/accounting consistency. It is deliberately separate from valuation and tape.")
        checks=qv.get("checks") or []
        if checks:
            display_table(pd.DataFrame([{"Check":x.get("name"),"Status":x.get("status"),"Evidence":x.get("reason")} for x in checks]))
        if qv.get("fails"):
            st.error("Quality challenge: "+" · ".join(x.get("name","") for x in qv["fails"]))
        elif qv.get("watches"):
            st.warning("Needs validation: "+" · ".join(x.get("name","") for x in qv["watches"]))
        else:
            st.success("No material quality cross-check is currently failing from the available data.")

        st.markdown("#### Alternative validation paths")
        st.write("• **Reported economics:** SEC/XBRL revenue, margins, cash flow, working capital and balance sheet.")
        st.write("• **Management delivery:** explicit guidance/targets versus later reported outcomes.")
        st.write("• **Capital allocation reality:** buybacks versus actual diluted-share trend, SBC and leverage.")
        st.write("• **Accounting consistency:** SEC revisions/restatements and reconciliation warnings.")
        st.write("• **Market confirmation:** valuation regime and tape remain independent checks; neither can make a weak business good.")

    with tabs[2]:
        if not state.get("metrics"):
            st.warning("SEC fundamentals are required before a forecast can be built.")
            return
        st.caption("This is the 5Y Operating Forecast Bear/Base/Bull model, not the Valuation Cases used for fair value. Change assumptions, save them, then compare the operating path with what today's price implicitly requires.")
        editable=json.loads(json.dumps(fr))
        f_last=service.last_successful_refresh(ticker) or {}
        f_state_version=fr.get("reviewed_at") or f_last.get("completed_at") or f_last.get("started_at") or "AUTO"
        def fkey(*parts): return tk(ticker,"forecast",f_state_version,*parts)
        cols=st.columns(3)
        for col,name in zip(cols,("bear","base","bull")):
            a=editable[name]
            with col:
                st.subheader(name.upper())
                a["growth_start"]=st.number_input("Year-1 revenue growth",value=float(a["growth_start"]),format="%.3f",step=.01,key=fkey(name,"g1"))
                a["growth_terminal"]=st.number_input("Year-5 revenue growth",value=float(a["growth_terminal"]),format="%.3f",step=.01,key=fkey(name,"g5"))
                a["gross_margin_target"]=st.number_input("Year-5 gross margin",value=float(a["gross_margin_target"]),format="%.3f",step=.01,key=fkey(name,"gm"))
                a["operating_margin_target"]=st.number_input("Year-5 operating margin",value=float(a["operating_margin_target"]),format="%.3f",step=.01,key=fkey(name,"om"))
                a["net_margin_target"]=st.number_input("Year-5 net margin",value=float(a["net_margin_target"]),format="%.3f",step=.01,key=fkey(name,"nm"))
                a["fcf_margin_target"]=st.number_input("Year-5 FCF margin",value=float(a["fcf_margin_target"]),format="%.3f",step=.01,key=fkey(name,"fm"))
                a["share_change"]=st.number_input("Annual share-count change",value=float(a.get("share_change",0)),format="%.3f",step=.005,key=fkey(name,"shares"))
                a["exit_pe"]=st.number_input("Year-5 exit P/E",value=float(a["exit_pe"]),step=1.0,key=fkey(name,"pe"))
                a["required_return"]=st.number_input("Required annual return",value=float(a.get("required_return",.10)),format="%.3f",step=.01,key=fkey(name,"rr"))
        sc1,sc2=st.columns(2)
        if sc1.button("Save reviewed forecast",type="primary",width="stretch"):
            editable["model_version"]="2.7"; editable["reviewed_at"]=db.now_utc(); db.save_forecast_assumptions(ticker,editable); st.success("Forecast assumptions saved."); st.rerun()
        if sc2.button("Reset to AUTO forecast",width="stretch"):
            db.execute("DELETE FROM forecast_assumptions WHERE ticker=?",(ticker.upper(),)); st.success("Saved forecast cleared; AUTO operating assumptions rebuilt."); st.rerun()

        live_pack=forecast.scenario_summary(state["metrics"],editable,state.get("price"))
        live_rec=forecast.price_reconciliation(state.get("price"),state["metrics"],editable,live_pack)
        st.subheader("Five-year operating forecast")
        fig=go.Figure()
        scenario_colors={"bear":"#D15353","base":"#3F78A8","bull":"#1F9D68"}
        for name in ("bear","base","bull"):
            rows=live_pack.get(name,{}).get("rows") or []
            if rows:
                color=scenario_colors[name]
                fig.add_trace(go.Scatter(x=[f"Y{x['year']}" for x in rows],y=[x["revenue"] for x in rows],mode="lines+markers",name=f"{name.title()} Revenue",line=dict(color=color),marker=dict(color=color)))
        style_plot(fig,height=390,title="Revenue scenarios",margin=dict(l=10,r=10,t=40,b=10))
        st.plotly_chart(fig,width="stretch")
        base_rows=live_pack.get("base",{}).get("rows") or []
        if base_rows:
            display_table(pd.DataFrame([{"Year":x["year"],"Revenue":x["revenue"],"Growth":x["growth"],"Gross Margin":x["gross_margin"],"Operating Margin":x["operating_margin"],"Net Margin":x["net_margin"],"FCF Margin":x["fcf_margin"],"EPS":x["eps"],"FCF":x["fcf"]} for x in base_rows]),{"Revenue":money,"Growth":fpct,"Gross Margin":fpct,"Operating Margin":fpct,"Net Margin":fpct,"FCF Margin":fpct,"EPS":fprice,"FCF":money})

        st.subheader("Price reconciliation · what must the market believe?")
        r1,r2,r3,r4=st.columns(4)
        r1.metric("Current Price",fprice(live_rec.get("current_price")))
        r2.metric("Forecast PV",fprice(live_rec.get("base_present_value")),"5Y EPS × exit P/E discounted")
        r3.metric("Forecast 5Y CAGR",fpct(live_rec.get("base_expected_cagr")),"terminal price / current price")
        r4.metric("Required Return",fpct(live_rec.get("required_return")))
        compare=pd.DataFrame([
            {"Driver":"Revenue CAGR","Our Base Forecast":fpct(live_rec.get("forecast_revenue_cagr")),"Implied by Current Price":fpct(live_rec.get("market_implied_revenue_cagr")),"Question":"Is the market demanding more or less growth than our operating case?"},
            {"Driver":"Year-5 Net Margin","Our Base Forecast":fpct(live_rec.get("forecast_terminal_net_margin")),"Implied by Current Price":fpct(live_rec.get("market_implied_net_margin")),"Question":"How much profitability is embedded in today's price?"},
            {"Driver":"Year-5 Exit P/E","Our Base Forecast":fnum(live_rec.get("forecast_exit_pe"),1,"x"),"Implied by Current Price":fnum(live_rec.get("market_implied_exit_pe"),1,"x"),"Question":"What exit multiple would still deliver the required return?"},
        ])
        display_table(compare)
        ig=live_rec.get("market_implied_revenue_cagr"); fg=live_rec.get("forecast_revenue_cagr")
        if ig is not None and fg is not None:
            gap=fg-ig
            if gap>=.03: st.success(f"Potential expectation edge: our Base revenue CAGR is {gap:+.1%} above what the current price appears to require under these assumptions.")
            elif gap<=-.03: st.warning(f"Demanding price: our Base revenue CAGR is {gap:+.1%} below what the current price appears to require under these assumptions.")
            else: st.info("Our Base revenue path is close to what the current price appears to require. Edge must come from margins, capital allocation, multiple, or a different thesis.")

def render_valuation(ticker, state):
    hero(ticker, state, "History-calibrated Bear / Base / Bull. The model must explain its assumptions, not hide them.")
    if not state["metrics"]:
        st.warning("Refresh SEC fundamentals first.")
        return
    ass = json.loads(json.dumps(state["assumptions"]))
    last_val_refresh = service.last_successful_refresh(ticker) or {}
    val_state_version = ass.get("reviewed_at") or last_val_refresh.get("completed_at") or last_val_refresh.get("started_at") or "AUTO"
    def vkey(*parts):
        return tk(ticker, "valuation", val_state_version, *parts)
    ctype = state["coverage"].get("company_type", "Generic")
    cal = state.get("calibration") or valuation.historical_calibration(state["fund_rows"], state["bars"])
    vc = state.get("valuation_confidence") or {}

    if ctype == "Financial / REIT":
        st.error("Financial / REIT: generic operating-company FCF/EV-Sales valuation is not decision-grade. Market Forensics caps confidence and uses P/E only as a reference until a specialized bank/REIT model is supplied.")
    if state.get("legacy_valuation"):
        st.warning("A pre-V2.5 valuation was found. Market Forensics is showing a fresh V2.5 history/regime-calibrated model instead of silently carrying older assumptions forward. Review and Save to adopt it.")

    a,b,c,d=st.columns(4)
    a.metric("Valuation Confidence",vc.get("label","LOW"),f"{fnum(vc.get('score'),0)}/100")
    a.caption(" · ".join((vc.get("reasons") or [])[:2]) or "History and methods are well supported.")
    b.metric("History points",len(cal.get("observations",[])),"Annual filing anchors")
    c.metric("Base Fair Value",fprice(state["scenarios"].get("base",{}).get("fair_value")))
    d.metric("Expected Value",fprice(state.get("expected_value")))

    st.subheader("Historical valuation calibration")
    st.caption("Historical multiples use the median split-adjusted close across up to 21 trading sessions after each annual filing, reducing single-day/event noise. SEC restatements/revisions are flagged separately rather than hidden.")
    current=valuation.current_multiples(state["metrics"],state["price"])
    hrows=[]
    for key,label,inverse in (("pe","P/E",False),("ev_sales","EV / Sales",False),("fcf_yield","FCF Yield",True)):
        h=cal.get(key,{})
        hrows.append({"Metric":label,"Current":current.get(key),"Observations":h.get("n"),"P25":h.get("p25"),"Median":h.get("median"),"P75":h.get("p75"),"Auto source":ass.get("calibration",{}).get(f"{key}_source","")})
    hdf=pd.DataFrame(hrows)
    if not hdf.empty:
        for col in ("Current","P25","Median","P75"):
            if col in hdf:
                hdf[col]=[fpct(v) if hdf.iloc[i]["Metric"]=="FCF Yield" else fnum(v,2) for i,v in enumerate(hdf[col])]
    display_table(hdf)

    regime_diag = state.get("valuation_regime") or valuation.multiple_regime_diagnostics(state["metrics"], state["price"], cal)
    regime_rows = regime_diag.get("rows", [])
    if regime_rows:
        st.subheader("Historical valuation regime check")
        high = [r for r in regime_rows if r.get("severity") == "HIGH"]
        headline = (
            "MAJOR REGIME BREAK — historical mean reversion is not safe to assume."
            if high else
            "Material current-vs-history valuation divergence — explain the re-rating before relying on the historical multiple."
        )
        if high:
            st.error(headline)
        else:
            st.warning(headline)
        rdf = pd.DataFrame([{
            "Metric": r.get("metric"),
            "Current": fpct(r.get("current")) if r.get("metric") == "FCF Yield" else fnum(r.get("current"),2),
            "Historical Median": fpct(r.get("historical_median")) if r.get("metric") == "FCF Yield" else fnum(r.get("historical_median"),2),
            "Current / History": fnum(r.get("ratio_to_history"),2,"x"),
            "Severity": r.get("severity"),
            "Current economics": r.get("economics"),
            "Interpretation": r.get("interpretation"),
        } for r in regime_rows])
        display_table(rdf)
        for r in regime_rows[:3]:
            st.caption(f"{r.get('metric')}: {r.get('explanation')}")

    obs=cal.get("observations",[])
    if obs:
        odf=pd.DataFrame(obs)
        cols=[c for c in ["fiscal_year","anchor_date","price_date","price_method","price","pe","ev_sales","fcf_yield","revenue_growth","operating_margin","net_margin","fcf_margin"] if c in odf.columns]
        odf=odf[cols]
        display_table(odf,{"price":fprice,"pe":lambda x:fnum(x,2),"ev_sales":lambda x:fnum(x,2),"fcf_yield":fpct,"revenue_growth":fpct,"operating_margin":fpct,"net_margin":fpct,"fcf_margin":fpct},height=310)
    else:
        st.info("Not enough overlapping historical price + SEC annual data yet. The model is using transparent company-type fallback priors and confidence is reduced.")

    reg=(ass.get("calibration") or {}).get("regime_score")
    if reg is not None:
        adj=(ass.get("calibration") or {}).get("regime_adjustment") or {}
        st.caption(f"Historical-regime adjustment: {float(reg):+.2f} · P/E ×{float(adj.get('pe_factor',1)):.2f} · EV/Sales ×{float(adj.get('ev_sales_factor',1)):.2f} · required FCF yield ×{float(adj.get('fcf_yield_factor',1)):.2f}. This is deliberately modest to avoid double-counting growth/margins.")

    if st.button("Rebuild AUTO assumptions from history",help="Discards only the saved valuation-assumption payload for this ticker. Research, data, journal and history stay intact."):
        db.execute("DELETE FROM valuation_assumptions WHERE ticker=?",(ticker,))
        st.success("Saved valuation assumptions cleared. AUTO calibration will be rebuilt from current history.")
        st.rerun()

    st.subheader("Valuation Cases — Bear / Base / Bull assumptions")
    st.caption("These inputs produce the Bear/Base/Bull fair values shown in Decide. They are separate from the 5Y Operating Forecast scenarios. AUTO uses company history first, sparse-history + company-type priors second, and type priors only as fallback.")
    columns = st.columns(3)
    for col, name in zip(columns, ("bear","base","bull")):
        with col:
            st.subheader(name.upper())
            a=ass[name]
            a["growth"]=st.number_input("Forward revenue growth",value=float(a["growth"]),format="%.3f",step=.01,key=vkey(name,"growth"))
            a["operating_margin"]=st.number_input("Normalized operating margin",value=float(a["operating_margin"]),format="%.3f",step=.01,key=vkey(name,"om"))
            a["net_margin"]=st.number_input("Normalized net margin (P/E)",value=float(a.get("net_margin", a["operating_margin"]*(1-a.get("tax_rate",.21)))),format="%.3f",step=.01,key=vkey(name,"nm"))
            a["fcf_margin"]=st.number_input("Normalized FCF margin",value=float(a["fcf_margin"]),format="%.3f",step=.01,key=vkey(name,"fm"))
            a["pe"]=st.number_input("P/E multiple",value=float(a["pe"]),step=1.0,key=vkey(name,"pe"))
            a["ev_sales"]=st.number_input("EV / Sales",value=float(a["ev_sales"]),step=.1,key=vkey(name,"evs"))
            a["target_fcf_yield"]=st.number_input("FCF yield",value=float(a["target_fcf_yield"]),format="%.3f",step=.005,key=vkey(name,"fy"))
            a["wacc"]=st.number_input("FCFE equity discount rate",value=float(a["wacc"]),format="%.3f",step=.005,key=vkey(name,"wacc"))
            a["terminal_growth"]=st.number_input("DCF terminal growth",value=float(a["terminal_growth"]),format="%.3f",step=.005,key=vkey(name,"tg"))
            a["prob"]=st.number_input("Probability",min_value=0.0,max_value=1.0,value=float(a["prob"]),step=.05,key=vkey(name,"prob"))
            ov=a.get("manual_override")
            a["manual_override"]=st.number_input("Manual fair-value override (0 = off)",min_value=0.0,value=float(ov or 0),step=1.0,key=vkey(name,"override")) or None

    st.subheader("Primary method weights")
    w1,w2,w3=st.columns(3)
    ass["weights"]["pe"]=w1.number_input("P/E weight",min_value=0.0,max_value=1.0,value=float(ass["weights"].get("pe",0)),step=.05,key=vkey("weight_pe"))
    ass["weights"]["ev_sales"]=w2.number_input("EV/Sales weight",min_value=0.0,max_value=1.0,value=float(ass["weights"].get("ev_sales",0)),step=.05,key=vkey("weight_evs"))
    ass["weights"]["fcf_yield"]=w3.number_input("FCF Yield weight",min_value=0.0,max_value=1.0,value=float(ass["weights"].get("fcf_yield",0)),step=.05,key=vkey("weight_fcf"))
    review_note=st.text_input("Valuation review note",value=str(ass.get("review_note") or ""),placeholder="Why these assumptions are reasonable / what you changed",key=vkey("review_note"))
    if st.button("Save reviewed valuation assumptions", type="primary"):
        ass["reviewed_at"]=db.now_utc(); ass["model_version"]="2.5"; ass["origin"]="REVIEWED_V2_5"; ass["review_note"]=review_note
        db.save_json_assumptions(ticker,ass)
        service.capture_snapshot(ticker)
        st.success("Saved as reviewed assumptions and timestamped.")
        st.rerun()

    scenarios, ev=valuation.scenario_values(state["metrics"],ass)
    rows=[]
    all_flags=[]
    for name in ("bear","base","bull"):
        x=scenarios[name]
        all_flags.extend([f"{name.upper()}: {z}" for z in x.get("flags",[])])
        rows.append({"Scenario":name.upper(),"P/E":x["pe"],"EV/Sales":x["ev_sales"],"FCF Yield":x["fcf_yield"],"Primary FV":x["fair_value"],"Method P25":x.get("range_low"),"Method P75":x.get("range_high"),"DCF cross-check":x["dcf"],"Probability":x["prob"],"Upside/Downside":(x["fair_value"]/state["price"]-1) if state["price"] and x["fair_value"] is not None else None})
    display_table(pd.DataFrame(rows), {"P/E":fprice,"EV/Sales":fprice,"FCF Yield":fprice,"Primary FV":fprice,"Method P25":fprice,"Method P75":fprice,"DCF cross-check":fprice,"Probability":fpct,"Upside/Downside":fpct})
    if all_flags:
        st.warning("Robust-blend adjustments: "+" · ".join(all_flags[:6]))

    c1,c2,c3,c4=st.columns(4)
    c1.metric("Current Price",fprice(state["price"])); c2.metric("Bear",fprice(scenarios["bear"]["fair_value"])); c3.metric("Base",fprice(scenarios["base"]["fair_value"])); c4.metric("Bull",fprice(scenarios["bull"]["fair_value"]))
    implied=valuation.implied_growth_for_price(state["price"],state["metrics"],ass["base"]) if state["price"] else None
    st.info(f"**Reverse DCF:** current price implies approximately **{fpct(implied)}** annual revenue growth for five years, holding Base FCF margin/Equity discount rate/terminal growth constant." if implied is not None else "Reverse DCF could not solve a plausible growth rate inside the -30% to +60% range with current Base assumptions.")
    st.caption("Point estimates are decision anchors, not precision claims. The method P25–P75 band shows cross-method dispersion. If P/E, EV/Sales, FCF Yield and DCF disagree materially, confidence falls and the dashboard asks you to investigate rather than average the problem away.")


def render_tape(ticker, state):
    hero(ticker, state, "Market plumbing: who is pressing, whether demand absorbs it, and whether price confirms the story.")
    s=state["scores"]
    if not s:
        st.warning("No tape data yet. Refresh selected ticker.")
        return
    cols=st.columns(8)
    names=["Institutional Flow","Long Demand","Short Pressure","Absorption","Battle Intensity","Price Resilience","Net Tape","Confidence"]
    for c,n in zip(cols,names): c.metric(n,fnum(s.get(n),0))
    st.info(f"**{s.get('Regime')} · Rank {s.get('Rank')}**")

    bars=state["bars"]
    r5=r20=None
    if len(bars)>=6 and bars[-6].get("close"):
        r5=bars[-1]["close"]/bars[-6]["close"]-1
    if len(bars)>=21 and bars[-21].get("close"):
        r20=bars[-1]["close"]/bars[-21]["close"]-1
    flows=state["snap"].get("flows",[])
    f5=sum(float(x.get("net_large") or 0) for x in flows[-5:]) if flows else None
    f20=sum(float(x.get("net_large") or 0) for x in flows[-20:]) if flows else None
    a,b,c,d=st.columns(4)
    a.metric("5D Price",fpct(r5)); b.metric("20D Price",fpct(r20)); c.metric("5D Net Large",money(f5)); d.metric("20D Net Large",money(f20))

    if flows:
        fdf=pd.DataFrame(flows); fdf["trade_date"]=pd.to_datetime(fdf["trade_date"])
        fig=go.Figure()
        fig.add_trace(go.Bar(x=fdf["trade_date"],y=fdf["net_large"],name="Net Large",marker_color="#3F78A8"))
        fig.add_trace(go.Bar(x=fdf["trade_date"],y=fdf["net_whale"],name="Net Whale",marker_color="#2E8894"))
        style_plot(fig,height=360,barmode="relative",title="Large / Whale aggressive flow proxy",margin=dict(l=10,r=10,t=40,b=10))
        st.plotly_chart(fig,width="stretch")

    shorts=state["snap"].get("shorts",[])
    if shorts:
        sdf=pd.DataFrame(shorts); sdf["trade_date"]=pd.to_datetime(sdf["trade_date"])
        fig=go.Figure(go.Scatter(x=sdf["trade_date"],y=sdf["short_pct"],name="FINRA Daily Short %",mode="lines+markers",line=dict(color="#C99A2E"),marker=dict(color="#C99A2E")))
        fig.update_yaxes(tickformat=".0%")
        style_plot(fig,height=320,title="FINRA Daily Short Sale Volume %",margin=dict(l=10,r=10,t=40,b=10))
        st.plotly_chart(fig,width="stretch")
        st.warning("FINRA Daily Short Sale Volume is not Short Interest. They answer different questions and are never merged as if they were the same dataset.")

    l,r=st.columns(2)
    with l:
        st.subheader("What changed since prior refresh?")
        for item in decision.what_changed(service.snapshot_history(ticker,10)): st.write(f"• {item}")
    with r:
        st.subheader("What would change the regime?")
        for item in flow.regime_requirements(s): st.write(f"• {item}")

    st.subheader("Official Short Interest · no-lookahead")
    with st.form(tk(ticker,"short_interest")):
        c1,c2,c3,c4=st.columns(4)
        settlement=c1.date_input("Settlement date",key=tk(ticker,"si_settle"))
        publication=c2.date_input("Publication date",key=tk(ticker,"si_pub"))
        shares=c3.number_input("Shares short",min_value=0.0,step=1000.0,key=tk(ticker,"si_shares"))
        dtc=c4.number_input("Days to cover",min_value=0.0,step=.1,key=tk(ticker,"si_dtc"))
        if st.form_submit_button("Save Short Interest"):
            db.execute("""INSERT INTO short_interest(ticker,settlement_date,publication_date,shares_short,days_to_cover,created_at)
            VALUES(?,?,?,?,?,?) ON CONFLICT(ticker,settlement_date) DO UPDATE SET publication_date=excluded.publication_date,shares_short=excluded.shares_short,days_to_cover=excluded.days_to_cover""",
            (ticker,settlement.isoformat(),publication.isoformat(),shares,dtc or None,db.now_utc()))
            st.success("Saved. Signals use publication date, not settlement date.")
            st.rerun()
    display_table(pd.DataFrame(state["snap"].get("si",[])))


def render_monitoring(ticker,state):
    hero(ticker,state,"Track thesis variables, not price. Lock thresholds before the event, then compare without negotiation.")
    cov=state["coverage"]
    if not state["kpis"]:
        st.warning("No monitoring framework yet.")
        if st.button("Create default 10-KPI monitoring pack",type="primary"):
            n=decision.seed_default_kpis(ticker,cov.get("company_type","Generic"))
            st.success(f"Created {n} KPI rows. Replace the seeded thresholds with your own thesis thresholds before relying on them.")
            st.rerun()

    if state["kpi_eval"]:
        triggered=[x for x in state["kpi_eval"] if x["kpi_status"]=="TRIGGERED"]
        if triggered:
            st.error("Decision-linked thresholds currently TRIGGERED: "+", ".join(x["name"] for x in triggered))
        rows=[]
        for x in state["kpi_eval"]:
            rows.append({"KPI":x["name"],"Category":x["category"],"Current":x["current_value"],"Rule":f"{x['operator']} {x['threshold'] if x['threshold'] is not None else '—'}","Linked To":x["linked_to"],"Status":x["kpi_status"],"Locked":"YES" if x["locked"] else "","Source":x["source_type"]})
        display_table(pd.DataFrame(rows),{"Current":lambda x:fnum(x,3)})

    st.subheader("Add / update monitoring rule")
    existing=state["kpis"]
    with st.form(tk(ticker,"add_kpi")):
        c1,c2,c3,c4=st.columns(4)
        name=c1.text_input("KPI name")
        category=c2.selectbox("Category",["Business","Margins","Cash","Working Capital","Capital Allocation","Market","Risk","Custom"])
        source_type=c3.selectbox("Source",["AUTO","MANUAL"])
        linked=c4.selectbox("Linked to",["THESIS","ADD","REDUCE","EXIT","INVALIDATION"])
        c1,c2,c3,c4=st.columns(4)
        metric_key=c1.selectbox("Auto metric key",["","cagr3","gross_margin","operating_margin","fcf_margin","roic","dso","dio","dpo","ccc","share_change","net_debt","net_tape","institutional_flow","short_pressure","absorption","price_resilience","confidence","net_large","net_whale","short_pct"])
        manual=c2.number_input("Manual value",value=0.0)
        operator=c3.selectbox("Operator",[">=",">","<=","<","=="])
        threshold=c4.number_input("Threshold",value=0.0)
        c1,c2,c3=st.columns(3)
        unit=c1.text_input("Unit",value="")
        importance=c2.slider("Importance",1,5,3)
        locked=c3.checkbox("LOCK threshold",value=False,help="Use this for pre-investment or pre-earnings invalidation rules. Editing a locked threshold should create a new rule, not rewrite history.")
        notes=st.text_area("Notes")
        if st.form_submit_button("Add KPI rule") and name.strip():
            db.execute("""INSERT INTO monitoring_kpis(ticker,name,category,metric_key,source_type,unit,manual_value,operator,threshold,linked_to,importance,locked,notes,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (ticker,name.strip(),category,metric_key,source_type,unit,manual if source_type=="MANUAL" else None,operator,threshold,linked,importance,1 if locked else 0,notes,db.now_utc(),db.now_utc()))
            st.success("KPI rule added.")
            st.rerun()

    if existing:
        with st.expander("Update manual KPI value"):
            choices={f"#{x['id']} · {x['name']}":x for x in existing}
            choice=st.selectbox("Rule",list(choices),key=tk(ticker,"kpi_edit"))
            row=choices[choice]
            if row.get("locked"):
                st.warning("This threshold is LOCKED. Do not rewrite the threshold retroactively. You may update only a MANUAL current value; create a new rule if the thesis threshold changes prospectively.")
            if row.get("source_type")=="MANUAL":
                newv=st.number_input("New manual current value",value=float(row.get("manual_value") or 0),key=tk(ticker,"manual_kpi_update"))
                if st.button("Record manual value"):
                    db.execute("UPDATE monitoring_kpis SET manual_value=?,updated_at=? WHERE id=?",(newv,db.now_utc(),row["id"]))
                    db.execute("INSERT INTO monitoring_history(kpi_id,ticker,captured_at,value) VALUES(?,?,?,?)",(row["id"],ticker,db.now_utc(),newv))
                    st.success("Value recorded.");st.rerun()

    st.subheader("Catalysts / Earnings Event Freeze")
    events=db.query("SELECT * FROM events WHERE ticker=? ORDER BY event_date",(ticker,))
    with st.form(tk(ticker,"event_form")):
        c1,c2,c3=st.columns(3)
        event_date=c1.date_input("Event date")
        event_type=c2.selectbox("Event type",["Earnings","Investor Day","Product","Regulatory","Macro","Catalyst","Other"])
        title=c3.text_input("Event title")
        exp=st.text_area("Thesis expectation before event")
        b1,b2,b3=st.columns(3)
        bear=b1.text_area("Bear event case"); base=b2.text_area("Base event case"); bull=b3.text_area("Bull event case")
        a1,a2,a3=st.columns(3)
        add=a1.text_area("What makes me ADD?"); reduce=a2.text_area("What makes me REDUCE?"); exitc=a3.text_area("What makes me EXIT?")
        if st.form_submit_button("Freeze event plan") and title.strip():
            db.execute("""INSERT INTO events(ticker,event_date,event_type,title,thesis_expectation,bear_case,base_case,bull_case,add_condition,reduce_condition,exit_condition,status,thesis_state,post_result,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (ticker,event_date.isoformat(),event_type,title.strip(),exp,bear,base,bull,add,reduce,exitc,"UPCOMING","","",db.now_utc(),db.now_utc()))
            st.success("Event plan frozen.");st.rerun()
    if events:
        display_table(pd.DataFrame(events)[["event_date","event_type","title","status","thesis_state","thesis_expectation","add_condition","reduce_condition","exit_condition","post_result"]])
        with st.expander("Close / review an event"):
            emap={f"#{x['id']} · {x['event_date']} · {x['title']}":x for x in events}
            echoice=st.selectbox("Event",list(emap),key=tk(ticker,"event_close_choice"))
            erow=emap[echoice]
            estate=st.selectbox("Post-event thesis state",["","STRONGER","SAME","WEAKER","BROKEN"],index=0,key=tk(ticker,"event_thesis_state"))
            eresult=st.text_area("What actually happened?",value=erow.get("post_result", ""),key=tk(ticker,"event_post_result"))
            if st.button("Close event / append result"):
                db.execute("UPDATE events SET status='DONE',thesis_state=?,post_result=?,updated_at=? WHERE id=?",(estate,eresult,db.now_utc(),erow["id"]))
                st.success("Event closed without changing the frozen pre-event plan.")
                st.rerun()


def render_research(ticker,state):
    hero(ticker,state,"Write the thesis evidence and bear case. Variant perception has one canonical home: Decide.")
    n=db.load_research(ticker)
    v=db.load_variant_case(ticker) or {}
    st.subheader("Canonical disagreement")
    a,b=st.columns(2)
    a.info("MARKET BELIEVES\n\n"+(v.get("market_belief") or "Not written yet."))
    b.info("WE BELIEVE\n\n"+(v.get("our_belief") or "Not written yet."))
    st.caption("Edit the market-vs-us disagreement in Decide. This page no longer keeps a second copy of the same thesis fields.")
    st.page_link("pages/02_decide_v3.py",label="Open Decide · edit Variant Perception",width="stretch")

    with st.form(tk(ticker,"research_v311_form")):
        title=st.text_input("Thesis title",value=n.get("thesis_title", ""))
        business=st.text_area("Business / Revenue Engine",value=n.get("business_notes", ""),height=110)
        drivers=st.text_area("3-5 variables that actually drive value",value=n.get("value_drivers", ""),height=90)
        evidence=st.text_area("Key evidence — measurable facts",value=n.get("key_evidence", ""),height=110)
        catalysts=st.text_area("Catalysts / Why now",value=n.get("catalysts", ""),height=80)
        add=st.text_area("Evidence required to ADD",value=n.get("evidence_to_add", ""),height=80)
        invalidation=st.text_area("Invalidation rationale / what would prove the thesis wrong?",value=n.get("invalidation", ""),height=90,help="Narrative explanation only. Decision-grade thesis invalidation requires a LOCKED numerical Monitoring KPI.")
        r1,r2=st.columns(2)
        primary=r1.text_area("Primary risk",value=n.get("primary_risk", "")); secondary=r2.text_area("Secondary risks",value=n.get("secondary_risks", ""))
        portfolio=st.text_area("Portfolio / factor concentration notes",value=n.get("portfolio_risk_notes", ""),height=80)
        if st.form_submit_button("Save new research version",type="primary"):
            db.save_research(ticker,{"thesis_title":title,"business_notes":business,"value_drivers":drivers,
                "market_narrative":n.get("market_narrative", ""),"variant_view":n.get("variant_view", ""),
                "key_evidence":evidence,"catalysts":catalysts,"evidence_to_add":add,"invalidation":invalidation,
                "primary_risk":primary,"secondary_risks":secondary,"portfolio_risk_notes":portfolio})
            st.success("Saved. Prior version archived.");st.rerun()

    decision.seed_bear_case(ticker)
    items=db.query("SELECT * FROM bear_case_items WHERE ticker=? ORDER BY item_key",(ticker,))
    st.subheader("Bear Case · try to kill the thesis")
    display_table(pd.DataFrame(items)[["item_key","evidence_for","evidence_against","severity","status"]] if items else pd.DataFrame())
    with st.expander("Update counter-thesis item"):
        choices={x["item_key"]:x for x in items}
        if choices:
            key=st.selectbox("Risk / counter-thesis",list(choices))
            row=choices[key]
            efor=st.text_area("Evidence FOR bear case",value=row.get("evidence_for", ""),key=tk(ticker,"bear_for"))
            eagainst=st.text_area("Evidence AGAINST bear case",value=row.get("evidence_against", ""),key=tk(ticker,"bear_against"))
            sev=st.slider("Severity",1,5,int(row.get("severity") or 3))
            status=st.selectbox("Status",["OPEN","WATCH","MITIGATED","CONFIRMED"])
            if st.button("Save counter-thesis item"):
                db.execute("UPDATE bear_case_items SET evidence_for=?,evidence_against=?,severity=?,status=?,updated_at=? WHERE ticker=? AND item_key=?",(efor,eagainst,sev,status,db.now_utc(),ticker,key))
                st.success("Saved.");st.rerun()
    st.caption("Pre-mortem: It is 12 months later and we lost 40%. What happened? Which assumption was fragile? Which KPI should have warned us first?")

    history=db.query("SELECT * FROM research_history WHERE ticker=? ORDER BY id DESC LIMIT 10",(ticker,))
    with st.expander("Research version history"):
        if history:
            display_table(pd.DataFrame([{"Version":x["id"],"Created":x["created_at"],"Snapshot":(json.loads(x["payload"]).get("thesis_title") or "Untitled")} for x in history]))
        else: st.caption("No archived versions yet.")


def render_risk(ticker,state):
    hero(ticker,state,"Sizing is downstream of invalidation. Preserve the decision record before the outcome.")
    rp=db.risk_plan(ticker)
    with st.form(tk(ticker,"risk_plan")):
        c1,c2,c3,c4=st.columns(4)
        budget=c1.number_input("Max portfolio loss budget",value=float(rp.get("portfolio_risk_budget") or .0075),format="%.4f",step=.001)
        inval=c2.number_input("Sizing reference price",value=float(rp.get("invalidation_price") or state["price"] or 0),step=1.0,help="Used only for position-size loss math. Thesis invalidation itself is defined by LOCKED numerical Monitoring KPIs.")
        haircut=c3.number_input("Liquidity / event haircut",value=float(rp.get("event_liquidity_haircut") or .05),format="%.3f",step=.01)
        cap=c4.number_input("Max position cap",value=float(rp.get("max_position_cap") or .10),format="%.3f",step=.01)
        corr=st.text_area("Correlation / factor concentration notes",value=rp.get("correlation_notes", ""))
        kill=st.text_area("Portfolio / thesis kill-switch",value=rp.get("kill_switch", ""))
        if st.form_submit_button("Save risk plan"):
            db.save_risk_plan(ticker,{"portfolio_risk_budget":budget,"invalidation_price":inval,"event_liquidity_haircut":haircut,"max_position_cap":cap,"correlation_notes":corr,"kill_switch":kill})
            st.success("Saved.");st.rerun()
    price=state["price"]
    suggested=None
    if price and inval>0:
        loss=abs(price-inval)/price
        adjusted=loss+haircut
        suggested=min(cap,budget/adjusted) if adjusted>0 else 0
        a,b,c=st.columns(3);a.metric("Loss to sizing reference",fpct(loss));b.metric("Adjusted loss",fpct(adjusted));c.metric("Suggested size",fpct(suggested))
    st.caption("The sizing reference price is not a thesis kill condition. Thesis invalidation requires locked numerical operating/fundamental thresholds. Conviction never replaces downside math.")

    st.subheader("Freeze Decision Journal")
    research=db.load_research(ticker)
    sc=state["scenarios"]
    with st.form(tk(ticker,"decision_journal")):
        action=st.selectbox("Action",["WATCH","INITIATE LONG","ADD LONG","REDUCE LONG","EXIT LONG","INITIATE SHORT","ADD SHORT","COVER SHORT"])
        pos=st.number_input("Position %",min_value=0.0,max_value=100.0,value=0.0,step=.25)/100
        thesis=st.text_area("Thesis — max 3 sentences")
        variant_case=db.load_variant_case(ticker) or {}; variant_view=st.text_area("Variant perception",value=variant_case.get("our_belief") or research.get("variant_view", ""))
        c1,c2,c3=st.columns(3)
        bv=c1.number_input("Bear Value",value=float(sc.get("bear",{}).get("fair_value") or 0));basev=c2.number_input("Base Value",value=float(sc.get("base",{}).get("fair_value") or 0));bullv=c3.number_input("Bull Value",value=float(sc.get("bull",{}).get("fair_value") or 0))
        p1,p2,p3=st.columns(3)
        bp=p1.number_input("Bear Prob",0.0,1.0,float(sc.get("bear",{}).get("prob") or .25),.05);basep=p2.number_input("Base Prob",0.0,1.0,float(sc.get("base",{}).get("prob") or .5),.05);bullp=p3.number_input("Bull Prob",0.0,1.0,float(sc.get("bull",{}).get("prob") or .25),.05)
        locked_inv=[k for k in (state.get("kpis") or []) if k.get("linked_to")=="INVALIDATION" and k.get("threshold") is not None and int(k.get("locked") or 0)==1]
        locked_text=" · ".join(f"{k.get('name') or k.get('metric_key')} {k.get('operator') or '?'} {k.get('threshold')} {k.get('unit') or ''}".strip() for k in locked_inv)
        inv_default=(locked_text+(" | "+research.get("invalidation","") if research.get("invalidation") else "")) if locked_text else research.get("invalidation", "")
        inv=st.text_area("Invalidation",value=inv_default); evidence=st.text_area("Evidence required to ADD",value=research.get("evidence_to_add", "")); bias=st.text_area("Emotional / bias check")
        if st.form_submit_button("Freeze decision record",type="primary"):
            db.execute("""INSERT INTO decision_journal(created_at,ticker,action,price,position_pct,thesis,variant_view,bear_value,bear_prob,base_value,base_prob,bull_value,bull_prob,invalidation,evidence_to_add,bias_check)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (db.now_utc(),ticker,action,price,pos,thesis,variant_view,bv,bp,basev,basep,bullv,bullp,inv,evidence,bias))
            st.success("Decision frozen. Do not overwrite it after the outcome.");st.rerun()
    journal=db.query("SELECT * FROM decision_journal WHERE ticker=? ORDER BY id DESC",(ticker,))
    if journal: display_table(pd.DataFrame(journal),height=420)

    st.subheader("Append outcome / post-mortem")
    if journal:
        with st.form(tk(ticker,"outcome")):
            did=st.selectbox("Decision ID",[x["id"] for x in journal])
            statex=st.selectbox("Thesis state",["STRONGER","SAME","WEAKER","BROKEN","CLOSED"])
            outcome=st.text_area("Outcome / what happened")
            pm=st.text_area("Post-mortem — process, not outcome bias")
            if st.form_submit_button("Append outcome"):
                db.execute("INSERT INTO decision_outcomes(decision_id,created_at,thesis_state,outcome,post_mortem) VALUES(?,?,?,?,?)",(did,db.now_utc(),statex,outcome,pm))
                st.success("Outcome appended without changing the original decision.")


def render_portfolio(ticker,state):
    st.markdown('<div class="mf-eyebrow">PORTFOLIO · DETAIL</div>',unsafe_allow_html=True)
    st.title("Portfolio & Exposure")
    st.caption("This page analyzes the independent Portfolio ledger. Positions do not need to exist in Coverage first.")
    settings=load_settings(); nav=float(settings.get("portfolio_nav") or 0)
    rows=[]; tags={}
    for pos in db.list_portfolio_positions():
        t=pos["ticker"]; shares=float(pos.get("shares") or 0); avg=float(pos.get("avg_cost") or 0); side=pos.get("side") or "LONG"; sign=-1 if side=="SHORT" else 1
        bars=db.query("SELECT close,trade_date FROM daily_bars WHERE ticker=? ORDER BY trade_date DESC LIMIT 1",(t,)); price=float(bars[0]["close"]) if bars and bars[0].get("close") is not None else None
        mv=abs(shares*price) if price is not None else None; pnl=(price-avg)*shares*sign if price is not None else None
        rows.append({"Ticker":t,"Side":side,"Shares":shares,"Avg Cost":avg,"Price":price,"Market Value":mv,"P/L":pnl,"P/L %":((price/avg-1)*sign if price is not None and avg>0 else None),"Weight":(mv/nav) if mv is not None and nav>0 else None,"Tags":pos.get("tags","")})
        if mv is not None:
            for tag in [x.strip() for x in str(pos.get("tags") or "").split(",") if x.strip()]: tags[tag]=tags.get(tag,0)+mv
    if rows: display_table(pd.DataFrame(rows),{"Avg Cost":fprice,"Price":fprice,"Market Value":fmoney,"P/L":fmoney,"P/L %":fpct,"Weight":fpct})
    else: st.info("No real positions are recorded. Use the main Portfolio page to add them.")
    if nav<=0: st.warning("Set Portfolio NAV in Settings to calculate position weights and concentration.")
    if tags:
        total=sum(tags.values()) or 1
        tdf=pd.DataFrame([{"Factor / Exposure":k,"Gross Exposure":v,"Share of tagged gross":v/total} for k,v in sorted(tags.items(),key=lambda x:-x[1])])
        st.subheader("Manual factor exposure map"); display_table(tdf,{"Gross Exposure":fmoney,"Share of tagged gross":fpct})
        big=[k for k,v in tags.items() if v/total>.40]
        if big: st.warning("Concentration check: more than 40% of tagged gross exposure depends on: "+", ".join(big))
    st.caption("Tags are intentionally manual: sector labels alone often hide the real shared driver (China demand, rates, AI capex, consumer discretionary, oil, liquidity).")


def render_sources(ticker,state):
    st.markdown('<div class="mf-eyebrow">SYSTEM</div>',unsafe_allow_html=True)
    st.title("Sources & Audit")
    settings=load_settings()
    st.info("Configuration has one home in V3.1.12: Settings. This Advanced page is audit/provenance only, so provider and portfolio controls are not duplicated here.")
    st.page_link("pages/06_settings_v3.py",label="Open Settings",width="stretch")

    st.subheader("Data Audit & Provenance")
    st.caption("No data system can promise 100% correctness. This layer makes the chain auditable: source, date/period, reported vs reconstructed vs derived, formulas and reconciliation checks.")
    ar=state.get("audit") or audit.build_audit(ticker,state)
    c1,c2,c3,c4=st.columns(4)
    c1.metric("Audit PASS",ar["counts"].get("PASS",0)); c2.metric("WARN",ar["counts"].get("WARN",0)); c3.metric("FAIL",ar["counts"].get("FAIL",0)); c4.metric("NO DATA",ar["counts"].get("NO DATA",0))
    display_table(pd.DataFrame(ar["checks"]),height=330)
    with st.expander("Metric provenance — what produced each number", expanded=False):
        prov=pd.DataFrame(ar["provenance"])
        if not prov.empty:
            def _prov_value(row):
                metric=str(row.get("Metric") or "")
                val=row.get("Value")
                if "Margin" in metric or metric in ("ROIC proxy","FINRA Daily Short %"):
                    return fpct(val)
                if "Price" in metric or "Fair Value" in metric:
                    return fprice(val)
                if metric in ("DSO","DIO","DPO","Cash Conversion Cycle"):
                    return fnum(val,1)
                return money(val)
            prov["Value"]=prov.apply(_prov_value,axis=1)
        display_table(prov,height=420)
    with st.expander("SEC XBRL tags actually selected", expanded=False):
        tags=pd.DataFrame(ar["sec_tags"])
        if tags.empty:
            st.caption("No SEC provenance stored yet. Refresh after configuring SEC User-Agent.")
        else:
            st.dataframe(tags,width="stretch",hide_index=True,column_config={"source_url":st.column_config.LinkColumn("SEC Companyfacts")})
    with st.expander("SEC revisions / corrections detected across filings", expanded=False):
        revisions=pd.DataFrame(db.query("SELECT metric,xbrl_tag,period_end,first_filed,latest_filed,first_form,latest_form,first_value,latest_value,delta_pct FROM sec_revisions WHERE ticker=? ORDER BY period_end DESC,latest_filed DESC",(ticker,)))
        if revisions.empty:
            st.caption("No changed modeled SEC fact has been detected for this ticker yet.")
        else:
            display_table(revisions,{"first_value":money,"latest_value":money,"delta_pct":fpct},height=420)
            st.caption("A changed fact is not automatically an accounting error. It can be an amendment, restatement, reclassification or later comparative presentation. Market Forensics flags it so you can inspect the filing instead of silently mixing versions.")

    st.subheader("Data freshness / last refresh")
    runs=db.query("SELECT * FROM refresh_runs WHERE ticker=? ORDER BY id DESC LIMIT 10",(ticker,))
    display_table(pd.DataFrame(runs))

    st.subheader("Source hierarchy")
    source_df=pd.DataFrame([
        ["SEC EDGAR / XBRL","T1","Fundamentals, filings","AUTO","Primary source; refreshed only when SEC User-Agent is set."],
        ["SEC filings + 8-K exhibits","T1","Management promises / guidance history","AUTO","Only explicit numeric promises are auto-scored; qualitative statements stay unverified."],
        ["FINRA Daily Short Sale Volume","T1","Off-exchange short-sale volume","AUTO","Never equated with Short Interest."],
        ["FINRA Short Interest","T1","Semi-monthly positioning","MANUAL","Publication-date no-lookahead."],
        ["Alpaca historical SIP","T2","Trades/quotes/bars","AUTO first","Full consolidated feed when historical access permits."],
        ["Alpaca IEX","T2","Trades/quotes/bars","AUTO fallback","Single exchange; confidence penalty."],
        ["FINRA ATS / OTC","T1","Delayed venue activity","ROADMAP","Requires robust official API credentials / access."],
        ["SEC 13F / 13D / 13G","T1","Delayed ownership / activism","ROADMAP","Confirmation layer, not daily score."],
        ["SEC Form 4 / 144","T1","Insider activity","ROADMAP","Must classify vesting, taxes, 10b5-1 and open-market activity."],
        ["Borrow / lending","T2/T3","Fee, utilization, on-loan","OPTIONAL","Only with stable licensed source."],
        ["Options / OPRA","T2","IV/OI/skew/strike concentration","OPTIONAL","Entitlement dependent."],
    ],columns=["Source","Tier","Use","Status","Rule"])
    display_table(source_df)

    st.subheader("Official SEC filings")
    if settings.get("sec_user_agent") and "@" in settings.get("sec_user_agent",""):
        try:
            links=sec.filing_links(ticker,settings["sec_user_agent"])
            if links: st.dataframe(pd.DataFrame(links),width="stretch",hide_index=True,column_config={"url":st.column_config.LinkColumn("SEC filing")})
        except Exception as e: st.error(str(e))
    else: st.info("Set the SEC User-Agent in Settings to activate EDGAR filings and XBRL fundamentals.")

    st.subheader("Research Source Log")
    with st.form(tk(ticker,"source_log")):
        c1,c2=st.columns(2)
        stype=c1.selectbox("Source type",["10-K","10-Q","8-K","Proxy","SEC XBRL","FINRA","Alpaca","Company IR","Competitor filing","Other"])
        doc=c2.text_input("Document / dataset")
        url=st.text_input("URL / reference")
        fact=st.text_area("Key fact used")
        c1,c2=st.columns(2); sc=c1.selectbox("Supports / challenges",["Supports","Challenges","Neutral / Context"]); rel=c2.slider("Reliability",1,5,5)
        if st.form_submit_button("Add source"):
            db.execute("INSERT INTO source_log(created_at,ticker,source_type,document,url,key_fact,supports_challenges,reliability) VALUES(?,?,?,?,?,?,?,?)",(db.now_utc(),ticker,stype,doc,url,fact,sc,rel))
            st.success("Source logged.");st.rerun()
    logs=db.query("SELECT * FROM source_log WHERE ticker=? ORDER BY id DESC",(ticker,))
    display_table(pd.DataFrame(logs),height=350)

    st.subheader("Export / backup")
    st.download_button("Download ticker dossier (JSON)",data=exporter.dossier_json(ticker,state["assumptions"],state["gates"]),file_name=f"{ticker}_Market_Forensics_Dossier.json",mime="application/json")
    try:
        if DB_PATH.exists(): st.download_button("Backup complete SQLite database",data=DB_PATH.read_bytes(),file_name="market_forensics_backup.sqlite",mime="application/octet-stream")
    except Exception as e: st.caption(f"Database backup unavailable: {e}")


