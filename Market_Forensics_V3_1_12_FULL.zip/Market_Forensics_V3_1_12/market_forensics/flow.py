from __future__ import annotations

from bisect import bisect_right
from datetime import datetime, timezone
import numpy as np


def percentile(values, p):
    if not values:
        return None
    return float(np.quantile(np.array(values, dtype=float), p))


def _timestamp_key(value):
    """Return an orderable UTC timestamp for Alpaca ISO timestamps.

    Do not compare RFC3339 timestamps as raw strings: fractional-second and
    non-fractional representations can sort incorrectly (e.g. .100Z vs Z).
    """
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value or "").strip()
    if not text:
        raise ValueError("empty timestamp")
    # Alpaca uses RFC3339 / UTC. datetime.fromisoformat accepts fractional
    # seconds (including nanosecond strings, truncated to microseconds).
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.timestamp()


def classify_session(trades, quotes, min_notional=25000, large_p=.75, very_large_p=.90, whale_p=.99):
    q = []
    for x in quotes:
        try:
            q.append((_timestamp_key(x["t"]), float(x["bp"]), float(x["ap"])))
        except Exception:
            pass
    q.sort(key=lambda z: z[0])
    qt = [x[0] for x in q]
    rows = []
    for t in trades:
        try:
            ts = t["t"]
            ts_key = _timestamp_key(ts)
            price = float(t["p"])
            size = float(t["s"])
            notional = price * size
        except Exception:
            continue
        i = bisect_right(qt, ts_key) - 1
        bid = ask = None
        side = "Neutral"
        if i >= 0:
            bid, ask = q[i][1], q[i][2]
            if bid > 0 and ask >= bid:
                mid = (bid + ask) / 2
                if price >= ask:
                    side = "Aggressive Buy"
                elif price <= bid:
                    side = "Aggressive Sell"
                elif price > mid:
                    side = "Aggressive Buy"
                elif price < mid:
                    side = "Aggressive Sell"
        rows.append({"ts": ts, "price": price, "size": size, "notional": notional, "side": side, "bid": bid, "ask": ask})

    eligible = [r["notional"] for r in rows if r["notional"] >= min_notional]
    p75 = percentile(eligible, large_p)
    p90 = percentile(eligible, very_large_p)
    p99 = percentile(eligible, whale_p)
    for r in rows:
        n = r["notional"]
        r["large"] = bool(p75 is not None and n >= p75)
        r["very_large"] = bool(p90 is not None and n >= p90)
        r["whale"] = bool(p99 is not None and n >= p99)

    def s(flag, side=None):
        return sum(r["notional"] for r in rows if r[flag] and (side is None or r["side"] == side))

    lb = s("large", "Aggressive Buy")
    ls = s("large", "Aggressive Sell")
    wb = s("whale", "Aggressive Buy")
    ws = s("whale", "Aggressive Sell")
    turn = sum(eligible)
    lturn = s("large")
    wturn = s("whale")
    buys = [r for r in rows if r["large"] and r["side"] == "Aggressive Buy"]
    sells = [r for r in rows if r["large"] and r["side"] == "Aggressive Sell"]

    def wap(xs):
        den = sum(x["size"] for x in xs)
        return sum(x["price"] * x["size"] for x in xs) / den if den else None

    covered = sum(1 for r in rows if r["bid"] is not None and r["ask"] is not None)
    return {
        "large_buy": lb, "large_sell": ls, "net_large": lb - ls,
        "whale_buy": wb, "whale_sell": ws, "net_whale": wb - ws,
        "large_turnover_pct": lturn / turn if turn else None,
        "whale_turnover_pct": wturn / turn if turn else None,
        "avg_aggressive_buy": wap(buys), "avg_aggressive_sell": wap(sells),
        "quote_coverage": covered / len(rows) if rows else 0,
        "large_threshold": p75, "very_large_threshold": p90, "whale_threshold": p99,
        "trade_count": len(rows), "classified_count": sum(r["side"] != "Neutral" for r in rows),
        "rows": rows,
    }


def clamp(x):
    return max(0, min(100, float(x)))


def _sign(x):
    return 1 if x > 0 else -1 if x < 0 else 0


def tape_scores(bar, flow, short_pct=None, si_change=None, feed="iex", persistence=0):
    ret = float(bar.get("return") or 0)
    rng = (bar["high"] - bar["low"]) if bar.get("high") is not None and bar.get("low") is not None else 0
    close_loc = (bar["close"] - bar["low"]) / rng if rng else .5
    net_large = float(flow.get("net_large") or 0)
    denom = abs(float(flow.get("large_buy") or 0)) + abs(float(flow.get("large_sell") or 0))
    flow_ratio = net_large / denom if denom else 0
    net_whale = float(flow.get("net_whale") or 0)
    wden = abs(float(flow.get("whale_buy") or 0)) + abs(float(flow.get("whale_sell") or 0))
    whale_ratio = net_whale / wden if wden else 0

    institutional_flow = clamp(50 + 28 * flow_ratio + 14 * whale_ratio + 8 * persistence + 5 * _sign(ret))
    long_demand = clamp(50 + 25 * flow_ratio + 12 * whale_ratio + 8 * persistence + 5 * _sign(ret))

    sp = 50
    if short_pct is not None:
        sp += 80 * (float(short_pct) - .50)
    if si_change is not None:
        sp += 120 * float(si_change)
    short_pressure = clamp(sp)

    direction = _sign(flow_ratio)
    absorption = clamp(50 + 25 * direction * (close_loc - .5) * 2 + 15 * direction * _sign(ret))
    resilience = clamp(55 * close_loc + 20 * (1 if ret > 0 else 0) + 15 * (1 if ret >= -.01 else 0) + 10 * min(1, abs(ret) / .03))
    battle = clamp(.55 * short_pressure + .45 * (50 + 50 * abs(flow_ratio)))
    net_tape = clamp(.22 * institutional_flow + .18 * long_demand + .18 * absorption + .17 * resilience + .15 * (100 - short_pressure) + .10 * (50 + 50 * flow_ratio))

    confidence = 25
    qcov = float(flow.get("quote_coverage") or 0)
    confidence += 25 if qcov > .80 else 15 if qcov > .50 else 5
    confidence += 20 if short_pct is not None else 0
    confidence += 15 if si_change is not None else 0
    f = (feed or "iex").lower()
    confidence += 15 if (f == "sip" or "sip" in f) else 8 if (f == "delayed_sip" or "iex" in f) else 0 if f in ("none", "") else 5
    confidence = clamp(confidence)

    if confidence < 50:
        regime = "LOW DATA"
    elif short_pressure >= 70 and institutional_flow >= 65 and absorption >= 60:
        regime = "ACCUMULATION UNDER PRESSURE"
    elif short_pressure >= 70 and institutional_flow >= 60 and absorption < 45:
        regime = "BATTLE - SELLERS STILL CONTROL"
    elif short_pressure >= 70 and absorption < 45:
        regime = "DISTRIBUTION / BEARS CONTROL"
    elif long_demand >= 65 and absorption >= 60 and resilience >= 55:
        regime = "ACCUMULATION"
    elif net_tape >= 60:
        regime = "CONSTRUCTIVE"
    elif long_demand <= 40 and resilience <= 40:
        regime = "DISTRIBUTION"
    else:
        regime = "NEUTRAL / BATTLE"

    rank = "A" if net_tape >= 80 else "B" if net_tape >= 65 else "C" if net_tape >= 50 else "D" if net_tape >= 35 else "F"
    return {
        "Institutional Flow": institutional_flow,
        "Long Demand": long_demand,
        "Short Pressure": short_pressure,
        "Absorption": absorption,
        "Battle Intensity": battle,
        "Price Resilience": resilience,
        "Net Tape": net_tape,
        "Confidence": confidence,
        "Regime": regime,
        "Rank": rank,
        "Close Location": close_loc,
        "Flow Ratio": flow_ratio,
        "Whale Ratio": whale_ratio,
    }


def regime_requirements(scores: dict) -> list[str]:
    """Transparent conditions that could materially improve or deteriorate the current tape regime."""
    if not scores:
        return ["Collect enough market/FINRA data to raise Data Confidence above 50."]
    out = []
    if scores.get("Confidence", 0) < 50:
        out.append("Raise Data Confidence above 50 with better quote/short-interest coverage.")
    if scores.get("Absorption", 0) < 60:
        out.append("Absorption > 60: large demand must translate into better price response.")
    if scores.get("Price Resilience", 0) < 55:
        out.append("Price Resilience > 55: stop making/accepting new lows and improve close location.")
    if scores.get("Institutional Flow", 0) < 60:
        out.append("Institutional Flow > 60 with persistent positive large/whale imbalance.")
    if scores.get("Short Pressure", 0) >= 70:
        out.append("High short pressure must either be absorbed or begin to fall; pressure alone is not bullish.")
    if not out:
        out.append("Maintain current flow, absorption and resilience for multiple sessions; one day is not confirmation.")
    return out[:5]
