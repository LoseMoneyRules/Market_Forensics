from __future__ import annotations

import math
from statistics import median

from . import db


def _f(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def _pct(a, b):
    a = _f(a); b = _f(b)
    if a is None or b in (None, 0):
        return None
    return a / b - 1.0


def auto_peers(ticker: str, limit: int = 5) -> list[dict]:
    """Find financially comparable peers from the cached discovery universe.

    Exact SIC is preferred. If that set is too small, the 2-digit SIC division is used.
    Market-cap distance is used only as a tie-breaker; it never manufactures a relationship.
    """
    t = ticker.upper()
    target = db.discovery_row(t)
    if not target:
        meta = db.query("SELECT * FROM company_meta WHERE ticker=?", (t,))
        target = meta[0] if meta else None
    if not target:
        return []
    sic = str(target.get("sic") or "")
    if not sic:
        return []
    exact = db.query(
        """SELECT * FROM discovery_universe WHERE ticker!=? AND sic=? AND revenue IS NOT NULL
           ORDER BY dollar_volume DESC LIMIT 40""", (t, sic)
    )
    pool = exact
    if len(pool) < max(3, limit):
        pool = db.query(
            """SELECT * FROM discovery_universe WHERE ticker!=? AND substr(sic,1,2)=? AND revenue IS NOT NULL
               ORDER BY dollar_volume DESC LIMIT 80""", (t, sic[:2])
        )
    target_mc = _f(target.get("market_cap"))
    def distance(r):
        mc = _f(r.get("market_cap"))
        if target_mc and mc and target_mc > 0 and mc > 0:
            return abs(math.log(mc / target_mc))
        return 99.0
    pool = sorted(pool, key=lambda r: (distance(r), -(r.get("dollar_volume") or 0)))
    return pool[:limit]


def linked_peers(ticker: str, limit: int = 8) -> list[dict]:
    manual = db.peer_links(ticker)
    out = []
    seen = set()
    for link in manual:
        p = db.discovery_row(link["peer_ticker"])
        if p:
            out.append({**p, "relation_type": link.get("relation_type") or "PEER", "relation_source": link.get("source") or "MANUAL", "relation_confidence": link.get("confidence")})
            seen.add(p["ticker"])
    for p in auto_peers(ticker, limit=limit):
        if p["ticker"] not in seen:
            out.append({**p, "relation_type": "PEER", "relation_source": "AUTO_SIC", "relation_confidence": 0.65})
            seen.add(p["ticker"])
        if len(out) >= limit:
            break
    return out[:limit]


METRICS = [
    ("Revenue Growth", "revenue_growth", True, 0.03),
    ("Operating Margin", "operating_margin", True, 0.02),
    ("FCF Margin", "fcf_margin", True, 0.02),
    ("ROIC", "roic", True, 0.03),
    ("Inventory / Revenue", "inventory_rev", False, 0.025),
    ("Receivables / Revenue", "receivables_rev", False, 0.02),
    ("Share Change", "share_change", False, 0.02),
    ("P/E", "pe", False, 0.15),
    ("EV / Sales", "ev_sales", False, 0.15),
    ("FCF Yield", "fcf_yield", True, 0.015),
]


def compare(ticker: str, limit: int = 6) -> dict:
    t = ticker.upper()
    company = db.discovery_row(t)
    peers = linked_peers(t, limit=limit)
    if not company or not peers:
        return {"company": company or {}, "peers": peers, "rows": [], "signals": [], "summary": "LOW DATA", "score": None}

    rows = []
    signals = []
    positive = 0
    negative = 0
    for label, key, higher_better, threshold in METRICS:
        cv = _f(company.get(key))
        pv = [_f(p.get(key)) for p in peers]
        pv = [x for x in pv if x is not None]
        med = median(pv) if pv else None
        if cv is None or med is None:
            verdict = "NO DATA"
            delta = None
        else:
            delta = cv - med
            if key in ("pe", "ev_sales"):
                rel = _pct(cv, med)
                strong = rel is not None and abs(rel) >= threshold
            else:
                strong = abs(delta) >= threshold
            if not strong:
                verdict = "IN LINE"
            else:
                better = cv > med if higher_better else cv < med
                verdict = "RELATIVE STRENGTH" if better else "RELATIVE WEAKNESS"
                if better: positive += 1
                else: negative += 1
        rows.append({"Metric": label, "Company": cv, "Peer Median": med, "Difference": delta, "Verdict": verdict})

    # Distinguish company-specific from industry-wide direction using year-over-year evidence.
    company_rev = _f(company.get("revenue_growth"))
    peer_rev = [_f(p.get("revenue_growth")) for p in peers]
    peer_rev = [x for x in peer_rev if x is not None]
    if company_rev is not None and peer_rev:
        med_rev = median(peer_rev)
        if company_rev < -0.02 and med_rev > 0.0:
            signals.append({"Type":"NEGATIVE","Signal":"COMPANY-SPECIFIC WEAKNESS","Evidence":f"Revenue growth {company_rev:.1%} vs peer median {med_rev:.1%}."})
        elif company_rev > 0.03 and med_rev < 0.0:
            signals.append({"Type":"POSITIVE","Signal":"COMPANY-SPECIFIC STRENGTH","Evidence":f"Revenue growth {company_rev:.1%} vs peer median {med_rev:.1%}."})
        elif company_rev < 0 and med_rev < 0:
            signals.append({"Type":"CONTEXT","Signal":"INDUSTRY-WIDE PRESSURE","Evidence":f"Company and peer median revenue growth are both negative ({company_rev:.1%} / {med_rev:.1%})."})
        elif company_rev > 0 and med_rev > 0:
            signals.append({"Type":"CONTEXT","Signal":"INDUSTRY-WIDE GROWTH","Evidence":f"Company and peer median revenue growth are both positive ({company_rev:.1%} / {med_rev:.1%})."})

    # Working-capital divergence can be an early warning when company behavior differs from the channel/peer set.
    for key, label in (("inventory_rev", "inventory/revenue"), ("receivables_rev", "receivables/revenue")):
        cv = _f(company.get(key)); pvals=[_f(p.get(key)) for p in peers]; pvals=[x for x in pvals if x is not None]
        if cv is not None and pvals:
            medv=median(pvals)
            if cv - medv > 0.05:
                signals.append({"Type":"NEGATIVE","Signal":"WORKING-CAPITAL DIVERGENCE","Evidence":f"{label} {cv:.1%} vs peer median {medv:.1%}."})

    # Relative valuation mismatch with stronger/weaker economics is the core triangulation edge.
    q = _f(company.get("quality_score")); val = _f(company.get("valuation_score"))
    peer_q = [_f(p.get("quality_score")) for p in peers]; peer_q=[x for x in peer_q if x is not None]
    peer_v = [_f(p.get("valuation_score")) for p in peers]; peer_v=[x for x in peer_v if x is not None]
    if q is not None and val is not None and peer_q and peer_v:
        qm=median(peer_q); vm=median(peer_v)
        if q >= qm + 8 and val >= vm + 10:
            signals.append({"Type":"POSITIVE","Signal":"RELATIVE VALUE + QUALITY","Evidence":f"Quality {q:.0f} vs {qm:.0f} peers while cheapness {val:.0f} vs {vm:.0f}."})
        if q <= qm - 8 and val <= vm - 10:
            signals.append({"Type":"NEGATIVE","Signal":"RELATIVE PREMIUM WITHOUT QUALITY","Evidence":f"Quality {q:.0f} vs {qm:.0f} peers while valuation is less attractive ({val:.0f} vs {vm:.0f})."})

    score = max(0, min(100, 50 + (positive-negative)*8 + sum(8 if s["Type"]=="POSITIVE" else -8 if s["Type"]=="NEGATIVE" else 0 for s in signals)))
    summary = "RELATIVE STRENGTH" if score >= 65 else "RELATIVE WEAKNESS" if score <= 35 else "MIXED / INDUSTRY-LIKE"
    return {"company": company, "peers": peers, "rows": rows, "signals": signals, "summary": summary, "score": score}
