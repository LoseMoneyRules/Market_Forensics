from __future__ import annotations

import math
from statistics import median
from . import db, valuation, fundamentals


def _f(x):
    try:
        v=float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def _div(a,b):
    a=_f(a); b=_f(b)
    return None if a is None or b in (None,0) else a/b


def _pct(x):
    return "—" if _f(x) is None else f"{float(x):+.1%}"


def _bps(x):
    return "—" if _f(x) is None else f"{float(x)*10000:+.0f} bps"


def build_forensic_signals(ticker: str, state: dict, calibration: dict | None=None, audit_result: dict | None=None):
    """Deterministic evidence engine: positives, negatives, and data-integrity alerts.

    It is intentionally explicit and rule-based. A signal is a prompt to investigate, not a trade instruction.
    """
    t=ticker.upper()
    metrics=state.get("metrics") or {}
    fund=state.get("fund_rows") or []
    scenarios=state.get("scenarios") or {}
    price=state.get("price")
    scores=state.get("scores") or {}
    calibration=calibration or valuation.historical_calibration(fund,state.get("bars") or [])
    rows=[]

    def add(direction,severity,category,title,evidence,why):
        rows.append({"Direction":direction,"Severity":severity,"Category":category,
                     "Signal":title,"Evidence":evidence,"Why it matters":why})

    # --- Data integrity / revisions ---
    revisions=db.query("SELECT * FROM sec_revisions WHERE ticker=? ORDER BY period_end DESC,latest_filed DESC",(t,))
    seen=set()
    for r in revisions:
        key=(r.get("metric"),r.get("period_end"))
        if key in seen: continue
        seen.add(key)
        dp=_f(r.get("delta_pct"))
        material=abs(dp) if dp is not None else None
        sev="HIGH" if (str(r.get("latest_form") or "").endswith("/A") or (material is not None and material>=.05)) else "MEDIUM"
        evidence=f"{r.get('metric')} · {r.get('period_end')} · {_pct(dp)} · {r.get('first_filed')} → {r.get('latest_filed')}"
        add("DATA",sev,"SEC revision","Previously reported SEC fact changed",evidence,
            "May be an amendment, restatement, reclassification or comparative-period update. Review the filing before trusting trend comparisons.")
        if len([x for x in rows if x["Category"]=="SEC revision"])>=6: break

    fys=sorted([r for r in fund if r.get("period_type")=="FY" and r.get("fiscal_year")],key=lambda r:r["fiscal_year"])
    bars=state.get("bars") or []
    for a,b in zip(fys,fys[1:]):
        sa=_f(a.get("diluted_shares")); sb=_f(b.get("diluted_shares"))
        if sa and sb and sa>0:
            af,av=fundamentals._split_factor_at(bars,a.get("share_value_filed") or a.get("period_filed"))
            bf,bv=fundamentals._split_factor_at(bars,b.get("share_value_filed") or b.get("period_filed"))
            if not (av and bv):
                continue
            ch=(sb*bf)/(sa*af)-1
            if abs(ch)>.25:
                add("DATA","HIGH","Unit / corporate action check","Large economic share-count discontinuity",
                    f"FY{a['fiscal_year']} → FY{b['fiscal_year']}: {ch:+.1%} after split normalization",
                    "Could be a major issuance/buyback or an XBRL context mismatch. Stock-split mechanics have already been normalized out.")
                break

    if audit_result:
        for c in audit_result.get("checks",[]):
            if c.get("Status") in ("FAIL","WARN"):
                sev="HIGH" if c.get("Status")=="FAIL" else "MEDIUM"
                add("DATA",sev,"Data audit",c.get("Check") or "Audit warning",c.get("Detail") or "",c.get("Source") or "Internal reconciliation")

    # --- Business evidence ---
    latest_fy=fys[-1] if fys else {}
    prev_fy=fys[-2] if len(fys)>=2 else {}
    ttm=next((r for r in fund if r.get("period_key")=="TTM"),{})

    def margin_signal(label,key,threshold=.015):
        cur=_div(ttm.get(key),ttm.get("revenue")) if key not in ("fcf",) else _div(ttm.get("fcf"),ttm.get("revenue"))
        old=_div(latest_fy.get(key),latest_fy.get("revenue")) if key not in ("fcf",) else _div(latest_fy.get("fcf"),latest_fy.get("revenue"))
        if cur is None or old is None: return
        d=cur-old
        if d>=threshold:
            add("POSITIVE","MEDIUM","Business",f"{label} is improving",f"TTM {cur:.1%} vs FY{latest_fy.get('fiscal_year')} {old:.1%} ({_bps(d)})","Higher normalized profitability can lift earnings power and support a higher fair value.")
        elif d<=-threshold:
            add("NEGATIVE","MEDIUM","Business",f"{label} is deteriorating",f"TTM {cur:.1%} vs FY{latest_fy.get('fiscal_year')} {old:.1%} ({_bps(d)})","Margin deterioration can make historical multiple/margin mean reversion too optimistic.")

    margin_signal("Gross margin","gross_profit",.0125)
    margin_signal("Operating margin","operating_income",.0125)
    margin_signal("FCF margin","fcf",.0200)

    # Revenue acceleration/deceleration using completed fiscal years.
    if len(fys)>=3:
        g_prev=_div(fys[-2].get("revenue"),fys[-3].get("revenue")); g_last=_div(fys[-1].get("revenue"),fys[-2].get("revenue"))
        if g_prev is not None and g_last is not None:
            g_prev-=1; g_last-=1; dg=g_last-g_prev
            if dg>=.04:
                add("POSITIVE","MEDIUM","Business","Revenue growth accelerated",f"{g_prev:+.1%} → {g_last:+.1%}","Acceleration can signal a real inflection if margins/cash conversion confirm it.")
            elif dg<=-.04:
                add("NEGATIVE","MEDIUM","Business","Revenue growth decelerated",f"{g_prev:+.1%} → {g_last:+.1%}","A slowing top line can invalidate a multiple based on the company's stronger historical regime.")

    # Working-capital divergences: scaled ratios, not absolute dollars.
    if latest_fy and ttm:
        for name,key,threshold in (("Inventory / Revenue","inventory",.025),("Receivables / Revenue","receivables",.020)):
            cur=_div(ttm.get(key),ttm.get("revenue")); old=_div(latest_fy.get(key),latest_fy.get("revenue"))
            if cur is None or old is None: continue
            d=cur-old
            if d>=threshold:
                add("NEGATIVE","HIGH" if d>=threshold*2 else "MEDIUM","Working capital",f"{name} moved against the business",f"{old:.1%} → {cur:.1%} ({d:+.1%})","Assets tied up faster than sales can flag demand, collections or channel-quality issues.")
            elif d<=-threshold:
                add("POSITIVE","MEDIUM","Working capital",f"{name} improved",f"{old:.1%} → {cur:.1%} ({d:+.1%})","Less working capital per dollar of sales improves cash conversion and lowers balance-sheet risk.")

    cfo_ni=_f(metrics.get("cfo_ni"))
    if cfo_ni is not None and _f(metrics.get("net_income")) and float(metrics.get("net_income"))>0:
        if cfo_ni>=1.20:
            add("POSITIVE","MEDIUM","Cash quality","Cash conversion is stronger than reported earnings",f"CFO / Net Income = {cfo_ni:.2f}x","Strong cash conversion supports earnings quality; check whether working-capital tailwinds are sustainable.")
        elif cfo_ni<.70:
            add("NEGATIVE","HIGH","Cash quality","Cash conversion lags reported earnings",f"CFO / Net Income = {cfo_ni:.2f}x","Persistent divergence can signal accruals or working-capital stress and should reduce confidence in earnings-based valuation.")

    share_ch=_f(metrics.get("share_change"))
    if share_ch is not None:
        if share_ch<=-.02:
            add("POSITIVE","LOW","Capital allocation","Diluted share count is shrinking",_pct(share_ch),"Buybacks that truly reduce diluted shares increase per-share ownership and can support per-share value.")
        elif share_ch>=.02:
            add("NEGATIVE","MEDIUM","Capital allocation","Diluted share count is rising",_pct(share_ch),"Dilution can offset operating growth and makes per-share valuation less attractive.")

    # --- Valuation evidence ---
    regime_diag = state.get("valuation_regime") or valuation.multiple_regime_diagnostics(metrics, price, calibration)
    regime_rows = regime_diag.get("rows", [])
    if regime_rows:
        pos = sum(1 for r in regime_rows if r.get("direction") == "POSITIVE")
        neg = sum(1 for r in regime_rows if r.get("direction") == "NEGATIVE")
        direction = "POSITIVE" if pos > neg else "NEGATIVE"
        severity = "HIGH" if any(r.get("severity") == "HIGH" for r in regime_rows) else "MEDIUM"
        evidence_parts=[]
        for r in regime_rows[:3]:
            cur=r.get("current"); med=r.get("historical_median"); ratio=r.get("ratio_to_history")
            if all(x is not None for x in (cur,med,ratio)):
                evidence_parts.append(f"{r.get('metric')} {cur:.2f} vs {med:.2f} hist. ({ratio:.2f}x)")
        if direction == "POSITIVE":
            title="Valuation is far below its historical regime — explain the de-rating"
        else:
            title="Valuation regime break challenges historical mean reversion"
        primary = next((r for r in regime_rows if r.get("direction") == direction), regime_rows[0])
        add(direction,severity,"Valuation regime",title," · ".join(evidence_parts),
            primary.get("explanation") or "Explain the re-rating before relying on historical mean reversion.")

    curm=valuation.current_multiples(metrics,price)
    for key,label,inverse in (("pe","P/E",False),("ev_sales","EV/Sales",False),("fcf_yield","FCF yield",True)):
        x=_f(curm.get(key)); hist=calibration.get(key,{})
        p25=_f(hist.get("p25")); p75=_f(hist.get("p75")); n=int(hist.get("n") or 0)
        if x is None or p25 is None or p75 is None or n<4: continue
        if not inverse:
            if x<p25:
                add("POSITIVE","MEDIUM","Valuation",f"Current {label} is below its historical lower quartile",f"Current {x:.2f} vs P25 {p25:.2f} ({n} observations)","Potential valuation support, but only if today's economics are not structurally worse than the historical sample.")
            elif x>p75:
                add("NEGATIVE","MEDIUM","Valuation",f"Current {label} is above its historical upper quartile",f"Current {x:.2f} vs P75 {p75:.2f} ({n} observations)","The market is paying a richer-than-normal multiple; the business must justify it with superior growth/quality.")
        else:
            if x>p75:
                add("POSITIVE","MEDIUM","Valuation","Current FCF yield is above its historical upper quartile",f"Current {x:.1%} vs P75 {p75:.1%} ({n} observations)","Higher FCF yield can indicate cheaper pricing if cash flow is sustainable.")
            elif x<p25:
                add("NEGATIVE","MEDIUM","Valuation","Current FCF yield is below its historical lower quartile",f"Current {x:.1%} vs P25 {p25:.1%} ({n} observations)","Low cash yield implies a richer valuation and less room for execution misses.")

    base=scenarios.get("base",{})
    comps=[_f(base.get(k)) for k in ("pe","ev_sales","fcf_yield","dcf")]
    comps=[x for x in comps if x is not None and x>0]
    if len(comps)>=3:
        med=median(comps); spread=(max(comps)-min(comps))/med if med else 0
        if spread>.70:
            add("NEGATIVE","HIGH","Valuation","Valuation methods materially disagree",f"Cross-method spread ≈ {spread:.0%}","A precise target is not defensible until the assumption causing the disagreement is understood.")
        elif spread<.30:
            add("POSITIVE","LOW","Valuation","Independent valuation methods cluster tightly",f"Cross-method spread ≈ {spread:.0%}","Method agreement does not prove correctness, but it reduces model-specific dependence.")

    # --- Market confirmation / contradiction ---
    fv=_f(base.get("fair_value")); nt=_f(scores.get("Net Tape")); sp=_f(scores.get("Short Pressure")); ab=_f(scores.get("Absorption"))
    upside=(fv/float(price)-1) if fv is not None and _f(price) not in (None,0) else None
    if upside is not None and nt is not None:
        if upside>=.20 and nt>=60:
            add("POSITIVE","MEDIUM","Cross-check","Fundamental value and tape are aligned",f"Base upside {upside:+.1%} · Net Tape {nt:.0f}","Price/flow confirmation can improve timing, though it does not replace the fundamental thesis.")
        elif upside>=.20 and nt<40:
            add("NEGATIVE","MEDIUM","Cross-check","Value thesis is not confirmed by tape",f"Base upside {upside:+.1%} · Net Tape {nt:.0f}","The stock may be cheap for a reason or simply early; require evidence rather than adding on price alone.")
    if sp is not None and sp>=70 and ab is not None:
        if ab>=60:
            add("POSITIVE","LOW","Tape","Heavy bearish supply is being absorbed",f"Short Pressure {sp:.0f} · Absorption {ab:.0f}","Persistent absorption can be constructive when price resilience also improves.")
        elif ab<40:
            add("NEGATIVE","MEDIUM","Tape","Bearish pressure is not being absorbed",f"Short Pressure {sp:.0f} · Absorption {ab:.0f}","Large buyers may be present, but sellers still control price response.")

    # Sort: high severity first, DATA then negative then positive within severity.
    sev={"HIGH":0,"MEDIUM":1,"LOW":2}
    direction={"DATA":0,"NEGATIVE":1,"POSITIVE":2}
    rows.sort(key=lambda r:(sev.get(r["Severity"],9),direction.get(r["Direction"],9),r["Category"],r["Signal"]))
    positives=[r for r in rows if r["Direction"]=="POSITIVE"]
    negatives=[r for r in rows if r["Direction"]=="NEGATIVE"]
    data_alerts=[r for r in rows if r["Direction"]=="DATA"]
    return {"all":rows,"positives":positives,"negatives":negatives,"data_alerts":data_alerts,
            "counts":{"POSITIVE":len(positives),"NEGATIVE":len(negatives),"DATA":len(data_alerts)}}
