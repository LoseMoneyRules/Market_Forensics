from __future__ import annotations

import math
from datetime import date
from . import db

GATES = [
    ("business", "I can explain how the company makes cash in plain English."),
    ("five_year_financials", "I have rebuilt at least five years of key financials."),
    ("working_capital", "I understand working capital and cash conversion."),
    ("value_drivers", "I know the 3-5 variables that actually drive value."),
    ("expectations", "I know what the market appears to expect."),
    ("variant", "I have a specific variant perception."),
    ("scenarios", "I have Bear / Base / Bull scenarios with probabilities totaling 100%."),
    ("expected_value", "I calculated expected value and downside."),
    ("counter_thesis", "I deliberately built the strongest counter-thesis."),
    ("catalysts", "I identified catalysts and a time horizon."),
    ("invalidation", "I wrote numerical thesis invalidation thresholds before entry."),
    ("evidence_to_add", "I defined evidence required to ADD."),
    ("sizing", "I calculated position size from risk budget and invalidation loss."),
    ("concentration", "I checked portfolio correlation / concentration."),
    ("sources", "I logged primary sources."),
    ("journal", "I wrote the decision in the Decision Journal."),
]

BEAR_ITEMS = [
    "Demand / end market", "Pricing pressure", "Competition / share loss",
    "Gross margin normalization", "Opex rigidity", "Working capital deterioration",
    "Accounting quality", "Customer concentration", "Supplier / input cost",
    "Balance sheet / covenants", "Management credibility", "Capital allocation",
    "Technology / disruption", "Regulatory / legal", "Valuation / expectations",
    "Crowded positioning / squeeze",
]

COMPANY_TEMPLATES = {
    "Generic": ["Revenue growth", "Gross margin", "Operating margin", "FCF margin", "ROIC", "CCC", "Share count"],
    "Consumer / Brand": ["Organic / unit growth", "Gross margin", "Inventory / Revenue", "DSO", "DTC vs wholesale", "Geography / China", "Store productivity / traffic"],
    "Industrial": ["Orders / backlog", "Book-to-bill", "Gross margin", "Working capital", "Service mix", "Capex intensity", "Customer concentration"],
    "Software": ["ARR / recurring revenue", "NRR / churn", "Billings / deferred revenue", "Gross margin", "SBC / Revenue", "FCF margin", "Sales efficiency"],
    "Semiconductor / AI": ["Customer concentration", "Inventory", "DSO / receivables", "Gross margin", "Capacity / lead times", "Hyperscaler capex", "End-demand mix"],
    "Auto / EV": ["Deliveries / volume", "ASP / mix", "Vehicle / gross margin", "Cash burn", "Capex", "Liquidity runway", "Dilution"],
    "Financial / REIT": ["Use specialized valuation", "Capital / leverage", "Credit / asset quality", "Funding cost", "Book value / NAV", "Distribution coverage", "Rate sensitivity"],
}


def _present(text):
    return bool(str(text or "").strip())


def _finite(x):
    try:
        return x is not None and math.isfinite(float(x))
    except Exception:
        return False


def seed_bear_case(ticker: str):
    existing = {r["item_key"] for r in db.query("SELECT item_key FROM bear_case_items WHERE ticker=?", (ticker.upper(),))}
    stamp = db.now_utc()
    rows = []
    for item in BEAR_ITEMS:
        if item not in existing:
            rows.append({"ticker": ticker.upper(), "item_key": item, "updated_at": stamp})
    if rows:
        db.upsert_many("bear_case_items", rows, ["ticker", "item_key"])


def auto_gate_context(ticker: str, metrics: dict, scenarios: dict, expected_value, coverage: dict | None = None, state: dict | None = None):
    t = ticker.upper()
    research = db.load_research(t)
    fy = db.query("SELECT * FROM fundamentals WHERE ticker=? AND period_type='FY' ORDER BY fiscal_year", (t,))
    kpis = db.query("SELECT * FROM monitoring_kpis WHERE ticker=?", (t,))
    events = db.query("SELECT * FROM events WHERE ticker=?", (t,))
    bears = db.query("SELECT * FROM bear_case_items WHERE ticker=?", (t,))
    sources = db.query("SELECT * FROM source_log WHERE ticker=?", (t,))
    journal = db.query("SELECT * FROM decision_journal WHERE ticker=?", (t,))
    risk = db.risk_plan(t)
    saved_valuation = db.load_json_assumptions(t)
    variant_case = (state or {}).get("variant_case") or db.load_variant_case(t) or {}
    rec = (state or {}).get("price_reconciliation") or {}

    probs_ok = False
    downside_ok = False
    if scenarios:
        probs = sum(float(scenarios.get(s, {}).get("prob", 0) or 0) for s in ("bear", "base", "bull"))
        probs_ok = abs(probs - 1.0) <= 0.03 and all(_finite(scenarios.get(s, {}).get("fair_value")) for s in ("bear", "base", "bull"))
        downside_ok = _finite(expected_value) and _finite(scenarios.get("bear", {}).get("fair_value"))

    numeric_invalidation = any(r.get("linked_to") == "INVALIDATION" and r.get("threshold") is not None and int(r.get("locked") or 0) == 1 for r in kpis)
    bear_work = sum(1 for r in bears if _present(r.get("evidence_for")) or _present(r.get("evidence_against")))
    primary_sources = sum(1 for r in sources if r.get("source_type") in ("10-K", "10-Q", "8-K", "Proxy", "SEC XBRL", "FINRA"))
    implied_pairs=sum(1 for a,b in (
        (rec.get("forecast_revenue_cagr"),rec.get("market_implied_revenue_cagr")),
        (rec.get("forecast_terminal_net_margin"),rec.get("market_implied_net_margin")),
        (rec.get("forecast_exit_pe"),rec.get("market_implied_exit_pe")),
    ) if _finite(a) and _finite(b))
    expectations_ready = implied_pairs >= 2 or _present(research.get("market_narrative"))
    variant_ready = _present(variant_case.get("market_belief")) and _present(variant_case.get("our_belief"))

    auto = {
        "business": "PASS" if _present(research.get("business_notes")) else "INCOMPLETE",
        "five_year_financials": "PASS" if len(fy) >= 5 else "WATCH" if len(fy) >= 3 else "INCOMPLETE",
        "working_capital": "PASS" if all(_finite(metrics.get(k)) for k in ("dso", "dio", "dpo", "ccc")) else "WATCH" if any(_finite(metrics.get(k)) for k in ("dso", "dio", "ccc")) else "INCOMPLETE",
        "value_drivers": "PASS" if _present(research.get("value_drivers")) else "INCOMPLETE",
        "expectations": "PASS" if expectations_ready else "INCOMPLETE",
        "variant": "PASS" if variant_ready else "INCOMPLETE",
        "scenarios": "PASS" if saved_valuation and probs_ok else "INCOMPLETE",
        "expected_value": "PASS" if saved_valuation and downside_ok else "INCOMPLETE",
        "counter_thesis": "PASS" if bear_work >= 3 else "WATCH" if bear_work >= 1 else "INCOMPLETE",
        "catalysts": "PASS" if _present(research.get("catalysts")) or len(events) >= 1 else "INCOMPLETE",
        "invalidation": "PASS" if numeric_invalidation else "WATCH" if _present(research.get("invalidation")) else "INCOMPLETE",
        "evidence_to_add": "PASS" if _present(research.get("evidence_to_add")) else "INCOMPLETE",
        "sizing": "PASS" if risk and _finite(risk.get("invalidation_price")) and _finite(risk.get("portfolio_risk_budget")) and _finite(risk.get("max_position_cap")) else "INCOMPLETE",
        "concentration": "PASS" if _present(research.get("portfolio_risk_notes")) or _present(risk.get("correlation_notes")) else "INCOMPLETE",
        "sources": "PASS" if primary_sources >= 3 else "WATCH" if primary_sources >= 1 else "INCOMPLETE",
        "journal": "PASS" if len(journal) >= 1 else "INCOMPLETE",
    }
    return auto

def investment_gates(ticker: str, metrics: dict, scenarios: dict, expected_value, coverage: dict | None = None, state: dict | None = None):
    auto = auto_gate_context(ticker, metrics, scenarios, expected_value, coverage, state=state)
    overrides = db.gate_overrides(ticker)
    rows = []
    for key, label in GATES:
        ov = overrides.get(key, {})
        manual = ov.get("manual_status")
        status = manual if manual in ("PASS", "WATCH", "FAIL", "INCOMPLETE") else auto.get(key, "INCOMPLETE")
        rows.append({
            "key": key, "gate": label, "status": status, "auto_status": auto.get(key, "INCOMPLETE"),
            "manual": bool(manual), "notes": ov.get("notes", ""),
        })
    return rows

def gate_summary(rows: list[dict]):
    counts = {k: sum(1 for r in rows if r["status"] == k) for k in ("PASS", "WATCH", "FAIL", "INCOMPLETE")}
    if counts["FAIL"]:
        label = "PROCESS BLOCKED"
    elif counts["INCOMPLETE"] == 0 and counts["WATCH"] <= 2:
        label = "DECISION READY"
    elif counts["PASS"] >= 10:
        label = "WATCH / NEED EVIDENCE"
    else:
        label = "RESEARCH INCOMPLETE"
    return counts, label


def metric_value(metric_key: str, metrics: dict, snap: dict | None = None):
    if metric_key in metrics:
        return metrics.get(metric_key)
    snap = snap or {}
    scores = snap.get("scores") or {}
    flow = snap.get("flow") or {}
    short = snap.get("short") or {}
    mapping = {
        "price": (snap.get("bar") or {}).get("close"),
        "net_tape": scores.get("Net Tape"),
        "institutional_flow": scores.get("Institutional Flow"),
        "short_pressure": scores.get("Short Pressure"),
        "absorption": scores.get("Absorption"),
        "price_resilience": scores.get("Price Resilience"),
        "confidence": scores.get("Confidence"),
        "net_large": flow.get("net_large"),
        "net_whale": flow.get("net_whale"),
        "short_pct": short.get("short_pct"),
    }
    return mapping.get(metric_key)


def compare(value, operator: str, threshold):
    if not _finite(value) or not _finite(threshold):
        return None
    v, t = float(value), float(threshold)
    return {
        ">=": v >= t, ">": v > t, "<=": v <= t, "<": v < t, "==": abs(v - t) < 1e-12,
    }.get(operator, None)


def kpi_status(row: dict, metrics: dict, snap: dict):
    value = row.get("manual_value") if row.get("source_type") == "MANUAL" else metric_value(row.get("metric_key", ""), metrics, snap)
    passed = compare(value, row.get("operator") or ">=", row.get("threshold"))
    if passed is None:
        status = "NO DATA"
    elif passed:
        status = "PASS"
    else:
        status = "TRIGGERED" if row.get("linked_to") in ("INVALIDATION", "EXIT", "REDUCE") else "MISS"
    return value, status


def seed_default_kpis(ticker: str, company_type: str = "Generic"):
    existing = db.query("SELECT name FROM monitoring_kpis WHERE ticker=?", (ticker.upper(),))
    if existing:
        return 0
    base = [
        ("Revenue Growth", "Business", "cagr3", "%", ">=", 0.00, "THESIS"),
        ("Gross Margin", "Business", "gross_margin", "%", ">=", 0.00, "THESIS"),
        ("Operating Margin", "Business", "operating_margin", "%", ">=", 0.00, "THESIS"),
        ("FCF Margin", "Cash", "fcf_margin", "%", ">=", 0.00, "THESIS"),
        ("ROIC", "Quality", "roic", "%", ">=", 0.00, "THESIS"),
        ("Cash Conversion Cycle", "Working Capital", "ccc", "days", "<=", 150.0, "THESIS"),
        ("Diluted Share Change", "Capital Allocation", "share_change", "%", "<=", 0.03, "THESIS"),
        ("Net Tape", "Market", "net_tape", "score", ">=", 50.0, "ADD"),
        ("Absorption", "Market", "absorption", "score", ">=", 55.0, "ADD"),
        ("Price Resilience", "Market", "price_resilience", "score", ">=", 50.0, "ADD"),
    ]
    stamp = db.now_utc()
    rows = []
    for name, cat, key, unit, op, threshold, linked in base:
        rows.append({
            "ticker": ticker.upper(), "name": name, "category": cat, "metric_key": key,
            "source_type": "AUTO", "unit": unit, "operator": op, "threshold": threshold,
            "linked_to": linked, "importance": 3, "locked": 0, "notes": "Seeded by V2; set your own thesis threshold before relying on it.",
            "created_at": stamp, "updated_at": stamp,
        })
    return _insert_kpi_rows(rows)


def _insert_kpi_rows(rows):
    if not rows:
        return 0
    with db.connect() as con:
        con.executemany(
            """INSERT INTO monitoring_kpis(ticker,name,category,metric_key,source_type,unit,operator,threshold,
            linked_to,importance,locked,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            [(
                r["ticker"], r["name"], r["category"], r["metric_key"], r["source_type"], r["unit"],
                r["operator"], r["threshold"], r["linked_to"], r["importance"], r["locked"], r["notes"],
                r["created_at"], r["updated_at"]
            ) for r in rows],
        )
    return len(rows)


def next_event(ticker: str):
    today = date.today().isoformat()
    rows = db.query(
        "SELECT * FROM events WHERE ticker=? AND event_date>=? AND status!='DONE' ORDER BY event_date LIMIT 1",
        (ticker.upper(), today),
    )
    return rows[0] if rows else None


def what_changed(snapshots: list[dict]) -> list[str]:
    if len(snapshots) < 2:
        return ["Need at least two refresh snapshots before change detection becomes meaningful."]
    prev, cur = snapshots[-2], snapshots[-1]
    checks = [
        ("price", 0.02, "Price", "%"),
        ("net_tape", 7, "Net Tape", "pts"),
        ("institutional_flow", 8, "Institutional Flow", "pts"),
        ("short_pressure", 8, "Short Pressure", "pts"),
        ("absorption", 8, "Absorption", "pts"),
        ("price_resilience", 8, "Price Resilience", "pts"),
        ("confidence", 10, "Data Confidence", "pts"),
    ]
    out = []
    for key, threshold, label, kind in checks:
        a, b = prev.get(key), cur.get(key)
        if not _finite(a) or not _finite(b):
            continue
        if kind == "%":
            if float(a) != 0:
                ch = float(b) / float(a) - 1
                if abs(ch) >= threshold:
                    out.append(f"{label} {'rose' if ch > 0 else 'fell'} {abs(ch):.1%} since the prior refresh.")
        else:
            d = float(b) - float(a)
            if abs(d) >= threshold:
                out.append(f"{label} {'improved' if d > 0 else 'deteriorated'} by {abs(d):.0f} points.")
    if prev.get("regime") != cur.get("regime") and cur.get("regime"):
        out.insert(0, f"Regime changed from {prev.get('regime') or 'N/A'} to {cur.get('regime')}.")
    for key,label,fmt in (("base_value","Base Fair Value","price"),("fcf_margin","FCF margin","pct"),("ccc","Cash Conversion Cycle","num")):
        a,b=prev.get(key),cur.get(key)
        if not _finite(a) or not _finite(b):
            continue
        if key=="base_value" and float(a)!=0 and abs(float(b)/float(a)-1)>=0.05:
            ch=float(b)/float(a)-1;out.append(f"{label} {'rose' if ch>0 else 'fell'} {abs(ch):.1%}.")
        elif key=="fcf_margin" and abs(float(b)-float(a))>=0.01:
            out.append(f"{label} changed by {(float(b)-float(a))*100:+.1f} percentage points.")
        elif key=="ccc" and abs(float(b)-float(a))>=10:
            out.append(f"{label} changed by {float(b)-float(a):+.0f} days.")
    if not out:
        out.append("No material threshold-level change since the prior refresh.")
    return out[:6]
