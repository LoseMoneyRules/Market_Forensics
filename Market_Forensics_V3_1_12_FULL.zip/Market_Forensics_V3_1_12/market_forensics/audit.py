from __future__ import annotations

from datetime import date, datetime, timezone
from . import db, service, marketdata, fundamentals


def _f(x):
    try:
        return float(x)
    except Exception:
        return None


def _eq(a, b, rel_tol=1e-6, abs_tol=1.0):
    a = _f(a); b = _f(b)
    if a is None or b is None:
        return None
    return abs(a-b) <= max(abs_tol, rel_tol * max(abs(a), abs(b), 1.0))


def _status(ok, missing="NO DATA"):
    if ok is None:
        return missing
    return "PASS" if ok else "WARN"


def build_audit(ticker: str, state: dict):
    """Return transparent data checks + provenance rows for the selected ticker.

    This is intentionally conservative: PASS means an internal reconciliation/check passed,
    not that an external source can never contain an error.
    """
    t = ticker.upper()
    snap = state.get("snap") or {}
    bar = state.get("bar") or {}
    m = state.get("metrics") or {}
    scores = state.get("scores") or {}
    fund_rows = state.get("fund_rows") or []
    scenarios = state.get("scenarios") or {}
    assumptions = state.get("assumptions") or {}
    last = service.last_refresh(t) or {}

    checks = []
    def add_check(name, status, detail, source):
        checks.append({"Check": name, "Status": status, "Detail": detail, "Source": source})

    add_check(
        "Latest refresh completed",
        "PASS" if last.get("status") == "PASS" else "WARN" if last.get("status") == "PARTIAL" else "FAIL" if last.get("status") == "FAIL" else "NO DATA",
        (last.get("completed_at") or last.get("started_at") or "No refresh recorded"),
        "Local refresh log",
    )

    pc = marketdata.latest_price_check(t)
    pc_status = str(pc.get("status") or "NO DATA").upper()
    if pc_status not in {"PASS","WARN","FAIL","NO DATA"}:
        pc_status = "NO DATA" if pc_status in {"LOW DATA","DISABLED"} else "WARN"
    add_check(
        "Independent price cross-check",
        pc_status,
        pc.get("message") or ("No independent comparison stored" if not pc.get("sources") else "Price comparison stored"),
        "Market-data router / independent providers",
    )

    if bar:
        low, high = _f(bar.get("low")), _f(bar.get("high"))
        opn, close = _f(bar.get("open")), _f(bar.get("close"))
        valid = None if None in (low, high, opn, close) else (low <= min(opn, close) <= max(opn, close) <= high)
        add_check("OHLC consistency", _status(valid), f"{bar.get('trade_date')} · feed {bar.get('feed') or '—'}", "Market-data router")
    else:
        add_check("OHLC consistency", "NO DATA", "No daily bar", "Market-data router")

    # Current valuation share basis is deliberately independent from historical raw/adjusted OHLC.
    vb=str(m.get("valuation_share_basis_status") or "")
    usable=m.get("valuation_share_basis_usable")
    if vb=="VERIFIED":
        vstat="PASS"
    elif vb in ("VERIFIED FALLBACK","USER VERIFIED"):
        vstat="WARN"
    elif usable is False or vb=="DATA REVIEW":
        vstat="FAIL"
    elif vb=="UNCHECKED":
        vstat="WARN"
    else:
        vstat="NO DATA"
    vdetail=(
        f"Source {m.get('valuation_share_source') or '—'} · SEC raw {m.get('valuation_share_raw') if m.get('valuation_share_raw') is not None else '—'} "
        f"· fact {m.get('valuation_share_fact_date') or '—'} · filed {m.get('valuation_share_filed_date') or '—'} "
        f"· split factor {m.get('valuation_split_factor') if m.get('valuation_split_factor') is not None else '—'} "
        f"· normalized {m.get('valuation_shares') if m.get('valuation_shares') is not None else '—'} "
        f"· confidence {m.get('valuation_share_confidence') or '—'}"
    )
    if m.get("valuation_basis_issue"):
        vdetail += " · " + str(m.get("valuation_basis_issue"))
    add_check("Current valuation share basis",vstat,vdetail,str(m.get("corporate_action_basis") or "SEC XBRL + verified split/reverse-split ledger"))

    if last.get("market_feed") == "sqlite_cache":
        add_check("Live market-data availability", "WARN", "Latest refresh attempt used last-good SQLite bars because external market providers were unavailable.", "Market-data router / local cache")
    elif last.get("market_feed"):
        add_check("Live market-data availability", "PASS", f"Latest refresh used {last.get('market_feed')}", "Market-data router")
    else:
        add_check("Live market-data availability", "NO DATA", "No market provider recorded on the latest refresh.", "Market-data router")

    short = snap.get("short") or {}
    if short:
        sv = _f(short.get("short_volume")); sev = _f(short.get("short_exempt_volume")); tv = _f(short.get("total_reported_volume")); pct = _f(short.get("short_pct"))
        calc = ((sv or 0) + (sev or 0)) / tv if tv not in (None, 0) else None
        add_check("FINRA short-volume formula", _status(_eq(calc, pct, rel_tol=1e-8, abs_tol=1e-10)), f"Reported {pct if pct is not None else '—'} · recomputed {calc if calc is not None else '—'}", "FINRA Daily Short Sale Volume")
    else:
        add_check("FINRA short-volume formula", "NO DATA", "No FINRA row", "FINRA")

    cfo, capex, fcf = _f(m.get("cfo")), None, _f(m.get("fcf"))
    ttm = next((r for r in fund_rows if r.get("period_key") == "TTM"), {})
    capex = _f(ttm.get("capex"))
    if cfo is not None and capex is not None:
        add_check("FCF reconciliation", _status(_eq(cfo-capex, fcf, rel_tol=1e-9, abs_tol=1.0)), f"CFO - Capex = {(cfo-capex):,.0f}", "SEC XBRL + model formula")
    else:
        add_check("FCF reconciliation", "NO DATA", "CFO/Capex unavailable", "SEC XBRL")

    assets, liab, eq = _f(m.get("assets")), _f(m.get("liabilities")), _f(m.get("equity"))
    if None not in (assets, liab, eq):
        diff = assets - (liab + eq)
        tol = max(abs(assets) * 0.01, 1_000_000)
        add_check("Balance-sheet equation", "PASS" if abs(diff) <= tol else "WARN", f"Assets - (Liabilities + Equity) = {diff:,.0f}; tolerance {tol:,.0f}", "SEC XBRL")
    else:
        add_check("Balance-sheet equation", "NO DATA", "Assets/Liabilities/Equity not all available", "SEC XBRL")

    fy_count = sum(1 for r in fund_rows if r.get("period_type") == "FY" and r.get("revenue") is not None)
    add_check("Financial-history depth", "PASS" if fy_count >= 5 else "WARN" if fy_count else "NO DATA", f"{fy_count} fiscal years with revenue", "SEC XBRL")

    # Historical continuity is an investigation trigger, not an error verdict. Large jumps can be
    # acquisitions, disposals, splits or real inflections; they can also reveal unit/context mistakes.
    fys = sorted([r for r in fund_rows if r.get("period_type") == "FY" and r.get("fiscal_year")], key=lambda r: int(r["fiscal_year"]))
    continuity=[]; share_pairs_checked=0
    bars=state.get("bars") or (snap.get("bars") if isinstance(snap,dict) else None) or []
    for a,b in zip(fys,fys[1:]):
        ra,rb=_f(a.get("revenue")),_f(b.get("revenue"))
        if ra not in (None,0) and rb is not None:
            g=rb/ra-1
            if abs(g) >= .50:
                continuity.append(f"Revenue FY{a.get('fiscal_year')}→FY{b.get('fiscal_year')} {g:+.0%}")
        # Compare annual share counts only after moving both filings onto today's split basis.
        # Raw XBRL weighted-average shares can jump purely because later filings retrospectively
        # restate comparative periods after a stock split.
        sa,sb=_f(a.get("diluted_shares")),_f(b.get("diluted_shares"))
        if sa not in (None,0) and sb is not None:
            af,av=fundamentals._split_factor_at(bars,a.get("share_value_filed") or a.get("period_filed"))
            bf,bv=fundamentals._split_factor_at(bars,b.get("share_value_filed") or b.get("period_filed"))
            if av and bv:
                share_pairs_checked+=1
                g=(sb*bf)/(sa*af)-1
                if abs(g) >= .35:
                    continuity.append(f"Diluted shares (split-normalized) FY{a.get('fiscal_year')}→FY{b.get('fiscal_year')} {g:+.0%}")
    if len(fys)<2:
        cont_status="NO DATA"; cont_detail="Insufficient annual history"
    elif continuity:
        cont_status="WARN"; cont_detail="; ".join(continuity[:4])
    elif share_pairs_checked:
        cont_status="PASS"; cont_detail="No >50% revenue or >35% split-normalized diluted-share jumps"
    else:
        cont_status="PASS"; cont_detail="Revenue continuity checked; share-count continuity withheld until split basis is verified"
    add_check("Historical continuity / corporate-action review",cont_status,cont_detail,"SEC XBRL + verified market split basis")

    # Plausibility checks catch common unit/context/tagging problems without pretending to know the issuer better than the filing.
    rev = _f(m.get("revenue")); shares = _f(m.get("diluted_shares"))
    plaus = True if rev is not None and rev > 0 and shares is not None and shares > 0 else False if (rev is not None or shares is not None) else None
    margin_bad=[]
    gp=_f(m.get("gross_profit"))
    if rev is not None and gp is not None and rev > 0 and gp > rev*1.02:
        margin_bad.append(f"Gross profit exceeds revenue ({gp/rev:.1%})")
    for key,label in (("gross_margin","Gross"),("operating_margin","Operating"),("net_margin","Net"),("fcf_margin","FCF")):
        v=_f(m.get(key))
        if v is not None and (v < -1.0 or v > 1.0): margin_bad.append(f"{label} {v:.1%}")
    if margin_bad: plaus=False
    detail=(f"Revenue {rev:,.0f}; diluted shares {shares:,.0f}" if rev is not None and shares is not None else "Revenue/share data incomplete")
    if margin_bad: detail += "; implausible margin(s): " + ", ".join(margin_bad)
    add_check("Fundamental plausibility / units", _status(plaus), detail, "SEC XBRL + internal plausibility rules")

    probs = []
    for name in ("bear", "base", "bull"):
        try:
            probs.append(float(assumptions.get(name, {}).get("prob")))
        except Exception:
            pass
    add_check("Scenario probabilities", "PASS" if len(probs) == 3 and abs(sum(probs)-1.0) < 1e-6 else "WARN", f"Total probability {sum(probs):.2%}" if probs else "No probabilities", "Internal valuation model")
    fvs=[(scenarios.get(n) or {}).get("fair_value") for n in ("bear","base","bull")]
    ordered=None if any(_f(x) is None for x in fvs) else (_f(fvs[0]) <= _f(fvs[1]) <= _f(fvs[2]))
    add_check("Bear / Base / Bull ordering", _status(ordered), (" / ".join(f"{_f(x):.2f}" for x in fvs) if ordered is not None else "One or more fair values unavailable"), "Internal valuation model")

    flow_row = snap.get("flow") or {}
    qc = _f(flow_row.get("quote_coverage"))
    if qc is None:
        add_check("Trade/quote match coverage", "NO DATA", "No flow session", "Market-data router trades + quotes")
    else:
        add_check("Trade/quote match coverage", "PASS" if qc >= 0.80 else "WARN", f"{qc:.1%} of prints had a quote match", f"Market-data router · {flow_row.get('feed') or '—'}")

    feed = (flow_row.get("feed") or bar.get("feed") or "").lower()
    if feed:
        if "sip" in feed:
            add_check("Tape feed scope", "PASS", f"Consolidated/NBBO-capable tape feed: {feed}", "Market-data router")
        elif "iex" in feed:
            add_check("Tape feed scope", "WARN", "IEX is a single-exchange sample; confidence is penalized", "Market-data router")
        elif feed in ("none","sqlite_cache"):
            add_check("Tape feed scope", "NO DATA", f"No current tick/NBBO tape feed ({feed})", "Market-data router")
        else:
            add_check("Tape feed scope", "WARN", f"Non-SIP tape/data feed: {feed}; verify scope before using timing signals", "Market-data router")
    else:
        add_check("Tape feed scope", "NO DATA", "No tape feed recorded", "Market-data router")

    si = snap.get("si") or []
    if si:
        valid = all((r.get("publication_date") or "") >= (r.get("settlement_date") or "") for r in si)
        add_check("Short-interest no-lookahead dates", "PASS" if valid else "WARN", f"{len(si)} stored observations; model gates by publication date", "FINRA Short Interest / manual entry")
    else:
        add_check("Short-interest no-lookahead dates", "NO DATA", "No Short Interest observations stored", "FINRA")

    revisions=db.query("SELECT * FROM sec_revisions WHERE ticker=? ORDER BY period_end DESC,latest_filed DESC",(t,))
    material=[r for r in revisions if _f(r.get("delta_pct")) is not None and abs(_f(r.get("delta_pct"))) >= .01]
    if material:
        add_check("SEC reported-value revisions", "WARN", f"{len(material)} modeled facts changed by >=1% across filings; inspect Forensic Signals", "SEC Companyfacts across filings")
    elif revisions:
        add_check("SEC reported-value revisions", "PASS", f"{len(revisions)} small/reclassification changes detected; none >=1%", "SEC Companyfacts across filings")
    else:
        add_check("SEC reported-value revisions", "PASS", "No changed modeled facts detected across stored filing periods", "SEC Companyfacts across filings")

    # Provenance - values surfaced in the dashboard.
    prov = []
    def p(metric, value, source, tier, period, kind, method):
        prov.append({"Metric":metric,"Value":value,"Source":source,"Tier":tier,"Period / Date":period,"Type":kind,"Method / Note":method})

    if bar:
        p("Current Market Price", bar.get("close"), f"Market-data router · {bar.get('feed') or '—'}", "T2", bar.get("trade_date"), "REPORTED", "Current quote basis; not used as a historical raw-close substitute")
        if bar.get("raw_close") is not None:
            p("Raw Historical Close", bar.get("raw_close"), f"Market-data router · {bar.get('feed') or '—'}", "T2", bar.get("trade_date"), "REPORTED", "Contemporaneous raw historical quote")
        if bar.get("split_adjusted_close") is not None:
            p("Split-adjusted Historical Close", bar.get("split_adjusted_close"), f"Market-data router · {bar.get('feed') or '—'}", "T2", bar.get("trade_date"), "DERIVED/PROVIDER", "Historical quote on current split-only basis")
        if bar.get("split_factor") is not None:
            p("Historical Split Factor", bar.get("split_factor"), f"Market-data router · {bar.get('feed') or '—'}", "T2", bar.get("trade_date"), "CORPORATE ACTION", "Cumulative future split/reverse-split factor")
        p("Daily Volume", bar.get("volume"), f"Market-data router · {bar.get('feed') or '—'}", "T2", bar.get("trade_date"), "REPORTED", "Daily bar volume")
    if m.get("valuation_share_raw") is not None:
        p("SEC Share Fact Used",m.get("valuation_share_raw"),"SEC EDGAR / XBRL","T1",m.get("valuation_share_fact_date") or "—","REPORTED",f"{m.get('valuation_share_source') or '—'} · filed {m.get('valuation_share_filed_date') or '—'}")
    if m.get("valuation_shares") is not None:
        p("Normalized Current Shares",m.get("valuation_shares"),str(m.get("corporate_action_basis") or "SEC + corporate actions"),"MODEL",m.get("current_price_date") or "Current","NORMALIZED",f"SEC fact × split factor {m.get('valuation_split_factor') if m.get('valuation_split_factor') is not None else '—'} · confidence {m.get('valuation_share_confidence') or '—'}")
    ttm_end = ttm.get("period_end") or "TTM"
    for label, key in [("Revenue TTM","revenue"),("Gross Profit TTM","gross_profit"),("Operating Income TTM","operating_income"),("Net Income TTM","net_income"),("CFO TTM","cfo"),("Capex TTM","capex")]:
        val = ttm.get(key)
        if val is not None:
            p(label, val, "SEC EDGAR / XBRL", "T1", ttm_end, "RECONSTRUCTED", "Latest four fiscal quarters where XBRL contexts permit; annual fallback otherwise")
    for label, key in [("Cash","cash"),("Debt","debt"),("Receivables","receivables"),("Inventory","inventory"),("Payables","payables")]:
        if m.get(key) is not None:
            p(label, m.get(key), "SEC EDGAR / XBRL", "T1", ttm_end, "REPORTED / COMBINED", "Latest balance-sheet instant; debt may combine current + noncurrent tags")
    if m.get("fcf") is not None:
        p("Free Cash Flow", m.get("fcf"), "Internal formula from SEC XBRL", "MODEL", ttm_end, "DERIVED", "CFO - Capex")
    for label,key,formula in [
        ("Gross Margin","gross_margin","Gross Profit / Revenue"),("Operating Margin","operating_margin","Operating Income / Revenue"),
        ("FCF Margin","fcf_margin","FCF / Revenue"),("DSO","dso","365 × Receivables / TTM Revenue"),
        ("DIO","dio","365 × Inventory / TTM COGS"),("DPO","dpo","365 × Payables / TTM COGS"),
        ("Cash Conversion Cycle","ccc","DSO + DIO - DPO"),("ROIC proxy","roic","NOPAT / (Debt + Equity - Cash)"),
    ]:
        if m.get(key) is not None:
            p(label, m.get(key), "Internal formula from SEC XBRL", "MODEL", ttm_end, "DERIVED", formula)
    if short:
        p("FINRA Daily Short %", short.get("short_pct"), "FINRA Daily Short Sale Volume", "T1", short.get("trade_date"), "DERIVED", "(Short + Short Exempt) / Total reported volume")
    if flow_row:
        p("Net Large Flow", flow_row.get("net_large"), f"Market-data router · {flow_row.get('feed') or '—'}", "T2 / HEURISTIC", flow_row.get("trade_date"), "DERIVED", "Aggressive buy - sell notional using contemporaneous NBBO proxy and adaptive threshold")
        p("Net Whale Flow", flow_row.get("net_whale"), f"Market-data router · {flow_row.get('feed') or '—'}", "T2 / HEURISTIC", flow_row.get("trade_date"), "DERIVED", "P99 adaptive trade-notional bucket")
    if scenarios:
        for name in ("bear","base","bull"):
            val = scenarios.get(name, {}).get("fair_value")
            if val is not None:
                p(f"{name.title()} Fair Value", val, "Internal valuation assumptions", "MODEL", state.get("assumptions", {}).get("reviewed_at") or "Current", "MODEL", "V2.3 history-calibrated P/E + EV/Sales + FCF Yield robust blend; DCF separate cross-check")

    sec_prov = db.query("SELECT metric,xbrl_tag,unit,latest_end,latest_filed,method,source_url FROM sec_provenance WHERE ticker=? ORDER BY metric", (t,))

    counts = {"PASS":0,"WARN":0,"FAIL":0,"NO DATA":0}
    for r in checks:
        counts[r["Status"]] = counts.get(r["Status"], 0) + 1
    overall = "FAIL" if counts.get("FAIL") else "WARN" if counts.get("WARN") else "PASS" if counts.get("PASS") else "NO DATA"
    return {"checks": checks, "provenance": prov, "sec_tags": sec_prov, "counts": counts, "overall": overall}
