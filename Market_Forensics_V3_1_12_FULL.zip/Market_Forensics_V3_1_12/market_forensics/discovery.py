from __future__ import annotations

import math
import time
from datetime import datetime, timezone, timedelta
from threading import Lock, Thread

import numpy as np
import pandas as pd

from . import alpaca, db, fundamentals, sec, marketdata, valuation
from .config import load_settings

_LOCK = Lock()
_THREAD: Thread | None = None
_RECOVERED = False


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _f(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def _safe_div(a, b):
    a = _f(a); b = _f(b)
    if a is None or b in (None, 0):
        return None
    return a / b


def _clamp(x, lo=0.0, hi=100.0):
    try:
        return max(lo, min(hi, float(x)))
    except Exception:
        return 50.0


def recover_orphaned_runs() -> None:
    global _RECOVERED
    if _RECOVERED:
        return
    with _LOCK:
        if _RECOVERED:
            return
        db.execute(
            """UPDATE discovery_runs SET status='INTERRUPTED',completed_at=?,
               error_message=COALESCE(error_message,'App/server restarted before discovery completed')
               WHERE status IN ('QUEUED','RUNNING')""",
            (_now(),),
        )
        _RECOVERED = True


def latest_run() -> dict | None:
    rows = db.query("SELECT * FROM discovery_runs ORDER BY id DESC LIMIT 1")
    return rows[0] if rows else None


def is_running() -> bool:
    r = latest_run()
    return bool(r and r.get("status") in ("QUEUED", "RUNNING"))


def start_scan(force_fundamentals: bool = False) -> dict:
    """Start a market discovery scan in a daemon thread.

    The scan intentionally has two speeds: market snapshots are cheap and refreshed every run;
    SEC fundamentals are cached and only re-fetched when stale (unless force_fundamentals=True).
    """
    global _THREAD
    recover_orphaned_runs()
    with _LOCK:
        active = latest_run()
        if active and active.get("status") in ("QUEUED", "RUNNING"):
            return {"started": False, "run_id": active["id"], "already_active": True}
        with db.connect() as con:
            cur = con.execute(
                "INSERT INTO discovery_runs(created_at,status,stage) VALUES(?,'QUEUED','QUEUED')",
                (_now(),),
            )
            run_id = int(cur.lastrowid)
        _THREAD = Thread(target=_run_scan, args=(run_id, force_fundamentals), name=f"MFDiscovery-{run_id}", daemon=True)
        _THREAD.start()
        return {"started": True, "run_id": run_id, "already_active": False}


def _snapshot_fields(snap: dict):
    lt = snap.get("latestTrade") or snap.get("latest_trade") or {}
    d = snap.get("dailyBar") or snap.get("daily_bar") or {}
    p = snap.get("prevDailyBar") or snap.get("previousDailyBar") or snap.get("prev_daily_bar") or {}
    price = _f(lt.get("p")) or _f(d.get("c")) or _f(p.get("c"))
    prev_close = _f(p.get("c"))
    # Previous full-session volume is a more stable liquidity input than an intraday partial bar.
    volume = _f(p.get("v")) or _f(d.get("v"))
    daily_change = (price / prev_close - 1.0) if price is not None and prev_close not in (None, 0) else None
    dollar_volume = (prev_close * volume) if prev_close is not None and volume is not None else None
    return price, prev_close, daily_change, volume, dollar_volume


def _fy_metrics(rows: list[dict]):
    fys = sorted(
        [r for r in rows if r.get("period_type") == "FY" and r.get("fiscal_year") is not None],
        key=lambda r: int(r["fiscal_year"]),
    )
    if not fys:
        return {}, {}
    latest = fys[-1]
    prev = fys[-2] if len(fys) >= 2 else {}

    def margin(row, num):
        return _safe_div(row.get(num), row.get("revenue"))

    cur = {
        "revenue": _f(latest.get("revenue")),
        "operating_margin": margin(latest, "operating_income"),
        "net_margin": margin(latest, "net_income"),
        "fcf_margin": margin(latest, "fcf"),
        "inventory_rev": _safe_div(latest.get("inventory"), latest.get("revenue")),
        "receivables_rev": _safe_div(latest.get("receivables"), latest.get("revenue")),
    }
    prv = {
        "revenue": _f(prev.get("revenue")),
        "operating_margin": margin(prev, "operating_income"),
        "net_margin": margin(prev, "net_income"),
        "fcf_margin": margin(prev, "fcf"),
        "inventory_rev": _safe_div(prev.get("inventory"), prev.get("revenue")),
        "receivables_rev": _safe_div(prev.get("receivables"), prev.get("revenue")),
    }
    cur["revenue_growth"] = (cur["revenue"] / prv["revenue"] - 1.0) if cur["revenue"] is not None and prv["revenue"] not in (None, 0) else None
    return cur, prv


def _fundamental_payload(ticker: str, facts: dict, bars=None, current_share_fact=None, current_basis_evidence=None):
    rows = fundamentals.build_fundamentals(ticker, facts, current_share_fact=current_share_fact)
    metrics = fundamentals.metrics_from_rows(rows, bars=bars, current_basis_evidence=current_basis_evidence)
    fy, prev = _fy_metrics(rows)
    fscore, _ = fundamentals.fundamental_score(metrics) if metrics else (None, {})
    return rows, metrics, fy, prev, fscore


def _company_type_from_sic(sic) -> str:
    try:
        div = int(str(sic or "")[:2])
        if 60 <= div <= 67:
            return "Financial / REIT"
    except Exception:
        pass
    return "Generic"


def _screen_value(metrics: dict, rows: list[dict] | None, price, company_type="Generic") -> tuple[float | None, float | None, str]:
    """Cheap, automatic absolute-value cross-check for Discovery.

    This deliberately excludes saved analyst assumptions and current-price anchoring. It is a
    screening gate, not a replacement for the full Valuation Cases page. Its job is simply to
    prevent a relative-peer bargain from being promoted when our own generic intrinsic-value
    engine says the shares are already roughly at fair value.
    """
    px = _f(price)
    if not metrics or px in (None, 0) or not _f(metrics.get("valuation_shares") or metrics.get("diluted_shares")):
        return None, None, "UNAVAILABLE"
    # Absolute fair value is per-share math.  Never screen on a share denominator whose split
    # basis has not been reconciled to the quote basis; a post-filing split can otherwise create
    # a false 2x/4x/10x value gap.
    basis_usable=metrics.get("valuation_share_basis_usable")
    if basis_usable is False or (basis_usable is None and (not bool(metrics.get("share_basis_checked")) or not bool(metrics.get("valuation_share_basis_verified",metrics.get("share_basis_verified"))))):
        return None, None, "DATA REVIEW — SHARE BASIS"
    try:
        assumptions, _, _ = valuation.resolve_assumptions(None, metrics, rows or [], [], company_type)
        scenarios, _ = valuation.scenario_values(metrics, assumptions)
        base = _f((scenarios.get("base") or {}).get("fair_value"))
        if base is None or base <= 0:
            return None, None, "UNAVAILABLE"
        gap = base / px - 1.0
        if gap >= .10:
            status = "LONG ALIGNED"
        elif gap <= -.10:
            status = "SHORT ALIGNED"
        else:
            status = "FAIR VALUE / NO ABSOLUTE EDGE"
        return base, gap, status
    except Exception:
        return None, None, "UNAVAILABLE"


def _cached_metrics(row: dict) -> dict:
    """Reconstruct the minimum valuation metric set from cached Discovery fundamentals."""
    revenue = _f(row.get("revenue"))
    nm = _f(row.get("net_margin"))
    om = _f(row.get("operating_margin"))
    fm = _f(row.get("fcf_margin"))
    fcf = _f(row.get("fcf"))
    net_income = revenue * nm if revenue is not None and nm is not None else None
    if fcf is None and revenue is not None and fm is not None:
        fcf = revenue * fm
    return {
        "revenue": revenue,
        "net_income": net_income,
        "operating_income": revenue * om if revenue is not None and om is not None else None,
        "operating_margin": om,
        "net_margin": nm,
        "fcf": fcf,
        "fcf_margin": fm,
        "cash": _f(row.get("cash")),
        "debt": _f(row.get("debt")),
        "net_debt": _f(row.get("net_debt")),
        "diluted_shares": _f(row.get("diluted_shares")),
        "shares_outstanding": _f(row.get("shares_outstanding")),
        "valuation_shares": _f(row.get("valuation_shares")) or _f(row.get("shares_outstanding")) or _f(row.get("diluted_shares")),
        "valuation_share_source": row.get("valuation_share_source") or ("CURRENT_OUTSTANDING" if _f(row.get("shares_outstanding")) else "DILUTED_WA_FALLBACK"),
        "valuation_share_confidence": row.get("valuation_share_confidence") or ("HIGH" if bool(row.get("market_cap_basis_verified")) else "MEDIUM" if bool(row.get("valuation_share_basis_verified")) else "LOW"),
        "valuation_share_basis_usable": bool(row.get("valuation_share_basis_usable",row.get("valuation_share_basis_verified"))),
        "market_cap_shares": _f(row.get("valuation_shares")) or _f(row.get("shares_outstanding")) or _f(row.get("diluted_shares")),
        "market_cap_basis_usable": bool(row.get("valuation_share_basis_usable",row.get("valuation_share_basis_verified"))),
        "share_denominator_kind": "DILUTED" if _f(row.get("diluted_shares")) else "OUTSTANDING_FALLBACK",
        "share_basis_checked": bool(row.get("share_basis_checked")),
        "share_basis_verified": bool(row.get("share_basis_verified")),
        "valuation_share_basis_verified": bool(row.get("valuation_share_basis_verified", row.get("share_basis_verified"))),
        "market_cap_basis_verified": bool(row.get("market_cap_basis_verified")),
        "eps_basis_verified": bool(row.get("eps_basis_verified")),
        "diluted_eps": _f(row.get("diluted_eps_reported")) if bool(row.get("eps_basis_verified")) else None,
        "diluted_eps_sec": _f(row.get("diluted_eps_reported")) if bool(row.get("eps_basis_verified")) else None,
        "eps_basis_warning": bool(row.get("eps_basis_warning")),
        "cfo_ni": _f(row.get("cfo_ni")),
        "roic": _f(row.get("roic")),
        "recent_growth": _f(row.get("revenue_growth")),
        "cagr3": _f(row.get("revenue_growth")),
        "tax_rate": .21,
        "share_change": _f(row.get("share_change")),
    }


def _needs_fundamentals(row: dict | None, max_age_days: int, force: bool) -> bool:
    # SEC Companyfacts is not published for some exchange-traded products/fund structures.  Treat
    # a confirmed 404 as a cached N/A state rather than retrying it on every scan and calling it an
    # issuer error. Force refresh still re-checks in case SEC coverage changes later.
    if not force and row and str(row.get("screen_value_status") or "")=="SEC FUNDAMENTALS N/A" and row.get("fundamentals_updated_at"):
        try:
            dt=datetime.fromisoformat(str(row["fundamentals_updated_at"]).replace("Z","+00:00"))
            if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
            if datetime.now(timezone.utc)-dt <= timedelta(days=max_age_days):
                return False
        except Exception:
            pass
    # Cache compatibility: older caches do not preserve the selected valuation denominator and
    # therefore cannot produce a trustworthy absolute fair-value gate. Refresh them once.
    if force or not row or not row.get("fundamentals_updated_at") or row.get("revenue") is None:
        return True
    if str(row.get("screen_model_version") or "") != "3.1.8":
        return True
    if int(row.get("share_basis_checked") or 0) == 0:
        return True
    try:
        dt = datetime.fromisoformat(str(row["fundamentals_updated_at"]).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return datetime.now(timezone.utc) - dt > timedelta(days=max_age_days)
    except Exception:
        return True


def _run_scan(run_id: int, force_fundamentals: bool) -> None:
    settings = load_settings()
    ua = str(settings.get("sec_user_agent") or "").strip()
    if not ua or "@" not in ua:
        db.execute(
            "UPDATE discovery_runs SET status='FAIL',stage='SEC CONFIG',completed_at=?,error_message=? WHERE id=?",
            (_now(), "SEC User-Agent with contact email is required for Discovery.", run_id),
        )
        return
    if not settings.get("alpaca_feed"):
        settings["alpaca_feed"] = "auto"

    min_price = float(settings.get("discovery_min_price", 3.0) or 3.0)
    min_dv = float(settings.get("discovery_min_dollar_volume", 5_000_000) or 5_000_000)
    max_symbols = int(settings.get("discovery_max_symbols", 600) or 600)
    fund_age = int(settings.get("discovery_fundamental_age_days", 7) or 7)

    try:
        db.execute("UPDATE discovery_runs SET status='RUNNING',started_at=?,stage='ASSET UNIVERSE' WHERE id=?", (_now(), run_id))
        assets, universe_feed = marketdata.get_active_us_assets(ua)
        # Common listed US venues. OTC and exotic classes are deliberately excluded from discovery by default.
        allowed_exchanges = {"NASDAQ", "NYSE", "AMEX", "ARCA", "NYSEARCA", "NYSE ARCA", "NYSE AMERICAN", "BATS", "CBOE", "CBOE BZX"}
        assets = [a for a in assets if a.get("tradable") and str(a.get("exchange") or "").upper() in allowed_exchanges]
        # SEC CIK mapping excludes many funds/non-operating instruments naturally.
        tmap = sec.ticker_map(ua)
        assets = [a for a in assets if a["ticker"] in tmap]
        db.execute("UPDATE discovery_runs SET universe_total=?,stage='MARKET SNAPSHOTS' WHERE id=?", (len(assets), run_id))

        snaps, feed = marketdata.get_snapshots([a["ticker"] for a in assets], settings.get("alpaca_feed", "auto"))
        ranked = []
        for a in assets:
            snap = snaps.get(a["ticker"], {})
            price, prev_close, chg, vol, dv = _snapshot_fields(snap)
            if price is None or price < min_price or dv is None or dv < min_dv:
                continue
            ranked.append({**a, "price": price, "prev_close": prev_close, "daily_change": chg, "volume": vol, "dollar_volume": dv})
        ranked.sort(key=lambda x: x.get("dollar_volume") or 0, reverse=True)
        ranked = ranked[:max_symbols]
        db.execute("UPDATE discovery_runs SET market_rows=?,stage='SEC FUNDAMENTALS' WHERE id=?", (len(ranked), run_id))

        # Upsert market metadata first so a partial run still leaves a useful, auditable footprint.
        stamp = _now()
        for a in ranked:
            mapping = tmap.get(a["ticker"], {})
            existing = db.discovery_row(a["ticker"]) or {}
            row = dict(existing)
            row.update({
                "ticker": a["ticker"], "cik": mapping.get("cik"), "company_name": mapping.get("name") or a.get("name"),
                "exchange": a.get("exchange"), "tradable": 1 if a.get("tradable") else 0,
                "shortable": 1 if a.get("shortable") else 0, "borrow_status": a.get("borrow_status") or "",
                "has_options": 1 if a.get("has_options") else 0, "price": a.get("price"), "prev_close": a.get("prev_close"),
                "daily_change": a.get("daily_change"), "volume": a.get("volume"), "dollar_volume": a.get("dollar_volume"),
                "market_updated_at": stamp,
            })
            # SQLite upsert helper requires a uniform column set; full schema columns are completed later.
            cols = [r["name"] for r in db.query("PRAGMA table_info(discovery_universe)")]
            full = {c: row.get(c) for c in cols}
            db.upsert_many("discovery_universe", [full], ["ticker"])

        completed_fund = 0
        fundamental_errors = []
        for idx, a in enumerate(ranked, start=1):
            t = a["ticker"]
            db.execute("UPDATE discovery_runs SET current_ticker=?,stage=? WHERE id=?", (t, f"SEC FUNDAMENTALS {idx}/{len(ranked)}", run_id))
            existing = db.discovery_row(t)
            if _needs_fundamentals(existing, fund_age, force_fundamentals):
                try:
                    facts = sec.get_companyfacts(tmap[t]["cik"], ua)
                    time.sleep(0.14)  # keep combined SEC request rate comfortably below the published ceiling
                    # Discovery fair value is per-share math, so it must use the same verified
                    # split/share basis as the full research engine.  A shorter request is enough
                    # for current filing dates while keeping the market scan practical.
                    try:
                        basis_bars, _basis_feed = marketdata.get_daily_bars(t, max(1100, int(settings.get("daily_lookback_days",500) or 500)), settings.get("alpaca_feed", "auto"))
                    except Exception:
                        basis_bars=[]
                    # Companyfacts may omit current dimensional share-class facts. Only when its
                    # current-share fact is missing/stale do we spend the extra SEC request on the
                    # latest Inline XBRL cover page; this keeps broad scans practical.
                    cover_share_fact=None
                    try:
                        so0=sec.latest_unambiguous_instant(facts,fundamentals.TAGS["shares_outstanding"])
                        px_date=str((basis_bars[-1] if basis_bars else {}).get("date") or (basis_bars[-1] if basis_bars else {}).get("trade_date") or "")[:10]
                        stale=True
                        if so0 and so0.get("end") and px_date:
                            stale=(date.fromisoformat(px_date)-date.fromisoformat(str(so0.get("end"))[:10])).days>550
                        elif so0 and so0.get("end"):
                            stale=False
                        if stale:
                            cover_share_fact=sec.latest_cover_page_shares(t,ua,limit=2,cik=tmap[t]["cik"])
                            time.sleep(0.14)
                    except Exception:
                        cover_share_fact=None

                    # Build once with the best current-share fact, then verify only the share-fact
                    # -> current-price corporate-action interval (not the historical OHLC basis).
                    pre_rows=fundamentals.build_fundamentals(t,facts,current_share_fact=cover_share_fact)
                    ttm0=next((r for r in pre_rows if r.get("period_key")=="TTM"),{})
                    px_date=str((basis_bars[-1] if basis_bars else {}).get("date") or (basis_bars[-1] if basis_bars else {}).get("trade_date") or "")[:10] or None
                    anchor0=fundamentals.current_valuation_share_anchor(ttm0,px_date)
                    basis_ev=marketdata.current_split_basis_evidence(t,anchor0,px_date) if anchor0 and px_date else None
                    metrics=fundamentals.metrics_from_rows(pre_rows,bars=basis_bars,current_basis_evidence=basis_ev)
                    rows=pre_rows; fy, prev=_fy_metrics(rows); fscore,_=fundamentals.fundamental_score(metrics) if metrics else (None,{})
                    # Try submissions metadata for SIC. One extra SEC call only when fundamentals are refreshed.
                    try:
                        sub = sec.get_submissions(tmap[t]["cik"], ua)
                        time.sleep(0.14)
                        sic = str(sub.get("sic") or "")
                        sic_desc = sub.get("sicDescription") or ""
                    except Exception:
                        sic = (existing or {}).get("sic") or ""
                        sic_desc = (existing or {}).get("sic_description") or ""

                    price = _f(a.get("price"))
                    shares = _f(metrics.get("valuation_shares") or metrics.get("diluted_shares"))
                    mcap_shares = _f(metrics.get("market_cap_shares") or shares)
                    mult = valuation.current_multiples(metrics, price)
                    market_cap = _f(mult.get("market_cap"))
                    ev = market_cap + (metrics.get("debt") or 0) - (metrics.get("cash") or 0) if market_cap is not None else None
                    pe = _f(mult.get("pe")); ev_sales = _f(mult.get("ev_sales")); fcf_yield = _f(mult.get("fcf_yield"))
                    screen_base, screen_gap, screen_status = _screen_value(metrics, rows, price, _company_type_from_sic(sic))
                    update = {
                        "sic": sic, "sic_description": sic_desc,
                        "market_cap": market_cap, "enterprise_value": ev,
                        "revenue": metrics.get("revenue"), "revenue_prev": prev.get("revenue"),
                        "revenue_growth": fy.get("revenue_growth") if fy.get("revenue_growth") is not None else metrics.get("recent_growth"),
                        "revenue_growth_prev": None,
                        "operating_margin": metrics.get("operating_margin"), "operating_margin_prev": prev.get("operating_margin"),
                        "net_margin": metrics.get("net_margin"), "net_margin_prev": prev.get("net_margin"),
                        "fcf": metrics.get("fcf"), "fcf_margin": metrics.get("fcf_margin"), "fcf_margin_prev": prev.get("fcf_margin"),
                        "roic": metrics.get("roic"), "cfo_ni": metrics.get("cfo_ni"), "cash": metrics.get("cash"), "debt": metrics.get("debt"),
                        "net_debt": metrics.get("net_debt"), "diluted_shares": metrics.get("diluted_shares"),
                        "shares_outstanding": metrics.get("shares_outstanding"), "shares_outstanding_date": metrics.get("shares_outstanding_date"), "shares_outstanding_filed": metrics.get("shares_outstanding_filed"),
                        "diluted_shares_date": metrics.get("diluted_shares_date"), "diluted_shares_filed": metrics.get("diluted_shares_filed"),
                        "valuation_shares": metrics.get("valuation_shares"), "valuation_share_source": metrics.get("valuation_share_source"), "valuation_share_confidence": metrics.get("valuation_share_confidence"), "valuation_share_basis_usable": 1 if metrics.get("valuation_share_basis_usable") else 0,
                        # Store the normalized SEC diluted EPS only when its split basis is proven.
                        "diluted_eps_reported": metrics.get("diluted_eps_sec") if metrics.get("eps_basis_verified") else None,
                        "share_basis_checked": 1 if metrics.get("share_basis_checked") else 0,
                        "share_basis_verified": 1 if metrics.get("share_basis_verified") else 0,
                        "valuation_share_basis_verified": 1 if metrics.get("valuation_share_basis_verified") else 0,
                        "market_cap_basis_verified": 1 if metrics.get("market_cap_basis_verified") else 0,
                        "eps_basis_verified": 1 if metrics.get("eps_basis_verified") else 0,
                        "eps_basis_warning": 1 if metrics.get("eps_basis_warning") else 0,
                        "share_change": metrics.get("share_change"),
                        "inventory_rev": _safe_div(metrics.get("inventory"), metrics.get("revenue")), "inventory_rev_prev": prev.get("inventory_rev"),
                        "receivables_rev": _safe_div(metrics.get("receivables"), metrics.get("revenue")), "receivables_rev_prev": prev.get("receivables_rev"),
                        "pe": pe, "ev_sales": ev_sales, "fcf_yield": fcf_yield,
                        "screen_base_value": screen_base, "screen_value_gap": screen_gap, "screen_value_status": screen_status,
                        "screen_model_version": "3.1.8",
                        # Store the transparent accounting score before cross-sectional scoring.
                        "quality_score": ((float(fscore) - 1.0) / 4.0 * 100.0) if fscore is not None else None,
                        "fundamentals_updated_at": _now(),
                    }
                    existing2 = db.discovery_row(t) or {}
                    merged = {**existing2, **update}
                    cols = [r["name"] for r in db.query("PRAGMA table_info(discovery_universe)")]
                    db.upsert_many("discovery_universe", [{c: merged.get(c) for c in cols}], ["ticker"])
                    completed_fund += 1
                except Exception as exc:
                    _msg=str(exc)
                    _issuer_meta={"company_name":(tmap.get(t) or {}).get("name") or "","name":(tmap.get(t) or {}).get("name") or "","sic":"","sic_description":""}
                    if isinstance(exc, sec.SECError) and "SEC HTTP 404" in _msg:
                        try:
                            _sub=sec.get_submissions((tmap.get(t) or {}).get("cik"),ua)
                            _issuer_meta.update({"company_name":_sub.get("name") or _issuer_meta.get("company_name"),"sic":str(_sub.get("sic") or ""),"sic_description":_sub.get("sicDescription") or ""})
                            time.sleep(0.14)
                        except Exception:
                            pass
                    if isinstance(exc, sec.SECError) and "SEC HTTP 404" in _msg and sec.companyfacts_not_applicable(_issuer_meta):
                        # Expected for some ETFs/fund structures (e.g. SPY/DIA/MDY): market data is
                        # still perfectly usable, but operating-company Companyfacts is not a valid
                        # source. Cache the N/A state and do not surface a false issuer error.
                        exrow=db.discovery_row(t) or {}
                        exrow.update({"screen_value_status":"SEC FUNDAMENTALS N/A","screen_model_version":"3.1.8",
                                      "fundamentals_updated_at":_now()})
                        cols=[r["name"] for r in db.query("PRAGMA table_info(discovery_universe)")]
                        db.upsert_many("discovery_universe",[{c:exrow.get(c) for c in cols}],["ticker"])
                    else:
                        # Discovery is a screening layer: one issuer with unusual XBRL must not kill
                        # the market scan, but genuine refresh failures remain visible for diagnosis.
                        fundamental_errors.append(f"{t}: {_msg[:180]}")
                time.sleep(0.04)  # small inter-issuer cushion after per-request SEC pacing above
            else:
                # Price-dependent valuation ratios must still be recomputed from cached fundamentals.
                ex = existing or {}
                price = _f(a.get("price")); cached_metrics = _cached_metrics(ex)
                mult = valuation.current_multiples(cached_metrics, price)
                mcap = _f(mult.get("market_cap"))
                ev = mcap + (ex.get("debt") or 0) - (ex.get("cash") or 0) if mcap is not None else None
                screen_base, screen_gap, screen_status = _screen_value(cached_metrics, [], price, _company_type_from_sic(ex.get("sic")))
                db.execute(
                    """UPDATE discovery_universe SET market_cap=?,enterprise_value=?,pe=?,ev_sales=?,fcf_yield=?,
                       screen_base_value=?,screen_value_gap=?,screen_value_status=? WHERE ticker=?""",
                    (mcap, ev, mult.get("pe"), mult.get("ev_sales"), mult.get("fcf_yield"),
                     screen_base, screen_gap, screen_status, t),
                )
            db.execute("UPDATE discovery_runs SET fundamentals_rows=? WHERE id=?", (completed_fund, run_id))

        db.execute("UPDATE discovery_runs SET stage='SCORING',current_ticker=NULL WHERE id=?", (run_id,))
        scored = score_universe()
        warning = None
        if fundamental_errors:
            warning = f"{len(fundamental_errors)} issuer fundamental refresh error(s). Sample: " + " | ".join(fundamental_errors[:5])
        db.execute(
            "UPDATE discovery_runs SET status='PASS',stage='COMPLETE',scored_rows=?,completed_at=?,error_message=? WHERE id=?",
            (scored, _now(), warning, run_id),
        )
    except Exception as exc:
        db.execute(
            "UPDATE discovery_runs SET status='FAIL',stage='FAILED',completed_at=?,error_message=? WHERE id=?",
            (_now(), str(exc)[:1500], run_id),
        )


def _pct_rank(series: pd.Series, higher_is_better=True) -> pd.Series:
    x = pd.to_numeric(series, errors="coerce")
    rank = x.rank(pct=True, method="average") * 100.0
    return rank if higher_is_better else 100.0 - rank


def _blend_group_rank(df: pd.DataFrame, col: str, higher_is_better=True) -> pd.Series:
    global_rank = _pct_rank(df[col], higher_is_better)
    group_rank = pd.Series(index=df.index, dtype=float)
    # Four-digit SIC is ideal; use 2-digit division when the exact industry is too small.
    sic4 = df["sic"].fillna("").astype(str)
    keys = sic4.where(sic4.str.len() >= 4, "")
    for _, idx in df.groupby(keys).groups.items():
        if len(idx) >= 5 and str(keys.loc[list(idx)[0]]):
            group_rank.loc[idx] = _pct_rank(df.loc[idx, col], higher_is_better)
    div = sic4.str[:2]
    for _, idx in df[group_rank.isna()].groupby(div).groups.items():
        if len(idx) >= 5 and str(div.loc[list(idx)[0]]):
            group_rank.loc[idx] = _pct_rank(df.loc[idx, col], higher_is_better)
    group_rank = group_rank.fillna(global_rank)
    return 0.70 * group_rank + 0.30 * global_rank


def score_universe() -> int:
    rows = db.query("SELECT * FROM discovery_universe WHERE price IS NOT NULL")
    if not rows:
        return 0
    df = pd.DataFrame(rows)
    # Require enough operating evidence to call something an investment candidate.
    for c in ["quality_score", "revenue_growth", "operating_margin", "fcf_margin", "roic", "cfo_ni", "share_change",
              "inventory_rev", "inventory_rev_prev", "receivables_rev", "receivables_rev_prev", "pe", "ev_sales", "fcf_yield",
              "screen_base_value", "screen_value_gap"]:
        if c not in df:
            df[c] = np.nan

    ey = np.where(pd.to_numeric(df["pe"], errors="coerce") > 0, 1.0 / pd.to_numeric(df["pe"], errors="coerce"), np.nan)
    df["earnings_yield"] = ey
    cheap_parts = pd.DataFrame(index=df.index)
    cheap_parts["earnings"] = _blend_group_rank(df.assign(earnings_yield=ey), "earnings_yield", True)
    cheap_parts["fcf"] = _blend_group_rank(df, "fcf_yield", True)
    cheap_parts["sales"] = _blend_group_rank(df, "ev_sales", False)
    df["cheap_score"] = cheap_parts.median(axis=1, skipna=True)
    df["expensive_score"] = 100.0 - df["cheap_score"]

    # Quality blends the existing transparent fundamental score with cross-sectional return/cash evidence.
    roic_rank = _blend_group_rank(df, "roic", True)
    fm_rank = _blend_group_rank(df, "fcf_margin", True)
    base_quality = pd.to_numeric(df["quality_score"], errors="coerce")
    df["quality_x"] = pd.concat([base_quality, roic_rank, fm_rank], axis=1).mean(axis=1, skipna=True)

    rg = pd.to_numeric(df["revenue_growth"], errors="coerce").clip(-0.30, 0.30)
    om = pd.to_numeric(df["operating_margin"], errors="coerce")
    omp = pd.to_numeric(df["operating_margin_prev"], errors="coerce")
    fm = pd.to_numeric(df["fcf_margin"], errors="coerce")
    fmp = pd.to_numeric(df["fcf_margin_prev"], errors="coerce")
    trend = 50 + rg.fillna(0) * 120 + (om - omp).fillna(0).clip(-0.15, 0.15) * 180 + (fm - fmp).fillna(0).clip(-0.15, 0.15) * 180
    df["trend_score"] = trend.clip(0, 100)

    cfo_ni = pd.to_numeric(df["cfo_ni"], errors="coerce")
    share = pd.to_numeric(df["share_change"], errors="coerce")
    inv_delta = pd.to_numeric(df["inventory_rev"], errors="coerce") - pd.to_numeric(df["inventory_rev_prev"], errors="coerce")
    ar_delta = pd.to_numeric(df["receivables_rev"], errors="coerce") - pd.to_numeric(df["receivables_rev_prev"], errors="coerce")
    forensic = pd.Series(65.0, index=df.index)
    forensic += np.where(cfo_ni >= 0.9, 10, np.where(cfo_ni < 0.6, -20, 0))
    forensic += np.where(share <= 0, 5, np.where(share > 0.05, -15, 0))
    forensic += np.where(inv_delta <= 0, 5, np.where(inv_delta > 0.05, -15, 0))
    forensic += np.where(ar_delta <= 0, 5, np.where(ar_delta > 0.04, -15, 0))
    df["forensic_score"] = forensic.clip(0, 100)

    # Confidence is about evidence completeness, not price-direction conviction.
    evidence_cols = ["revenue", "operating_margin", "fcf_margin", "diluted_shares", "quality_x", "cheap_score", "screen_value_gap"]
    present = sum(pd.to_numeric(df[c], errors="coerce").notna().astype(int) for c in evidence_cols)
    df["confidence"] = (35 + present / len(evidence_cols) * 65).clip(0, 100)

    gap = pd.to_numeric(df["screen_value_gap"], errors="coerce")
    # Zero gap is neutral (50); +/-25% reaches the directional extreme. Missing values stay neutral
    # in the score but are blocked by classification until the absolute-value gate is available.
    df["absolute_long_score"] = (50.0 + gap.fillna(0) * 200.0).clip(0, 100)
    df["absolute_short_score"] = (50.0 - gap.fillna(0) * 200.0).clip(0, 100)

    df["long_score"] = (0.24 * df["cheap_score"].fillna(50) + 0.22 * df["absolute_long_score"] +
                        0.24 * df["quality_x"].fillna(50) + 0.18 * df["trend_score"].fillna(50) +
                        0.12 * df["forensic_score"].fillna(50))
    df["short_score"] = (0.24 * df["expensive_score"].fillna(50) + 0.22 * df["absolute_short_score"] +
                         0.22 * (100-df["quality_x"].fillna(50)) + 0.20 * (100-df["trend_score"].fillna(50)) +
                         0.12 * (100-df["forensic_score"].fillna(50)))

    def classify(r):
        conf = _f(r.get("confidence")) or 0
        q = _f(r.get("quality_x")) or 50
        tr = _f(r.get("trend_score")) or 50
        fh = _f(r.get("forensic_score")) or 50
        cheap = _f(r.get("cheap_score")) or 50
        exp = _f(r.get("expensive_score")) or 50
        ls = _f(r.get("long_score")) or 50
        ss = _f(r.get("short_score")) or 50
        vg = _f(r.get("screen_value_gap"))
        if conf < 55:
            return "DATA REVIEW", 5, "Insufficient comparable fundamentals"
        if vg is None:
            return "DATA REVIEW", 5, "Absolute screening fair value unavailable; relative dislocation not promoted"
        if abs(vg) < .10:
            return "NO EDGE", 5, "Relative valuation signal exists, but automatic absolute fair value is within ±10% of price"
        if cheap >= 72 and (q < 45 or tr < 40):
            if vg <= -.08:
                return "VALUE TRAP", 2 if cheap >= 82 else 3, "Cheap versus peers, but weak economics and absolute valuation still shows downside"
            return "NO EDGE", 5, "Looks cheap versus peers, but automatic absolute valuation does not show downside or sufficient upside"
        if fh < 35:
            if vg <= -.08:
                return "FORENSIC DIVERGENCE", 2, "Forensic evidence conflicts with headline economics and absolute valuation shows downside"
            return "FORENSIC REVIEW", 4, "Forensic evidence conflicts with headline economics, but absolute valuation does not support a directional short"
        if ls >= 75 and q >= 67 and cheap >= 65 and vg >= .12:
            return "QUALITY AT DISCOUNT", 1, "Strong business quality + cheap peer valuation + at least 12% automatic absolute upside"
        if ls >= 70 and tr >= 70 and cheap >= 55 and vg >= .10:
            return "FUNDAMENTAL INFLECTION", 1 if ls >= 80 else 2, "Operating trend improving with at least 10% automatic absolute upside"
        if ss >= 75 and exp >= 65 and (q <= 55 or tr <= 45) and vg <= -.12:
            return "POTENTIAL SHORT", 1, "Demanding peer valuation + weak economics + at least 12% automatic absolute downside"
        if exp >= 78 and q >= 70:
            return "RICH / STRONG BUSINESS", 3, "Excellent business, but valuation already demands a lot"
        if max(ls, ss) >= 68 and abs(ls-ss) >= 8:
            if ls > ss and vg >= .10:
                return "LONG DISLOCATION", 2, "Relative dislocation is confirmed by at least 10% automatic absolute upside"
            if ss > ls and vg <= -.10:
                return "SHORT DISLOCATION", 2, "Relative dislocation is confirmed by at least 10% automatic absolute downside"
            return "NO EDGE", 5, "Relative dislocation and absolute fair-value direction are not aligned"
        return "NO EDGE", 5, "No material long/short dislocation"

    updates = []
    for idx, r in df.iterrows():
        lens, pri, reason = classify(r)
        updates.append({
            "ticker": r["ticker"], "quality_score": _f(r.get("quality_x")), "trend_score": _f(r.get("trend_score")),
            "forensic_score": _f(r.get("forensic_score")), "valuation_score": _f(r.get("cheap_score")),
            "long_score": _f(r.get("long_score")), "short_score": _f(r.get("short_score")),
            "confidence": _f(r.get("confidence")), "lens": lens, "system_priority": pri,
            "reason": reason, "scored_at": _now(),
        })
    with db.connect() as con:
        for u in updates:
            con.execute(
                """UPDATE discovery_universe SET quality_score=?,trend_score=?,forensic_score=?,valuation_score=?,
                   long_score=?,short_score=?,confidence=?,lens=?,system_priority=?,reason=?,scored_at=? WHERE ticker=?""",
                (u["quality_score"],u["trend_score"],u["forensic_score"],u["valuation_score"],u["long_score"],u["short_score"],
                 u["confidence"],u["lens"],u["system_priority"],u["reason"],u["scored_at"],u["ticker"]),
            )
    return len(updates)


def interesting_rows(limit=50, side="BOTH"):
    rows = db.query("SELECT * FROM discovery_universe WHERE lens!='NO EDGE' ORDER BY system_priority ASC, MAX(long_score,short_score) DESC, dollar_volume DESC LIMIT ?", (int(limit),))
    if side == "LONG":
        rows = [r for r in rows if (_f(r.get("long_score")) or 0) > (_f(r.get("short_score")) or 0)]
    elif side == "SHORT":
        rows = [r for r in rows if (_f(r.get("short_score")) or 0) > (_f(r.get("long_score")) or 0)]
    return rows[:limit]


def sync_ticker_from_local(ticker: str) -> None:
    """Keep a fully refreshed Coverage ticker usable by Discovery/Triangulation even before a market-wide scan."""
    t=ticker.upper()
    bars=db.query("SELECT * FROM daily_bars WHERE ticker=? ORDER BY trade_date",(t,))
    fund=db.query("SELECT * FROM fundamentals WHERE ticker=? ORDER BY fiscal_year",(t,))
    meta_rows=db.query("SELECT * FROM company_meta WHERE ticker=?",(t,))
    if not bars or not fund:
        return
    bar=bars[-1]; prevbar=bars[-2] if len(bars)>1 else {}
    metrics=fundamentals.metrics_from_rows(fund,bar.get("close"),bars=bars)
    fy,prev=_fy_metrics(fund)
    fscore,_=fundamentals.fundamental_score(metrics) if metrics else (None,{})
    existing=db.discovery_row(t) or {}
    meta=meta_rows[0] if meta_rows else {}
    price=_f(bar.get("close")); shares=_f(metrics.get("valuation_shares") or metrics.get("diluted_shares"))
    mult=valuation.current_multiples(metrics,price); mcap=_f(mult.get("market_cap"))
    ev=mcap+(metrics.get("debt") or 0)-(metrics.get("cash") or 0) if mcap is not None else None
    screen_base,screen_gap,screen_status=_screen_value(metrics,fund,price,_company_type_from_sic(meta.get("sic")))
    row={**existing,
        "ticker":t,"cik":meta.get("cik"),"company_name":meta.get("company_name") or t,"exchange":meta.get("exchange"),
        "sic":meta.get("sic"),"sic_description":meta.get("sic_description"),"tradable":1,
        "price":price,"prev_close":prevbar.get("close"),"daily_change":price/prevbar.get("close")-1 if price and prevbar.get("close") else None,
        "volume":prevbar.get("volume") or bar.get("volume"),"dollar_volume":((prevbar.get("close") or price)*(prevbar.get("volume") or bar.get("volume"))) if (prevbar.get("close") or price) and (prevbar.get("volume") or bar.get("volume")) else None,
        "market_cap":mcap,"enterprise_value":ev,"revenue":metrics.get("revenue"),"revenue_prev":prev.get("revenue"),
        "revenue_growth":fy.get("revenue_growth") if fy.get("revenue_growth") is not None else metrics.get("recent_growth"),
        "operating_margin":metrics.get("operating_margin"),"operating_margin_prev":prev.get("operating_margin"),
        "net_margin":metrics.get("net_margin"),"net_margin_prev":prev.get("net_margin"),"fcf":metrics.get("fcf"),
        "fcf_margin":metrics.get("fcf_margin"),"fcf_margin_prev":prev.get("fcf_margin"),"roic":metrics.get("roic"),"cfo_ni":metrics.get("cfo_ni"),
        "cash":metrics.get("cash"),"debt":metrics.get("debt"),"net_debt":metrics.get("net_debt"),"diluted_shares":metrics.get("diluted_shares"),
        "shares_outstanding":metrics.get("shares_outstanding"),"shares_outstanding_date":metrics.get("shares_outstanding_date"),"shares_outstanding_filed":metrics.get("shares_outstanding_filed"),
        "diluted_shares_date":metrics.get("diluted_shares_date"),"diluted_shares_filed":metrics.get("diluted_shares_filed"),
        "valuation_shares":metrics.get("valuation_shares"),"valuation_share_source":metrics.get("valuation_share_source"),"valuation_share_confidence":metrics.get("valuation_share_confidence"),"valuation_share_basis_usable":1 if metrics.get("valuation_share_basis_usable") else 0,
        "diluted_eps_reported":metrics.get("diluted_eps_sec") if metrics.get("eps_basis_verified") else None,
        "share_basis_checked":1 if metrics.get("share_basis_checked") else 0,
        "share_basis_verified":1 if metrics.get("share_basis_verified") else 0,
        "valuation_share_basis_verified":1 if metrics.get("valuation_share_basis_verified") else 0,
        "market_cap_basis_verified":1 if metrics.get("market_cap_basis_verified") else 0,
        "eps_basis_verified":1 if metrics.get("eps_basis_verified") else 0,
        "eps_basis_warning":1 if metrics.get("eps_basis_warning") else 0,
        "share_change":metrics.get("share_change"),
        "inventory_rev":_safe_div(metrics.get("inventory"),metrics.get("revenue")),"inventory_rev_prev":prev.get("inventory_rev"),
        "receivables_rev":_safe_div(metrics.get("receivables"),metrics.get("revenue")),"receivables_rev_prev":prev.get("receivables_rev"),
        "pe":mult.get("pe"),"ev_sales":mult.get("ev_sales"),"fcf_yield":mult.get("fcf_yield"),
        "screen_base_value":screen_base,"screen_value_gap":screen_gap,"screen_value_status":screen_status,"screen_model_version":"3.1.8",
        "quality_score":((float(fscore)-1)/4*100) if fscore is not None else existing.get("quality_score"),
        "fundamentals_updated_at":_now(),"market_updated_at":_now()}
    cols=[r["name"] for r in db.query("PRAGMA table_info(discovery_universe)")]
    db.upsert_many("discovery_universe",[{c:row.get(c) for c in cols}],["ticker"])
    score_universe()
