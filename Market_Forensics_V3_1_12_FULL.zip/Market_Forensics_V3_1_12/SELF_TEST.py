from __future__ import annotations

import ast
import json
import os
import py_compile
import shutil
import sys
import tempfile
from datetime import date, timedelta, datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REAL_LOCALAPPDATA = os.environ.get("LOCALAPPDATA")
TEST_LOCAL = Path(tempfile.mkdtemp(prefix="MarketForensicsV311_Test_"))
os.environ["LOCALAPPDATA"] = str(TEST_LOCAL)
sys.path.insert(0, str(ROOT))

checks = []

def check(name, fn):
    try:
        fn()
        print(f"[PASS] {name}")
        checks.append(True)
    except Exception as e:
        print(f"[FAIL] {name}")
        print(f"       {type(e).__name__}: {e}")
        checks.append(False)


def dependencies():
    import streamlit, pandas, numpy, requests, plotly, docx, reportlab, matplotlib
    assert tuple(int(x) for x in streamlit.__version__.split(".")[:2]) >= (1, 63)


def source_regression():
    files = [ROOT / "app.py", *sorted((ROOT / "pages").glob("*.py")), *sorted((ROOT / "market_forensics").glob("*.py"))]
    forbidden = ["use_" + "container_width", "datetime." + "utcnow()", ".style." + "format("]
    for p in files:
        text = p.read_text(encoding="utf-8")
        ast.parse(text, filename=str(p))
        for token in forbidden:
            assert token not in text, f"deprecated / unsafe token {token} in {p.name}"
        py_compile.compile(str(p), doraise=True)
        tree = ast.parse(text, filename=str(p))
        for node in ast.walk(tree):
            if isinstance(node, ast.Expr) and isinstance(node.value, ast.IfExp):
                for branch in (node.value.body, node.value.orelse):
                    if isinstance(branch, ast.Call) and isinstance(branch.func, ast.Attribute):
                        owner = branch.func.value
                        assert not (isinstance(owner, ast.Name) and owner.id == "st"), \
                            f"bare conditional Streamlit expression in {p.name}:{getattr(node, 'lineno', '?')}"
    app = (ROOT / "app.py").read_text(encoding="utf-8")
    v3 = (ROOT / "market_forensics" / "v3.py").read_text(encoding="utf-8")
    ws = (ROOT / "market_forensics" / "workstation.py").read_text(encoding="utf-8")
    disc = (ROOT / "market_forensics" / "discovery.py").read_text(encoding="utf-8")
    tri = (ROOT / "market_forensics" / "triangulation.py").read_text(encoding="utf-8")
    dbs = (ROOT / "market_forensics" / "db.py").read_text(encoding="utf-8")

    assert 'initial_sidebar_state="expanded"' in app
    assert 'st.navigation(' in app and 'position="hidden"' in app
    assert 'render_sidebar(nav_items, pg)' in app
    assert 'st.page_link(' in v3 and 'st.radio(' not in v3
    assert 'Discover' in app and 'Decision Queue' in app and 'Decide' in app and 'Research' in app and 'Monitor' in app and 'Validate' in app
    visible = ["00_discovery.py","01_coverage_v3.py","02_decide_v3.py","03_research_v3.py","04_monitor_v3.py","05_validate_v3.py","05_portfolio_v3.py","06_settings_v3.py"]
    for name in visible:
        assert (ROOT / "pages" / name).exists(), f"missing V3 page: {name}"
    assert (ROOT / "pages" / "03_financial_flows.py").exists(), "Financial Flows detail page missing"
    assert not (ROOT / "pages" / "01_coverage.py").exists(), "obsolete V2 Coverage page still packaged"
    assert not (ROOT / "pages" / "02_command_center.py").exists(), "obsolete V2 Command Center page still packaged"

    assert 'discovery_universe' in dbs and 'discovery_runs' in dbs and 'peer_links' in dbs and 'variant_case' in dbs
    assert 'def start_scan(' in disc and 'def score_universe(' in disc and 'NO EDGE' in disc
    assert 'QUALITY AT DISCOUNT' in disc and 'POTENTIAL SHORT' in disc and 'VALUE TRAP' in disc
    assert 'def compare(' in tri and 'RELATIVE VALUE + QUALITY' in tri
    assert 'market_belief' in v3 and 'our_belief' in v3 and 'resolution_signal' in v3
    assert 'External triangulation' in v3 and 'Decision Queue' in v3
    assert 'STEP-BY-STEP DECISION' in v3 and 'WHAT SHOULD I DO NOW?' in v3 and 'What kills the thesis' in v3
    assert 'Price vs valuation range' in v3 and 'Operating trend' in v3
    assert 'FORENSIC LENS' in v3 and 'CORE SNAPSHOT' in v3 and 'EXPECTATIONS — WHAT MUST THE MARKET BELIEVE?' in v3
    assert 'CORE CONFIGURATION' in v3 and 'DISCOVERY CONFIGURATION' in v3 and 'CURRENT COMPANY DATA HEALTH' in v3
    assert 'Test Alpaca' in v3 and 'SEC User-Agent' in v3 and 'Large-number display' in v3
    assert 'MARKET-DATA RESILIENCE' in v3 and 'Prepare Discovery PDF' in v3 and 'Prepare Word report' in v3 and 'Prepare PDF report' in v3
    assert 'render_icon_rail(nav_items)' in app and 'mf-icon-rail' in v3
    assert 'render_sidebar(nav_items, pg)' in app and 'by Lose Money Rules' in v3 and 'detail_parent' in v3
    # V3.1.8 design/branding regression: institutional palette, no legacy slogans, custom logo support.
    cfg_text = (ROOT / '.streamlit' / 'config.toml').read_text(encoding='utf-8')
    config_src = (ROOT / 'market_forensics' / 'config.py').read_text(encoding='utf-8')
    exporter_src = (ROOT / 'market_forensics' / 'exporter.py').read_text(encoding='utf-8')
    combined_visual = '\n'.join([v3, ws, cfg_text, exporter_src])
    for token in ['ADD ON ' + 'EVIDENCE, NOT ON PRICE.', 'resilient data · visible ' + 'evidence · drill down when needed', '#8E' + '7CFF', '#7C' + '6FE3', '#9B' + '59B6']:
        assert token not in combined_visual, f'legacy visual/copy token remains: {token}'
    assert 'Lose Money Rules' in v3 and 'Lose Money Rules' in ws and 'Lose Money Rules' in exporter_src
    assert 'def save_branding_logo' in config_src and 'def clear_branding_logo' in config_src and 'branding_logo_path' in config_src
    assert 'Save logo' in v3 and 'Remove logo' in v3
    assert 'landscape(letter)' in exporter_src, 'Discovery PDF should remain landscape for readable screening tables'
    # V3.1.8 color/border regression: Discovery bars must never fall back to Plotly purple.
    assert v3.count('marker_color="#3F78A8"') >= 2, 'Discovery long/short bars must use institutional blue'
    assert '--mf-border:color-mix(in srgb,var(--text-color) 17%,transparent)' in v3
    assert '--mf-line:color-mix(in srgb,var(--text-color) 34%,transparent)' in ws
    assert 'aria-current="page"' in v3 and 'var(--mf-blue)!important' in v3
    assert '--primary-color:#3F78A8!important' in v3, 'global Streamlit accent must be hard-locked to institutional blue'
    assert '[data-baseweb="menu"] [aria-selected="true"]' in v3 and 'baseButton-primary' in v3, 'menu/primary fallback states must be explicitly de-purpled'
    assert '--mf-cyan:#3F78A8' in ws, 'advanced pages must use the same institutional blue'
    assert 'MF_PLOTLY_COLORS' in v3 and 'MF_PLOTLY_COLORS' in ws, 'both UI shells must hard-lock a non-purple Plotly colorway'
    assert 'style_plot(fig' in ws and '_style_plot(fig' in v3, 'all chart families need centralized non-purple layout styling'
    assert 'increasing_line_color="#1F9D68"' in ws and 'decreasing_line_color="#D15353"' in ws, 'candlestick colors must be explicit'
    assert 'marker_color="#2E8894"' in ws and 'FINRA Daily Short %' in ws and 'color="#C99A2E"' in ws, 'advanced tape charts must not use Plotly fallback colors'
    assert '#3A4751' in v3 and '#3A4751' in ws and '#D7DEE4' in v3 and '#D7DEE4' in ws, 'light/dark border tokens must be explicitly theme-aware'
    assert 'screen_base_value' in dbs and 'screen_value_gap' in dbs and 'screen_value_status' in dbs and 'screen_model_version' in dbs
    assert 'Absolute Value Gate (V3.1.12)' in v3 and 'screen_value_gap' in disc
    assert 'Relative dislocation and absolute fair-value direction are not aligned' in disc
    assert 'WeightedAverageNumberOfSharesOutstandingBasic' in (ROOT / 'market_forensics' / 'fundamentals.py').read_text(encoding='utf-8')
    md_src=(ROOT / 'market_forensics' / 'marketdata.py').read_text(encoding='utf-8')
    assert '_yahoo_validation_bars' in md_src and 'split_events' in md_src and 'minimum_start_year' in md_src
    bt_src=(ROOT / 'market_forensics' / 'backtest.py').read_text(encoding='utf-8')
    assert 'lookback_days: int = 14610' in bt_src and 'earliest_modelable_year' in bt_src and 'price_history_start' in bt_src
    assert 'validation_runs' in dbs and 'latest_validation_result' in dbs and 'portfolio_positions' in dbs, 'historical reliability must persist per company'
    assert 'COMPANY-SPECIFIC RELIABILITY' in v3 and 'HISTORICAL MODEL RELIABILITY' in v3
    assert 'CORE PRICE CASES' in v3 and 'Bear / Base / Bull — ALL valuation assumptions & outputs' in v3, 'Decide must expose every valuation-case input/output'
    assert 'ASYMMETRY & POSITION MATH' in v3 and 'Model Confidence' in v3
    assert 'Research · Evidence Room' in v3, 'Research should not be a second decision cockpit'
    assert 'Financial Flows' in v3 and 'pages/03_financial_flows.py' in v3, 'Research must link to Financial Flows'
    assert 'def render_financial_flows' in ws and 'go.Sankey' in ws, 'Income/Cash Sankey renderer missing'
    assert 'customdata=[money(x[2]) for x in links]' in ws and '%{customdata}' in ws, 'Sankey amounts must use compact/readable money display'
    assert 'display_table(idf,{"Amount":money,"% Revenue":fpct})' in ws and 'display_table(cdf,{"Amount":money,"% CFO":fpct})' in ws, 'Financial Flows tables must use app-wide compact money formatting'
    assert 'validate_ticker(' in v3 and 'Ticker not found / symbol not recognized.' in v3, 'user-entered tickers must be validated before save'
    decide_page=(ROOT/'pages'/'02_decide_v3.py').read_text(encoding='utf-8')
    assert 'st.fragment(run_every="60s")' in decide_page and 'live_price=True' in decide_page, 'Decide current price must auto-refresh without a full fundamental refresh'
    assert 'def current_price_overlay' in md_src and 'latestTrade' in md_src, 'snapshot price overlay missing'
    assert 'Valuation Cases — Bear / Base / Bull assumptions' in ws and '5Y Operating Forecast Bear/Base/Bull model' in ws
    assert 'Sizing reference price' in ws and 'Thesis invalidation price' not in ws
    assert 'Configuration has one home in V3.1.12: Settings' in ws
    assert 'Long Dislocation' in v3 and 'Short Dislocation' in v3
    assert '.mf-ticker-symbol{font-size:3.05rem' in ws, 'Advanced-page ticker must remain prominently readable'
    assert '.mf3-kicker.company-ticker{font-size:2.65rem' in v3, 'V3 company-page ticker must remain prominently readable'
    assert 'Comparable +1Y (anchor basis)' in v3 and '+1Y year-end raw close' in v3 and '+1Y exact market date' in v3, 'Validate must make raw-vs-comparable +1Y prices explicit'
    assert 'def position_action(' in v3 and 'ADD / EDIT REAL POSITION' in v3, 'position-aware action + independent portfolio editor missing'
    assert 'PARSER_VERSION = 5' in (ROOT / 'market_forensics' / 'management.py').read_text(encoding='utf-8')
    assert 'Do not force rowHeights' in exporter_src and 'metric_long=ParagraphStyle' in exporter_src, 'PDF narrative KPI boxes must auto-expand instead of clipping'

    # Navigation regression: every non-home Streamlit pathname must be explicit and unique.
    app_tree = ast.parse(app)
    literal_lists = {}
    for node in app_tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            if node.targets[0].id in {"VISIBLE", "DETAIL"}:
                literal_lists[node.targets[0].id] = ast.literal_eval(node.value)
    visible_rows = literal_lists["VISIBLE"]
    detail_rows = literal_lists["DETAIL"]
    visible_slugs = [row[4] for row in visible_rows if row[4]]
    detail_slugs = [row[3] for row in detail_rows]
    all_slugs = visible_slugs + detail_slugs
    assert all(detail_slugs), "Advanced pages must use explicit URL pathnames"
    assert len(all_slugs) == len(set(all_slugs)), f"duplicate Streamlit URL pathnames: {all_slugs}"
    assert "advanced-portfolio" in detail_slugs and "portfolio" in visible_slugs
    assert "validate" in visible_slugs, "Validate page must have an explicit unique pathname"
    bt = (ROOT / "market_forensics" / "backtest.py").read_text(encoding="utf-8")
    assert "filter_companyfacts_as_of" in bt and "saved current assumptions are intentionally excluded" in bt
    assert "replay_one_year" in bt and "beat_no_change_baseline" in bt and "thesis_driver_hit_ratio" in bt
    assert '_comparable_outcome_price' in bt and 'get_validation_daily_bars' in (ROOT / "market_forensics" / "marketdata.py").read_text(encoding="utf-8")
    assert 'price_basis_verified' in bt and 'Corporate-action basis' in v3
    assert 'pages/05_validate_v3.py' in app and 'def render_validate()' in v3

    # Retain V2.7.1 safety work underneath the simplified V3 shell.
    assert 'key=vkey(name,"pe")' in ws and 'key=vkey(name,"growth")' in ws
    assert 'val_state_version' in ws and 'def vkey(*parts)' in ws
    assert 'multiple_regime_diagnostics' in ws
    assert 'Institutional Equity Research Report' in ws
    assert 'Data Audit & Provenance' in ws
    assert 'st.error(f"Data review required: {text}") if high else' not in ws
    exp=(ROOT / "market_forensics" / "exporter.py").read_text(encoding="utf-8")
    assert 'filing_documents WHERE ticker=? ORDER BY filed DESC,id DESC' not in exp
    assert 'filing_documents WHERE ticker=? ORDER BY filed DESC, accession DESC, document_type, source_url' in exp

def theme_config_check():
    import tomllib
    cfg_path = ROOT / ".streamlit" / "config.toml"
    with cfg_path.open("rb") as f:
        cfg = tomllib.load(f)
    theme = cfg.get("theme", {})
    assert "light" in theme and "dark" in theme, "switchable light/dark theme tables missing"
    assert theme["light"].get("backgroundColor") != theme["dark"].get("backgroundColor")


def settings_bounds_regression():
    from market_forensics.config import normalize_settings
    s = normalize_settings({
        "flow_days": 0,
        "management_filing_limit": 2,
        "discovery_max_symbols": 10,
        "discovery_fundamental_age_days": 90,
        "portfolio_nav": -1,
        "discovery_min_price": -5,
        "alpaca_feed": "bad",
        "number_display": "bad",
    })
    assert s["flow_days"] == 1
    assert s["management_filing_limit"] == 6
    assert s["discovery_max_symbols"] == 100
    assert s["discovery_fundamental_age_days"] == 30
    assert s["portfolio_nav"] == 0.0
    assert s["discovery_min_price"] == 0.0
    assert s["alpaca_feed"] == "auto"
    assert s["number_display"] == "AUTO"


def synthetic_core():
    from market_forensics import db, decision, flow, fundamentals, service, valuation
    db.init_db()
    tables = {r["name"] for r in db.query("SELECT name FROM sqlite_master WHERE type='table'")}
    required = {"coverage","refresh_runs","refresh_batches","refresh_batch_items","metric_snapshots","monitoring_kpis","events","research_history","bear_case_items","risk_plans","sec_provenance","sec_revisions","filing_documents","management_statements","forecast_assumptions"}
    assert required.issubset(tables)
    db.ensure_coverage("TEST")
    db.update_coverage("TEST", status="WATCHLIST", company_type="Consumer / Brand", tags="consumer, China")

    bars=[]; start=date(2026,7,1)
    for i in range(45):
        d=start+timedelta(days=i)
        if d.weekday()>=5: continue
        p=100+i*.25
        bars.append({"ticker":"TEST","trade_date":d.isoformat(),"open":p-1,"high":p+2,"low":p-2,"close":p,"volume":1_000_000+i*1000,"trade_count":10000,"vwap":p-.1,"feed":"sip","updated_at":db.now_utc()})
    db.upsert_many("daily_bars",bars,["ticker","trade_date"])

    fys=[]
    for fy in range(2021,2026):
        rev=10e9*(1.05**(fy-2021));gp=rev*.45;oi=rev*.15
        fys.append({"ticker":"TEST","period_key":f"FY{fy}","period_end":f"{fy}-12-31","fiscal_year":fy,"period_type":"FY","revenue":rev,"gross_profit":gp,"operating_income":oi,"net_income":oi*.8,"cfo":rev*.14,"capex":rev*.04,"fcf":rev*.10,"sbc":rev*.01,"buybacks":rev*.02,"dividends":rev*.01,"diluted_shares":100e6,"pretax":oi,"tax":oi*.2,"cash":2e9,"debt":1e9,"receivables":rev*.1,"inventory":rev*.12,"payables":rev*.08,"assets":20e9,"liabilities":8e9,"equity":12e9,"source":"SEC XBRL","updated_at":db.now_utc()})
    db.upsert_many("fundamentals",fys,["ticker","period_key"])
    ttm=dict(fys[-1]);ttm.update({"period_key":"TTM","fiscal_year":None,"period_type":"TTM"})
    db.upsert_many("fundamentals",[ttm],["ticker","period_key"])

    lastd=bars[-1]["trade_date"]
    db.upsert_many("flow_daily",[{ "ticker":"TEST","trade_date":lastd,"feed":"sip","large_buy":8e6,"large_sell":5e6,"net_large":3e6,"whale_buy":2e6,"whale_sell":1e6,"net_whale":1e6,"large_turnover_pct":.30,"whale_turnover_pct":.08,"avg_aggressive_buy":110,"avg_aggressive_sell":109,"quote_coverage":.92,"large_threshold":100000,"very_large_threshold":250000,"whale_threshold":1000000,"trade_count":5000,"classified_count":4500,"updated_at":db.now_utc()}],["ticker","trade_date"])
    db.upsert_many("finra_short_volume",[{"ticker":"TEST","trade_date":lastd,"short_volume":400000,"short_exempt_volume":10000,"total_reported_volume":900000,"short_pct":.455,"market":"CNMS","updated_at":db.now_utc()}],["ticker","trade_date"])

    snap=service.latest_snapshot("TEST")
    assert snap["scores"]["Confidence"]>=50
    assert "Institutional Flow" in snap["scores"]
    metrics=fundamentals.metrics_from_rows(snap["fund"],snap["bar"]["close"])
    assert metrics["ccc"] is not None and metrics["inventory"] is not None

    ass=valuation.default_assumptions(metrics)
    sc,ev=valuation.scenario_values(metrics,ass)
    assert all(sc[x]["fair_value"] is not None for x in ("bear","base","bull"))
    assert sc["base"]["dcf"] is not None and ev is not None
    assert valuation.implied_growth_for_price(sc["base"]["dcf"],metrics,ass["base"]) is not None
    ass["model_version"]="2.5"; ass["reviewed_at"]=db.now_utc()
    db.save_json_assumptions("TEST", ass)

    db.save_research("TEST",{
        "thesis_title":"Test","business_notes":"Makes cash selling products","value_drivers":"volume, price, margin",
        "market_narrative":"Market expects stagnation","variant_view":"Growth higher than implied","key_evidence":"A B C",
        "catalysts":"Earnings","evidence_to_add":"Margin and revenue improve","invalidation":"FCF breaks",
        "primary_risk":"Demand","secondary_risks":"Competition","portfolio_risk_notes":"Consumer factor"
    })
    assert decision.seed_default_kpis("TEST")==10
    # Seeded KPIs must NOT accidentally satisfy numerical invalidation gate.
    gates=decision.investment_gates("TEST",metrics,sc,ev,db.coverage_row("TEST"))
    inv=[g for g in gates if g["key"]=="invalidation"][0]
    assert inv["status"] != "PASS"
    # Create an explicit LOCKED invalidation rule.
    db.execute("""INSERT INTO monitoring_kpis(ticker,name,category,metric_key,source_type,operator,threshold,linked_to,importance,locked,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",("TEST","Locked FCF invalidation","Cash","fcf_margin","AUTO",">=",.05,"INVALIDATION",5,1,db.now_utc(),db.now_utc()))
    db.save_risk_plan("TEST",{"portfolio_risk_budget":.0075,"invalidation_price":90,"event_liquidity_haircut":.05,"max_position_cap":.10,"correlation_notes":"consumer","kill_switch":"FCF breach"})
    for stype in ("10-K","10-Q","SEC XBRL"):
        db.execute("INSERT INTO source_log(created_at,ticker,source_type,document,reliability) VALUES(?,?,?,?,?)",(db.now_utc(),"TEST",stype,"doc",5))
    decision.seed_bear_case("TEST")
    for item in decision.BEAR_ITEMS[:3]:
        db.execute("UPDATE bear_case_items SET evidence_for='evidence' WHERE ticker='TEST' AND item_key=?",(item,))
    db.execute("INSERT INTO decision_journal(created_at,ticker,action,price,thesis) VALUES(?,?,?,?,?)",(db.now_utc(),"TEST","WATCH",110,"test"))
    gates=decision.investment_gates("TEST",metrics,sc,ev,db.coverage_row("TEST"))
    counts,label=decision.gate_summary(gates)
    assert counts["PASS"]==16 and label=="DECISION READY"

    service.capture_snapshot("TEST");service.capture_snapshot("TEST")
    assert len(service.snapshot_history("TEST"))>=2
    summary=service.coverage_summary_row("TEST")
    assert summary["Ticker"]=="TEST" and summary["Price"] is not None

    db.ensure_coverage("REMOVE")
    db.remove_from_coverage("REMOVE")
    assert db.coverage_row("REMOVE") is None

    # Trade/quote classifier including nullable/empty edge cases.
    empty=flow.classify_session([],[])
    assert empty["trade_count"]==0
    q=[{"t":"2026-08-01T14:00:00Z","bp":99.9,"ap":100.1}]
    tr=[{"t":"2026-08-01T14:00:00.100Z","p":100.1,"s":1000}]
    agg=flow.classify_session(tr,q,min_notional=1)
    assert agg["large_buy"]>0


def synthetic_v23_valuation_and_forensics():
    from market_forensics import audit, db, forensics, fundamentals, service, valuation
    # Build 7 filing-anchored annual observations with realistic multiple variation.
    fund=[]; bars=[]
    for i,fy in enumerate(range(2019,2026)):
        rev=8e9*(1.06**i); om=.12+.004*i; ni=rev*om*.80; fcf=rev*(.075+.003*i); shares=100e6
        filed=f"{fy+1}-02-15"
        fund.append({"ticker":"CAL","period_key":f"FY{fy}","period_end":f"{fy}-12-31","period_filed":filed,"fiscal_year":fy,"period_type":"FY","revenue":rev,"gross_profit":rev*.42,"operating_income":rev*om,"net_income":ni,"cfo":fcf+rev*.03,"capex":rev*.03,"fcf":fcf,"diluted_shares":shares,"diluted_eps_reported":ni/shares,"pit_revenue":rev,"pit_gross_profit":rev*.42,"pit_operating_income":rev*om,"pit_net_income":ni,"pit_cfo":fcf+rev*.03,"pit_capex":rev*.03,"pit_fcf":fcf,"pit_diluted_shares":shares,"pit_diluted_eps":ni/shares,"pit_cash":1.5e9,"pit_debt":.5e9,"pit_shares_outstanding":shares,"pit_shares_outstanding_date":f"{fy}-12-31","cash":1.5e9,"debt":.5e9,"receivables":rev*.09,"inventory":rev*.10,"payables":rev*.07,"assets":15e9,"liabilities":6e9,"equity":9e9,"updated_at":db.now_utc()})
        bars.append({"ticker":"CAL","trade_date":filed,"open":48+i*2,"high":51+i*2,"low":47+i*2,"close":50+i*2,"raw_close":50+i*2,"split_adjusted_close":50+i*2,"split_factor":1.0,"basis_verified":1,"price_basis":"synthetic raw","volume":1e6,"trade_count":1000,"vwap":50+i*2,"feed":"sip","updated_at":db.now_utc()})
    ttm=dict(fund[-1]); ttm.update({"period_key":"TTM","period_type":"TTM","fiscal_year":None,"period_filed":None})
    fund.append(ttm)
    db.ensure_coverage("CAL"); db.update_coverage("CAL",company_type="Consumer / Brand")
    db.upsert_many("fundamentals",fund,["ticker","period_key"]); db.upsert_many("daily_bars",bars,["ticker","trade_date"])
    metrics=fundamentals.metrics_from_rows(fund,bars[-1]["close"])
    ass,cal=valuation.smart_assumptions(metrics,fund,bars,"Consumer / Brand")
    assert len(cal["observations"]) >= 6 and cal["pe"]["n"] >= 4
    assert ass["calibration"]["pe_source"] == "company history"
    sc,ev=valuation.scenario_values(metrics,ass)
    assert 0 < sc["bear"]["fair_value"] < sc["bull"]["fair_value"] and ev is not None
    vc=valuation.valuation_confidence(metrics,sc,cal,"Consumer / Brand",{"WARN":0,"FAIL":0},reviewed=True)
    assert vc["score"] >= 55
    # Insert a revision to ensure the forensic layer surfaces a DATA alert.
    db.upsert_many("sec_revisions",[{"ticker":"CAL","metric":"revenue","xbrl_tag":"Revenues","unit":"USD","period_start":"2024-01-01","period_end":"2024-12-31","fiscal_year":2024,"fiscal_period":"FY","first_filed":"2025-02-15","latest_filed":"2026-02-15","first_form":"10-K","latest_form":"10-K","first_value":10e9,"latest_value":10.6e9,"delta":.6e9,"delta_pct":.06,"updated_at":db.now_utc()}],["ticker","metric","period_end","first_filed","latest_filed"])
    snap=service.latest_snapshot("CAL")
    state={"snap":snap,"bars":bars,"fund_rows":fund,"bar":bars[-1],"scores":{},"metrics":metrics,"assumptions":ass,"scenarios":sc,"expected_value":ev,"base_value":sc["base"]["fair_value"],"price":bars[-1]["close"],"upside":sc["base"]["fair_value"]/bars[-1]["close"]-1,"coverage":db.coverage_row("CAL") or {}}
    ar=audit.build_audit("CAL",state)
    fs=forensics.build_forensic_signals("CAL",state,cal,ar)
    assert fs["data_alerts"] and any("SEC" in x["Category"] or "Data" in x["Category"] for x in fs["data_alerts"])

    # Extreme current-vs-history multiple gaps must be treated as regime breaks, not automatic bargains.
    hist_cal={
        "pe":{"n":6,"p25":20.0,"median":25.0,"p75":30.0},
        "ev_sales":{"n":6,"p25":2.0,"median":2.5,"p75":3.0},
        "fcf_yield":{"n":6,"p25":.03,"median":.04,"p75":.05},
        "revenue_growth":{"median":.05},"net_margin":{"median":.10},"fcf_margin":{"median":.10},
        "observations":[{}]*6,
    }
    rb_metrics={"diluted_shares":100.0,"net_income":100.0,"revenue":1000.0,"fcf":100.0,"net_debt":0.0,"cagr3":.02,"net_margin":.10,"fcf_margin":.10}
    rb=valuation.multiple_regime_diagnostics(rb_metrics,2.0,hist_cal)
    assert rb["high_count"] >= 1 and any(r["metric"]=="P/E" and r["ratio_to_history"] < .10 for r in rb["rows"])
    vc_break=valuation.valuation_confidence(rb_metrics,{"base":{"pe":20,"ev_sales":20,"fcf_yield":20,"dcf":20},"bear":{"fair_value":10},"bull":{"fair_value":30}},hist_cal,"Generic",{"WARN":0,"FAIL":0},reviewed=True,regime_breaks=rb)
    assert vc_break["score"] < 80 and any("regime break" in x for x in vc_break["reasons"])


def synthetic_exports_and_audit():
    from market_forensics import audit, db, decision, exporter, fundamentals, service, valuation
    snap=service.latest_snapshot("TEST")
    metrics=fundamentals.metrics_from_rows(snap.get("fund") or [], (snap.get("bar") or {}).get("close"))
    ass=valuation.normalize_assumptions(db.load_json_assumptions("TEST"), metrics)
    sc,ev=valuation.scenario_values(metrics,ass)
    cov=db.coverage_row("TEST") or {}
    gates=decision.investment_gates("TEST",metrics,sc,ev,cov)
    counts,label=decision.gate_summary(gates)
    state={"snap":snap,"bar":snap.get("bar"),"scores":snap.get("scores") or {},"metrics":metrics,"assumptions":ass,"scenarios":sc,"expected_value":ev,"base_value":sc.get("base",{}).get("fair_value"),"price":(snap.get("bar") or {}).get("close"),"upside":None,"coverage":cov,"gates":gates,"gate_counts":counts,"gate_label":label,"fund_rows":snap.get("fund") or []}
    if state["price"] and state["base_value"] is not None:
        state["upside"]=state["base_value"]/state["price"]-1
    ar=audit.build_audit("TEST",state)
    assert ar["checks"] and ar["provenance"] and ar["counts"]["PASS"] >= 3
    # Regression: filing_documents has NO `id` column (composite PK). Dossier export must never order by id.
    db.upsert_many("filing_documents", [{
        "ticker":"TEST", "accession":"0000000000-26-000001", "document_type":"PRIMARY",
        "form":"10-K", "filed":"2026-02-01", "report_date":"2025-12-31",
        "source_url":"https://www.sec.gov/Archives/test.htm", "content_sha1":"abc",
        "extracted_at":db.now_utc()
    }], ["ticker","accession","document_type","source_url"])
    dossier=json.loads(exporter.dossier_json("TEST",ass,gates))
    assert dossier.get("filing_documents") and dossier["filing_documents"][0]["accession"] == "0000000000-26-000001"
    docx_bytes=exporter.research_report_docx("TEST",state)
    pdf_bytes=exporter.research_report_pdf("TEST",state)
    discovery_pdf=exporter.discovery_report_pdf()
    assert docx_bytes[:2] == b"PK" and len(docx_bytes) > 5000
    assert pdf_bytes[:4] == b"%PDF" and len(pdf_bytes) > 3000
    assert discovery_pdf[:4] == b"%PDF" and len(discovery_pdf) > 3000


def synthetic_sec_xbrl():
    from market_forensics import fundamentals
    facts = {"facts":{"us-gaap":{}}}
    years = list(range(2021, 2026))

    def flowtag(tag, values, unit="USD"):
        facts["facts"]["us-gaap"][tag] = {"units":{unit:[]}}
        for fy, val in values:
            facts["facts"]["us-gaap"][tag]["units"][unit].append({
                "fy":fy,"fp":"FY","form":"10-K","filed":f"{fy+1}-02-01",
                "start":f"{fy}-01-01","end":f"{fy}-12-31","val":val
            })

    def instant(tag, values, unit="USD"):
        facts["facts"]["us-gaap"][tag] = {"units":{unit:[]}}
        for fy, val in values:
            facts["facts"]["us-gaap"][tag]["units"][unit].append({
                "fy":fy,"fp":"FY","form":"10-K","filed":f"{fy+1}-02-01",
                "end":f"{fy}-12-31","val":val
            })

    growth = lambda y: 1.05 ** (y-2021)
    flowtag("RevenueFromContractWithCustomerExcludingAssessedTax", [(y,1e9*growth(y)) for y in years])
    flowtag("GrossProfit", [(y,.4e9*growth(y)) for y in years])
    flowtag("OperatingIncomeLoss", [(y,.12e9*growth(y)) for y in years])
    flowtag("NetIncomeLoss", [(y,.09e9*growth(y)) for y in years])
    flowtag("NetCashProvidedByUsedInOperatingActivities", [(y,.14e9*growth(y)) for y in years])
    flowtag("PaymentsToAcquirePropertyPlantAndEquipment", [(y,.04e9*growth(y)) for y in years])
    flowtag("WeightedAverageNumberOfDilutedSharesOutstanding", [(y,100e6) for y in years], "shares")
    flowtag("IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest", [(y,.11e9*growth(y)) for y in years])
    flowtag("IncomeTaxExpenseBenefit", [(y,.022e9*growth(y)) for y in years])
    for tag, mult in (("CashAndCashEquivalentsAtCarryingValue",.2),("AccountsReceivableNetCurrent",.10),
                      ("InventoryNet",.12),("AccountsPayableCurrent",.06),("Assets",1.5),
                      ("Liabilities",.6),("StockholdersEquity",.9),("LongTermDebtNoncurrent",.1)):
        instant(tag, [(y,mult*1e9*growth(y)) for y in years])

    rows = fundamentals.build_fundamentals("XBRL", facts)
    metrics = fundamentals.metrics_from_rows(rows, 100)
    assert len([r for r in rows if r.get("period_type")=="FY"]) >= 5
    assert metrics["revenue"] is not None and metrics["dso"] is not None and metrics["ccc"] is not None
    assert metrics["diluted_shares"] == 100e6


def synthetic_refresh_pipeline():
    """Exercise refresh_core end-to-end without external network calls."""
    from market_forensics import db, service
    from datetime import date, timedelta, datetime, timezone

    # Fresh isolated test ticker within the temporary self-test database.
    t = "PIPE"
    base = date(2026, 9, 8)
    bars = []
    for i in range(3):
        d = base + timedelta(days=i)
        p = 100 + i
        bars.append({"date": d.isoformat(), "open": p-.5, "high": p+1, "low": p-1,
                     "close": p, "volume": 1_000_000, "trade_count": 1000, "vwap": p})

    original = {
        "settings": service.load_settings,
        "bars": service.marketdata.get_daily_bars,
        "finra": service.finra.get_daily_short_volume,
        "meta": service.sec.company_metadata,
        "facts": service.sec.get_companyfacts,
        "build": service.fundamentals.build_fundamentals,
        "tq": service.marketdata.get_session_trades_quotes,
        "pricecheck": service.marketdata.price_cross_check,
        "management": service.management.refresh_management_documents,
    }
    try:
        service.load_settings = lambda: {
            "alpaca_feed":"auto", "daily_lookback_days":30, "flow_days":2,
            "minimum_notional":1, "large_percentile":.75, "very_large_percentile":.90,
            "whale_percentile":.99, "sec_user_agent":"MarketForensics/2.5 test@example.com"
        }
        service.marketdata.get_daily_bars = lambda *a, **k: (bars, "alpaca_sip")
        service.marketdata.price_cross_check = lambda *a, **k: {"status":"PASS","sources":[{"provider":"MOCK","price":bars[-1]["close"],"asof":bars[-1]["date"],"quality":"TEST","deviation_pct":0.0}],"message":"synthetic"}
        service.finra.get_daily_short_volume = lambda *a, **k: [{
            "trade_date":bars[-1]["date"], "short_volume":400, "short_exempt_volume":10,
            "total_reported_volume":900, "short_pct":410/900, "market":"CNMS"
        }]
        service.sec.company_metadata = lambda *a, **k: {
            "ticker":t, "cik":"0001", "company_name":"Pipeline Test Co", "exchange":"NYSE",
            "sic":"1234", "sic_description":"Test", "fiscal_year_end":"1231"
        }
        service.sec.get_companyfacts = lambda *a, **k: {"facts":{}}
        row = {
            "ticker":t,"period_key":"TTM","period_end":"2026-06-30","fiscal_year":None,"period_type":"TTM",
            "revenue":1e9,"gross_profit":.4e9,"operating_income":.1e9,"net_income":.08e9,
            "cfo":.12e9,"capex":.02e9,"fcf":.1e9,"sbc":.01e9,"buybacks":0,"dividends":0,
            "diluted_shares":10e6,"pretax":.1e9,"tax":.02e9,"cash":.2e9,"debt":.1e9,
            "receivables":.1e9,"inventory":.1e9,"payables":.05e9,"assets":1.2e9,
            "liabilities":.4e9,"equity":.8e9,"source":"SEC XBRL","updated_at":db.now_utc()
        }
        fy = dict(row); fy.update({"period_key":"FY2025","fiscal_year":2025,"period_type":"FY"})
        service.fundamentals.build_fundamentals = lambda *a, **k: [fy, row]
        def tq(ticker, d, feed):
            q = [{"t":f"{d.isoformat()}T14:00:00Z","bp":100,"ap":100.1}]
            tr = [{"t":f"{d.isoformat()}T14:00:00.100Z","p":100.1,"s":1000}]
            return tr, q, "sip"
        service.marketdata.get_session_trades_quotes = tq
        service.management.refresh_management_documents = lambda *a, **k: {"documents":1,"statements":3,"skipped":0,"errors":[]}

        result = service.refresh_core(t, include_flow=True)
        last = service.last_refresh(t)
        snap = service.latest_snapshot(t)
        assert result["bars"] == 3 and result["flow_dates"] == 2
        assert last and last["status"] == "PASS" and last["market_feed"] == "alpaca_sip"
        assert snap["flow"]["large_buy"] > 0 and snap["scores"]["Confidence"] >= 50
        pass_id=last["id"]
        def finra_down(*a,**k): raise RuntimeError("synthetic FINRA outage")
        service.finra.get_daily_short_volume=finra_down
        partial=service.refresh_core(t, include_flow=True)
        assert partial["status"]=="PARTIAL" and partial["warnings"],partial
        assert service.last_refresh(t)["status"]=="PARTIAL"
        assert service.last_successful_refresh(t)["id"]==pass_id
    finally:
        service.load_settings = original["settings"]
        service.marketdata.get_daily_bars = original["bars"]
        service.finra.get_daily_short_volume = original["finra"]
        service.sec.company_metadata = original["meta"]
        service.sec.get_companyfacts = original["facts"]
        service.fundamentals.build_fundamentals = original["build"]
        service.marketdata.get_session_trades_quotes = original["tq"]
        service.marketdata.price_cross_check = original["pricecheck"]
        service.management.refresh_management_documents = original["management"]



def synthetic_coverage_intelligence_and_background_jobs():
    import time
    from datetime import datetime, timezone, timedelta as dt_timedelta
    from market_forensics import db, jobs, opportunity

    state = {
        "price": 100.0,
        "base_value": 135.0,
        "expected_value": 128.0,
        "scenarios": {"bear":{"fair_value":80},"base":{"fair_value":135},"bull":{"fair_value":170}},
        "metrics": {"revenue":1e9,"operating_margin":.16,"fcf_margin":.11,"roic":.18,"cfo_ni":1.1,"net_debt":-1e8,"cagr3":.08,"share_change":-.01},
        "scores": {"Net Tape":62,"Confidence":75,"Short Pressure":55,"Absorption":65},
        "forensics": {"positives":[{"Severity":"HIGH"},{"Severity":"MEDIUM"}],"negatives":[],"data_alerts":[]},
        "audit": {"counts":{"PASS":8,"WARN":0,"FAIL":0,"NO DATA":0}},
        "valuation_confidence": {"score":78,"label":"HIGH"},
        "gate_counts": {"PASS":12,"WATCH":2,"FAIL":0,"INCOMPLETE":2},
    }
    last = {"completed_at": datetime.now(timezone.utc).isoformat()}
    opp = opportunity.evaluate(state,last)
    assert opp["focus"] in ("LONG FOCUS","LONG WATCH")
    assert opp["system_priority"] <= 2 and opp["long_score"] > opp["short_score"]

    short_state = dict(state)
    short_state.update({"price":100.0,"base_value":62.0,"expected_value":66.0})
    short_state["metrics"] = dict(state["metrics"], operating_margin=.03, fcf_margin=.01, roic=.03, cagr3=-.05, share_change=.05)
    short_state["scores"] = {"Net Tape":28,"Confidence":80,"Short Pressure":82,"Absorption":28}
    short_state["forensics"] = {"positives":[],"negatives":[{"Severity":"HIGH"},{"Severity":"MEDIUM"}],"data_alerts":[]}
    short_opp = opportunity.evaluate(short_state,last)
    assert short_opp["focus"] in ("SHORT FOCUS","SHORT WATCH") and short_opp["short_score"] > short_opp["long_score"]

    review_state = dict(state)
    review_state["audit"] = {"counts":{"PASS":5,"WARN":0,"FAIL":1,"NO DATA":0}}
    review_state["forensics"] = {"positives":[],"negatives":[],"data_alerts":[{"Severity":"HIGH"}]}
    review_opp = opportunity.evaluate(review_state,last)
    assert review_opp["focus"] == "DATA REVIEW" and review_opp["system_priority"] == 1

    regime_state = dict(state)
    regime_state["valuation_regime"] = {"high_count":1,"medium_count":0}
    regime_opp = opportunity.evaluate(regime_state,last)
    assert regime_opp["focus"] == "VALUATION REVIEW" and regime_opp["system_priority"] == 1

    stale = opportunity.freshness((datetime.now(timezone.utc)-dt_timedelta(hours=25)).isoformat())
    assert stale["status"] == "STALE" and "🔴" in stale["label"]

    # A failed attempt must never reset freshness.
    db.ensure_coverage("STALEFAIL")
    old=(datetime.now(timezone.utc)-dt_timedelta(hours=30)).isoformat()
    now=datetime.now(timezone.utc).isoformat()
    db.execute("INSERT INTO refresh_runs(ticker,started_at,completed_at,status) VALUES(?,?,?,?)",("STALEFAIL",old,old,"PASS"))
    db.execute("INSERT INTO refresh_runs(ticker,started_at,completed_at,status,error_message) VALUES(?,?,?,?,?)",("STALEFAIL",now,now,"FAIL","synthetic"))
    latest_ok=jobs.service.last_successful_refresh("STALEFAIL")
    latest_attempt=jobs.service.last_refresh("STALEFAIL")
    assert latest_ok and latest_ok["completed_at"]==old and latest_attempt["status"]=="FAIL"
    assert opportunity.freshness(latest_ok["completed_at"])["status"] in ("STALE","VERY STALE")

    original = jobs.service.refresh_core
    try:
        def fake_refresh(ticker, include_flow=True):
            db.ensure_coverage(ticker)
            started=db.now_utc()
            with db.connect() as con:
                cur=con.execute("INSERT INTO refresh_runs(ticker,started_at,completed_at,status,bars_rows,finra_rows,fundamental_periods,flow_dates,market_feed,flow_feed) VALUES(?,?,?,?,?,?,?,?,?,?)",
                                (ticker,started,db.now_utc(),"PASS",1,1,1,1,"sip","sip"))
            return {"bars":1,"finra":1,"fundamentals":1,"flow_dates":1,"market_feed":"sip","flow_feed":"sip"}
        jobs.service.refresh_core=fake_refresh
        res=jobs.start_or_enqueue(["JOB1","JOB2"],reason="SELF_TEST",include_flow=True)
        assert res.get("batch_id")
        deadline=time.time()+5
        status=None
        while time.time()<deadline:
            status=jobs.batch_status(res["batch_id"],include_items=True)
            if status and status.get("status") not in ("QUEUED","RUNNING"):
                break
            time.sleep(.05)
        assert status and status["status"]=="PASS", status
        assert status["passed"]==2 and all(x["status"]=="PASS" for x in status["items"])
    finally:
        jobs.service.refresh_core=original


def synthetic_management_and_forecast():
    from market_forensics import db, forecast, fundamentals, management
    t="MGMT"
    db.ensure_coverage(t)
    rows=[]
    for fy,rev,gm,om,nm,fm in [(2024,100e9,.40,.12,.08,.09),(2025,105e9,.41,.13,.085,.095),(2026,112e9,.42,.14,.09,.10)]:
        filed=f"{fy+1}-02-15"
        row={"ticker":t,"period_key":f"FY{fy}","period_end":f"{fy}-12-31","period_filed":filed,"fiscal_year":fy,"period_type":"FY",
             "revenue":rev,"gross_profit":rev*gm,"operating_income":rev*om,"net_income":rev*nm,"cfo":rev*(fm+.02),"capex":rev*.02,"fcf":rev*fm,
             "sbc":0,"buybacks":1e9,"dividends":0,"diluted_shares":1e9,"pretax":rev*nm/0.8,"tax":rev*nm/0.8*.2,
             "cash":20e9,"debt":5e9,"receivables":10e9,"inventory":12e9,"payables":8e9,"assets":150e9,"liabilities":50e9,"equity":100e9,
             "source":"SEC","updated_at":db.now_utc()}
        # Management scoring must use the originally-published values, not today's comparative restatement.
        for k in ("revenue","gross_profit","operating_income","net_income","cfo","capex","fcf","buybacks"):
            row[f"pit_{k}"]=row[k]
        rows.append(row)
    db.upsert_many("fundamentals",rows,["ticker","period_key"])
    ttm=dict(rows[-1]); ttm.update({"period_key":"TTM","fiscal_year":None,"period_type":"TTM"}); db.upsert_many("fundamentals",[ttm],["ticker","period_key"])
    text=("For fiscal 2026, we expect revenue growth of approximately 6.7%. "
          "For fiscal 2026, we target gross margin of approximately 42%. "
          "For fiscal 2026, we expect operating margin of approximately 14%. "
          "For fiscal 2026, we expect free cash flow of $11 billion. "
          "For fiscal 2026, we expect adjusted diluted EPS of $3.10 to $3.20. "
          "For the first quarter of fiscal 2026, we expect revenue growth of 8%. "
          "We plan to improve digital capabilities over time.")
    statements=management.extract_management_statements(text,ticker=t,form="10-K",filed="2025-02-01",source_url="https://sec.test",accession="a")
    assert len(statements)>=6 and all(x.get("extract_confidence") for x in statements)
    by_metric={}
    for x in statements: by_metric.setdefault(x.get("metric_key"),[]).append(x)
    assert any(float(x.get("extract_confidence") or 0)>=.80 for x in by_metric.get("revenue_growth",[]))
    assert any(float(x.get("extract_confidence") or 0)<.80 for x in by_metric.get("fcf",[])), "management-defined FCF must remain evidence-only"
    assert any(float(x.get("extract_confidence") or 0)<.80 for x in by_metric.get("eps",[])), "adjusted/non-GAAP EPS must remain evidence-only"
    db.upsert_many("management_statements",statements,["ticker","statement_hash"])
    mg=management.credibility_summary(t)
    assert mg["scorable"]==3, mg
    assert mg["met"]==3 and mg["score"]>=95 and mg["label"]=="HIGH", mg
    metrics=fundamentals.metrics_from_rows(rows+[ttm],100)
    q=management.quality_cross_checks(t,metrics,{"data_alerts":[]},mg)
    assert q["label"] in ("STRONG","SOLID") and q["score"]>=68
    auto=forecast.auto_assumptions(metrics,rows+[ttm],{"base":{"pe":20}})
    pack=forecast.scenario_summary(metrics,auto,100)
    assert len(pack["base"]["rows"])==5 and pack["base"]["terminal_price"]>0
    rec=forecast.price_reconciliation(100,metrics,auto,pack)
    assert rec["forecast_revenue_cagr"] is not None and rec["market_implied_exit_pe"] is not None
    db.save_forecast_assumptions(t,auto)
    assert db.load_forecast_assumptions(t)["model_version"]=="2.7"

    # Parser traps: comparator year cannot become target year; annual GAAP diluted EPS is scorable,
    # adjusted EPS and interim guidance are not.
    traps=management.extract_management_statements(
        "Revenue grew 5% in fiscal 2025. For fiscal 2026, we expect revenue growth of 6.7%. "
        "For fiscal 2026, we expect GAAP diluted EPS of $3.10 to $3.20. "
        "For fiscal 2026, we expect adjusted diluted EPS of $3.30 to $3.40. "
        "For Q1 fiscal 2026, we expect revenue growth of 9%.",
        ticker=t,form="10-K",filed="2025-02-01",source_url="https://sec.test/traps",accession="b")
    rev=[x for x in traps if x.get("metric_key")=="revenue_growth" and float(x.get("extract_confidence") or 0)>=.8]
    assert rev and all(int(x.get("target_fiscal_year") or 0)==2026 for x in rev), traps
    eps=[x for x in traps if x.get("metric_key")=="eps"]
    assert any(float(x.get("extract_confidence") or 0)>=.8 for x in eps) and any(float(x.get("extract_confidence") or 0)<.8 for x in eps), eps



def synthetic_v3_discovery_and_triangulation():
    import time
    from market_forensics import db, discovery, triangulation
    from market_forensics.config import save_settings

    cols=[r["name"] for r in db.query("PRAGMA table_info(discovery_universe)")]
    def put(**kw):
        row={c:None for c in cols}
        row.update({"tradable":1,"shortable":1,"has_options":1,"exchange":"NYSE",
                    "market_updated_at":db.now_utc(),"fundamentals_updated_at":db.now_utc(),**kw})
        db.upsert_many("discovery_universe",[row],["ticker"])

    put(ticker="AAA",company_name="AAA Co",sic="3149",price=50,dollar_volume=50e6,revenue=10e9,
        revenue_growth=.08,operating_margin=.18,operating_margin_prev=.14,net_margin=.12,fcf=1.3e9,
        fcf_margin=.13,fcf_margin_prev=.09,roic=.22,cfo_ni=1.2,diluted_shares=100e6,share_change=-.02,
        inventory_rev=.11,inventory_rev_prev=.15,receivables_rev=.08,receivables_rev_prev=.09,
        pe=10,ev_sales=1.1,fcf_yield=.09,quality_score=85,market_cap=5e9,
        screen_base_value=72,screen_value_gap=.44,screen_value_status="LONG ALIGNED")
    for i in range(1,7):
        put(ticker=f"P{i}",company_name=f"Peer {i}",sic="3149",price=60+i,dollar_volume=20e6+i*1e6,
            revenue=9e9,revenue_growth=.02,operating_margin=.12,operating_margin_prev=.12,net_margin=.08,
            fcf=.7e9,fcf_margin=.08,fcf_margin_prev=.08,roic=.12,cfo_ni=.9,diluted_shares=100e6,
            share_change=.01,inventory_rev=.14,inventory_rev_prev=.14,receivables_rev=.09,receivables_rev_prev=.09,
            pe=22+i,ev_sales=2.2,fcf_yield=.04,quality_score=58,market_cap=(6+i)*1e9,
            screen_base_value=62+i,screen_value_gap=.02,screen_value_status="FAIR VALUE / NO ABSOLUTE EDGE")
    put(ticker="ZZZ",company_name="ZZZ Co",sic="3149",price=100,dollar_volume=60e6,revenue=8e9,
        revenue_growth=-.12,operating_margin=.03,operating_margin_prev=.09,net_margin=.02,fcf=.08e9,
        fcf_margin=.01,fcf_margin_prev=.07,roic=.03,cfo_ni=.45,diluted_shares=120e6,share_change=.08,
        inventory_rev=.25,inventory_rev_prev=.15,receivables_rev=.18,receivables_rev_prev=.10,
        pe=45,ev_sales=4.5,fcf_yield=.005,quality_score=25,market_cap=12e9,
        screen_base_value=62,screen_value_gap=-.38,screen_value_status="SHORT ALIGNED")
    assert discovery.score_universe() >= 8
    aa=db.discovery_row("AAA"); zz=db.discovery_row("ZZZ"); p1=db.discovery_row("P1")
    assert aa["long_score"] > aa["short_score"] and aa["lens"] != "NO EDGE"
    assert zz["short_score"] > zz["long_score"] and zz["lens"] != "NO EDGE"
    assert p1["lens"] == "NO EDGE", "fair-value peer must not be promoted by relative cheapness alone"
    tri=triangulation.compare("AAA")
    assert tri["score"] is not None and tri["peers"] and tri["summary"] != "LOW DATA"
    db.save_variant_case("AAA",{"market_belief":"flat","our_belief":"recovery","disagreement_evidence":"margin",
                                "resolution_signal":"GM > 45%","resolution_horizon":"12m","path_status":"SUPPORTIVE"})
    v=db.load_variant_case("AAA")
    assert v["our_belief"] == "recovery" and v["path_status"] == "SUPPORTIVE"

    # Mock the complete market scan: assets -> snapshots -> SEC fundamentals -> scoring -> persisted run.
    save_settings({"sec_user_agent":"Market Forensics test qa@example.com","alpaca_feed":"auto",
                   "discovery_min_price":3.0,"discovery_min_dollar_volume":1_000_000,
                   "discovery_max_symbols":10,"discovery_fundamental_age_days":7})
    original = {
        "assets": discovery.marketdata.get_active_us_assets,
        "snap": discovery.marketdata.get_snapshots,
        "tmap": discovery.sec.ticker_map,
        "facts": discovery.sec.get_companyfacts,
        "sub": discovery.sec.get_submissions,
        "payload": discovery._fundamental_payload,
        "sleep": discovery.time.sleep,
    }
    try:
        assets=[{"ticker":"MKA","name":"Mock A","exchange":"NYSE","tradable":True,"shortable":True,"borrow_status":"EASY","has_options":True},
                {"ticker":"MKB","name":"Mock B","exchange":"NASDAQ","tradable":True,"shortable":True,"borrow_status":"EASY","has_options":True}]
        snaps={"MKA":{"latestTrade":{"p":50},"dailyBar":{"c":50,"v":500000},"prevDailyBar":{"c":49,"v":500000}},
               "MKB":{"latestTrade":{"p":80},"dailyBar":{"c":80,"v":500000},"prevDailyBar":{"c":82,"v":500000}}}
        discovery.marketdata.get_active_us_assets=lambda ua="": (assets,"mock_assets")
        discovery.marketdata.get_snapshots=lambda tickers,feed_mode="auto":(snaps,"mock_snapshots")
        discovery.sec.ticker_map=lambda ua:{"MKA":{"cik":"0001","name":"Mock A"},"MKB":{"cik":"0002","name":"Mock B"}}
        discovery.sec.get_companyfacts=lambda cik,ua:{}
        discovery.sec.get_submissions=lambda cik,ua:{"sic":"3149","sicDescription":"Synthetic"}
        def fp(t,facts):
            good=t=="MKA"; rev=10e9 if good else 8e9
            metrics={"revenue":rev,"operating_margin":.18 if good else .03,"net_margin":.12 if good else .02,
                     "fcf":1.2e9 if good else .1e9,"fcf_margin":.12 if good else .012,"roic":.20 if good else .03,
                     "cfo_ni":1.1 if good else .5,"cash":1e9,"debt":.5e9,"net_debt":-.5e9,
                     "diluted_shares":100e6,"share_change":-.01 if good else .08,"inventory":1e9 if good else 2e9,
                     "receivables":.7e9 if good else 1.6e9}
            fy={"revenue":rev,"revenue_growth":.10 if good else -.12,"operating_margin":metrics["operating_margin"],
                "net_margin":metrics["net_margin"],"fcf_margin":metrics["fcf_margin"],
                "inventory_rev":metrics["inventory"]/rev,"receivables_rev":metrics["receivables"]/rev}
            prv={"revenue":9e9,"operating_margin":.15 if good else .09,"net_margin":.10 if good else .06,
                 "fcf_margin":.09 if good else .07,"inventory_rev":.14 if good else .15,"receivables_rev":.08 if good else .10}
            return [],metrics,fy,prv,4.5 if good else 1.5
        discovery._fundamental_payload=fp
        discovery.time.sleep=lambda x:None
        res=discovery.start_scan(True)
        deadline=time.time()+5
        run=None
        while time.time()<deadline:
            run=discovery.latest_run()
            if run and run.get("status") not in ("QUEUED","RUNNING"):
                break
            time.sleep(.02)
        assert run and run["status"]=="PASS", run
        assert db.discovery_row("MKA") and db.discovery_row("MKB")
    finally:
        discovery.marketdata.get_active_us_assets=original["assets"]
        discovery.marketdata.get_snapshots=original["snap"]
        discovery.sec.ticker_map=original["tmap"]
        discovery.sec.get_companyfacts=original["facts"]
        discovery.sec.get_submissions=original["sub"]
        discovery._fundamental_payload=original["payload"]
        discovery.time.sleep=original["sleep"]


def synthetic_market_data_resilience():
    from market_forensics import db, marketdata
    db.init_db()
    tables={r["name"] for r in db.query("SELECT name FROM sqlite_master WHERE type='table'")}
    assert "price_checks" in tables
    original={
        "alpaca_ready":marketdata.alpaca_ready,
        "settings":marketdata.load_settings,
        "secrets":marketdata.load_market_data_secrets,
        "ibkr_bars":marketdata._ibkr_daily_bars,
        "refs":marketdata.reference_prices,
        "paged":marketdata._massive_paged,
    }
    try:
        marketdata.alpaca_ready=lambda:False
        marketdata.load_settings=lambda:{"market_data_order":["ALPACA","IBKR","TIINGO","ALPHA_VANTAGE"],"ibkr_enabled":True,"price_crosscheck_warn_pct":.005,"price_crosscheck_fail_pct":.02}
        marketdata.load_market_data_secrets=lambda:{}
        marketdata._ibkr_daily_bars=lambda ticker,days:[{"date":"2026-01-05","open":100,"high":102,"low":99,"close":101,"volume":1000000,"trade_count":0,"vwap":101}]
        bars,provider=marketdata.get_daily_bars("TEST",30,"auto")
        assert provider=="ibkr" and bars[-1]["close"]==101

        # If every external source is unavailable, last-good SQLite continuity is explicit and stale-safe.
        db.upsert_many("daily_bars",[{"ticker":"CACHE","trade_date":"2026-01-05","open":50,"high":51,"low":49,"close":50,"volume":1000,"trade_count":10,"vwap":50,"feed":"alpaca_sip","updated_at":"2026-01-05T22:00:00+00:00"}],["ticker","trade_date"])
        marketdata.load_settings=lambda:{"market_data_order":["ALPACA","IBKR","TIINGO","ALPHA_VANTAGE"],"ibkr_enabled":False,"price_crosscheck_warn_pct":.005,"price_crosscheck_fail_pct":.02}
        cached,provider2=marketdata.get_daily_bars("CACHE",30,"auto")
        assert provider2=="sqlite_cache" and cached[-1]["close"]==50

        marketdata.reference_prices=lambda *a,**k:[
            {"provider":"ALPACA_SIP","price":100.0,"asof":"2026-01-05","quality":"MODEL_INPUT_BAR","is_primary":True},
            {"provider":"IBKR","price":100.2,"asof":"2026-01-05","quality":"TOP_OF_BOOK"},
            {"provider":"TIINGO","price":100.1,"asof":"2026-01-05","quality":"EOD"},
        ]
        chk=marketdata.price_cross_check("TEST",100,"2026-01-05","alpaca_sip")
        assert chk["status"]=="PASS",chk
        marketdata.store_price_check("TEST",chk)
        stored_check=marketdata.latest_price_check("TEST")
        assert stored_check["status"]=="PASS"
        assert all(r.get("comparable") in (0,1,None) for r in stored_check.get("sources",[]))
        assert any(r.get("comparable")==1 for r in stored_check.get("sources",[]))

        marketdata.reference_prices=lambda *a,**k:[
            {"provider":"ALPACA_SIP","price":100.0,"asof":"2026-01-05","quality":"MODEL_INPUT_BAR","is_primary":True},
            {"provider":"IBKR","price":105.0,"asof":"2026-01-05","quality":"TOP_OF_BOOK"},
        ]
        chk2=marketdata.price_cross_check("TEST",100,"2026-01-05","alpaca_sip")
        assert chk2["status"]=="FAIL",chk2

        marketdata.load_market_data_secrets=lambda:{"MASSIVE_API_KEY":"test"}
        ts=int(datetime(2026,1,5,15,0,tzinfo=timezone.utc).timestamp()*1e9)
        def fake_paged(path,params,key):
            if "/trades/" in path:return [{"sip_timestamp":ts,"price":100.1,"size":500}]
            return [{"sip_timestamp":ts-1_000_000,"bid_price":100.0,"ask_price":100.2,"bid_size":10,"ask_size":12}]
        marketdata._massive_paged=fake_paged
        trades,quotes,feed=marketdata.get_session_trades_quotes("TEST",date(2026,1,5),"auto")
        assert feed=="massive_sip" and len(trades)==1 and len(quotes)==1
    finally:
        marketdata.alpaca_ready=original["alpaca_ready"]
        marketdata.load_settings=original["settings"]
        marketdata.load_market_data_secrets=original["secrets"]
        marketdata._ibkr_daily_bars=original["ibkr_bars"]
        marketdata.reference_prices=original["refs"]
        marketdata._massive_paged=original["paged"]

def point_in_time_validation_regression():
    from market_forensics import backtest
    sample = backtest.leakage_self_test()
    assert sample.get("pass"), sample
    kept = sample.get("kept") or []
    assert len(kept) == 1 and kept[0].get("filed") == "2024-02-01"

def reliability_score_regression():
    from market_forensics import backtest, db
    rows=[]
    for i in range(6):
        rows.append({
            "status":"COMPLETE", "price_range_hit": i != 0, "direction_hit": i < 5,
            "beat_no_change_baseline": i < 4, "base_abs_error": [0.12,0.16,0.18,0.22,0.24,0.28][i],
            "base_signed_error": [0.02,0.04,-0.03,0.08,0.11,-0.05][i],
            "growth_thesis_hit": i < 5, "net_margin_thesis_hit": i < 4, "fcf_margin_thesis_hit": i < 4,
            "thesis_status": "SUPPORTED" if i < 4 else "MIXED", "model_call": "LONG" if i < 3 else "NEUTRAL",
        })
    full=backtest.summarize(rows); short=backtest.summarize(rows[:2])
    assert 0 <= full["reliability_score"] <= 100
    assert full["sample_confidence"] == "HIGH"
    assert short["sample_confidence"] == "LOW" and short["reliability_label"].startswith("LOW SAMPLE")
    assert short["reliability_score"] < short["raw_reliability_score"], "small-sample penalty missing"
    for key in ("valuation_reliability_score","thesis_reliability_score","direction_reliability_score","bias_control_score"):
        assert full.get(key) is not None and 0 <= full[key] <= 100

    anchor={"close":400.0,"split_factor":4.0}
    outcome={"close":120.0,"split_factor":1.0}
    assert abs(backtest._comparable_outcome_price(anchor,outcome)-480.0) < 1e-9, "split normalization failed"

    db.init_db()
    result={
        "ticker":"TEST", "generated_at":datetime.now(timezone.utc).isoformat(),
        "model_version":"V3.1.8 / test", "start_year":2019, "end_year":2024, "call_threshold":.15,
        "rows":rows, "summary":full, "methodology":{},
    }
    db.save_validation_result("TEST", result)
    loaded=db.latest_validation_result("TEST")
    assert loaded and loaded["summary"]["reliability_score"] == full["reliability_score"]


def split_basis_router_regression():
    from market_forensics import marketdata, backtest
    original_ready=marketdata.alpaca_ready; original_get=marketdata.alpaca.get_daily_bars
    try:
        marketdata.alpaca_ready=lambda: True
        def fake_bars(ticker, lookback_days=500, feed_mode="auto", adjustment="split"):
            if adjustment == "raw":
                return ([
                    {"date":"2024-12-31","open":400,"high":400,"low":400,"close":400,"volume":1},
                    {"date":"2025-12-31","open":120,"high":120,"low":120,"close":120,"volume":1},
                ], "sip")
            return ([
                {"date":"2024-12-31","open":100,"high":100,"low":100,"close":100,"volume":4},
                {"date":"2025-12-31","open":120,"high":120,"low":120,"close":120,"volume":1},
            ], "sip")
        marketdata.alpaca.get_daily_bars=fake_bars
        bars,provider,verified=marketdata.get_validation_daily_bars("TEST",7305,"auto")
        assert verified and "raw" in provider and "split_basis" in provider
        b=backtest.normalize_bars(bars)
        a=backtest.price_on_or_before(b,date(2024,12,31)); o=backtest.price_on_or_before(b,date(2025,12,31))
        assert a["split_factor"] == 4 and o["split_factor"] == 1
        assert abs(backtest._comparable_outcome_price(a,o)-480) < 1e-9
    finally:
        marketdata.alpaca_ready=original_ready; marketdata.alpaca.get_daily_bars=original_get



def yahoo_long_history_parser_regression():
    """Verify raw price + explicit split events build a point-in-time comparable share basis."""
    from market_forensics import marketdata
    from datetime import datetime, timezone

    original_get=marketdata.requests.get
    class FakeResponse:
        status_code=200
        def json(self):
            t1=int(datetime(2019,12,31,tzinfo=timezone.utc).timestamp())
            ts=int(datetime(2020,8,31,tzinfo=timezone.utc).timestamp())
            t2=int(datetime(2020,12,31,tzinfo=timezone.utc).timestamp())
            return {"chart":{"result":[{
                "timestamp":[t1,t2],
                "indicators":{"quote":[{
                    "open":[99.5,130.0],"high":[101.25,135.0],"low":[97.5,125.0],
                    "close":[100.0,132.0],"volume":[1000,4000]
                }]},
                "events":{"splits":{str(ts):{
                    "date":ts,"numerator":4.0,"denominator":1.0,"splitRatio":"4:1"
                }}}
            }],"error":None}}
    try:
        marketdata.requests.get=lambda *a,**k: FakeResponse()
        rows=marketdata._yahoo_validation_bars("TEST",lookback_days=14610)
        assert len(rows)==2
        assert rows[0]["date"]=="2019-12-31" and abs(rows[0]["split_factor"]-4.0)<1e-12
        assert rows[1]["date"]=="2020-12-31" and abs(rows[1]["split_factor"]-1.0)<1e-12
        assert abs(rows[0]["close"]-400.0)<1e-12, "Validate must retain raw contemporaneous close"
    finally:
        marketdata.requests.get=original_get

def financial_math_and_basis_regression():
    """Property-style checks for split/share basis, debt, DCF and TTM math."""
    from datetime import date
    from market_forensics import backtest, fundamentals, sec, valuation

    # A future 4:1 split must NOT leak into a replay anchored before the split.
    full_bars=[
        {"date":"2024-02-15","trade_date":"2024-02-15","close":400.0,"raw_close":400.0,"split_factor":4.0,"basis_verified":True},
        {"date":"2024-12-31","trade_date":"2024-12-31","close":420.0,"raw_close":420.0,"split_factor":4.0,"basis_verified":True},
        {"date":"2025-06-01","trade_date":"2025-06-01","close":110.0,"raw_close":110.0,"split_factor":1.0,"basis_verified":True},
    ]
    old=backtest._bars_through(full_bars,date(2024,12,31))
    assert abs(float(old[-1]["split_factor"])-1.0)<1e-12
    assert abs(float(old[0]["split_factor"])-1.0)<1e-12, "future split leaked into historical replay"

    # Current normalization after the split: shares x4, EPS /4; market capitalization invariant.
    ttm={"ticker":"BASIS","period_key":"TTM","period_type":"TTM","period_end":"2024-12-31",
         "revenue":10_000.0,"gross_profit":4_000.0,"operating_income":1_500.0,"net_income":1_000.0,
         "cfo":1_300.0,"capex":300.0,"fcf":1_000.0,"cash":500.0,"debt":1_000.0,"equity":5_000.0,
         "diluted_shares":100.0,"diluted_shares_filed":"2024-04-15","shares_outstanding":100.0,"shares_outstanding_date":"2024-04-15",
         "diluted_eps_reported":10.0,"diluted_eps_filed":"2024-04-15","diluted_eps_source":"latest reported FY"}
    live_bars=[dict(x) for x in full_bars]
    live_bars[-1] |= {"date":"2025-09-15","trade_date":"2025-09-15","close":105.0,"raw_close":105.0,"split_factor":1.0,"basis_verified":True}
    m=fundamentals.metrics_from_rows([ttm],105.0,bars=live_bars)
    assert abs(m["diluted_shares"]-400.0)<1e-9 and abs(m["shares_outstanding"]-400.0)<1e-9
    assert abs(m["diluted_eps"]-2.5)<1e-9 and m["valuation_share_basis_verified"] and m["market_cap_basis_verified"]
    assert abs(m["market_cap"]-42_000.0)<1e-9

    # Valuation and current multiples are split-invariant when all quantities share one basis.
    a={"bear":{"growth":.02,"net_margin":.08,"operating_margin":.10,"fcf_margin":.08,"tax_rate":.21,"pe":16,"ev_sales":1.5,"target_fcf_yield":.07,"wacc":.11,"terminal_growth":.02,"prob":.25,"manual_override":None},
       "base":{"growth":.05,"net_margin":.10,"operating_margin":.13,"fcf_margin":.10,"tax_rate":.21,"pe":20,"ev_sales":2.0,"target_fcf_yield":.05,"wacc":.10,"terminal_growth":.025,"prob":.50,"manual_override":None},
       "bull":{"growth":.08,"net_margin":.12,"operating_margin":.16,"fcf_margin":.12,"tax_rate":.21,"pe":24,"ev_sales":2.5,"target_fcf_yield":.04,"wacc":.09,"terminal_growth":.03,"prob":.25,"manual_override":None},
       "weights":{"pe":.4,"ev_sales":.3,"fcf_yield":.3},"horizon_years":5}
    pre={"revenue":10_000.0,"net_debt":500.0,"valuation_shares":100.0,"diluted_shares":100.0,"share_change":0.0,"share_change_verified":True,
         "share_basis_checked":True,"share_basis_verified":True,"valuation_share_basis_verified":True,"share_denominator_kind":"DILUTED"}
    post=dict(pre);post.update(valuation_shares=400.0,diluted_shares=400.0)
    sv_pre,_=valuation.scenario_values(pre,a);sv_post,_=valuation.scenario_values(post,a)
    for sc in ("bear","base","bull"):
        assert abs(float(sv_pre[sc]["fair_value"])/4-float(sv_post[sc]["fair_value"]))<1e-8
        assert abs(float(sv_pre[sc]["dcf"])/4-float(sv_post[sc]["dcf"]))<1e-8

    mp_pre={"valuation_shares":100.0,"diluted_shares":100.0,"market_cap_shares":100.0,"shares_outstanding":100.0,
            "diluted_eps":10.0,"diluted_eps_sec":10.0,"net_income":1_000.0,"revenue":10_000.0,"fcf":1_000.0,"net_debt":500.0,
            "share_basis_checked":True,"valuation_share_basis_verified":True,"market_cap_basis_verified":True,"eps_basis_verified":True}
    mp_post=dict(mp_pre);mp_post.update(valuation_shares=400.0,diluted_shares=400.0,market_cap_shares=400.0,shares_outstanding=400.0,diluted_eps=2.5,diluted_eps_sec=2.5)
    cm1=valuation.current_multiples(mp_pre,100.0);cm2=valuation.current_multiples(mp_post,25.0)
    for k in ("pe","ev_sales","fcf_yield","market_cap"):
        assert abs(float(cm1[k])-float(cm2[k]))<1e-10, (k,cm1,cm2)
    bad=dict(mp_post);bad["market_cap_basis_verified"]=False
    cmb=valuation.current_multiples(bad,25.0)
    assert cmb["market_cap"] is None and cmb["ev_sales"] is None and cmb["fcf_yield"] is None and cmb["basis_status"]=="DATA REVIEW"

    # Weighted-average diluted shares are not allowed to masquerade as exact market-cap shares.
    ttm_no_out=dict(ttm);ttm_no_out["shares_outstanding"]=None;ttm_no_out["shares_outstanding_date"]=None
    m2=fundamentals.metrics_from_rows([ttm_no_out],105.0,bars=live_bars)
    assert m2["market_cap_share_kind"]=="DILUTED_FALLBACK" and not m2["market_cap_basis_verified"]
    cm_fallback=valuation.current_multiples(m2,105.0)
    assert cm_fallback["market_cap"] is not None and cm_fallback["basis_status"]=="VERIFIED FALLBACK" and cm_fallback["basis_confidence"]=="MEDIUM", cm_fallback

    # Debt: a comprehensive DebtCurrent already includes short borrowings; specific current LTD does not.
    rec=lambda val,tag:{"val":val,"first_val":val,"filed":"2025-02-01","first_filed":"2025-02-01","tag":tag}
    assert fundamentals._debt_from_records(rec(20,"ShortTermBorrowings"),rec(30,"DebtCurrent"),rec(70,"LongTermDebtNoncurrent"))==100
    assert fundamentals._debt_from_records(rec(20,"ShortTermBorrowings"),rec(10,"LongTermDebtCurrent"),rec(70,"LongTermDebtNoncurrent"))==100
    assert fundamentals._debt_from_records(rec(20,"ShortTermBorrowings"),None,None,rec(80,"LongTermDebt"),None)==100

    # Levered FCF DCF is an equity cross-check: changing net debt alone must not subtract debt twice.
    d1=valuation.dcf_value(1000,.05,.10,.10,.025,5,0,100)
    d2=valuation.dcf_value(1000,.05,.10,.10,.025,5,10_000,100)
    assert abs(d1-d2)<1e-12

    # Four-quarter sums must be temporally contiguous; a missing quarter cannot silently become TTM.
    good=[{"end":"2025-03-31"},{"end":"2025-06-30"},{"end":"2025-09-30"},{"end":"2025-12-31"}]
    badq=[{"end":"2024-12-31"},{"end":"2025-06-30"},{"end":"2025-09-30"},{"end":"2025-12-31"}]
    assert sec._valid_four_quarter_window(good) and not sec._valid_four_quarter_window(badq)

    # Missing fiscal years are annualized over the real gap, not treated as one-year growth.
    hist=[{"ticker":"GAP","period_key":"FY2020","period_type":"FY","fiscal_year":2020,"revenue":100.0},
          {"ticker":"GAP","period_key":"FY2022","period_type":"FY","fiscal_year":2022,"revenue":121.0},
          {"ticker":"GAP","period_key":"TTM","period_type":"TTM","revenue":121.0}]
    gm=fundamentals.metrics_from_rows(hist,100.0)
    assert abs(float(gm["recent_growth"])-.10)<1e-10, gm["recent_growth"]

    # Equivalent SEC tag migration: current view uses the newest comparative restatement while
    # PIT retains the first value that was actually public.
    facts={"facts":{"us-gaap":{
        "RevenueFromContractWithCustomerExcludingAssessedTax":{"units":{"USD":[
            {"form":"10-K","start":"2022-01-01","end":"2022-12-31","filed":"2023-02-15","val":100.0,"accn":"a"}]}},
        "SalesRevenueNet":{"units":{"USD":[
            {"form":"10-K","start":"2022-01-01","end":"2022-12-31","filed":"2024-02-15","val":110.0,"accn":"b"}]}}
    }}}
    ar=sec.annual_series(facts,[('us-gaap','RevenueFromContractWithCustomerExcludingAssessedTax'),('us-gaap','SalesRevenueNet')],years=5)
    assert len(ar)==1 and ar[0]['val']==110.0 and ar[0]['first_val']==100.0 and ar[0]['first_filed']=='2023-02-15', ar

    # Auto fair value must not chase the current market price. Historical calibration and
    # fundamental regime may influence multiples; the latest quote is diagnostics only.
    base_metrics={"revenue":1000.0,"net_income":100.0,"operating_margin":.15,"net_margin":.10,"fcf":100.0,"fcf_margin":.10,
                  "cagr3":.05,"tax_rate":.21,"cfo_ni":1.0,"valuation_shares":100.0,"diluted_shares":100.0,
                  "share_basis_checked":False,"share_change":0.0,"share_change_verified":True}
    fund=[];bars=[]
    for y,px in [(2020,10),(2021,11),(2022,12),(2023,13)]:
        filed=f"{y+1}-02-15";fund.append({"period_type":"FY","fiscal_year":y,"period_filed":filed,"period_end":f"{y}-12-31",
            "pit_revenue":1000*(1.05**(y-2020)),"pit_net_income":100*(1.05**(y-2020)),"pit_operating_income":150*(1.05**(y-2020)),
            "pit_fcf":100*(1.05**(y-2020)),"pit_diluted_shares":100.0,"pit_diluted_eps":1.0*(1.05**(y-2020)),
            "pit_cash":100.0,"pit_debt":200.0,"pit_shares_outstanding":100.0,"pit_shares_outstanding_date":f"{y}-12-31"})
        for d in range(5):
            bars.append({"date":f"{y+1}-02-{15+d:02d}","raw_close":px,"close":px,"split_factor":1.0,"basis_verified":True})
    bars_low=bars+[{"date":"2025-09-15","close":10.0,"raw_close":10.0,"split_factor":1.0,"basis_verified":True}]
    bars_high=bars+[{"date":"2025-09-15","close":100.0,"raw_close":100.0,"split_factor":1.0,"basis_verified":True}]
    aa,_=valuation.smart_assumptions(base_metrics,fund,bars_low,'Generic')
    bb,_=valuation.smart_assumptions(base_metrics,fund,bars_high,'Generic')
    for sc in ('bear','base','bull'):
        for key in ('pe','ev_sales','target_fcf_yield'):
            assert abs(float(aa[sc][key])-float(bb[sc][key]))<1e-12, (sc,key,aa[sc][key],bb[sc][key])


def v316_recovery_regression():
    """Recovery-release invariants: portfolio-before-thesis, screener-cache migration, management parser and +1Y price convention."""
    from market_forensics import db, discovery, management, backtest
    db.init_db()

    # A real position must exist independently from research Coverage.
    t="PORTONLY"
    db.delete_portfolio_position(t)
    db.remove_from_coverage(t)
    db.upsert_portfolio_position(t,"LONG",123,45.50,"consumer","existing holding")
    pos=db.portfolio_position(t)
    assert pos and pos["side"]=="LONG" and abs(float(pos["shares"])-123)<1e-12
    assert db.coverage_row(t) is None, "Portfolio save must not create a thesis/Coverage record"
    assert t in db.all_workspace_tickers()
    db.upsert_portfolio_position(t,"SHORT",80,52.25)
    pos=db.portfolio_position(t)
    assert pos["side"]=="SHORT" and abs(float(pos["avg_cost"])-52.25)<1e-12
    db.delete_portfolio_position(t)
    assert db.portfolio_position(t) is None

    # Legacy 3.1.2 discovery cache must refresh once; a 3.1.8 checked cache must not loop forever.
    fresh=datetime.now(timezone.utc).isoformat()
    base={"fundamentals_updated_at":fresh,"revenue":100.0,"share_basis_checked":1}
    assert discovery._needs_fundamentals({**base,"screen_model_version":"3.1.2"},7,False)
    assert not discovery._needs_fundamentals({**base,"screen_model_version":"3.1.8"},7,False)

    # V3.1.8 current-target recovery: split ledger verification is independent from full raw/adjusted OHLC proof.
    from market_forensics import marketdata, fundamentals, valuation
    _orig_events=marketdata._yahoo_split_events
    try:
        marketdata._yahoo_split_events=lambda ticker,start_date=None: [(date(2025,6,10),4.0)]
        _bars=marketdata._enrich_split_factor_verification("BASIS",[
            {"date":"2025-04-01","close":100.0,"raw_close":400.0,"split_factor":1.0,"basis_verified":False,"price_basis":"unverified OHLC"},
            {"date":"2026-09-14","close":120.0,"raw_close":120.0,"split_factor":1.0,"basis_verified":False,"price_basis":"unverified OHLC"},
        ])
        assert _bars[0]["split_factor_verified"] and abs(float(_bars[0]["split_factor"])-4.0)<1e-12
        assert not _bars[0]["basis_verified"], "split-ledger proof must not pretend raw historical OHLC is verified"

        # The exact user-facing recovery case: current Bear/Base/Bull must NOT be blocked merely
        # because full historical OHLC basis is unverified when the split ledger itself is proven.
        ttm_basis={"ticker":"BASIS","period_key":"TTM","period_type":"TTM","period_end":"2023-12-31",
                   "revenue":10000.0,"gross_profit":4000.0,"operating_income":1500.0,"net_income":1000.0,
                   "cfo":1300.0,"capex":300.0,"fcf":1000.0,"cash":500.0,"debt":1000.0,"equity":5000.0,
                   "diluted_shares":100.0,"diluted_shares_filed":"2025-04-01",
                   "shares_outstanding":100.0,"shares_outstanding_date":"2025-04-01"}
        mm=fundamentals.metrics_from_rows([ttm_basis],120.0,bars=_bars)
        assert mm.get("valuation_share_basis_verified") and abs(float(mm.get("valuation_shares"))-400.0)<1e-9, mm
        aa={"bear":{"growth":.02,"net_margin":.08,"operating_margin":.10,"fcf_margin":.08,"tax_rate":.21,"pe":16,"ev_sales":1.5,"target_fcf_yield":.07,"wacc":.11,"terminal_growth":.02,"prob":.25,"manual_override":None},
            "base":{"growth":.05,"net_margin":.10,"operating_margin":.13,"fcf_margin":.10,"tax_rate":.21,"pe":20,"ev_sales":2.0,"target_fcf_yield":.05,"wacc":.10,"terminal_growth":.025,"prob":.50,"manual_override":None},
            "bull":{"growth":.08,"net_margin":.12,"operating_margin":.16,"fcf_margin":.12,"tax_rate":.21,"pe":24,"ev_sales":2.5,"target_fcf_yield":.04,"wacc":.09,"terminal_growth":.03,"prob":.25,"manual_override":None},
            "weights":{"pe":.4,"ev_sales":.3,"fcf_yield":.3},"horizon_years":5}
        ss,_=valuation.scenario_values(mm,aa)
        assert all(ss[k].get("fair_value") is not None for k in ("bear","base","bull")), ss
    finally:
        marketdata._yahoo_split_events=_orig_events

    # V3.1.8 exact regression: a legacy OLD bar can be unverified while the recent 250-day
    # window is already verified. The repair must still backfill the old SEC-basis anchor.
    _orig_events=marketdata._yahoo_split_events
    try:
        marketdata._yahoo_split_events=lambda ticker,start_date=None: [(date(2024,6,10),4.0)]
        legacy=[{"date":"2023-12-29","close":100.0,"split_factor":1.0,"split_factor_verified":False,"basis_verified":False}]
        legacy += [{"date":(date(2025,1,1)+timedelta(days=i)).isoformat(),"close":120.0,"split_factor":1.0,"split_factor_verified":True,"basis_verified":False} for i in range(300)]
        repaired,ok=marketdata.ensure_split_factor_verification("BASIS",legacy)
        assert ok and repaired[0].get("split_factor_verified") and abs(float(repaired[0].get("split_factor"))-4.0)<1e-12, repaired[0]
    finally:
        marketdata._yahoo_split_events=_orig_events

    # V3.1.8 exact regression: an unverified weighted-average diluted fact must NOT block
    # verified current shares outstanding. Current equity value per share should use the
    # verified current share count as its denominator baseline.
    ttm_current={"ticker":"CURSH","period_key":"TTM","period_type":"TTM","revenue":1000.0,"gross_profit":450.0,
                 "operating_income":150.0,"net_income":100.0,"cfo":140.0,"capex":40.0,"fcf":100.0,"cash":100.0,"debt":200.0,"equity":500.0,
                 "diluted_shares":100.0,"diluted_shares_filed":"2024-01-01",
                 "shares_outstanding":400.0,"shares_outstanding_date":"2026-09-01"}
    current_bars=[{"date":"2023-12-29","close":100.0,"split_factor":4.0,"split_factor_verified":False,"basis_verified":False},
                  {"date":"2026-09-01","close":25.0,"split_factor":1.0,"split_factor_verified":True,"basis_verified":False},
                  {"date":"2026-09-15","close":25.0,"split_factor":1.0,"split_factor_verified":True,"basis_verified":False}]
    mm2=fundamentals.metrics_from_rows([ttm_current],25.0,bars=current_bars)
    assert mm2.get("valuation_share_basis_verified") and mm2.get("valuation_share_source")=="CURRENT_OUTSTANDING", mm2
    assert abs(float(mm2.get("valuation_shares"))-400.0)<1e-9, mm2
    ss2,_=valuation.scenario_values(mm2,aa)
    assert all(ss2[k].get("fair_value") is not None for k in ("bear","base","bull")), ss2

    # Validate/SEC parser: exact context ties must never fall through to comparing raw dicts.
    from market_forensics import sec
    facts_tie={"facts":{"us-gaap":{"WeightedAverageNumberOfDilutedSharesOutstanding":{"units":{"shares":[
        {"form":"10-Q","start":"2025-04-01","end":"2025-06-30","filed":"2025-08-01","accn":"A","val":100.0},
        {"form":"10-Q","start":"2025-04-01","end":"2025-06-30","filed":"2025-08-01","accn":"B","val":100.0}
    ]}}}}}
    tied=sec.latest_duration_fact(facts_tie,[("us-gaap","WeightedAverageNumberOfDilutedSharesOutstanding")])
    assert tied and abs(float(tied["val"])-100.0)<1e-12

    # Management: target year must beat comparison-year traps; adjusted/interim remain evidence-only.
    txt=("For fiscal 2026, we expect GAAP diluted EPS of $3.10 to $3.20 vs $2.80 in fiscal 2025. "
         "For fiscal 2026, we expect adjusted diluted EPS of $3.30 to $3.40. "
         "For Q1 fiscal 2026, we expect revenue growth of 9%.")
    rows=management.extract_management_statements(txt,ticker="MTEST",form="10-K",filed="2025-02-01",source_url="https://sec.test")
    gaap=[r for r in rows if r.get("metric_key")=="eps" and "GAAP diluted" in r.get("statement","")]
    assert gaap and gaap[0].get("target_fiscal_year")==2026 and float(gaap[0].get("extract_confidence") or 0)>=.80
    adjusted=[r for r in rows if r.get("metric_key")=="eps" and "adjusted diluted" in r.get("statement","")]
    assert adjusted and float(adjusted[0].get("extract_confidence") or 0)<.80
    interim=[r for r in rows if r.get("metric_key")=="revenue_growth" and "Q1" in r.get("statement","")]
    assert interim and float(interim[0].get("extract_confidence") or 0)<.80

    # Management delivery arithmetic: original GAAP diluted EPS must be compared on the same
    # share basis as the guidance, including an intervening stock split.
    mt="MGMTBASIS"
    db.upsert_many("fundamentals",[{
        "ticker":mt,"period_key":"FY2026","period_end":"2026-12-31","period_filed":"2027-02-15",
        "fiscal_year":2026,"period_type":"FY","revenue":1000.0,"gross_profit":400.0,"operating_income":150.0,"net_income":100.0,
        "cfo":130.0,"capex":30.0,"fcf":100.0,"diluted_shares":100.0,"pit_diluted_eps":1.575,"pit_diluted_eps_filed":"2027-02-15",
        "pit_revenue":1000.0,"pit_gross_profit":400.0,"pit_operating_income":150.0,"pit_net_income":100.0,"pit_cfo":130.0,"pit_capex":30.0,"pit_fcf":100.0,
        "source":"SEC","updated_at":db.now_utc()
    }],["ticker","period_key"])
    db.upsert_many("daily_bars",[
        {"ticker":mt,"trade_date":"2025-02-01","close":100.0,"raw_close":100.0,"split_adjusted_close":50.0,"split_factor":2.0,"basis_verified":1,"price_basis":"RAW","updated_at":db.now_utc()},
        {"ticker":mt,"trade_date":"2027-02-15","close":60.0,"raw_close":60.0,"split_adjusted_close":60.0,"split_factor":1.0,"basis_verified":1,"price_basis":"RAW","updated_at":db.now_utc()},
    ],["ticker","trade_date"])
    stmt=management.extract_management_statements("For fiscal 2026, we expect GAAP diluted EPS of $3.10 to $3.20.",ticker=mt,form="10-K",filed="2025-02-01",source_url="https://sec.test/mgmtbasis")[0]
    db.upsert_many("management_statements",[stmt],["ticker","statement_hash"])
    scored=management.evaluate_statements(mt)
    assert scored and scored[0]["validation_status"]=="MET" and abs(float(scored[0]["actual_value"])-3.15)<1e-9, scored

    late=management.extract_management_statements("For fiscal 2026, we expect GAAP diluted EPS of $3.10 to $3.20.",ticker=mt,form="8-K",filed="2027-01-15",source_url="https://sec.test/late",accession="late")[0]
    db.upsert_many("management_statements",[late],["ticker","statement_hash"])
    scored=management.evaluate_statements(mt)
    assert any(r.get("filed")=="2027-01-15" and r.get("validation_status")=="UNVERIFIED" and "after the target fiscal period ended" in (r.get("score_note") or "") for r in scored), scored

    # Validate: without a split the comparable +1Y price equals the actual year-end raw close.
    a={"close":100.0,"split_factor":1.0}; o={"close":112.0,"split_factor":1.0}
    assert abs(backtest._comparable_outcome_price(a,o)-112.0)<1e-12
    # With a 4:1 split, the raw close is rebased to the anchor share basis for model scoring.
    a={"close":400.0,"split_factor":4.0}; o={"close":120.0,"split_factor":1.0}
    assert abs(backtest._comparable_outcome_price(a,o)-480.0)<1e-12



def v316_correctness_recovery_matrix():
    """Explicit V3.1.8 correctness/recovery matrix requested for the release.

    These are deterministic regressions for economic invariance, current-vs-historical basis
    separation, conservative management scoring, provider fallbacks and portfolio independence.
    """
    from market_forensics import backtest, db, discovery, fundamentals, management, marketdata, sec, valuation

    assumptions={
        "bear":{"growth":.02,"net_margin":.08,"operating_margin":.10,"fcf_margin":.08,"tax_rate":.21,"pe":16,"ev_sales":1.5,"target_fcf_yield":.07,"wacc":.11,"terminal_growth":.02,"prob":.25,"manual_override":None},
        "base":{"growth":.05,"net_margin":.10,"operating_margin":.13,"fcf_margin":.10,"tax_rate":.21,"pe":20,"ev_sales":2.0,"target_fcf_yield":.05,"wacc":.10,"terminal_growth":.025,"prob":.50,"manual_override":None},
        "bull":{"growth":.08,"net_margin":.12,"operating_margin":.16,"fcf_margin":.12,"tax_rate":.21,"pe":24,"ev_sales":2.5,"target_fcf_yield":.04,"wacc":.09,"terminal_growth":.03,"prob":.25,"manual_override":None},
        "weights":{"pe":.4,"ev_sales":.3,"fcf_yield":.3},"horizon_years":5,
    }
    base_ttm={
        "ticker":"INV","period_key":"TTM","period_type":"TTM","period_end":"2024-12-31",
        "revenue":10_000.0,"gross_profit":4_000.0,"operating_income":1_500.0,"net_income":1_000.0,
        "cfo":1_300.0,"capex":300.0,"fcf":1_000.0,"cash":500.0,"debt":1_000.0,"equity":5_000.0,
        "diluted_shares":100.0,"diluted_shares_date":"2025-04-01","diluted_shares_filed":"2025-04-01",
        "shares_outstanding":100.0,"shares_outstanding_date":"2025-04-01","shares_outstanding_filed":"2025-04-15",
        "diluted_eps_reported":10.0,"diluted_eps_filed":"2025-04-01","diluted_eps_source":"latest reported FY",
    }

    # no split / 2:1 / 4:1 / 1:10 reverse split. Historical raw/adjusted OHLC proof is deliberately
    # FALSE: current valuation is allowed because the independent split ledger is verified.
    cases=[("NO_SPLIT",1.0,100.0,100.0),("SPLIT_2_1",2.0,50.0,200.0),("SPLIT_4_1",4.0,25.0,400.0),("REVERSE_1_10",0.1,1000.0,10.0)]
    economic_fv={}
    for name,factor,price,expected_shares in cases:
        bars=[
            {"date":"2025-04-01","trade_date":"2025-04-01","close":100.0,"raw_close":100.0,"split_adjusted_close":100.0/factor if factor else 100.0,"split_factor":factor,"split_factor_verified":True,"basis_verified":False,"feed":"test"},
            {"date":"2026-09-15","trade_date":"2026-09-15","close":price,"raw_close":price,"split_adjusted_close":price,"split_factor":1.0,"split_factor_verified":True,"basis_verified":False,"feed":"test"},
        ]
        m=fundamentals.metrics_from_rows([dict(base_ttm)],price,bars=bars)
        assert m["valuation_share_basis_usable"] and m["valuation_share_basis_status"]=="VERIFIED", (name,m)
        assert m["valuation_share_source"]=="CURRENT_OUTSTANDING" and m["valuation_share_confidence"]=="HIGH", (name,m)
        assert abs(float(m["valuation_shares"])-expected_shares)<1e-9, (name,m["valuation_shares"])
        assert not m["historical_price_basis_verified"] and m["split_ledger_verified"], (name,m)
        cm=valuation.current_multiples(m,price)
        assert abs(float(cm["market_cap"])-10_000.0)<1e-8, (name,cm)
        ev=float(cm["enterprise_value"])
        assert abs(ev-10_500.0)<1e-8, (name,ev)
        assert abs(float(cm["pe"])-10.0)<1e-8, (name,cm)
        assert abs(float(cm["ev_sales"])-1.05)<1e-10, (name,cm)
        assert abs(float(cm["fcf_yield"])-.10)<1e-10, (name,cm)
        sc,_=valuation.scenario_values(m,assumptions)
        assert all(sc[k]["fair_value"] is not None for k in ("bear","base","bull")), (name,sc)
        economic_fv[name]={k:float(sc[k]["fair_value"])*expected_shares for k in ("bear","base","bull")}
    for scen in ("bear","base","bull"):
        ref=economic_fv["NO_SPLIT"][scen]
        for name in economic_fv:
            assert abs(economic_fv[name][scen]-ref)<1e-7, (scen,name,economic_fv)

    # Current outstanding unavailable -> verified diluted-share fallback remains usable, disclosed MEDIUM.
    fallback_ttm=dict(base_ttm);fallback_ttm.update(shares_outstanding=None,shares_outstanding_date=None,shares_outstanding_filed=None)
    fbars=[
        {"date":"2025-04-01","trade_date":"2025-04-01","close":100.0,"split_factor":4.0,"split_factor_verified":True,"basis_verified":False},
        {"date":"2026-09-15","trade_date":"2026-09-15","close":25.0,"split_factor":1.0,"split_factor_verified":True,"basis_verified":False},
    ]
    fm=fundamentals.metrics_from_rows([fallback_ttm],25.0,bars=fbars)
    assert fm["valuation_share_source"]=="DILUTED_WA_FALLBACK" and fm["valuation_share_confidence"]=="MEDIUM" and fm["valuation_share_basis_usable"], fm
    fsc,_=valuation.scenario_values(fm,assumptions)
    assert all(fsc[k]["fair_value"] is not None for k in ("bear","base","bull")), fsc
    fcm=valuation.current_multiples(fm,25.0)
    assert fcm["basis_status"]=="VERIFIED FALLBACK" and fcm["market_cap"] is not None, fcm

    # Truly unverified corporate-action basis must fail closed with an exact reason, not the old generic gate.
    ubars=[
        {"date":"2025-04-01","trade_date":"2025-04-01","close":100.0,"split_factor":4.0,"split_factor_verified":False,"basis_verified":False},
        {"date":"2026-09-15","trade_date":"2026-09-15","close":25.0,"split_factor":1.0,"split_factor_verified":False,"basis_verified":False},
    ]
    um=fundamentals.metrics_from_rows([dict(base_ttm)],25.0,bars=ubars)
    assert not um["valuation_share_basis_usable"] and "Unable to verify split/reverse-split actions after share fact dated" in str(um["valuation_basis_issue"]), um
    usc,_=valuation.scenario_values(um,assumptions)
    assert all(usc[k]["fair_value"] is None for k in ("bear","base","bull")), usc
    assert all("DATA REVIEW:" in " ".join(usc[k]["flags"]) for k in ("bear","base","bull")), usc

    # A share fact newer than the current quote is not allowed to look ahead into a stale price.
    stale=dict(base_ttm);stale.update(shares_outstanding_date="2026-09-16",shares_outstanding_filed="2026-09-16")
    sm=fundamentals.metrics_from_rows([stale],25.0,bars=fbars)
    assert sm["valuation_share_source"]=="DILUTED_WA_FALLBACK" or not sm["valuation_share_basis_usable"], sm
    if sm["valuation_share_source"]=="DILUTED_WA_FALLBACK":
        assert "postdates current price" in str(sm.get("valuation_basis_issue") or ""), sm

    # Important buyback / strong dilution: economic share change is separate from split normalization,
    # is directionally preserved, and is capped at +/-15% for one-year forward valuation.
    verified_flat=[
        {"date":"2024-02-15","trade_date":"2024-02-15","close":100.0,"split_factor":1.0,"split_factor_verified":True,"basis_verified":False},
        {"date":"2025-02-15","trade_date":"2025-02-15","close":100.0,"split_factor":1.0,"split_factor_verified":True,"basis_verified":False},
        {"date":"2026-09-15","trade_date":"2026-09-15","close":100.0,"split_factor":1.0,"split_factor_verified":True,"basis_verified":False},
    ]
    def share_trend(old_sh,new_sh):
        rows=[
            {"ticker":"TREND","period_key":"FY2024","period_type":"FY","fiscal_year":2024,"revenue":9000.0,"diluted_shares":old_sh,"share_value_filed":"2024-02-15"},
            {"ticker":"TREND","period_key":"FY2025","period_type":"FY","fiscal_year":2025,"revenue":10000.0,"diluted_shares":new_sh,"share_value_filed":"2025-02-15"},
            dict(base_ttm),
        ]
        return fundamentals.metrics_from_rows(rows,100.0,bars=verified_flat)
    bm=share_trend(120.0,100.0); dm=share_trend(100.0,130.0)
    assert bm["share_change_verified"] and bm["share_change"]<-.15, bm
    assert dm["share_change_verified"] and dm["share_change"]>.15, dm
    bsc,_=valuation.scenario_values(bm,assumptions); dsc,_=valuation.scenario_values(dm,assumptions)
    assert abs(float(bsc["base"]["forward_diluted_shares"])-85.0)<1e-9, bsc["base"]
    assert abs(float(dsc["base"]["forward_diluted_shares"])-115.0)<1e-9, dsc["base"]

    # EPS versus NI/shares mismatch: P/E must use SEC-reported GAAP diluted EPS, not NI/share proxy.
    epsrow=dict(base_ttm);epsrow["diluted_eps_reported"]=8.0
    eps_bars=[{"date":"2025-04-01","trade_date":"2025-04-01","close":100.0,"split_factor":1.0,"split_factor_verified":True,"basis_verified":False}]+verified_flat
    em=fundamentals.metrics_from_rows([epsrow],100.0,bars=eps_bars)
    assert em["eps_basis_warning"] and abs(float(em["diluted_eps_proxy"])-10.0)<1e-9, em
    ecm=valuation.current_multiples(em,100.0)
    assert ecm["eps_source"]=="SEC_REPORTED_GAAP_DILUTED" and abs(float(ecm["pe"])-12.5)<1e-9, ecm

    # Missing debt/cash is method-specific, not a global valuation blocker. EV/Sales must fail
    # closed instead of silently assuming zero net debt, while P/E and FCF yield remain usable.
    no_debt=dict(base_ttm);no_debt.update(cash=None,debt=None)
    ndm=fundamentals.metrics_from_rows([no_debt],100.0,bars=eps_bars)
    ndcm=valuation.current_multiples(ndm,100.0)
    assert ndcm["market_cap"] is not None and ndcm["enterprise_value"] is None and ndcm["ev_sales"] is None, ndcm
    assert ndcm["pe"] is not None and ndcm["fcf_yield"] is not None, ndcm
    ndsc,_=valuation.scenario_values(ndm,assumptions)
    assert all(ndsc[k]["ev_sales"] is None for k in ("bear","base","bull")), ndsc
    assert all(ndsc[k]["fair_value"] is not None for k in ("bear","base","bull")), ndsc

    # Historical SEC restatement: current uses latest restated value, PIT retains first-public fact.
    facts_restated={"facts":{"us-gaap":{"Revenues":{"units":{"USD":[
        {"form":"10-K","start":"2023-01-01","end":"2023-12-31","filed":"2024-02-15","accn":"A","val":100.0},
        {"form":"10-K","start":"2023-01-01","end":"2023-12-31","filed":"2025-02-15","accn":"B","val":110.0},
    ]}}}}}
    ars=sec.annual_series(facts_restated,[("us-gaap","Revenues")],years=3)
    assert ars and ars[0]["val"]==110.0 and ars[0]["first_val"]==100.0 and ars[0]["first_filed"]=="2024-02-15", ars
    pit=backtest.filter_companyfacts_as_of(facts_restated,"2024-12-31")
    pitar=sec.annual_series(pit,[("us-gaap","Revenues")],years=3)
    assert pitar and pitar[0]["val"]==100.0, pitar

    # Provider price fallback: primary unavailable -> configured IBKR route remains usable and its
    # split ledger is independently verified. No web access is needed for this regression.
    orig_ready,orig_settings,orig_secrets=marketdata.alpaca_ready,marketdata.load_settings,marketdata.load_market_data_secrets
    orig_ibkr,orig_events=marketdata._ibkr_daily_bars,marketdata._yahoo_split_events
    try:
        marketdata.alpaca_ready=lambda: False
        marketdata.load_settings=lambda: {"market_data_order":["ALPACA","IBKR"],"ibkr_enabled":True}
        marketdata.load_market_data_secrets=lambda: {}
        marketdata._ibkr_daily_bars=lambda ticker,lookback: [{"date":"2026-09-15","close":77.0,"open":76.0,"high":78.0,"low":75.0,"volume":1000}]
        marketdata._yahoo_split_events=lambda ticker,start_date=None: []
        prow,provider=marketdata.get_daily_bars("FALL",500,"auto")
        assert provider=="ibkr" and prow and float(prow[-1]["close"])==77.0 and prow[-1]["split_factor_verified"], (provider,prow)
    finally:
        marketdata.alpaca_ready,marketdata.load_settings,marketdata.load_market_data_secrets=orig_ready,orig_settings,orig_secrets
        marketdata._ibkr_daily_bars,marketdata._yahoo_split_events=orig_ibkr,orig_events

    # Validate duplicate SEC facts: exact duplicate contexts/filings must never compare dict objects.
    facts_dup={"facts":{"us-gaap":{"WeightedAverageNumberOfDilutedSharesOutstanding":{"units":{"shares":[
        {"form":"10-Q","start":"2025-04-01","end":"2025-06-30","filed":"2025-08-01","accn":"A","val":100.0},
        {"form":"10-Q","start":"2025-04-01","end":"2025-06-30","filed":"2025-08-01","accn":"A","val":100.0},
    ]}}}}}
    dup=sec.latest_duration_fact(facts_dup,[("us-gaap","WeightedAverageNumberOfDilutedSharesOutstanding")])
    assert dup and float(dup["val"])==100.0, dup

    # Validate explicit no-split / 2:1 / 4:1 / reverse-split rebasing.
    assert backtest._comparable_outcome_price({"close":100,"split_factor":1},{"close":112,"split_factor":1})==112
    assert backtest._comparable_outcome_price({"close":200,"split_factor":2},{"close":55,"split_factor":1})==110
    assert backtest._comparable_outcome_price({"close":400,"split_factor":4},{"close":120,"split_factor":1})==480
    assert backtest._comparable_outcome_price({"close":10,"split_factor":0.1},{"close":120,"split_factor":1})==12

    # Ambiguous / non-comparable management guidance must remain evidence-only (never MET/MISS).
    ambiguous=management.extract_management_statements(
        "For fiscal 2026, we expect revenue of $1.0 billion and GAAP diluted EPS of $3.00.",
        ticker="AMB",form="10-K",filed="2025-02-15",source_url="https://sec.test/amb")
    assert ambiguous and all((not r.get("metric_key")) and float(r.get("extract_confidence") or 0)<.80 for r in ambiguous), ambiguous
    evidence=management.extract_management_statements(
        "For Q1 fiscal 2026, we expect adjusted free cash flow of $300 million.",
        ticker="AMB",form="10-Q",filed="2025-05-01",source_url="https://sec.test/evidence")
    assert evidence and all(float(r.get("extract_confidence") or 0)<.80 for r in evidence), evidence

    # Portfolio position exists independently of thesis / Coverage state.
    db.init_db(); pt="NO_THS"
    db.delete_portfolio_position(pt);db.remove_from_coverage(pt)
    db.upsert_portfolio_position(pt,"LONG",50,20.0)
    assert db.portfolio_position(pt) and db.coverage_row(pt) is None
    db.delete_portfolio_position(pt)

def v318_share_recovery_and_etf_scan_regression():
    from datetime import datetime, timezone
    from market_forensics import sec, fundamentals, discovery, db, marketdata

    def _facts(vals,end="2026-07-08",filed="2026-07-23",form="10-K"):
        return {"facts":{"dei":{"EntityCommonStockSharesOutstanding":{"units":{"shares":[
            {"val":v,"end":end,"filed":filed,"form":form,"accn":"same"} for v in vals
        ]}}}}}

    # Real-world shapes: NKE and UPS expose class A + class B cover-page facts.
    nke=sec.latest_unambiguous_instant(_facts([281_387_752,1_202_110_951]),fundamentals.TAGS["shares_outstanding"])
    assert nke and nke["aggregation_method"]=="MULTI_CLASS_SUM" and abs(float(nke["val"])-1_483_498_703)<1, nke
    ups=sec.latest_unambiguous_instant(_facts([101_432_177,749_349_405],"2026-07-17","2026-08-05","10-Q"),fundamentals.TAGS["shares_outstanding"])
    assert ups and abs(float(ups["val"])-850_781_582)<1, ups

    # If a filing provides class values plus an explicit non-dimensional framed total, use it once.
    framed=_facts([100_000_000,200_000_000,300_000_000])
    framed["facts"]["dei"]["EntityCommonStockSharesOutstanding"]["units"]["shares"][-1]["frame"]="CY2026Q2I"
    total=sec.latest_unambiguous_instant(framed,fundamentals.TAGS["shares_outstanding"])
    assert total and total["aggregation_method"]=="CONSOLIDATED_FRAME" and float(total["val"])==300_000_000, total

    # A genuinely complex fresh share fact must not cause a silent decade-old legacy-tag fallback.
    complex_facts={"facts":{
        "dei":{"EntityCommonStockSharesOutstanding":{"units":{"shares":[
            {"val":x,"end":"2026-07-01","filed":"2026-08-01","form":"10-Q","accn":"fresh"}
            for x in [10_000_000,20_000_000,30_000_000,40_000_000,50_000_000]
        ]}}},
        "us-gaap":{"CommonStockSharesOutstanding":{"units":{"shares":[
            {"val":999_000_000,"end":"2015-07-17","filed":"2015-07-24","form":"10-Q","accn":"old"}
        ]}}}
    }}
    assert sec.latest_unambiguous_instant(complex_facts,fundamentals.TAGS["shares_outstanding"]) is None

    # V3.1.8: the actual recovery path is the latest filing Inline XBRL, not Companyfacts.
    inline="""<html><body>
    <xbrli:context id="A"><xbrli:entity><xbrli:segment><xbrldi:explicitMember dimension="dei:StatementClassOfStockAxis">nke:ClassAMember</xbrldi:explicitMember></xbrli:segment></xbrli:entity><xbrli:period><xbrli:instant>2026-07-08</xbrli:instant></xbrli:period></xbrli:context>
    <xbrli:context id="B"><xbrli:entity><xbrli:segment><xbrldi:explicitMember dimension="dei:StatementClassOfStockAxis">nke:ClassBMember</xbrldi:explicitMember></xbrli:segment></xbrli:entity><xbrli:period><xbrli:instant>2026-07-08</xbrli:instant></xbrli:period></xbrli:context>
    <ix:nonFraction name="dei:EntityCommonStockSharesOutstanding" contextRef="A" unitRef="shares">281,387,752</ix:nonFraction>
    <ix:nonFraction name="dei:EntityCommonStockSharesOutstanding" contextRef="B" unitRef="shares">1,202,110,951</ix:nonFraction>
    </body></html>"""
    inline_fact=sec.parse_inline_cover_shares(inline,filed="2026-07-23",form="10-K")
    assert inline_fact and inline_fact["aggregation_method"]=="INLINE_XBRL_MULTI_CLASS_SUM"
    assert abs(float(inline_fact["val"])-1_483_498_703)<1, inline_fact

    # Exercise the real latest-filing resolver, not only the parser in isolation.
    old_sub,old_text=sec.get_submissions,sec._get_text
    try:
        sec.get_submissions=lambda cik,ua: {"filings":{"recent":{
            "form":["10-K"],"accessionNumber":["0000320187-26-000088"],
            "primaryDocument":["nke-20260531.htm"],"filingDate":["2026-07-15"],"reportDate":["2026-05-31"]}}}
        sec._get_text=lambda url,ua: inline
        resolved=sec.latest_cover_page_shares("NKE","MarketForensics test@example.com",limit=3,cik="0000320187")
        assert resolved and resolved["aggregation_method"]=="INLINE_XBRL_MULTI_CLASS_SUM" and resolved["filed"]=="2026-07-15", resolved
    finally:
        sec.get_submissions,sec._get_text=old_sub,old_text

    # The refresh ledger anchor must skip a decade-old instant fact and move to the recent
    # diluted-share filing; a fresh filing-level outstanding fact remains preferred.
    assert fundamentals.current_valuation_share_anchor({"shares_outstanding_date":"2010-02-17","diluted_shares_filed":"2026-07-28"},"2026-09-15")=="2026-07-28"
    assert fundamentals.current_valuation_share_anchor({"shares_outstanding_date":"2026-07-17","diluted_shares_filed":"2026-07-28"},"2026-09-15")=="2026-07-17"

    # Alpaca filters its request by process_date, not ex_date. The adapter deliberately requests
    # a lookback buffer and then filters on ex_date so a pre-announced post-fact split is not lost.
    from market_forensics import alpaca as alpaca_mod
    old_ca_get=alpaca_mod._get; seen_params=[]
    try:
        def _fake_ca(path,params=None,attempts=4):
            seen_params.append(dict(params or {}))
            return {"corporate_actions":{"forward_splits":[
                {"symbol":"NKE","ex_date":"2026-07-15","new_rate":"4","old_rate":"1"},
                {"symbol":"NKE","ex_date":"2026-06-15","new_rate":"2","old_rate":"1"}
            ],"reverse_splits":[]},"next_page_token":None}
        alpaca_mod._get=_fake_ca
        cae=alpaca_mod.get_split_events("NKE","2026-07-08","2026-09-15")
        assert cae==[(date(2026,7,15),4.0)], cae
        assert seen_params and seen_params[0]["start"]<"2026-07-08" and seen_params[0]["end"]=="2026-09-15", seen_params
    finally:
        alpaca_mod._get=old_ca_get

    # Current corporate-action verification is a separate ledger and may prove an empty interval.
    old_ready=marketdata.alpaca_ready; old_split=marketdata.alpaca.get_split_events
    try:
        marketdata.alpaca_ready=lambda: True
        marketdata.alpaca.get_split_events=lambda ticker,start,end: []
        ev=marketdata.current_split_basis_evidence("NKE","2026-07-08","2026-09-15")
        assert ev["status"]=="VERIFIED" and ev["split_factor"]==1.0 and ev["source"]=="ALPACA CORPORATE ACTIONS", ev
    finally:
        marketdata.alpaca_ready=old_ready; marketdata.alpaca.get_split_events=old_split

    # Evidence bypasses unverified historical bars for CURRENT valuation only.
    live_rows=[{"ticker":"NKE","period_key":"TTM","revenue":1e9,"gross_profit":4e8,"operating_income":1e8,"net_income":8e7,"cfo":1.2e8,"fcf":8e7,
                "cash":1e8,"debt":2e8,"equity":5e8,"receivables":1e8,"inventory":1e8,"payables":1e8,
                "shares_outstanding":1_483_498_703,"shares_outstanding_date":"2026-07-08","shares_outstanding_filed":"2026-07-23",
                "shares_outstanding_method":"INLINE_XBRL_MULTI_CLASS_SUM","shares_outstanding_components_json":"[281387752,1202110951]",
                "diluted_shares":1_500_000_000,"diluted_shares_date":"2026-05-31","diluted_shares_filed":"2026-07-23"}]
    live_bars=[{"trade_date":"2026-09-15","close":40.0,"feed":"alpaca","split_factor_verified":0,"basis_verified":0}]
    lm=fundamentals.metrics_from_rows(live_rows,bars=live_bars,current_basis_evidence={"status":"VERIFIED","anchor_date":"2026-07-08","verified_through":"2026-09-15","split_factor":1.0,"source":"ALPACA CORPORATE ACTIONS","actions":[]})
    assert lm["valuation_share_basis_usable"] and lm["valuation_share_basis_verified"] and lm["valuation_share_confidence"]=="HIGH", lm
    assert abs(float(lm["valuation_shares"])-1_483_498_703)<1 and lm["corporate_actions_since_share_fact"]=="None (verified)", lm

    # If Inline-XBRL recovery is unavailable, a decade-old instant share fact is never made
    # "current" just because split history is known. A recent verified diluted denominator is
    # the automatic MEDIUM-confidence fallback, so price cases remain visible without false precision.
    stale_rows=[dict(live_rows[0],shares_outstanding=900_000_000,shares_outstanding_date="2010-02-17",
                     shares_outstanding_filed="2010-02-24",shares_outstanding_method="LEGACY_SINGLE",
                     diluted_shares=860_000_000,diluted_shares_date="2026-06-30",diluted_shares_filed="2026-07-28")]
    sm=fundamentals.metrics_from_rows(stale_rows,bars=live_bars,current_basis_evidence={"status":"VERIFIED","anchor_date":"2026-07-28","verified_through":"2026-09-15","split_factor":1.0,"source":"ALPACA CORPORATE ACTIONS","actions":[]})
    assert sm["valuation_share_source"]=="DILUTED_WA_FALLBACK" and sm["valuation_share_confidence"]=="MEDIUM", sm
    assert sm["valuation_share_basis_usable"] and sm["valuation_share_basis_verified"], sm
    assert "too old" in str(sm.get("valuation_basis_issue") or "").lower(), sm

    # Manual current-basis recovery unlocks current valuation only and preserves auto diagnosis.
    m={"valuation_shares":100.0,"valuation_share_source":"UNVERIFIED_FALLBACK","valuation_share_confidence":"LOW",
       "valuation_share_basis_status":"DATA REVIEW","valuation_share_basis_usable":False,"valuation_share_raw":100.0,
       "valuation_share_fact_date":"2026-07-01","valuation_share_filed_date":"2026-08-01","valuation_split_factor":1.0,
       "corporate_actions_since_share_fact":"UNVERIFIED","corporate_action_basis":"UNVERIFIED",
       "valuation_basis_issue":"split ledger unavailable","current_price":50.0}
    ov={"mode":"USER_VERIFIED_NO_SPLIT","current_basis_shares":100.0,"basis_date":"2026-07-01",
        "source_note":"filing + corporate actions checked","confirmed":1,"updated_at":datetime.now(timezone.utc).isoformat()}
    mo=fundamentals.apply_share_basis_override(m,ov)
    assert mo["valuation_share_basis_usable"] and mo["valuation_share_basis_status"]=="USER VERIFIED" and mo["market_cap"]==5000.0, mo
    assert not mo["valuation_share_basis_verified"] and mo["auto_valuation_basis_issue"]=="split ledger unavailable", mo

    db.init_db(); db.save_current_share_basis_evidence("NKE",{"anchor_date":"2026-07-08","verified_through":"2026-09-15","split_factor":1.0,"source":"ALPACA CORPORATE ACTIONS","actions":[],"status":"VERIFIED","issue":""})
    saved_ev=db.current_share_basis_evidence("NKE"); assert saved_ev and saved_ev["status"]=="VERIFIED" and saved_ev["anchor_date"]=="2026-07-08"
    db.save_share_basis_override("NKE","USER_CURRENT_BASIS",1_483_498_703,"2026-07-08","SEC cover + actions",True)
    saved=db.share_basis_override("NKE")
    assert saved and saved["confirmed"]==1 and abs(float(saved["current_basis_shares"])-1_483_498_703)<1
    db.clear_share_basis_override("NKE"); assert db.share_basis_override("NKE") is None

    # Confirmed Companyfacts 404/N-A instruments are cached without generating a repeated scan error.
    etp={"screen_value_status":"SEC FUNDAMENTALS N/A","fundamentals_updated_at":datetime.now(timezone.utc).isoformat(),
         "revenue":None,"screen_model_version":"3.1.8"}
    assert discovery._needs_fundamentals(etp,7,False) is False
    assert discovery._needs_fundamentals(etp,7,True) is True
    assert sec.companyfacts_not_applicable({"company_name":"SPDR S&P 500 ETF TRUST","sic":"6726"}) is True
    assert sec.companyfacts_not_applicable({"company_name":"STATE STREET SPDR DOW JONES INDUSTRIAL AVERAGE ETF TRUST","sic":""}) is True
    assert sec.companyfacts_not_applicable({"company_name":"Example Manufacturing Inc.","sic":"3714"}) is False


def v319_financial_flows_price_and_symbol_regression():
    from market_forensics import financial_flows, marketdata, symbols, alpaca, db

    fy={
        "period_type":"FY","fiscal_year":2026,"revenue":1000.0,"gross_profit":400.0,
        "operating_income":200.0,"pretax":180.0,"tax":40.0,"net_income":140.0,
        "cfo":220.0,"capex":60.0,"fcf":160.0,"buybacks":70.0,"dividends":30.0,
    }
    inc=financial_flows.income_statement_flow(fy)
    assert inc["ok"] is True
    amounts={r["Line"]:r["Amount"] for r in inc["rows"]}
    assert amounts["Cost of revenue"]==600.0
    assert amounts["Operating expenses (aggregate)"]==200.0
    assert amounts["Net non-operating / other expense"]==20.0
    assert amounts["Income tax"]==40.0 and amounts["Net income"]==140.0
    # Every conventional branch must reconcile exactly at its source node.
    for src in set(x[0] for x in inc["links"]):
        assert sum(x[2] for x in inc["links"] if x[0]==src) >= 0

    cash=financial_flows.cash_flow_flow(fy)
    assert cash["ok"] is True
    camounts={r["Line"]:r["Amount"] for r in cash["rows"]}
    assert camounts["Non-cash + working-capital bridge"]==80.0
    assert camounts["Free cash flow"]==160.0
    assert camounts["Retained cash / other uses"]==60.0
    loss=dict(fy); loss["net_income"]=-10
    assert financial_flows.income_statement_flow(loss)["ok"] is True
    assert financial_flows.cash_flow_flow(loss)["ok"] is True

    # Symbol validation: a clean authoritative miss must never be silently saved.
    orig_query=db.query; orig_asset=alpaca.get_asset; orig_yahoo=symbols.requests.get
    try:
        db.query=lambda *a,**k: []
        alpaca.get_asset=lambda t: None
        class _Resp:
            status_code=404
            def json(self): return {}
        symbols.requests.get=lambda *a,**k: _Resp()
        bad=symbols.validate_ticker("THISDOESNOTEXIST")
        assert bad.status=="INVALID" and not bad.valid
        alpaca.get_asset=lambda t: {"ticker":str(t).upper(),"name":"Test Corp"}
        good=symbols.validate_ticker("TEST")
        assert good.valid and good.ticker=="TEST"
    finally:
        db.query=orig_query; alpaca.get_asset=orig_asset; symbols.requests.get=orig_yahoo

    # Current-price overlay is a display/decision layer only; it reads an Alpaca snapshot and does not
    # write a daily bar or mutate SEC/share-basis history.
    orig_snap=alpaca.get_snapshots
    try:
        marketdata._LIVE_PRICE_CACHE.clear()
        now=datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
        alpaca.get_snapshots=lambda tickers,feed_mode='auto',chunk_size=100: ({"TEST":{"latestTrade":{"p":123.45,"t":now}}},"iex")
        q=marketdata.current_price_overlay("TEST","auto",1)
        assert q and abs(q["price"]-123.45)<1e-9 and q["provider"]=="ALPACA IEX"
        assert q["quality"]=="LAST TRADE" and q["freshness"] in {"RECENT","DELAYED ~0 MIN"}
    finally:
        alpaca.get_snapshots=orig_snap; marketdata._LIVE_PRICE_CACHE.clear()


def v3110_financial_flow_statement_backfill_regression():
    from market_forensics import fundamentals, financial_flows, sec

    def make_facts(ambiguous_sga=False):
        facts={"facts":{"us-gaap":{}}}
        def flow(tag,val,unit="USD",extra=None):
            xs=[{"fy":2026,"fp":"FY","form":"10-K","filed":"2026-07-15",
                 "start":"2025-06-01","end":"2026-05-31","val":val}]
            if extra is not None:
                xs.append({"fy":2026,"fp":"FY","form":"10-K","filed":"2026-07-15",
                           "start":"2025-06-01","end":"2026-05-31","val":extra})
            facts["facts"]["us-gaap"][tag]={"units":{unit:xs}}
        # NIKE-style presentation: no standalone OperatingIncomeLoss, but Gross Profit and total SG&A.
        flow("RevenueFromContractWithCustomerExcludingAssessedTax",46.398e9)
        flow("GrossProfit",19.911e9)
        flow("SellingGeneralAndAdministrativeExpense",16.114e9,extra=(15.0e9 if ambiguous_sga else None))
        flow("IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest",3.900e9)
        flow("IncomeTaxExpenseBenefit",0.792e9)
        flow("NetIncomeLoss",3.108e9)
        flow("NetCashProvidedByUsedInOperatingActivities",2.868e9)
        flow("PaymentsToAcquirePropertyPlantAndEquipment",0.700e9)
        flow("WeightedAverageNumberOfDilutedSharesOutstanding",1.481e9,"shares")
        return facts

    rows=fundamentals.build_fundamentals("FLOW",make_facts())
    fy=next(r for r in rows if r.get("period_type")=="FY" and r.get("fiscal_year")==2026)
    assert fy["pretax"]==3.900e9 and fy["tax"]==0.792e9, fy
    assert fy.get("operating_income") is None, "core operating_income must remain untouched when SEC does not report it"
    assert abs(float(fy.get("flow_operating_income"))-3.797e9)<1, fy
    assert fy.get("flow_operating_income_method")=="DERIVED_GROSS_PROFIT_MINUS_SG&A"
    pack=financial_flows.income_statement_flow(fy)
    assert pack.get("ok") is True, pack
    assert abs(pack["resolved"]["operating_income"]-3.797e9)<1
    amounts={r["Line"]:r["Amount"] for r in pack["rows"]}
    assert abs(amounts["Other / non-operating income"]-0.103e9)<1
    assert abs(amounts["Income tax"]-0.792e9)<1
    assert "GROSS PROFIT MINUS SG&A" in pack.get("basis","")

    # Ambiguous dimension-flattened SG&A must fail closed rather than choose a random component.
    amb=sec.annual_series_unambiguous(make_facts(True),fundamentals.TAGS["flow_sga"],10)
    assert amb==[], amb
    rows2=fundamentals.build_fundamentals("FLOW2",make_facts(True))
    fy2=next(r for r in rows2 if r.get("period_type")=="FY")
    assert fy2.get("flow_operating_income") is None
    pack2=financial_flows.income_statement_flow(fy2)
    assert pack2.get("ok") is True, pack2
    assert pack2.get("resolved",{}).get("operating_income") is None
    assert "Operating income" not in [r.get("Line") for r in pack2.get("rows",[])]



def v3112_adaptive_financial_flows_regression():
    import math
    from market_forensics import financial_flows

    # UPS-style presentation: no Gross Profit; Revenue -> Operating Expenses -> Operating Income.
    ups={
        "period_type":"FY","fiscal_year":2025,"revenue":88_661e6,"gross_profit":None,
        "operating_income":7_867e6,"flow_operating_income":7_867e6,
        "flow_operating_income_method":"REPORTED_OPERATING_INCOME",
        "pretax":7_164e6,"tax":1_592e6,"net_income":5_572e6,
        "cfo":8_800e6,"capex":5_900e6,"fcf":2_900e6,"buybacks":1_000e6,"dividends":5_600e6,
    }
    p=financial_flows.income_statement_flow(ups)
    assert p["ok"] is True, p
    lines=[r["Line"] for r in p["rows"]]
    assert "Gross profit" not in lines
    assert "Operating expenses / costs (aggregate)" in lines
    assert "Operating income" in lines and "Pretax income" in lines and "Net income" in lines
    assert abs(next(r["Amount"] for r in p["rows"] if r["Line"]=="Operating expenses / costs (aggregate)") - 80_794e6) < 1

    # Missing Gross Profit + missing Pretax/Tax must still render, using explicit reconciliation.
    sparse=dict(ups); sparse.update({"gross_profit":None,"pretax":None,"tax":None})
    p2=financial_flows.income_statement_flow(sparse)
    assert p2["ok"] is True, p2
    lines2=[r["Line"] for r in p2["rows"]]
    assert "Gross profit" not in lines2 and "Pretax income" not in lines2
    assert "Remaining expenses / tax / reconciliation" in lines2

    # If Gross Profit exists but Operating Income/Pretax/Tax do not, skip optional levels safely.
    gp_only=dict(ups); gp_only.update({"gross_profit":40_000e6,"flow_operating_income":None,"operating_income":None,"pretax":None,"tax":None})
    p3=financial_flows.income_statement_flow(gp_only)
    assert p3["ok"] is True, p3
    lines3=[r["Line"] for r in p3["rows"]]
    assert "Gross profit" in lines3 and "Operating income" not in lines3 and "Net income" in lines3

    # Loss years remain visualizable without negative Sankey widths.
    loss=dict(ups); loss["net_income"]=-1_000e6; loss["pretax"]=-800e6; loss["tax"]=200e6
    pl=financial_flows.income_statement_flow(loss)
    assert pl["ok"] is True, pl
    assert any(r["Line"]=="Net loss" and r["Amount"]<0 for r in pl["rows"])
    assert all(v>0 for _,_,v in pl["links"])

    # Cash flow: Capex is optional; missing Capex no longer blocks the whole view.
    c=dict(ups); c["capex"]=None; c["fcf"]=None
    pc=financial_flows.cash_flow_flow(c)
    assert pc["ok"] is True, pc
    assert "Capex" not in [r["Line"] for r in pc["rows"]]

    # Negative CFO/FCF are shown as deficit/funding flows, not rejected.
    c2=dict(ups); c2.update({"cfo":-500e6,"capex":100e6,"fcf":-600e6})
    pc2=financial_flows.cash_flow_flow(c2)
    assert pc2["ok"] is True, pc2
    assert any(r["Line"]=="Cash from operations" and r["Amount"]<0 for r in pc2["rows"])
    assert all(v>0 for _,_,v in pc2["links"])

    # Fuzz optional-line combinations: Revenue + NI is enough for income flow; CFO is enough for cash flow.
    import random
    rng=random.Random(3112)
    for _ in range(10000):
        rev=rng.uniform(1e6,1e12)
        ni=rng.uniform(-0.20*rev,0.30*rev)
        oi=rng.uniform(0,max(0.0,0.45*rev)) if rng.random()>.25 else None
        gp=(rng.uniform(max(0.0,oi or 0.0),rev) if rng.random()>.40 else None)
        pt=(rng.uniform(0,max(0.0,oi or (gp or rev))) if rng.random()>.35 else None)
        row={"revenue":rev,"gross_profit":gp,"flow_operating_income":oi,"operating_income":None,"pretax":pt,"tax":None if rng.random()<.4 else rng.uniform(0,0.15*rev),"net_income":ni}
        pack=financial_flows.income_statement_flow(row)
        assert pack["ok"] is True, (row,pack)
        assert all(math.isfinite(v) and v>0 for _,_,v in pack["links"])


def app_test():
    from streamlit.testing.v1 import AppTest
    visible = [
        "pages/00_discovery.py", "pages/01_coverage_v3.py", "pages/02_decide_v3.py",
        "pages/03_research_v3.py", "pages/04_monitor_v3.py", "pages/05_validate_v3.py", "pages/05_portfolio_v3.py", "pages/06_settings_v3.py",
    ]
    advanced = [
        "pages/03_fundamentals.py", "pages/03_financial_flows.py", "pages/04_management_forecast.py", "pages/04_valuation.py",
        "pages/05_tape.py", "pages/06_monitoring.py", "pages/07_thesis.py", "pages/08_risk.py",
        "pages/09_portfolio.py", "pages/10_sources.py",
    ]
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=30).run()
    assert len(at.exception) == 0, [str(x.value) for x in at.exception]
    at.session_state["ticker"] = "TEST"
    for path in visible[1:] + advanced:
        at.switch_page(path).run(timeout=30)
        assert len(at.exception) == 0, f"{path}: {[str(x.value) for x in at.exception]}"

def optional_alpaca():
    # Test the user's REAL local secrets without exposing them. SIP failure is a warning because AUTO falls back to IEX.
    if not REAL_LOCALAPPDATA:
        print("       SKIP: LOCALAPPDATA unavailable")
        return
    secret_path=Path(REAL_LOCALAPPDATA)/"MarketForensics"/"alpaca_secrets.json"
    if not secret_path.exists():
        print("       SKIP: Alpaca secrets not installed yet")
        return
    import requests
    data=json.loads(secret_path.read_text(encoding="utf-8-sig"))
    key=data.get("ALPACA_API_KEY");secret=data.get("ALPACA_SECRET_KEY")
    assert key and secret
    headers={"APCA-API-KEY-ID":key,"APCA-API-SECRET-KEY":secret}
    r=requests.get("https://paper-api.alpaca.markets/v2/account",headers=headers,timeout=20)
    assert r.status_code==200, f"Paper HTTP {r.status_code}"
    end=(date.today()-timedelta(days=2));start=end-timedelta(days=5)
    r2=requests.get("https://data.alpaca.markets/v2/stocks/NKE/bars",headers=headers,params={"timeframe":"1Day","start":start.isoformat(),"end":end.isoformat(),"feed":"iex","limit":5},timeout=20)
    assert r2.status_code==200, f"IEX HTTP {r2.status_code}"
    rs=requests.get("https://data.alpaca.markets/v2/stocks/NKE/bars",headers=headers,params={"timeframe":"1Day","start":start.isoformat(),"end":end.isoformat(),"feed":"sip","limit":5},timeout=20)
    print(f"       Alpaca Paper 200 · IEX 200 · historical SIP HTTP {rs.status_code} (AUTO can fall back to IEX)")


print("MARKET FORENSICS V3.1.12 - SELF TEST")
print("================================")
check("Python dependencies", dependencies)
check("Application source / deprecation regression scan", source_regression)
check("Switchable Light / Dark theme configuration", theme_config_check)
check("Settings bounds / legacy-value normalization", settings_bounds_regression)
check("Core database + valuation + tape + gates + monitoring synthetic workflow", synthetic_core)
check("History-calibrated valuation + forensic signal engine", synthetic_v23_valuation_and_forensics)
check("Coverage intelligence + non-blocking background refresh jobs", synthetic_coverage_intelligence_and_background_jobs)
check("V3 Discovery + peer triangulation + variant case + mocked market scan", synthetic_v3_discovery_and_triangulation)
check("Market-data router + price cross-check + Massive tape fallback", synthetic_market_data_resilience)
check("Management accountability + five-year forecast + price reconciliation", synthetic_management_and_forecast)
check("Data audit + Word/PDF institutional research report", synthetic_exports_and_audit)
check("SEC/XBRL parser + working-capital reconstruction", synthetic_sec_xbrl)
check("Mocked end-to-end refresh pipeline", synthetic_refresh_pipeline)
check("Point-in-time anti-leakage validation engine", point_in_time_validation_regression)
check("Company-specific reliability score + persistence", reliability_score_regression)
check("Split-safe historical price basis router", split_basis_router_regression)
check("Long-history Yahoo split-event parser", yahoo_long_history_parser_regression)
check("Financial math + share/price-basis invariants", financial_math_and_basis_regression)
check("V3.1.8 correctness/recovery regression matrix retained", v316_correctness_recovery_matrix)
check("V3.1.8 recovery invariants retained: Portfolio / Screener / Management / Validate", v316_recovery_regression)
check("V3.1.8 share-basis recovery + ETF Companyfacts N/A retained", v318_share_recovery_and_etf_scan_regression)
check("V3.1.12 Financial Flows + ticker validation + auto price overlay", v319_financial_flows_price_and_symbol_regression)
check("V3.1.11 annual Pretax/Tax backfill + operating-income Sankey recovery", v3110_financial_flow_statement_backfill_regression)
check("V3.1.12 adaptive Financial Flows across filing presentations", v3112_adaptive_financial_flows_regression)
check("Real Streamlit app startup smoke test", app_test)
check("Alpaca Paper + market-data connection", optional_alpaca)

ok=all(checks)
print("\nSELF TEST RESULT:", "PASS" if ok else "FAIL")
try:
    shutil.rmtree(TEST_LOCAL,ignore_errors=True)
except Exception:
    pass
sys.exit(0 if ok else 1)
