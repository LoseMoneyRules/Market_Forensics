@echo off
call "%~dp0RUN_DASHBOARD.cmd"
