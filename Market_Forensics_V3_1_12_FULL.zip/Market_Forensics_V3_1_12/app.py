from __future__ import annotations

import streamlit as st

st.set_page_config(
    page_title="Market Forensics",
    page_icon="◈",
    layout="wide",
    initial_sidebar_state="expanded",
)

from market_forensics import db, discovery, jobs
from market_forensics import workstation as ws
from market_forensics import v3


db.init_db()
jobs.recover_orphaned_batches()
discovery.recover_orphaned_runs()
ws.inject_css()
v3.inject_css()

VISIBLE = [
    ("pages/00_discovery.py", "Discover", ":material/radar:", False, "", True),
    ("pages/01_coverage_v3.py", "Decision Queue", ":material/bookmarks:", False, "coverage", False),
    ("pages/02_decide_v3.py", "Decide", ":material/gavel:", True, "decide", False),
    ("pages/03_research_v3.py", "Research", ":material/science:", True, "research", False),
    ("pages/04_monitor_v3.py", "Monitor", ":material/monitoring:", True, "monitor", False),
    ("pages/05_validate_v3.py", "Validate", ":material/history:", True, "validate", False),
    ("pages/05_portfolio_v3.py", "Portfolio", ":material/account_balance:", False, "portfolio", False),
    ("pages/06_settings_v3.py", "Settings", ":material/settings:", False, "settings", False),
]

DETAIL = [
    ("pages/03_fundamentals.py", "Advanced · Fundamentals", ":material/query_stats:", "advanced-fundamentals"),
    ("pages/03_financial_flows.py", "Advanced · Financial Flows", ":material/account_tree:", "advanced-financial-flows"),
    ("pages/04_management_forecast.py", "Advanced · 5Y Operating Forecast", ":material/track_changes:", "advanced-management"),
    ("pages/04_valuation.py", "Advanced · Valuation Cases", ":material/payments:", "advanced-valuation"),
    ("pages/05_tape.py", "Advanced · Tape", ":material/show_chart:", "advanced-tape"),
    ("pages/06_monitoring.py", "Advanced · Monitoring", ":material/notifications:", "advanced-monitoring"),
    ("pages/07_thesis.py", "Advanced · Thesis & Bear Case", ":material/description:", "advanced-thesis"),
    ("pages/08_risk.py", "Advanced · Risk & Journal", ":material/shield:", "advanced-risk"),
    ("pages/09_portfolio.py", "Advanced · Portfolio", ":material/account_tree:", "advanced-portfolio"),
    ("pages/10_sources.py", "Advanced · Sources & Audit", ":material/fact_check:", "advanced-sources"),
]

page_objects = []
nav_items = []
for i, (path, title, icon, requires_ticker, url_path, is_default) in enumerate(VISIBLE):
    p = st.Page(path, title=title, icon=icon, url_path=(url_path or None), default=is_default)
    page_objects.append(p)
    nav_items.append({"page": p, "label": title, "icon": icon, "requires_ticker": requires_ticker, "url_path": url_path, "default": is_default})
for path, title, icon, url_path in DETAIL:
    page_objects.append(st.Page(path, title=title, icon=icon, url_path=url_path))

pg = st.navigation(page_objects, position="hidden")
v3.render_sidebar(nav_items, pg)
v3.render_icon_rail(nav_items)
pg.run()
