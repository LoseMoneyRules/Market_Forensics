# Market Forensics V3.1.12

## V3.1.12 Adaptive Financial Flows
Financial Flows now follows the issuer's actual annual statement presentation instead of assuming every company reports the same subtotal sequence.

For the **Income Statement**, only annual Revenue and Net Income/Loss are essential anchors. Gross Profit, Operating Income, Pretax Income and Income Tax are optional layers: when a subtotal exists and reconciles, it is shown; when it is absent (for example UPS does not present a consolidated Gross Profit subtotal), the Sankey bypasses it and uses an explicit aggregate/reconciliation bridge. No missing optional line blocks the whole chart.

For the **Cash Flow**, reported CFO is the essential anchor. Net Income, Capex and FCF improve the detail when available but are not mandatory. Negative CFO/FCF and Capex above CFO are represented as explicit cash-deficit / funding-gap nodes rather than being converted to misleading positive flows.

The existing large-number formatter remains active: `AUTO` shows K/M/B/T while the Sankey still uses raw dollars internally.

Financial Flows remains visualization-only. It does not change Valuation, Bear/Base/Bull, Decide, Validate, Management or stored SEC facts.

## V3.1.8 recovery rule — one path to an action
The application now separates **holdings**, **evidence** and **decision**. Portfolio positions can exist before research. Decision Queue is the master worklist. Decide must always end in a position-aware action after the same six checks: **Data → Value → Thesis → Timing → Risk → Action**. Bear/Base/Bull remain visible even when blocked; an unsafe case reads **DATA REVIEW** rather than disappearing.

Advanced pages belong to a parent area and include a **Back to Parent** control. Management accountability uses conservative parser v4: ambiguous, non-GAAP, interim-vs-annual or retrospectively filed promises remain evidence-only rather than becoming false MET/MISS observations.

Validate shows two distinct +1Y prices: **Year-end raw close**, the actual as-traded close on the final trading day on/before Dec 31, and **Comparable +1Y**, the same economic price translated to the anchor-year share basis for Bear/Base/Bull scoring across splits. With no split/reverse split, the two values are identical.

### V3.1.8 price-target recovery
Current Bear/Base/Bull no longer require proof of the entire historical OHLC adjustment convention. The automatic current-valuation path is now: **latest SEC 10-Q/10-K filing cover shares → current split/reverse-split ledger → normalized current-basis shares → Bear/Base/Bull**. For multi-class issuers the filing-level Inline XBRL facts are combined only when they share the same instant and class dimensions are unambiguous. Companyfacts remains the general fundamentals/PIT archive, but it is no longer allowed to force current valuation back to a decade-old single-class share fact.

If the latest exact outstanding-share fact cannot be recovered, Market Forensics next tries a recent weighted-average diluted-share denominator on a verified corporate-action basis and shows the targets as **MEDIUM confidence**. A stale old instant share count is not promoted merely because split history is known, because splits cannot correct later buybacks or issuance. Historical calibration and Validate remain stricter because they use old raw prices.

### Decision checklist editing
On **Decide**, open **Decision checklist — what is missing & where to edit**. Every gate now has an **Edit · ...** link to the exact evidence/assumption page. The checklist answers *is the investment process complete enough to trust the conclusion?*; it does not itself mean BUY. The position-aware action at the very top of Decide remains the final instruction after Data → Value → Thesis → Timing → Risk.

## V3.1.8 visual rule
V3.1.8 keeps the V3 workflow but restores the information that should never require a click.

**Always visible on Decide:** current price, Bear/Base/Bull, asymmetry, Business/Value/Expectations/Model Confidence/Variant/Path/Risk, core financial snapshot, forensic evidence, freshness and multi-driver price-implied expectations. The complete valuation-case assumptions and outputs are one expander away on Decide.

**Expandable:** full peer tables, all 16 process gates, detailed formulas, raw provenance and specialist engines.

The rule is: **conclusion → visible evidence → technical detail**. Important evidence is not hidden just to make the page look minimal.


## What changed in V3
V3 is designed to answer one question faster:

> **Where is the disagreement worth my time, and what must be true before I act?**

The normal workflow is now:

**Discover → Decision Queue → Decide → Research → Monitor → Validate → Portfolio**

The detailed accounting/valuation/tape pages still exist, but they are Advanced detail. You should not need them on every visit.

---

## 1. Discover — find the edge
Use Discover when you do **not** already know what stock to analyze.

### Scan Market
The background scan:
1. pulls active US equities from Alpaca;
2. keeps listed, liquid names with SEC identifiers;
3. downloads market snapshots in batches;
4. refreshes stale SEC fundamentals only when needed;
5. compares quality, trend, valuation and forensic evidence relative to peers and the broader universe;
6. assigns separate Long and Short **Dislocation Scores**;
7. surfaces only material dislocations.

The scan is intentionally lighter than deep research. It does **not** run the full tape, management history, 16-gate process or full valuation model on the entire market.

### Main long lenses
- `QUALITY AT DISCOUNT`: stronger business + unusually cheap relative valuation.
- `FUNDAMENTAL INFLECTION`: operating trend improving before valuation fully reflects it.
- `LONG DISLOCATION`: broader evidence points to a meaningful positive price/economics mismatch.

### Main short / trap lenses
- `POTENTIAL SHORT`: demanding valuation with weak or deteriorating economics.
- `SHORT DISLOCATION`: material negative price/economics mismatch.
- `VALUE TRAP`: apparently cheap but quality/trend weak.
- `FORENSIC DIVERGENCE`: cash/working-capital/share evidence conflicts with headline economics.

`NO EDGE`, `DATA REVIEW`, and context-only names are kept out of the two primary action lists.

### Promote to the Decision Queue
When a candidate deserves real work, choose **Promote to Decision Queue + deep refresh**. This launches the existing company-level research pipeline.

---

## 2. Decision Queue — everything that needs a decision
Decision Queue combines the permanent research list with real Portfolio positions, including positions entered before a thesis exists.

The main table emphasizes:
- system priority;
- current decision state;
- long/short focus;
- price and Base Fair Value;
- gap to Base;
- Business / Value / Path;
- freshness;
- next action.

Names with `NO EDGE / WAIT` are collapsed into **No-edge / middle names** by default.

### Refresh
- `Refresh All`: update active research names in the background.
- `Refresh Stale`: only names whose last successful refresh is stale.
- a failed refresh never makes stale data look fresh.

---

## 3. Decide — the page to read first for a company
This is the primary decision cockpit.

It reduces the research to one Decision plus seven lenses:

### BUSINESS
`GOOD / MIXED / BAD`

Based primarily on the independent business-quality validation and operating evidence.

### VALUE
`ATTRACTIVE / FAIR / EXPENSIVE`

Based on Base-value gap plus valuation confidence. A large model gap with poor confidence is not treated the same as a well-supported valuation gap.

### EXPECTATIONS
`FAVORABLE / BALANCED / DEMANDING`

Compares **three** price-implied drivers with our Base operating path: revenue CAGR, year-5 net margin and year-5 exit P/E. One growth estimate can no longer determine the label by itself.

### VARIANT
`POSITIVE EDGE / NEGATIVE EDGE / POSSIBLE / DEFINED UNPROVEN / UNPROVEN`

Variant is not “I like the stock.” It requires an explicit disagreement between what the market appears to believe and what you believe.

### PATH
`SUPPORTIVE / UNCLEAR / HOSTILE`

A cheap stock with no visible path can remain WATCH.

### MODEL CONFIDENCE
`STRONG / MODERATE / LIMITED / UNVALIDATED`

Combines current valuation confidence with the company-specific walk-forward Reliability Score. A weak or unvalidated model can keep a setup on WATCH even when valuation looks attractive.

### RISK
`CONTROLLED / UNRESOLVED / HIGH / DATA REVIEW`

`CONTROLLED` requires LOCKED numerical thesis invalidation plus an explicit sizing plan. Large Bear downside, leverage, concentration or audit failures can keep risk unresolved/high.

### DECISION
Examples:
- `LONG READY`
- `LONG WATCH`
- `SHORT READY`
- `SHORT WATCH`
- `VALUATION REVIEW`
- `DATA REVIEW`
- `NO EDGE / WAIT`

This is process guidance, not an automatic order instruction.

### Where to review every Bear / Base / Bull value
On **Decide**, open **Bear / Base / Bull — ALL valuation assumptions & outputs**. It shows, side by side, the exact inputs used for fair value: probability, growth, operating/net/FCF margin, tax, P/E, EV/Sales, target FCF yield, WACC, terminal growth and any manual override; plus each method value, DCF cross-check, P25/P75 range and final fair value.

Use **Open / edit all valuation scenario values** to go to Advanced · Valuation Cases and change them.

Important: Market Forensics also has a separate **5Y Operating Forecast Bear/Base/Bull** under Advanced · 5Y Operating Forecast. Those scenarios model the operating path and price-implied expectations; they are **not** the same inputs as the Valuation Cases that produce Bear/Base/Bull fair values.

### Four questions below the conclusion
Decide then shows:
- **Why now**
- **Why not yet**
- **What changes the decision**
- **What kills the thesis**

If these four blocks are unclear, the thesis is not yet clear enough.

---

## 4. Variant perception & catalyst/path
Inside Decide, explicitly save:

**Market believes** — what appears embedded in consensus/price/narrative.

**We believe** — your different view.

**Evidence for the disagreement** — why you think the difference is real.

**What resolves the disagreement?** — the evidence/event that can close the gap.

**Horizon** — expected time window.

**Path** — `SUPPORTIVE`, `UNCLEAR`, or `HOSTILE`.

A defined variant with no evidence remains `DEFINED UNPROVEN`.

---

## 5. External triangulation
Research includes an External Triangulation container.

### Automatic peers
Market Forensics prefers:
1. exact SEC SIC;
2. 2-digit SIC division if the exact set is too small;
3. market-cap similarity only as a tie-breaker.

It compares:
- Revenue Growth
- Operating Margin
- FCF Margin
- ROIC
- Inventory / Revenue
- Receivables / Revenue
- Share Change
- P/E
- EV / Sales
- FCF Yield

Possible signals include:
- COMPANY-SPECIFIC STRENGTH / WEAKNESS
- INDUSTRY-WIDE GROWTH / PRESSURE
- WORKING-CAPITAL DIVERGENCE
- RELATIVE VALUE + QUALITY
- RELATIVE PREMIUM WITHOUT QUALITY

### Manual relationship links
You can add:
- PEER
- CUSTOMER
- SUPPLIER
- DISTRIBUTOR
- INDUSTRY

Auto peers are hypotheses, not truth. Review important comparisons manually.

---

## 6. Research — expand only what you need
Research is now an **Evidence Room**, not a second Decide cockpit. It avoids repeating the same price/value/decision cards and instead organizes seven evidence sections:

1. **Business & numbers**
2. **External triangulation**
3. **Management + 5Y operating forecast**
4. **Valuation mechanics & scenario evidence**
5. **Tape & positioning**
6. **Thesis, bear case, invalidation & risk**
7. **Sources, provenance & revisions**

The decision lives in Decide. Research exists to prove or disprove it.

---

## 7. Advanced analytical pages
These engines are retained from the mature V2.7.1 stack:
- Business & Fundamentals
- Advanced · 5Y Operating Forecast
- Advanced · Valuation Cases
- Tape & Positioning
- Monitoring & Events
- Thesis & Bear Case
- Risk & Journal
- Portfolio & Exposure
- Sources & Data Audit

Use them for deep work, not routine navigation.

---

## 8. Monitor — exceptions, not noise
Monitor should contain only the variables that can strengthen, weaken or kill the thesis.

Prefer **3–7 thesis KPIs**.

The page emphasizes:
- What changed?
- KPI `FAIL / WATCH`
- next event/catalyst

Do not create dozens of KPIs merely because the data exists.

---

## 9. Portfolio
Portfolio shows only active `LONG / SHORT` names and their current Decision/Risk state. Use the Advanced Portfolio page for detailed concentration and sizing analysis.

---

## 10. Settings & Data
The simplified Settings page exposes Discovery controls:
- minimum price;
- minimum daily dollar volume;
- liquid universe size;
- SEC cache age.

Use **Sources & Audit** for:
- SEC User-Agent;
- Alpaca readiness;
- Light / Dark and number display settings where applicable;
- Data Audit & Provenance;
- source log;
- dossier export;
- full technical settings.

---

## 11. How to interpret Discovery scores
`Long Dislocation 82` does **not** mean an 82% probability that the stock rises.

Scores are ranking tools only. V3.1.8 also applies an **Absolute Value Gate** before a relative dislocation can enter the Top Long / Top Short queues. Discovery computes a conservative automatic screening Base Fair Value from current SEC fundamentals without loading the analyst's saved valuation assumptions. A relative bargain that sits roughly within ±10% of that screening fair value is labeled **NO EDGE** rather than promoted.

`Screen FV` is a triage control, not the final decision-grade target. The full Bear / Base / Bull valuation in Decide / Advanced · Valuation Cases remains the canonical company valuation.

A capital decision should still require:
- a real business thesis;
- expectations/variant view;
- valuation;
- strongest bear case;
- catalyst/path;
- numerical invalidation;
- risk-based position sizing;
- source quality;
- Decision Journal.

---

## 12. Reliability rules
1. `DATA REVIEW` takes precedence over attractive valuation.
2. An extreme current-vs-history multiple gap triggers valuation review rather than automatic mean reversion.
3. SEC revision alerts are review flags, not accusations.
4. Management Delivery measures only verifiable numeric execution, not honesty.
5. Tape is timing/context and remains separate from fundamental valuation.
6. Stale data weakens confidence and should be refreshed before action.
7. Do not move invalidation thresholds after the outcome is known.
8. Historical Reliability never creates a LONG/SHORT direction; it only raises or caps confidence in the current model.

---

## 13. Daily workflow
A practical routine:

**Morning / research start**
1. Open Discover.
2. Look only at the strongest long and short/trap dislocations.
3. Promote very few names.

**Company work**
4. Open Decide first.
5. Define the disagreement and path.
6. Open Research only to challenge the conclusion.
7. Run Validate before treating a model/company pair as decision-grade.
8. Use Advanced pages when a number needs to be audited.

**Existing positions**
9. Open Monitor.
10. Review thesis KPI exceptions and upcoming events.
11. Change size only when evidence/risk changed, not because price moved alone.

## V3.1.8 — Validate: point-in-time walk-forward test
Open **Validate** after selecting a company from the Decision Queue, Portfolio or research workspace.

The purpose is to answer a hard question: **if today's Market Forensics model had existed years ago, and it had only known what was public at that date, how often would its price range and operating thesis have been right one year later?**

For each calendar year-end anchor the app:
1. takes the last market close on or before December 31;
2. filters SEC Companyfacts to records whose original filing date was on or before that cutoff;
3. rebuilds fundamentals and historical valuation calibration from that restricted information set;
4. regenerates automatic Bear / Base / Bull assumptions with **no current saved assumptions**;
5. stores the historical price call and operating thesis;
6. unlocks the following year's price/fundamentals only for scoring.

### Price validation
The table compares Bear / Base / Bull with the actual +1Y price. The summary reports:
- **Bear–Bull range hit** — how often the realized price landed inside the historical scenario range;
- **Direction hit** — LONG finished higher, SHORT finished lower, or NEUTRAL stayed within the selected threshold;
- **Median Base error** — median absolute distance between historical Base target and actual +1Y price;
- **Beat no-change** — how often Base was more accurate than simply forecasting the same price as the anchor.

### Thesis validation
The app also checks whether the historical operating assumptions were directionally credible. It compares realized +1Y:
- revenue growth;
- net margin;
- FCF margin;

against the Bear/Bull bands that the model generated at the historical anchor. **SUPPORTED** means at least two of the three available drivers landed inside the scenario bands; **MIXED** means one did; **MISSED** means none did.

### Company-specific Reliability Score
Validate now converts the historical replay into a company/model **Reliability Score from 0 to 100**. It is not a probability that the next target will be correct. It measures how well the current Market Forensics rules have historically fit this specific company.

The score is decomposed into:
- **Valuation Reliability** — scenario-band hit rate plus Base-target accuracy;
- **Thesis Reliability** — operating-driver hit rate plus the percentage of historically supported thesis years;
- **Direction Reliability** — whether historical LONG / SHORT / NEUTRAL calls resolved in the expected direction;
- **Bias Control** — penalty for persistent overprediction or underprediction.

The composite is sample-adjusted. Fewer than 3 completed annual replays is always labeled **LOW SAMPLE**. Full sample credit is reached at 6 completed walk-forwards. The latest run is stored locally per ticker and is surfaced on **Decision → Historical Model Reliability**.

### How far back Validate can go
Validate now requests up to roughly **40 years of daily price history** and automatically reports the earliest price year, earliest modelable anchor and earliest completed +1Y replay for the selected company. The default first anchor is 2009 when enough data exists, rather than stopping around 2020.

The real limit is issuer-specific SEC point-in-time coverage, not an arbitrary UI cutoff. Older XBRL periods may expose only basic weighted-average shares, so V3.1.8 falls back from diluted to basic shares when necessary. A long-history raw-price fallback with explicit split events is used only for historical validation when the configured primary provider does not reach the requested year. Years before sufficient SEC filing-date data remain unavailable rather than being fabricated.

### Split-safe price validation
Stock splits can make a historical target look catastrophically wrong when an adjusted historical quote is compared with a pre-split share count. V3.1.8 prevents that unit mismatch when a verifiable corporate-action basis is available:
1. the model sees the **raw contemporaneous quote** at the historical anchor, matching the share basis in the SEC filing available then;
2. a parallel split-adjusted series is used only to derive the corporate-action conversion factor;
3. the +1Y raw market quote is translated back to the **anchor-year share basis** before target error and realized return are scored.

Validate displays **Corporate-action basis: VERIFIED** when that normalization was cross-checked. A fallback-provider run that cannot be cross-normalized is labeled **UNVERIFIED** and should be reviewed before using the Reliability Score as decision-grade evidence.

### Anti-leakage rules
- Future SEC filings and later restatements cannot enter an earlier replay.
- Today's saved valuation assumptions are never used historically.
- Manual thesis text is not backcast, because rewriting a subjective 2024 thesis with 2026 knowledge would create hindsight bias.
- The page contains an explicit anti-leakage self-test.

### Important limitation
This is the best available filing-date replay using SEC Companyfacts, not a commercial vintage-fundamentals database. It tests **today's model rules on historical information**. Strong historical results increase confidence in calibration; they do not prove future targets will be correct.

The current blended valuation target is tested on a rolling **+1 year** basis because the P/E, EV/Sales and FCF-yield components normalize one forward year. Multi-year reliability is measured by repeating the one-year test across many historical anchors rather than peeking forward from one anchor.

## V3.1.8 page-reading rule
For normal daily use, start with **Decide**. You should be able to read the current case without opening an expander:
price and Bear/Base/Bull, both core charts, operating metrics, six decision lenses, forensic positives/challenges/data alerts,
expectation gap, process readiness and freshness are visible immediately.

Use expanders only to challenge or edit the case. Use Advanced pages only when you need the full model, raw source trail or detailed workflow.

## V3.1.8 — Market-data backups and price check
Open **Settings → Market-Data Resilience**.

The normal daily-price path is:

**Alpaca → IBKR Gateway → Tiingo → Alpha Vantage → local last-good cache**

IBKR is disabled by default because Market Forensics should not wait on `localhost:5000` when Client Portal Gateway is not installed/running. Enable it only when you actually use an authenticated Gateway session.

Optional Tiingo, Alpha Vantage and Massive keys can be saved from the app. They are written to:

`%LOCALAPPDATA%\MarketForensics\market_data_secrets.json`

Leave password fields blank to keep existing values. Never paste API keys into chat.

The tape path is stricter:

**Alpaca trades/quotes → Massive trades/NBBO → LOW DATA**

If the app has only daily bars, valuation and fundamentals continue to work but tape/timing is not fabricated.

### Price cross-check
A full refresh performs the check automatically when enabled. You can also use **Cross-check current price** in Settings. The detail table shows Provider, Price, As-of, Quality, Comparable and Deviation.

A source from a different trading date is not used to create a hard FAIL. During a potentially partial US session, large differences are shown as WARN so delayed/partial bars are not confused with an actual bad price.

## V3.1.8 — Reports
Research Word and PDF are deliberately separate:
- **Prepare Word report** → editable `.docx`, four-page institutional research layout.
- **Prepare PDF report** → finished `.pdf`, four-page institutional research layout.

Tables and metric values use larger type than prior V3 builds, with less column compression and clearer section boundaries. Discovery adds **Prepare Discovery PDF**, producing a two-page **landscape** screening brief with readable long, short/value-trap and review/context tables.

## V3.1.8 — Branding
Settings -> **Branding** accepts a local PNG/JPG logo. A transparent PNG is preferred. The file is stored only in `%LOCALAPPDATA%\MarketForensics\branding` and is used in the sidebar and generated reports. **Remove logo** returns the product to the built-in MF mark. The app and report footer contains only **Lose Money Rules**.

## V3.1.8 — Collapsed navigation
When the Streamlit sidebar is collapsed, a small persistent icon rail remains on the left edge for Discover, Decision Queue, Decide, Research, Monitor, Validate, Portfolio and Settings. The selected ticker is carried in the link query string.

## V3.1.8 — Visual color rule
- Price / Bear / Base / Bull: neutral theme text (white in dark mode).
- Positive evidence / decisions: green accent.
- Negative / short / failure: red accent.
- Mixed / watch / uncertain: amber/yellow accent.
- Purple is intentionally excluded from the application and report palette.
- Cards and main panels use explicit borders; colored decision cards use matching border accents rather than relying only on text color.

### Share Basis Recovery (V3.1.8)

Current valuation first tries to establish the denominator automatically from the freshest usable SEC share fact and corporate actions after that fact. Same-date, same-filing multi-class `EntityCommonStockSharesOutstanding` facts are resolved as one economic denominator rather than forcing a fallback to an obsolete single-class record.

If automatic corporate-action verification is still unresolved, Decide exposes **Share Basis Recovery**. Use automatic refresh first. After that, you may (a) certify no split/reverse split after a sufficiently recent displayed SEC share fact, or (b) enter a separately verified current-basis share count, its basis/as-of date, and an evidence/source note. The resulting targets are shown as **USER VERIFIED / MEDIUM confidence**. The original SEC evidence and automatic failure reason remain preserved for audit. This override is used only for current valuation and is excluded from Validate and historical calibration.

A manual override is not a way to force a preferred valuation. It is appropriate only when you have independently checked that the entered denominator is on the same split/reverse-split basis as the current market price. Remove the override at any time to return to automatic verification.

### ETF / fund SEC fundamentals handling

Some scan vehicles and fund structures do not expose SEC Companyfacts in the same way as operating companies. A confirmed Companyfacts HTTP 404 is therefore stored as **SEC FUNDAMENTALS N/A** rather than counted as an issuer refresh failure. Other SEC, network, parsing, or stale-data errors continue to surface normally.