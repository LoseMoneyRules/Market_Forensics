# Market Forensics Changelog

## 3.1.12 — Adaptive Financial Flows
- Financial Flows no longer assumes every issuer reports Gross Profit, Operating Income, Pretax Income and Tax as the same mandatory sequence.
- Income Statement Sankey requires only annual Revenue + Net Income/Loss; optional subtotals are included when they reconcile and bypassed otherwise.
- UPS-style Revenue → Operating Expenses → Operating Income presentations render directly without a Gross Profit error.
- Missing Pretax/Tax/Operating Income produces explicit aggregate/reconciliation bridges instead of blocking the chart.
- Loss years are visualized with a signed Net Loss row and a positive-width deficit flow; negative widths are never fabricated.
- Cash Flow Sankey now treats NI and Capex as optional layers; CFO is the essential cash anchor. Negative CFO/FCF and Capex > CFO are represented with explicit funding/deficit nodes.
- Added 10,000-case optional-line fuzz regression plus UPS-style, sparse-statement, loss-year and negative-cash-flow tests.
- Valuation, Decide, Validate, Management and share-basis engines are unchanged.

# Market Forensics changelog

## 3.1.11 — Financial Flows number formatting

- Presentation-only release based on V3.1.10. No valuation, Decide, Validate, Management, SEC/share-basis, or Financial-Flows arithmetic changed.
- Financial Flows tables now display dollar amounts with the app's existing compact-number setting (`AUTO` = K/M/B/T), instead of long ungrouped raw dollar values.
- Sankey hover values now use the same compact money formatter while retaining raw numeric values internally for link widths and accounting math.
- Percentage columns use the existing readable percent formatter.

# Market Forensics Changelog

## 3.1.10 — Financial Flows Statement-Line Recovery

- Corrected the V3.1.9 annual fundamentals bug that explicitly overwrote FY `pretax` and `tax` with `None`. Annual Pretax Income and Income Tax are now backfilled from conservative consolidated SEC Companyfacts.
- Added `annual_series_unambiguous()` for Financial Flows. Dimension-flattened Companyfacts are accepted only when the latest filing has one unique value or one unique framed consolidated value; ambiguous periods fail closed instead of selecting a random component.
- Added a **Financial-Flows-only operating-income bridge**. Core `operating_income` used by valuation/Validate is not replaced. If a filer does not publish `OperatingIncomeLoss`, the Sankey may use exact SEC statement arithmetic in this order: Revenue − CostsAndExpenses; Gross Profit − OperatingExpenses; Gross Profit − SG&A (plus R&D when separately reported).
- SG&A fallback has an additional pretax reconciliation guard. If the implied operating bridge is not economically plausible, Financial Flows remains `DATA REVIEW` rather than forcing a diagram.
- Income Statement metrics now display the resolved Financial-Flows operating income when a safe bridge is used, and the Sankey basis states the derivation method.
- Existing V3.1.9 databases migrate in place. Companies already refreshed under V3.1.9 need **one Refresh** to backfill the corrected annual fields.
- Valuation, Bear/Base/Bull, Decide, Validate, Management, share-basis recovery, Portfolio, Scan and report engines are intentionally unchanged from V3.1.9.

## 3.1.9 — Financial Flows + Safe Current-Price Layer

- Added **Research → Financial Flows** as a hidden/detail Research page, preserving the main sidebar structure.
- Added year-selectable **Income Statement Sankey**: Revenue → cost of revenue → gross profit → aggregate operating expenses → operating income → non-operating bridge → pretax → tax/reconciliation → net income.
- Added year-selectable **Cash Flow Sankey**: Net income → exact CFO reconciliation → CFO → Capex → FCF → buybacks/dividends/residual uses. The app never invents a D&A/working-capital split that is not stored.
- Negative/non-monotonic years are shown as **DATA REVIEW** rather than converted into misleading positive-width flows.
- Added pre-save ticker validation for Research Queue, Portfolio, and manual peer links. Invalid/unresolved symbols are not persisted. Validation uses local resolved metadata, Alpaca, SEC mapping, and a public market-chart fallback.
- Added a current-price snapshot overlay for decision display. Decide and Portfolio rerun every 60 seconds while open; the snapshot is labeled with provider, timestamp, and freshness/delay state.
- The snapshot price is deliberately separate from historical bars, SEC facts, corporate-action/share-basis evidence, and Validate. It does not rewrite history.
- V3.1.8 valuation/share-basis/Validate/Management logic is retained; this release does not refactor those stable engines.

# Market Forensics — Changelog

## 3.1.8 — Filing-Level Share Recovery + Current Corporate-Action Ledger

- **Root cause fixed for UPS/NKE-style stale share facts.** Current valuation no longer relies on SEC Companyfacts alone for the latest outstanding-share denominator. Refresh now reads the newest 10-Q/10-K **Inline XBRL filing itself**, extracts `EntityCommonStockSharesOutstanding`, and deterministically sums class-level facts reported on the same instant when no consolidated total is present. Historical/PIT logic remains on Companyfacts.
- Added a separate **current corporate-action evidence ledger**. For the exact interval from the selected denominator anchor to the current quote, Market Forensics queries Alpaca Corporate Actions (`forward_split` / `reverse_split`) when configured and falls back to Yahoo split events. A successful empty ledger is valid evidence that no split occurred in the interval. This proof is independent from historical OHLC calibration.
- Added a **stale instant-share guard**. A years-old outstanding-share fact can no longer become “current” merely because its split history is known: split normalization cannot repair intervening buybacks or issuance. If filing-level recovery is unavailable, a recent verified diluted-share denominator is used automatically as **MEDIUM-confidence fallback**; otherwise the model shows an exact DATA REVIEW reason.
- Automatic **HIGH-confidence CURRENT_OUTSTANDING wins over any previously saved manual override**. Users do not need to delete an old recovery override after the automatic pipeline becomes healthy.
- **Share Basis Recovery remains a safe fallback**, not the primary path. A user can approve a recent SEC basis after independently checking no split, or enter separately verified current-basis shares. It is labelled `USER VERIFIED / MEDIUM`, preserves the automatic failure reason for audit, and is never used by Validate or historical calibration.
- Fixed the actual **Scan ETF/fund 404 branch**: the previous 3.1.7 handler referenced issuer metadata incorrectly in the exception path. Confirmed fund/ETF Companyfacts 404s (for structures such as SPY/DIA/MDY) are now classified `SEC FUNDAMENTALS N/A`; ordinary-company 404/network/parser failures remain visible.
- Scan only attempts filing-level share recovery when Companyfacts current shares are missing/stale, avoiding unnecessary filing downloads across the whole universe.
- Preserved all prior correctness protections: Bear/Base/Bull are separated from historical OHLC certification; Validate remains strict point-in-time with raw historical closes and split-safe comparable outcomes; Management ambiguous/non-comparable guidance remains evidence-only; debt/DCF/EPS/share-basis invariants remain enforced.
- Added regression coverage for Inline-XBRL multi-class recovery using real-world NKE/UPS share shapes, dedicated current split-ledger evidence, automatic stale-fact → diluted fallback, manual override isolation, automatic-overrides-manual precedence, ETF Companyfacts N/A handling, and the full split/no-split/reverse-split economic invariance matrix.

## 3.1.5 — Price Target Recovery + Decision Navigation Hardening

- **Critical V3.1.4 regression fixed:** an existing but unverified weighted-average diluted-share fact no longer overrides a verified current shares-outstanding fact. Bear/Base/Bull now use verified current outstanding shares as the primary equity-value denominator and diluted weighted-average shares only as a verified fallback.
- **Critical cache-repair regression fixed:** split-basis self-heal now repairs the full cached history needed by SEC filing dates, not just the most recent 250 trading days. This fixes the case where Refresh appeared successful but the filing-date share basis remained unverified and price cases stayed blocked.
- Decide now shows the actual per-share denominator source (`CURRENT OUTSTANDING` or `DILUTED WA FALLBACK`) and verification status directly below Core Price Cases.
- Fixed the over-strict price/share-basis gate that could block **Bear / Base / Bull** even after refresh. Current valuation now distinguishes the split/reverse-split proof needed for current per-share targets from the stronger raw-vs-adjusted OHLC proof required by historical calibration and Validate.
- Added an independent Yahoo split/reverse-split event ledger. A successful no-split lookup is also treated as verified. This can reconcile current SEC share denominators even when the primary quote provider cannot prove the full historical OHLC basis.
- Added `split_factor_verified` to daily-bar storage with in-place DB migration. Legacy/local cached bars can self-heal their corporate-action metadata without rewriting the quote, provider, or freshness timestamp.
- Kept historical calibration and Validate strict: point-in-time historical work still requires the stronger price-basis evidence where raw historical prices are used.
- Fixed a Validate replay crash caused by tied SEC contexts falling through to dictionary comparison; an issuer/year-specific replay error is now isolated instead of aborting the whole validation run.
- Restored the sidebar to **primary pages only**. Advanced/detail pages remain hidden from the main menu; when one is open, its owning parent is visually marked and a small breadcrumb identifies the current detail page. The `← Back to ...` control remains at the top.
- Replaced the opaque **Process gates + advanced detail** block with **Decision checklist — what is missing & where to edit**. Every gate has a direct `Edit` link to the exact page where its evidence or assumption is maintained.
- Clarified decision semantics: process gates are readiness controls, not a BUY score. The final output remains the position-aware action at the top of Decide: BUY / SHORT / WAIT for an unowned name, and HOLD / ADD / SELL / COVER variants for an existing position.
- Retained the V3.1.3 recovery work for Portfolio, Decision Queue, Screener, Management and Validate plus all V3.1.2 numerical-correctness protections.
- Kept borders restrained in both themes and retained the larger company ticker hierarchy.
- Added `by Lose Money Rules` beneath the sidebar version label.

## 3.1.3 — Recovery Release: Portfolio, Decision Flow, Screener, Management & Validate
- Rebuilt Portfolio as an independent real-holdings ledger. Positions can be added or edited before Coverage/research exists; legacy researched positions migrate automatically.
- Replaced the ambiguous Coverage surface with **Decision Queue**, combining researched names and real positions into one worklist.
- Added a position-aware decision path on Decide: **Data → Value → Thesis → Timing → Risk → Action**. Outside positions resolve to BUY / SHORT / WAIT; existing LONG/SHORT positions resolve to HOLD / ADD ON EVIDENCE / REDUCE / SELL / COVER as appropriate.
- Restored Bear/Base/Bull as first-class, always-visible outputs. Unsafe price/share/EPS/corporate-action inputs now show DATA REVIEW with the exact blocker instead of silently hiding scenarios.
- Added explicit Back-to-Parent navigation and grouped Advanced pages beneath Decide, Research, Monitor and Portfolio.
- Fixed Market Screener regression caused by stale pre-3.1.3 cache rows lacking the new share-basis fields. Cache now carries an explicit model version and incompatible rows refresh once without creating a permanent fetch loop.
- Hardened Management accountability parser to v4: target-year selection distinguishes forward target years from comparator years; interim guidance cannot be scored as annual; adjusted/non-GAAP and definition-mismatched FCF stay evidence-only; retrospective filings cannot become MET/MISS; original point-in-time actuals are used.
- Clarified Validate pricing. **Year-end raw close** is the actual as-traded close at +1Y; **Comparable +1Y** rebases it to the anchor share basis for split-safe scenario accuracy. Exact quote dates and basis factor are displayed.
- Removed future-split leakage from historical replay by rebasing each replay to the corporate-action basis known at the anchor date.
- Added recovery regression tests for independent Portfolio, screener cache migration, Management parser traps, split-safe Validate and economic invariance across a 4:1 split.
- Retained V3.1.2 correctness fixes for price/share basis, point-in-time valuation, DCF/FCFE consistency, debt hierarchy, SEC tag migration, live P/E basis and report layout.

## 3.1.2 — Correctness Release: Price/Share Basis, Management Scoring & Valuation Integrity
- Rebuilt price/share-basis handling around explicit **raw price, split-adjusted price, split factor and verification state**. Provider changes can no longer silently change the valuation methodology.
- Corrected Yahoo long-history reconstruction so split-adjusted historical closes are converted back to contemporaneous raw prices exactly once; removed double-split risk.
- Added split-only canonical histories for Alpaca, Tiingo and Alpha Vantage where the provider exposes sufficient corporate-action data; unverified bases fail closed.
- Separated **current shares outstanding**, **weighted-average diluted shares** and **forward diluted shares**. Market cap/EV require verified instant shares outstanding; P/E uses verified GAAP diluted EPS; forward multiple values use forward diluted shares.
- Corrected split-after-last-filing cases by rebasing SEC share/EPS facts to the current price basis before live valuation.
- Reworked historical calibration as true point-in-time: original filing values + contemporaneous raw filing-date price. Later restatements and today's split basis cannot rewrite historical multiples.
- Removed future-split leakage from Validate: every replay is rebased to the corporate-action basis known at the anchor date. Spin-off/non-split corporate-action uncertainty is quarantined from reliability scoring rather than guessed.
- Fixed SEC equivalent-tag migrations so current views can use genuine later restatements while point-in-time replays retain the earliest value actually public.
- Added per-period diluted/basic-share fallback instead of choosing one share tag for an issuer's whole history.
- Added unambiguous share-class handling: multiple materially different instant share facts do not get summed or arbitrarily selected.
- Rebuilt debt extraction hierarchy so short-term borrowings, current long-term debt and non-current debt are combined without omission or double counting; comprehensive total-debt tags are fallback-only.
- Corrected the DCF framework: `CFO - Capex` is treated as a levered/equity cash-flow proxy and no longer has net debt subtracted a second time. The stored `wacc` field remains for compatibility but functions as the equity discount rate in this cross-check.
- Strengthened P/E: live P/E requires SEC-reported diluted EPS on a verified split basis. `Net income / latest share count` is no longer treated as exact EPS in live decision work.
- Added EPS reconciliation diagnostics for convertibles, two-class accounting, buybacks and issuance; material divergence lowers confidence instead of being hidden.
- Fixed growth calculations across missing fiscal years by annualizing over the actual elapsed fiscal-year gap.
- Hardened Management Delivery scoring: target year, annual/interim period, GAAP/non-GAAP basis, metric, units and actual must all be comparable before MET/MISS is assigned. Adjusted EPS, ambiguous multi-metric statements, interim guidance and management-defined FCF remain evidence-only unless equivalence is proven.
- Management actuals are evaluated against the values originally reported for that fiscal year, not later comparative restatements.
- Discovery's absolute fair-value gate now uses the same verified share/price basis rules as the live valuation; unverified share basis becomes DATA REVIEW rather than a false long/short signal.
- Fixed PDF `NEXT ACTION` overflow: narrative KPI cells wrap and rows expand instead of using a fixed-height box.
- Kept report table typography larger while preserving the institutional layout.
- Softened V3.1.1 borders to an intermediate contrast: visible in light/dark mode without looking boxed-in.
- Enlarged company tickers on V3 decision/research/monitor pages and Advanced-page hero headers for much stronger visual orientation.
- Added/expanded regression tests covering forward/reverse split invariance, future-split leakage, market-cap basis, P/E basis, EV/Sales/FCF yield, debt hierarchy, DCF leverage treatment, missing-year annualization, SEC tag migration, Management parser traps and long-history validation.

## 3.1.1 — Discovery Value Gate, Long-History Validate & Visual Hardening
- Removed residual Plotly fallback violet by centralizing a non-purple chart palette and assigning explicit colors to the remaining chart families.
- Added the Discovery absolute fair-value gate so relative peer cheapness/expensiveness alone cannot promote a name into Top Long/Top Short.
- Added Screen Fair Value / FV Gap visibility to Discovery and its PDF brief.
- Extended Validate to request materially longer price history and expose the earliest actually modelable/completed point-in-time replay year.
- Added older-history share-tag fallback and kept split-event auditability in historical replay.
- Increased Word/PDF table typography and visually rechecked dense report pages.
- Increased border contrast in both themes; V3.1.2 subsequently softened these tokens after user review while retaining visibility.

## 3.1.0 — Logic Consolidation, Scenario Transparency & Decision Discipline
- Consolidated the product around **one decision cockpit**: Decide owns the current investment conclusion; Research is now a dedicated **Evidence Room** and no longer repeats the same Price/Base/Value/Expectations charts and cards.
- Added **Bear / Base / Bull — ALL valuation assumptions & outputs** directly on Decide. The table shows every fair-value input (probability, growth, operating/net/FCF margins, tax, P/E, EV/Sales, target FCF yield, WACC, terminal growth, manual override) plus P/E, EV/Sales, FCF-yield, DCF, P25/P75 and final fair-value outputs side by side.
- Explicitly separated **Valuation Cases** (used for Bear/Base/Bull fair values) from the independent **5Y Operating Forecast Cases** (used for operating-path analysis and price-implied expectations).
- Rebuilt **Expectations** as a three-driver lens: price-implied revenue CAGR, year-5 net margin and exit P/E are compared with our Base path. Labels are now FAVORABLE / BALANCED / DEMANDING; one growth estimate can no longer determine the result alone.
- Added **Model Confidence** to Decide. It combines live valuation confidence with company-specific walk-forward Reliability, sample quality and corporate-action basis. LONG READY / SHORT READY now require MODERATE or STRONG model confidence.
- Tightened **Risk**. CONTROLLED now requires LOCKED numerical thesis invalidation rules plus an explicit sizing plan; large Bear downside, leverage, concentration and audit failures can keep Risk HIGH / UNRESOLVED / DATA REVIEW.
- Clarified invalidation semantics: the Risk-page `invalidation_price` field is now labeled **Sizing reference price** and is used only for position-size loss math. Thesis invalidation is driven by LOCKED numerical Monitoring KPIs and preserved in the Decision Journal.
- Added **Asymmetry & Position Math** to Decide: Bear downside, Base upside, Bull upside, expected-value gap, suggested size and invalidation lock status.
- Made `variant_case` the canonical market-vs-us disagreement. Advanced Thesis & Bear Case shows the canonical disagreement read-only and preserves legacy fields only for database compatibility.
- Investment Gates now use the canonical Variant record and multi-driver price reconciliation when available.
- Removed duplicate configuration controls from Advanced Sources & Audit. **Settings** is now the single configuration surface; Sources & Audit is provenance, revisions, source log, freshness and backup.
- Renamed Discovery table scores to **Long Dislocation / Short Dislocation** to distinguish screening scores from company-level opportunity/decision logic.
- Fixed a real display bug on Decide where Bear probability looked up a non-existent `assumptions.probabilities` object; probabilities now read from each actual Bear/Base/Bull case.
- Updated user guidance and removed the stray Reliability Rules placeholder.
- Retains all V3.0.9 split-safe historical validation, reliability persistence, dark-mode border and zero-purple fixes.

## 3.0.9 — Historical Reliability, Split-Safe Validation & Zero-Purple Navigation
- Added a **company-specific Reliability Score (0–100)** to Validate, decomposed into Valuation Reliability, Thesis Reliability, Direction Reliability and Bias Control.
- Reliability is deliberately **sample-adjusted**: fewer than 3 completed walk-forwards is labeled LOW SAMPLE and full sample credit is reached at 6 completed annual tests.
- Persisted the latest validation result per ticker in SQLite so **Decision** can show the historical reliability of the current model/company pair without rerunning the page every time.
- Added explicit historical bias classification: BALANCED / OVERPREDICTS / UNDERPREDICTS.
- Fixed a material backtest unit-risk around **stock splits**. Validate now uses contemporaneous raw Alpaca prices for the historical model and a raw-vs-split adjustment factor to translate the future outcome price back to the anchor-year share basis before scoring Bear/Base/Bull.
- Added **Corporate-action basis VERIFIED / UNVERIFIED** status. Fallback-provider validations remain available but are marked for review when split normalization cannot be independently verified.
- Added raw +1Y market price and share-basis normalization factor to the replay table for auditability.
- Hard-locked Streamlit/BaseWeb menu, selected, hover, focus, primary-button, option, checkbox and radio accents to institutional blue `#3F78A8`; removed dependency on framework fallback colors.
- Standardized Advanced-page cyan accents to the same institutional blue.
- Retained the V3.0.8 point-in-time anti-look-ahead boundary and all V3.0.7 dark-border / Discovery color fixes.
- No change to the live current-company valuation formula, Discovery scoring, portfolio sizing, tape scoring or decision gates.

## 3.0.8 — Point-in-Time Walk-Forward Validation
- Added a new **Validate** workspace to test whether the current model's historical price targets and operating thesis would have held up using only information available at the time.
- Replays the current valuation engine at each calendar year-end and scores the resulting Bear / Base / Bull values against the realized market price one year later.
- Added strict anti-look-ahead filtering of SEC Companyfacts by original filing date. Later filings, amendments and comparative restatements are excluded from earlier cutoffs.
- Historical replays deliberately ignore today's saved valuation assumptions and manual thesis text to avoid hindsight contamination.
- Added operating-thesis validation: realized +1Y revenue growth, net margin and FCF margin are checked against the Bear/Bull assumption bands generated at the historical anchor.
- Added range-hit rate, direction-hit rate, median Base target error, target bias, thesis-driver hit rate, thesis-supported rate and a naive **no-change price** baseline.
- Added year-by-year target-vs-actual chart, detailed replay table and CSV export.
- Added an embedded anti-leakage regression test proving that a later restatement cannot enter an earlier historical cutoff.
- Validation is explicitly a replay of today's model rules on old information; it is evidence about historical calibration, not a guarantee of future accuracy.
- Retained the V3.0.7 visual hotfixes: Discovery Top Long/Top Short use institutional blue and dark-mode borders remain high-contrast.
- No change to live Discovery scoring, portfolio sizing, provider routing, current valuation mathematics, reports, tape or decision gates outside the new validation workspace.

## 3.0.5 — Institutional Design & Branding
- Reworked the V3 visual system into a restrained institutional research-workstation style with true bordered containers, stronger hierarchy and denser-but-readable spacing.
- Removed purple from the application/report palette; neutral market prices use normal white/dark text while green/red/amber are reserved for positive/negative/mixed states.
- Removed the two legacy interface taglines from application and report surfaces.
- Added local custom-logo upload/remove controls in Settings. The logo can appear in the app sidebar and generated reports; no logo is required.
- Standardized the application/report footer to the single line `Lose Money Rules`.
- Rebuilt Word and PDF equity-research reports around four readable institutional pages with larger metric values, larger table text and less column compression.
- Rebuilt the Discovery PDF as a two-page landscape screening brief for substantially more readable long/short candidate tables.
- Fixed a DOCX pagination edge case that could insert a blank page between Management & Forecast and Market Evidence.
- Preserved V3.0.4 navigation safety and all valuation, Discovery, provider-routing, tape, forecast and decision-model logic.

## 3.0.4 — Navigation Path Hotfix
- Fixed Streamlit startup failure caused by duplicate inferred URL pathname `portfolio`.
- Assigned explicit, unique `advanced-*` URL pathnames to every hidden Advanced page.
- Added a navigation-regression test that parses the page registry and fails on duplicate pathnames before launch.
- No changes to valuation, Discovery scoring, data-provider routing, reports, tape, forecast, or decision logic.

## 3.0.3 — Data Resilience, Price Validation & Terminal Polish
- Added market-data router for daily prices/bars: Alpaca → optional IBKR Client Portal Gateway → Tiingo → Alpha Vantage → last-good SQLite cache.
- Added full-tape fallback: Alpaca trades/NBBO → optional Massive trades/NBBO; if neither is available, Tape explicitly degrades to LOW DATA.
- Added Discovery-universe fallback from Alpaca active assets to the official SEC ticker/exchange mapping.
- Added independent price cross-check persisted in SQLite with PASS / WARN / FAIL / LOW DATA, provider, timestamp, quality, comparable flag and deviation.
- Price checks avoid hard FAILs during potentially partial US sessions when source timing is mixed.
- Added Settings UI for provider resilience, IBKR Gateway, local backup API keys and price-check thresholds.
- Added persistent collapsed-sidebar icon rail for one-click navigation.
- Strengthened card/panel borders and tone accents. Neutral Price / Bear / Base / Bull values use normal theme text; positive is green, negative red, mixed/uncertain yellow.
- Split Word and PDF research-report preparation/download into independent controls.
- Added printable two-page Discovery Brief PDF with long and short/trap maps, candidate tables and review context.
- Data Audit now includes independent price-check status and generic provider provenance instead of assuming Alpaca is always the market source.
- Cache-only market fallback does not falsely refresh market-data freshness; partial provider failures remain visible as PARTIAL.

## 3.0.2 — Visual Balance & Information Density
- Rebalanced V3 progressive disclosure: important decision data is visible by default; technical detail remains expandable.
- Decide now shows Price / Bear / Base / Bull, valuation range chart, operating trend chart, six decision lenses, operating snapshot, forensic positives/challenges/data alerts, expectations gap, freshness and process readiness without requiring expanders.
- Research now has a visible price/value/business/tape cockpit plus price and operating-trend charts before the deeper evidence sections.
- Discovery adds visual top-long and top-short dislocation charts while retaining detailed tables.
- Coverage adds visible Top Priorities cards with price, Base value and valuation gap.
- Settings restores core configuration inline: Alpaca feed, flow sessions, trade-notional floor, number units, SEC User-Agent, NAV, management filing depth, plus Discovery settings and current-company data health.
- Sources/Audit remains available as Advanced detail for provenance, SEC tags/revisions, source logs and backups.
- No change to valuation, Discovery scoring, forecast, forensic, management-accountability or decision-engine mathematics.

## 3.0.1 — Settings Bounds Hotfix
- Fixed V3 Settings startup failure: `Liquid universe size` could receive persisted/test value `10` while the widget minimum is `100`.
- Added central `normalize_settings()` guardrail so legacy or malformed settings are clamped/sanitized before any Streamlit widget is created.
- Protected bounded settings including Discovery universe size, SEC cache days, flow sessions, management filing scan, NAV and non-negative Discovery filters.
- Added regression test that deliberately saves the old invalid value (`discovery_max_symbols=10`) and verifies it normalizes safely to `100`.
- No changes to Discovery scoring, valuation, triangulation, forecasts, forensic logic, or investment decisions.


## 3.0.0 — Discovery, Triangulation & Progressive Disclosure

### Major architecture
- Replaced the technical-first workflow with seven visible areas: Discover, Coverage, Decide, Research, Monitor, Portfolio, Settings.
- Detailed V2.7.1 pages remain available as hidden Advanced detail pages.
- New conclusion -> evidence -> detail interaction hierarchy.

### Discovery
- Added background US-equity market scan using Alpaca active assets + batch snapshots + cached SEC fundamentals.
- Added price/liquidity prefilter and configurable liquid-universe size.
- Added peer-relative scoring by SIC with global blending.
- Added separate Quality, Trend, Forensic, Valuation, Long Opportunity, Short Opportunity and Confidence outputs.
- Added discovery lenses for long dislocations, short dislocations, value traps and forensic divergences.
- Main Discovery lists now hide NO EDGE, DATA REVIEW and context-only names from the primary long/short queues.
- Promotion to Coverage launches the existing deep-refresh engine.

### External triangulation
- Added automatic SIC peer candidates with market-cap similarity tie-breaker.
- Added manual PEER / CUSTOMER / SUPPLIER / DISTRIBUTOR / INDUSTRY links.
- Added peer-median comparison and company-specific / industry-wide signals.

### Variant / catalyst path
- Added dedicated variant_case storage for Market Believes / We Believe / evidence / resolution signal / horizon / path status.
- Decide page makes disagreement and path central to the investment conclusion.

### Simplification
- Coverage collapses no-edge/middle names.
- Decide shows Business / Value / Expectations / Variant / Path / Risk / Decision before any technical detail.
- Research uses expandable evidence containers and links to advanced pages only when needed.
- Monitor focuses on thesis KPI exceptions and changes rather than every metric.

### Reliability
- Preserved all V2.7.1 valuation, forensic, management, forecast, refresh, audit and report engines.
- Removed obsolete unregistered V2 Coverage and Command Center page files.
- Added V3 synthetic Discovery/triangulation/variant tests and mocked end-to-end market scan.
- Added migration test coverage for older database schemas.
- Added conservative SEC pacing for the Discovery scan.
- Research dossier now includes variant case, peer links and Discovery state.
