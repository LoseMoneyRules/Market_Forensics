# Market Forensics V3.1.12 — Data Sources & Interpretation Rules

## Alpaca
Used for:
- active US-equity asset universe
- multi-symbol market snapshots for Discovery
- historical daily bars
- trade/quote flow analysis

Discovery uses previous full-session dollar volume when available to avoid ranking liquidity from an incomplete intraday session.

Feed quality remains explicit. SIP is preferred when available; AUTO can fall back to IEX.

## SEC EDGAR / XBRL
Used for:
- ticker/CIK mapping
- Companyfacts/XBRL fundamentals
- submissions metadata including SIC
- filing history / management-accountability evidence

V3 caches Discovery fundamentals so a normal market rescan does not redownload every issuer. Deep Refresh forces current fundamentals.

The application deliberately paces SEC requests below the public fair-access ceiling. A truthful SEC User-Agent with contact email is required.

XBRL remains issuer-specific. Missing/ambiguous facts must produce missing data or Data Review, never fabricated zeroes.

For **Financial Flows**, V3.1.12 uses an additional conservative annual resolver: a duration fact is accepted only when the freshest annual filing has one unique value or one unique framed consolidated value. This prevents a segment/geography/tax-note component from being mistaken for the consolidated income-statement line. The Sankey is adaptive: Gross Profit, Operating Income, Pretax and Tax are optional presentation layers and are omitted when unavailable or non-reconciling. Any arithmetic bridge is exact, labelled as aggregate/reconciliation, and visualization-only; it never replaces the reported core metric used by Valuation or Validate.

## FINRA
Used in deep company research for Daily Short Sale Volume and manually/officially sourced Short Interest. Discovery does not run FINRA/tape analysis across the entire market universe because that would make the screening layer unnecessarily expensive.

## Discovery vs deep research
Discovery is intentionally lighter than company research.

Discovery asks:
"Is there a price/economics disagreement worth spending time on?"

Deep research asks:
"Does the disagreement survive business, valuation, management, triangulation, tape, bear-case, risk and monitoring review?"

A Discovery score therefore must never be treated as a trade recommendation.

## Peer triangulation
Automatic peers are generated from cached SEC SIC classification and market-cap proximity. SIC can be coarse or stale, so important peers must be reviewed by the analyst.

Manual relationship links are first-class evidence and can classify a ticker as PEER, CUSTOMER, SUPPLIER, DISTRIBUTOR or INDUSTRY.

## Derived/model values
The following are model/derived outputs, not reported facts:
- Long Dislocation / Short Dislocation
- Discovery lens and priority
- Business/Value/Expectations/Variant/Path/Risk summaries
- Bear/Base/Bull fair values
- valuation confidence
- forensic signals
- management delivery score
- price-reconciliation implied expectations
- triangulation score

Always drill into provenance and assumptions before committing capital.

## V3 provider resilience

### Daily price / OHLCV router
- **Alpaca** — preferred primary market-data connection.
- **IBKR Client Portal Gateway** — optional fallback. Requires an authenticated local Gateway session plus the user's market-data entitlements.
- **Tiingo** — optional independent EOD/reference-price fallback when a local API key is configured.
- **Alpha Vantage** — optional final external daily/reference fallback when a local API key is configured.
- **SQLite last-good cache** — final continuity layer. Cached prices are always subject to freshness warnings.

### Tape router
- **Alpaca SIP/IEX trades + quotes** first.
- **Massive trades + NBBO quotes** as an optional independent tick-level fallback when configured.
- If neither provider supplies usable tick/quote data, the tape engine returns LOW DATA. It does not infer buyer/seller aggression from daily bars.

### TradingView / StockAnalysis
They are intentionally not core data backends. Market Forensics requires a documented provider/API contract for production data retrieval rather than fragile website scraping. TradingView is useful as a charting/front-end ecosystem, not as the application's market-data source.

### SEC / FINRA
No inferior third-party replacement is inserted ahead of these official sources. Live failure falls back to the locally stored last-good observations and a visible freshness/data-quality warning.

## Independent price cross-check
Price validation is evidence, not a new fair-value model. When two or more comparable sources are available, Market Forensics calculates dispersion around a consensus reference and stores the result in `price_checks`.

- **PASS** — independent comparable prices agree within the configured WARN threshold.
- **WARN** — moderate dispersion, mixed timing, or a potentially partial US session.
- **FAIL** — comparable same-trading-date prices disagree beyond the configured FAIL threshold.
- **LOW DATA / NO DATA** — too few independent comparable sources.

Corporate actions, timestamp differences and entitlement/feed scope must be reviewed before treating a discrepancy as a bad print.
## Historical validation / point-in-time replay
The Validate page uses two source classes:

1. **SEC Companyfacts** — the current payload is treated as a filing archive, but every individual observation is filtered by its `filed` date before a historical model run. Facts without a filing date are excluded from the PIT model.
2. **Historical daily prices** — requested with a long lookback. Validate first tries the configured primary history on a raw + split-normalized basis. If that history does not reach the requested anchor, a best-effort long-history Yahoo Chart fallback can provide **raw OHLC plus explicit split events** for Validate only. It is not used for live price, Discovery or trading decisions. Only bars on or before the historical anchor are visible to the model; later bars are reserved for outcome scoring.

The engine requests up to roughly 40 years of price history, but the earliest valid replay is normally constrained by issuer-specific SEC Companyfacts/XBRL filing-date coverage. V3.1.8 can fall back from diluted to basic weighted-average shares for older periods. Missing point-in-time fundamentals are never filled with future observations.

The PIT engine is not a commercial vintage database. The important control is that later SEC filing observations are not allowed to contaminate an earlier cutoff.



### V3.1.8 corporate-action normalization
When Alpaca is connected, Validate fetches two views of the same daily history: `adjustment=raw` and `adjustment=split`. Raw quotes are the historical model input because they are on the same contemporaneous share basis as SEC-reported diluted shares. The split-adjusted series is not used as an investment input; it is used only to calculate the corporate-action conversion factor needed to compare a future quote with an old per-share target on a consistent unit basis.

If the Alpaca dual-series cross-check cannot be completed, the long-history fallback is considered **VERIFIED** only when explicit split events are available and parsed into the same cumulative share-basis factor. Other fallback histories are labeled **UNVERIFIED**. An unverified historical result remains inspectable but should not be treated as decision-grade for split-sensitive years without manual review.

### V3.1.8 current shares, filing-level recovery and corporate-action evidence

Current valuation uses a different source discipline from historical replay:

1. **Latest SEC 10-Q/10-K Inline XBRL filing** — preferred current outstanding-share source. Market Forensics parses `EntityCommonStockSharesOutstanding` from the filing itself because dimensional class facts may be absent from Companyfacts. A unique consolidated non-dimensional total is preferred; otherwise a small, unambiguous same-date class set may be summed.
2. **SEC Companyfacts** — general fundamentals and fallback source, and the canonical filing archive for historical/PIT work. It is not allowed to silently substitute a decade-old single-class fact for a complex fresh cover disclosure.
3. **Current corporate-action ledger** — Alpaca Corporate Actions is queried first when credentials are configured, limited to `forward_split` and `reverse_split` between the denominator anchor and current quote date. Yahoo split events are the fallback. A successful empty response is valid `no split` evidence. This ledger verifies the current share unit; it does not claim historical OHLC adjustment semantics.
4. **Verified diluted-share fallback** — if exact current outstanding shares are unavailable or stale but a recent weighted-average diluted denominator plus the corporate-action ledger is usable, Bear/Base/Bull remain visible with **MEDIUM confidence**.
5. **Manual Share Basis Recovery** — final current-only fallback. It is audit logged, labelled `USER VERIFIED / MEDIUM`, and excluded from Validate/historical calibration.

A stale instant outstanding-share fact is never made current solely by multiplying through known splits. Corporate-action normalization cannot correct intervening repurchases, issuance, conversions or other economic share-count changes.

### SEC Companyfacts N/A for fund/ETF structures

A Companyfacts HTTP 404 is suppressed only when SEC metadata also identifies a fund/ETF or unit-investment structure. This avoids repeated false scan warnings for instruments such as ETF trusts without turning an arbitrary operating-company 404 into a silent success.
