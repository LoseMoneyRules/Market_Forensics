@echo off
setlocal
cd /d "%~dp0"
title Market Forensics V3.1.12 - Install

echo.
echo MARKET FORENSICS V3.1.12 - INSTALL + SELF TEST
echo =========================================
echo.
set "PYEXE="
where py >nul 2>&1
if not errorlevel 1 set "PYEXE=py -3"
if not defined PYEXE (
  where python >nul 2>&1
  if not errorlevel 1 set "PYEXE=python"
)
if not defined PYEXE (
  echo Python 3 was not found.
  echo Install Python 3.11 or newer and enable Add Python to PATH.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Creating local Python environment...
  %PYEXE% -m venv .venv
  if errorlevel 1 goto :fail
)
echo Installing/updating dependencies...
".venv\Scripts\python.exe" -m pip install --upgrade pip --disable-pip-version-check
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -m pip install -r requirements.txt --disable-pip-version-check
if errorlevel 1 goto :fail

echo.
echo Running V3.1.12 self-test...
".venv\Scripts\python.exe" SELF_TEST.py
if errorlevel 1 goto :fail

echo.
echo INSTALL + SELF TEST PASSED.
echo Run RUN_DASHBOARD.cmd to open Market Forensics V3.1.12.
echo.
pause
exit /b 0

:fail
echo.
echo INSTALL OR SELF TEST FAILED.
echo Copy the visible error text to ChatGPT.
echo Never send alpaca_secrets.json.
pause
exit /b 1
