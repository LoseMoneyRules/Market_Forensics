# Market Forensics V3.1.12 — Architecture

## Product objective
Market Forensics is a local decision workstation for public-equity research. V3 optimizes for **attention allocation and decision quality**, not maximum visible data density.

The interaction hierarchy is:

**CONCLUSION -> EVIDENCE -> DETAIL**

rather than detail first.

## Visible workflow

### 1. Discover
Market-wide screening layer. Uses a liquid US-equity universe, batch market snapshots and cached SEC fundamentals. It surfaces material dislocations and suppresses the middle.

### 2. Coverage
Only companies that deserve follow-up. Shows freshness, high-level decision state and next action. Middle/no-edge names are collapsed.

### 3. Decide
The single decision cockpit. It reduces the research state to:
- Business
- Value
- Expectations (three price-implied drivers)
- Model Confidence (live valuation confidence + historical Reliability)
- Variant
- Path
- Risk
- Decision

It also exposes Asymmetry & Position Math and a complete Bear/Base/Bull valuation-case table. Then it explains Why now, Why not yet, What changes the decision, and What kills the thesis.

### 4. Research
Evidence Room with seven expandable evidence groups. It deliberately does not duplicate the Decide cockpit. Deep analytical pages remain available as Advanced detail.

**Financial Flows** is a Research detail page, not a valuation engine. V3.1.12 uses an adaptive statement path: Revenue and Net Income/Loss are the essential Income Statement anchors, while Gross Profit, Operating Income, Pretax and Tax are optional presentation layers. CFO is the essential Cash Flow anchor; NI/Capex/FCF are optional layers. Missing optional subtotals are bypassed with explicitly labelled arithmetic reconciliation buckets rather than blocking the page or inventing line-item composition. The separate `flow_operating_income` bridge remains visualization-only and is isolated from core valuation/Validate metrics.

### 5. Monitor
What changed, open thesis KPI exceptions and next event.

### 6. Validate
Point-in-time walk-forward replay. It measures company-specific historical valuation/thesis/direction reliability without future leakage.

### 7. Portfolio
Active positions and decision/risk state.

### 8. Settings
The single configuration surface for providers, SEC identity, NAV, Discovery, resilience and branding. Advanced Sources & Audit is provenance/audit only.


## V3.1.8 — Logic consolidation and source-of-truth rules
- **Decide owns the conclusion. Research owns the evidence.** Research cannot become a second cockpit.
- **Variant perception:** `variant_case` is canonical (`market_belief`, `our_belief`, evidence, resolution signal, horizon, path). Legacy research narrative fields are compatibility fallback only.
- **Thesis invalidation:** LOCKED numerical Monitoring KPI thresholds are canonical. Narrative invalidation explains them. The Risk-page price field is only a **sizing reference price**.
- **Configuration:** Settings is canonical. Sources & Audit contains provenance, revisions, source logs, freshness and backup/export.
- **Valuation Cases vs Operating Forecast Cases:** the former generate Bear/Base/Bull fair values; the latter model the five-year operating path and reverse expectations. They are intentionally separate and labeled as such.
- **Historical Reliability:** never creates LONG/SHORT direction; it caps or strengthens confidence in the current model/company pair. Decision-grade READY requires at least MODERATE Model Confidence.

### Current valuation share-basis pipeline
Current valuation and historical replay intentionally use different evidence contracts. The current path is:

`latest 10-Q/10-K Inline XBRL cover shares → exact denominator anchor → dedicated split/reverse-split ledger → normalized current-basis shares → valuation`

- Filing-level cover shares may replace Companyfacts only in the current TTM/current-valuation view; FY/PIT rows are untouched.
- Alpaca Corporate Actions is the preferred dedicated current ledger when configured; Yahoo split events is fallback.
- A stale old instant share fact is rejected for current market-cap use because splits cannot repair buybacks/dilution. A recent verified diluted-share denominator can be used as an explicit MEDIUM-confidence fallback.
- A saved user override is current-only and loses precedence automatically when a HIGH-confidence automatic current-outstanding basis becomes available.
- Validate never consumes the user override or this relaxed current-only fallback; it retains its strict point-in-time raw-price/corporate-action controls.

## Discovery architecture

### Universe
- Alpaca active US-equity asset master.
- Common listed exchanges only.
- Intersection with SEC ticker/CIK map.
- Minimum price and previous-session dollar-liquidity filters.
- Top liquid universe size configurable (default 600, maximum UI setting 2000).

### Data cadence
Market snapshots update every scan. SEC fundamentals are cached and refreshed only when stale unless Deep Refresh is requested.

### Cross-sectional scoring
Peer-relative ranks prefer exact SIC when the group is sufficiently populated, fall back to 2-digit SIC division, and blend with global rank.

V3.1.8 adds a second, absolute layer. `discovery._screen_value()` builds an automatic screening Base Fair Value from current SEC fundamentals without loading saved analyst assumptions. The relative dislocation score is then blended with this absolute value gap, and the final lens requires directional alignment. Names inside approximately ±10% of screening fair value are suppressed to **NO EDGE** even if they look cheap/expensive versus peers. This prevents a peer-relative ranking from masquerading as absolute valuation edge.

Separate evidence families:
- Quality
- Trend
- Valuation / cheapness
- Forensic health
- Confidence

Separate screening outputs:
- Long Dislocation
- Short Dislocation

These are Discovery prioritization devices, not company-level opportunity scores and not probabilities.

### Primary discovery lenses
Long-oriented:
- QUALITY AT DISCOUNT
- FUNDAMENTAL INFLECTION
- LONG DISLOCATION

Short/trap-oriented:
- POTENTIAL SHORT
- SHORT DISLOCATION
- VALUE TRAP
- FORENSIC DIVERGENCE

Secondary/context:
- DATA REVIEW
- RICH / STRONG BUSINESS
- NO EDGE

Only primary long and short/trap lenses appear in the main action lists.

## External triangulation
Automatic peer selection:
1. exact SIC;
2. 2-digit SIC fallback if necessary;
3. market-cap distance is only a tie-breaker.

Manual relationship links can add:
PEER / CUSTOMER / SUPPLIER / DISTRIBUTOR / INDUSTRY.

Triangulation compares growth, margins, ROIC, working capital, dilution and valuation versus peer medians. It can identify company-specific vs industry-wide evidence when the data supports the inference.

## Variant perception
Stored independently in `variant_case`:
- market_belief
- our_belief
- disagreement_evidence
- resolution_signal
- resolution_horizon
- path_status

This is intentionally separate from generic research notes so that disagreement and resolution path remain explicit.

## Persistence
New V3 SQLite tables:
- discovery_universe
- discovery_runs
- peer_links
- variant_case

Existing V2.7.1 tables and history are preserved.

## Background work
- Coverage refresh jobs remain persistent through `refresh_batches` / `refresh_batch_items`.
- Discovery scans run in a separate daemon thread and persist state in `discovery_runs`.
- Stale RUNNING/QUEUED jobs are marked INTERRUPTED after app/server restart.

## Data-source discipline
- SEC is rate-limited deliberately below its public fair-access ceiling.
- Discovery tolerates a single issuer with unusual XBRL without aborting the market scan.
- Low-data names are not promoted as directional opportunities.
- Data Review and valuation-regime warnings take precedence over attractive model outputs.

## Advanced pages retained
V3 does not discard the detailed V2.7.1 engines. Fundamentals, Management/Forecast, Valuation, Tape, Monitoring, Thesis/Bear Case, Risk/Journal, Portfolio and Sources/Audit are registered as hidden pages and opened only when requested.

## V3.1.8 — Institutional visual hierarchy
V3.1.8 keeps the decision-first workflow while moving the presentation to an institutional research-workstation standard: bordered content blocks, stronger typography, neutral prices, and semantic green/red/amber status accents.
The display contract is:

1. **Conclusion** — decision, price and valuation range.
2. **Visible evidence** — charts, operating snapshot, forensic evidence, expectations and freshness.
3. **Technical detail** — peer tables, process gates, model inputs, XBRL provenance and source logs.

Important evidence must never require opening an expander merely to understand the current investment case.

## V3 — Data resilience layer
Market data is routed by capability rather than hard-coded to one provider.

### Daily prices and bars
1. Alpaca (preferred)
2. IBKR Client Portal Gateway, when explicitly enabled and authenticated
3. Tiingo, when a local API key exists
4. Alpha Vantage, when a local API key exists
5. Last-good SQLite daily bars

The router returns the provider label with the data. Fallbacks are therefore visible and auditable rather than silent.

### Tape / microstructure
1. Alpaca trades + quotes
2. Massive tick trades + NBBO quotes, when configured
3. LOW DATA

Daily OHLCV is not used to fabricate institutional-flow or absorption metrics.

### Discovery universe
1. Alpaca active US assets
2. SEC ticker/exchange map

Discovery batch snapshots prefer Alpaca and can fall back to Tiingo EOD/reference data when configured. Deep SEC fundamentals remain cached separately.

### Official-source resilience
SEC and FINRA remain authoritative. Their fallback is the local last-good database plus explicit freshness warnings; Market Forensics does not replace them with a lower-quality aggregator merely to avoid a missing live request.

### Price validation
Each full company refresh can compare the model-input price with independently configured providers. The stored check includes source, price, as-of timestamp/date, quality, deviation and overall PASS/WARN/FAIL state. Trading-date mismatches are excluded from hard comparisons. During a potentially partial US session, a large dispersion is WARN rather than automatic FAIL because source timestamps may not be synchronized.
## V3.1.8 — Point-in-time validation architecture
`market_forensics/backtest.py` is intentionally isolated from the live decision state. It fetches one current SEC Companyfacts payload and a long daily-price history, then reconstructs historical information sets by filtering every SEC fact observation to `filed <= cutoff`.

The replay never loads `valuation_assumptions` from SQLite. For every historical year-end it regenerates automatic assumptions from the filtered fundamentals plus price history truncated to the same cutoff. The future +1Y price and future fundamentals are used only by the scoring phase.

Core outputs per anchor:
- historical anchor price and last filing actually available;
- Bear / Base / Bull target and model call;
- realized +1Y price, range hit, Base error and direction hit;
- realized revenue growth / net margin / FCF margin;
- individual operating-driver hits and aggregate thesis status;
- comparison with a naive no-change-price baseline.

`pages/05_validate_v3.py` exposes the workflow through the V3 shell. Results are held in Streamlit session state and can be downloaded as CSV. The anti-leakage test is deterministic and also wired into `SELF_TEST.py`.



## V3.1.8 — Reliability score and corporate-action-safe replay
`backtest.summarize()` now produces a per-company composite Reliability Score. The four lenses are valuation accuracy, operating-thesis accuracy, directional accuracy and systematic bias. The aggregate is sample-adjusted so short histories cannot receive the same confidence as mature six-plus-year histories.

Completed validation payloads are stored in the `validation_runs` SQLite table. `db.latest_validation_result()` exposes the most recent ticker result to the Decision workspace without coupling historical validation to the live valuation state.

For Alpaca-backed validation, `marketdata.get_validation_daily_bars()` fetches raw and split-adjusted daily histories. Historical modeling uses raw quotes; the split-adjusted series supplies only a share-basis conversion factor. If the primary provider is too short, Validate can fall back to long-history raw Yahoo Chart bars plus explicit split events, only for the historical replay. `backtest._comparable_outcome_price()` normalizes the +1Y outcome back to the anchor share basis. The process avoids split-unit errors while keeping future fundamentals outside the historical information set.

Validate requests up to roughly 40 years of prices and exposes the earliest price year, earliest modelable anchor and earliest completed replay. The point-in-time boundary is still set by actual SEC filing-date coverage; older periods are not synthesized from later filings.

UI accent states are hard-locked to `#3F78A8` in both V3 and Advanced shells to prevent Streamlit/BaseWeb fallback purple.
